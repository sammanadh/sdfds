# Hana

Source code for the Hana mobile app.

## Requirements

- Node.js >= 14.x
- Xcode
- Android Studio

## Setup

Install all required dependencies with:

```shell
yarn install
(cd ios && pod install)
```

## Environment

You'll need to create a _.env.example_ file at the project root with all the required environment variables. You can find the required environment variables in _[.env.example](./.env.example)_.

## Development

### iOS

To run on iOS you need to use Xcode.

1. Open Xcode and load the project in _[ios/](./ios/)_
1. In the top bar, choose "Hana (Debug)" scheme (not "Hana (Release)")
1. Choose a device or simulator
1. Press the Play button, or Product menu > Run

### Android

You'll need to setup Android Studio, and a virtual device using Tools menu > Device Manager.

Then you can run it from the command-line:

```shell
yarn android
```

## Build

### iOS

1. In Xcode, setup your developer account under Signing & Capabilities > Signing > Team. Apple will manage signing & deployment certificates
1. Check the release version and bump if necessary under General > Identity > Version, and Build
1. In the top bar, choose "Hana (Release)" scheme (not "Hana (Debug)")
1. Choose "Any iOS Device (arm64)"
1. Start the build Product menu > Archive
1. Once the build has completed, the Organizer window will appear and show the most recent build as well as previous builds. You can access the Organizer at any time by going to Window menu > Organizer.
1. From the Organizer window, choose the build you want to test with and click Distribute App
1. If you choose "App Store Connect", you'll need to visit [App Store Connect](https://appstoreconnect.apple.com/) to finish adding the build to a testing channel after it has finished uploading

### Android

#### Upload key

You'll need to generate or obtain an upload key. For testing, generating your own key is fine, for Play Store release you'll need to use the team's upload key.

You can generate a key for yourself with this command:

```shell
keytool -genkey -v -keystore hana-upload-key.keystore -alias com.HanaWallet.App -keyalg RSA -keysize 2048 -validity 10000
```

After you have an upload key, move it to _[android/app/](./android/app/)_, and make sure the variables in _[android/gradle.properties](./android/gradle.properties)_ reflect the right key file name, alias and passwords:

```shell
MYAPP_UPLOAD_STORE_FILE=hana-upload-key.keystore
MYAPP_UPLOAD_KEY_ALIAS=com.HanaWallet.App
MYAPP_UPLOAD_STORE_PASSWORD=your_upload_store_password
MYAPP_UPLOAD_KEY_PASSWORD=youre_upload_key_password
```

#### Create the signed bundle (.aab)

With your upload key setup, you can create the signed bundle. Bundle files are preferred when uploading for release via the Play Store

```shell
cd android
./gradlew clean
./gradlew bundleRelease
```

If you want to build a signed package file (.apk) which is easier to directly load on a device for testing:

```shell
cd android
./gradlew clean
./gradlew assembleRelease
```

After the build completes, the signed bundle or package can be found under _[android/app/build/outputs/](./android/app/build/outputs/)_
