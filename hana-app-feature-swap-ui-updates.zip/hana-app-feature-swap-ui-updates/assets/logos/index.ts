import LogoHanaDarkHome from './logo-hana-dark-home.svg';
import LogoHanaDarkText from './logo-hana-dark-text.svg';
import LogoHanaDark from './logo-hana-dark.svg';
import LogoHanaLightText from './logo-hana-light-text.svg';
import LogoHanaLight from './logo-hana-light.svg';
import LogoHanaNewLight from './logo-hana-new-light.svg';
import LogoHana from './logo-hana-new.svg';
import LogoHanaOnboarding from './logo-hana-onboarding.svg';
import LogoReceive from './logo-receive.svg';
import LogoSend from './logo-send.svg';

export {
  LogoHanaLightText,
  LogoHanaDarkText,
  LogoHana,
  LogoHanaOnboarding,
  LogoHanaLight,
  LogoSend,
  LogoHanaDark,
  LogoHanaDarkHome,
  LogoReceive,
  LogoHanaNewLight,
};
