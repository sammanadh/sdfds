import Frame from './frame.svg';

export { Frame };
