import IconAddressBookDark from './address-book-dark.svg';
import IconAddressBook from './address-book.svg';
import ArrowDownWhiteIcon from './arrow-down-white.svg';
import ArrowDownIcon from './arrow-down.svg';
import IconBack from './arrow-left-new.svg';
import IconBackWhite from './arrow-left-white-new.svg';
import IconNextBlack from './arrow-right-black-new.svg';
import IconNextWhite from './arrow-right-white-new.svg';
import IconCaretDown from './caret-down.svg';
import IconChangePassword from './change-password.svg';
import CrossIcon from './circle-xmark.svg';
import IconCloneGray from './clone-gray.svg';
import IconClose from './close.svg';
import CogIconWhite from './cog-white.svg';
import CogIcon from './cog.svg';
import ConfigureChainIcon from './configure-chains.svg';
import IconDarkMode from './dark-mode.svg';
import DocumentTextIconWhite from './document-text-white.svg';
import DocumentTextIcon from './document-text.svg';
import IconDotHorizontalWhite from './dot-horizontal-white.svg';
import IconDotHorizontal from './dot-horizontal.svg';
import DropdownIconWhite from './drop-down-icon-white.svg';
import DropdownIcon from './drop-down-icon.svg';
import Earth from './earth.svg';
import IconEditWhite from './edit-white.svg';
import IconEdit from './edit.svg';
import IconExternalLink from './external-link.svg';
import FileLockIcon from './file-lock.svg';
import IconAuthorizedDappMock from './icon-authorized-dapp-mock.svg';
import IconMenuWhite from './icon-menu-white-new.svg';
import IconTick from './icon-tick.svg';
import IconWarning from './icon-warning.svg';
import IconInfoCircle from './info-circle.svg';
import KeyLockIconWhite from './key-lock-white.svg';
import KeysIconWhite from './keys-white.svg';
import KeysIcon from './keys.svg';
import LedgerIcon from './ledger-icon.svg';
import IconLightMode from './light-mode.svg';
import LockWhiteIcon from './lock-white.svg';
import LockIcon from './lock.svg';
import IconManageToken from './manage-token.svg';
import IconManageTokensDark from './manage-tokens-dark.svg';
import IconManageTokens from './manage-tokens.svg';
import IconManageWalletDark from './manage-wallet-dark.svg';
import IconManageWallet from './manage-wallet.svg';
import IconMinus from './minus-icon.svg';
import IconMinusWhite from './minus-white-icon.svg';
import IconNetwork from './network.svg';
import PadlockIconWhite from './padlock-white.svg';
import PadlockIcon from './padlock.svg';
import IconAddBoldBlack from './plus-bold.svg';
import IconAddWhite from './plus-dark-mode.svg';
import IconPlus from './plus-icon.svg';
import PlusIconBoldWhite from './plus-white-bold.svg';
import IconPlusWhite from './plus-white-icon.svg';
import PlusIconWhite from './plus-white.svg';
import { default as IconAddBlack, default as PlusIcon } from './plus.svg';
import QuestionIconWhite from './question-white.svg';
import QuestionIcon from './question.svg';
import IconResetHana from './reset-hana.svg';
import RightArrowIconWhite from './right-arrow-white.svg';
import RightArrowIcon from './right-arrow.svg';
import SearchIconWhite from './search-white.svg';
import SearchIcon from './search.svg';
import SeedingIcon from './seeding.svg';
import SConfigureChainIcon from './settings-configure-chains.svg';
import DAppsIcon from './settings-dapps.svg';
import ManageWalletIconWhite from './settings-manage-wallet-white.svg';
import ManageWalletIcon from './settings-manage-wallet.svg';
import Slider from './sliders.svg';
import IconTwitter from './social-twitter-new.svg';
import IconWeb from './social-web-new.svg';
import UploadIconWhite from './upload-white.svg';
import UploadIcon from './upload.svg';
import IconCloseWhite from './x-icon-white.svg';
import IconArrowBidirectionalBlack from './arrow-bidirectional-black.svg';
import IconArrowBidirectionalLight from './arrow-bidirectional-light.svg';

export {
  PlusIconBoldWhite,
  IconAddBoldBlack,
  LockIcon,
  LockWhiteIcon,
  IconCaretDown,
  IconInfoCircle,
  IconEdit,
  IconNetwork,
  IconEditWhite,
  IconWarning,
  IconBack,
  IconNextWhite,
  IconTick,
  IconClose,
  IconMinus,
  IconPlus,
  IconNextBlack,
  IconBackWhite,
  IconMenuWhite,
  IconDotHorizontal,
  IconManageToken,
  IconAddBlack,
  IconManageWallet,
  IconManageWalletDark,
  IconManageTokens,
  IconManageTokensDark,
  IconResetHana,
  IconChangePassword,
  IconAddressBook,
  IconAddressBookDark,
  ConfigureChainIcon,
  SConfigureChainIcon,
  DAppsIcon,
  IconAuthorizedDappMock,
  IconCloseWhite,
  ArrowDownWhiteIcon,
  ArrowDownIcon,
  CogIcon,
  PadlockIcon,
  QuestionIcon,
  PlusIcon,
  CogIconWhite,
  PadlockIconWhite,
  PlusIconWhite,
  QuestionIconWhite,
  IconAddWhite,
  IconTwitter,
  IconWeb,
  SearchIconWhite,
  SearchIcon,
  IconDotHorizontalWhite,
  IconPlusWhite,
  IconMinusWhite,
  ManageWalletIcon,
  ManageWalletIconWhite,
  DocumentTextIcon,
  KeysIcon,
  RightArrowIcon,
  DocumentTextIconWhite,
  KeysIconWhite,
  RightArrowIconWhite,
  UploadIcon,
  UploadIconWhite,
  KeyLockIconWhite,
  DropdownIcon,
  DropdownIconWhite,
  FileLockIcon,
  SeedingIcon,
  LedgerIcon,
  IconExternalLink,
  IconLightMode,
  IconDarkMode,
  Slider,
  IconCloneGray,
  CrossIcon,
  Earth,
  IconArrowBidirectionalBlack,
  IconArrowBidirectionalLight
};
