#!/bin/bash

yarn install
npx react-native setup-ios-permissions
cd ios
pod install
cd ..
