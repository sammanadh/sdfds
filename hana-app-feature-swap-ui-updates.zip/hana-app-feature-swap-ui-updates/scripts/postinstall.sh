#!/bin/bash

# Husky
./node_modules/.bin/husky install

# RN Nodeify
./node_modules/.bin/rn-nodeify --yarn --install assert,buffer,crypto,events,http,https,os,process,stream,url,fs,path,util --hack

# Jetify
./node_modules/.bin/jetify

# Add patch-package here if required
patch-package