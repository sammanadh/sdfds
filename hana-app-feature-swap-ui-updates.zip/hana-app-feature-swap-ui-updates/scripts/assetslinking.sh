#!/bin/bash

# Symlink injection code scripts so they can be accessed on Android
cd android/app/src/main/assets
ln -s -f ../../../../../src/core/EthereumProvider.js EthereumProvider.js
ln -s -f ../../../../../src/core/IconProvider.js IconProvider.js
ln -s -f ../../../../../src/core/PolkadotProvider.js PolkadotProvider.js
