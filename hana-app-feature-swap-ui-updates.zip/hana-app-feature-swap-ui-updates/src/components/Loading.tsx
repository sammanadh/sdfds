import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import React from 'react';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';

interface Props {
  height: number | string;
  width: number | string;
}

const Loading = ({ height, width }: Props) => {
  const { isDarkMode } = useTheme();
  const primaryColor = isDarkMode ? colors.black : '#eeeeee';
  const secondaryColor = isDarkMode ? '#4D3F6F' : '#dddddd';

  return (
    <SkeletonPlaceholder backgroundColor={primaryColor} highlightColor={secondaryColor}>
      <SkeletonPlaceholder.Item width={width} height={height} />
    </SkeletonPlaceholder>
  );
};

export default Loading;
