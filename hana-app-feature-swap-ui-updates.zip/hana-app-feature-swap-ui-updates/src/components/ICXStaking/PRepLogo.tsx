import IconBlueCircleLogo from '@/assets/logos/icon-blue-circle.svg';
import { PRep } from '@/models/PRep';
import { isEmpty } from 'lodash-es';
import React, { useMemo, useState } from 'react';
import { Image, StyleProp, View, ViewStyle } from 'react-native';

interface Props {
  pRep: PRep;
  size?: number;
  style?: StyleProp<ViewStyle>;
}

export function PRepLogo({ pRep, size = 50, style }: Props) {
  const [loadFailed, setLoadFailed] = useState(false);
  const hasLogo = useMemo(() => !isEmpty(pRep.logo) && !loadFailed, [pRep]);

  return (
    <View style={[{ width: size, height: size }, style]}>
      {hasLogo ? (
        <Image
          source={{ uri: `https://images.weserv.nl/?url=${pRep.logo}` }}
          resizeMode="contain"
          onError={() => setLoadFailed(true)}
          style={{
            width: size,
            height: size,
          }}
        />
      ) : (
        <IconBlueCircleLogo />
      )}
    </View>
  );
}
