import { IconCaretDown, IconInfoCircle } from '@/assets/icons';
import { PRepItem } from '@/components/ICXStaking/PRepItem';
import { PRepsLearnMoreModal } from '@/components/Modals/Earn/PRepsLearnMoreModal';
import { ModalTextItem } from '@/components/ModalTextItem';
import { SearchInput } from '@/components/SearchInput';
import { TextButton } from '@/components/TextButton';
import { Text } from '@/components/Typography';
import { PRep } from '@/models/PRep';
import { useIconNetwork } from '@/stores/IconNetwork';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { formatNumber } from '@/utils/format';
import { dismissModal, presentModal } from '@/utils/modal';
import { orderBy, shuffle } from 'lodash-es';
import React from 'react';
import { FlatList, StyleSheet, TouchableOpacity, View } from 'react-native';

interface SortOption {
  label: string;
  sort(pReps: Array<PRep>): Array<PRep>;
  formatMetric(pRep: PRep): string;
}

export const sortOptions: Array<SortOption> = [
  {
    label: 'Random',
    sort: (pReps) => orderBy(shuffle(pReps), ['featured']),
    formatMetric: ({ rank }) => `Rank #${rank}`,
  },
  {
    label: 'Voters',
    sort: (pReps) => orderBy(pReps, ['voters'], ['desc']),
    formatMetric: ({ voters }) => `${formatNumber(voters)} voters`,
  },
  {
    label: 'Rank',
    sort: (pReps) => orderBy(pReps, ['rank']),
    formatMetric: ({ rank }) => `Rank #${rank}`,
  },
];

interface Props {
  onSelectedPRep: (pRep: PRep) => unknown;
  scrollEnabled?: boolean;
}

export function PReps({ onSelectedPRep, scrollEnabled = true }: Props) {
  const { refreshPReps, pReps: allPReps } = useIconNetwork();
  const { isDarkMode } = useTheme();

  const [query, setQuery] = React.useState('');
  const [sort, setSort] = React.useState<SortOption>(sortOptions[0]);

  React.useEffect(() => {
    refreshPReps();
  }, []);

  const onSortPress = React.useMemo(() => {
    return () => {
      presentModal({
        title: 'Sort validators by',
        content: sortOptions.map((option) => (
          <ModalTextItem
            title={option.label}
            isActive={option.label === sort.label}
            onPress={() => {
              setSort(option);

              dismissModal();
            }}
          />
        )),
      });
    };
  }, [sort, isDarkMode]);

  const pReps = React.useMemo(() => {
    const toQuery = query.trim().toLowerCase();
    const filtered = allPReps.filter((pRep) => {
      return (
        pRep.name.toLowerCase().includes(toQuery) ||
        pRep.country.toLowerCase().includes(toQuery) ||
        pRep.city.toLowerCase().includes(toQuery)
      );
    });

    return sort.sort(filtered);
  }, [allPReps, query, sort]);

  function learnMore() {
    presentModal({
      title: 'ICON voting',
      content: <PRepsLearnMoreModal isDarkMode={isDarkMode} />,
    });
  }

  return (
    <>
      <View style={styles.headers}>
        <Text muted style={{ flex: 1, marginRight: 16 }}>
          Vote for validators that are creating value for the ICON ecosystem.
        </Text>
        <TouchableOpacity onPress={learnMore} style={{ marginTop: 3 }}>
          <IconInfoCircle color={isDarkMode ? 'white' : '#16083a'} width={24} height={24} />
        </TouchableOpacity>
      </View>

      <SearchInput
        value={query}
        inputBorderColor="transparent"
        inputFocusBorderColor="transparent"
        onChangeText={setQuery}
        placeholder="Search"
        style={styles.marginTop}
      />

      <View style={styles.sortContainer}>
        <Text style={isDarkMode ? { color: colors.whiteSecond } : {}}>Sort by:</Text>
        <TextButton
          style={{ marginLeft: 5 }}
          bold
          textStyle={{ color: isDarkMode ? 'white' : '#16083a', marginRight: 6 }}
          onPress={onSortPress}
        >
          {sort.label}
        </TextButton>
        <IconCaretDown color={isDarkMode ? 'white' : '#16083a'} width={14} height={14} />
      </View>

      <FlatList
        style={styles.pReps}
        data={pReps}
        scrollEnabled={scrollEnabled}
        renderItem={({ item }) => (
          <PRepItem
            pRep={item}
            style={styles.marginVertical}
            description={sort.formatMetric(item)}
            onPress={() => onSelectedPRep(item)}
          />
        )}
        keyExtractor={(item, index) => String(index)}
      />
    </>
  );
}

const styles = StyleSheet.create({
  headers: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginTop: 30,
  },
  sortContainer: {
    flexDirection: 'row',
    marginTop: 16,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  pReps: {
    marginTop: 10,
  },
  marginTop: { marginTop: 20 },
  marginVertical: { marginVertical: 7 },
});
