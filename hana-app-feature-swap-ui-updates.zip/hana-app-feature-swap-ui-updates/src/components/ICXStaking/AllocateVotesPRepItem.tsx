import { PRepLogo } from '@/components/ICXStaking/PRepLogo';
import { TextInput, TextInputRef } from '@/components/TextInput';
import { Text } from '@/components/Typography';
import { DelegatedPRep } from '@/models/Delegation';
import { useTheme } from '@/stores/Theme';
import { BigNumber, toNumber } from '@/utils/bignumber';
import { ZERO } from '@/utils/constants';
import { colors, fonts } from '@/utils/designTokens';
import { formatAmount } from '@/utils/format';
import { Slider } from '@miblanchard/react-native-slider';
import React from 'react';
import { StyleSheet, View } from 'react-native';

interface Props {
  pRep: DelegatedPRep;
  maxSliderValue: number;
  maxAllowedValue: number;
  onVotesChanged: (votes: number) => unknown;
  availableVotes: BigNumber;
  disabled?: boolean;
}

export function AllocateVotesPRepItem({
  pRep,
  maxSliderValue,
  maxAllowedValue,
  onVotesChanged,
  availableVotes,
  disabled = false,
}: Props) {
  const [votes, setVotes] = React.useState(0);
  const [percentageOfVotes, setPercentageOfVotes] = React.useState(ZERO);
  const [percentageOfVotesInput, setPercentageOfVotesInput] = React.useState('');
  const [inputFocused, setInputFocused] = React.useState(false);
  const { isDarkMode } = useTheme();

  // // This helps to enable limiting slider maximum value
  const [forceUpdateTimestamp, setForceUpdateTimestamp] = React.useState(new Date());

  const maxAllowedPercentage = React.useMemo(() => {
    return new BigNumber(maxAllowedValue)
      .dividedBy(new BigNumber(availableVotes))
      .multipliedBy(100)
      .decimalPlaces(1);
  }, [maxAllowedValue, availableVotes]);

  const inputRef = React.useRef<TextInputRef>(null);

  React.useEffect(() => {
    setPercentageOfVotes(
      availableVotes.gt(ZERO)
        ? pRep.amount.dividedBy(availableVotes).times(100).decimalPlaces(1)
        : ZERO
    );
  }, [pRep, availableVotes]);

  React.useEffect(() => {
    setPercentageOfVotesInput(percentageOfVotes.toString());
  }, [percentageOfVotes]);

  React.useEffect(() => {
    setVotes(toNumber(pRep.amount));
  }, [pRep]);

  return (
    <View style={styles.container}>
      <PRepLogo pRep={pRep} />

      <View style={styles.content}>
        <View style={styles.direction}>
          <View style={styles.flex}>
            <Text large bold>
              {pRep.name}
            </Text>
            <Text bold muted style={styles.description}>
              {formatAmount(pRep.amount)} ICX
            </Text>
          </View>

          <TextInput
            isDarkMode={isDarkMode}
            ref={inputRef}
            editable={!disabled}
            inputStyle={styles.inputStyle}
            styleInputContainer={styles.inputContainer}
            clearButtonMode="never"
            value={inputFocused ? percentageOfVotesInput : `${percentageOfVotes.toString()}%`}
            onFocus={() => {
              setInputFocused(true);
              setForceUpdateTimestamp(new Date());
            }}
            onBlur={() => {
              setInputFocused(false);
              setForceUpdateTimestamp(new Date());

              const percentageOfVotesBN = new BigNumber(percentageOfVotesInput);

              let newVotes;

              if (percentageOfVotesBN.isGreaterThanOrEqualTo(maxAllowedPercentage)) {
                setPercentageOfVotes(maxAllowedPercentage);
                newVotes = toNumber(
                  availableVotes.multipliedBy(maxAllowedPercentage.dividedBy(100))
                );
              } else if (percentageOfVotesBN.isGreaterThanOrEqualTo(0)) {
                setPercentageOfVotes(percentageOfVotesBN);
                newVotes = toNumber(
                  availableVotes.multipliedBy(percentageOfVotesBN.dividedBy(100))
                );
              } else {
                setPercentageOfVotes(ZERO);
                newVotes = 0;
              }

              setVotes(newVotes);
              onVotesChanged(newVotes);
            }}
            onChangeText={(text) => {
              setPercentageOfVotesInput(text);
            }}
          />
        </View>

        <Slider
          value={votes}
          maximumValue={maxSliderValue}
          onValueChange={(value) => {
            const thisValue = (value as any)[0];

            if (thisValue > maxAllowedValue) {
              setVotes(maxAllowedValue);
              onVotesChanged(maxAllowedValue);

              setForceUpdateTimestamp(new Date());
            } else {
              setVotes(thisValue);
              onVotesChanged(thisValue);
            }
          }}
          thumbStyle={styles.sliderThumbStyle}
          maximumTrackTintColor={colors.gray.cards}
          minimumTrackTintColor={colors.primary}
          trackStyle={{
            height: 5,
          }}
          disabled={disabled}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    paddingHorizontal: 0,
    justifyContent: 'center',
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingTop: 23,
    paddingBottom: 15,
  },
  inputStyle: {
    paddingHorizontal: 0,
    textAlign: 'right',
    fontSize: 16,
    lineHeight: 21,
    fontFamily: fonts.heavy,
  },
  flex: { flex: 1 },
  direction: {
    flexDirection: 'row',
  },
  content: {
    marginLeft: 10,
    flex: 1,
    flexDirection: 'column',
  },
  description: {
    fontSize: 12,
    lineHeight: 13,
    letterSpacing: 0.2,
    marginTop: 7,
    textTransform: 'uppercase',
  },
  sliderThumbStyle: {
    width: 25,
    height: 25,
    backgroundColor: colors.white,
    borderStyle: 'solid',
    borderWidth: 3,
    borderColor: colors.primary,
    borderRadius: 25,
  },
  inputContainer: {
    borderWidth: 0,
    paddingHorizontal: 0,
  },
});
