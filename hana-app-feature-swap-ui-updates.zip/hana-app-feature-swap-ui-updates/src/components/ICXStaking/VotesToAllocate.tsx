import { Button, ButtonSize, ButtonVariant } from '@/components/Button';
import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import type { BigNumber } from '@/utils/bignumber';
import { colors } from '@/utils/designTokens';
import { formatAmount } from '@/utils/format';
import React from 'react';
import { StyleSheet } from 'react-native';

interface Props {
  unallocatedVotes: BigNumber;
  onAllocateNow: () => unknown;
}

export function VotesToAllocate({ unallocatedVotes, onAllocateNow }: Props) {
  const { isDarkMode } = useTheme();

  return (
    <>
      <Text muted style={[styles.text, isDarkMode && { color: colors.whiteSecond }]}>
        You have{' '}
        <Text large bold style={styles.subText}>
          {formatAmount(unallocatedVotes)}
        </Text>{' '}
        votes available to allocate.
      </Text>

      <Button variant={ButtonVariant.Primary} size={ButtonSize.Small} onPress={onAllocateNow}>
        Allocate votes
      </Button>
    </>
  );
}

const styles = StyleSheet.create({
  text: {
    marginTop: 30,
    marginBottom: 20,
  },
  subText: {
    color: colors.primary,
  },
});
