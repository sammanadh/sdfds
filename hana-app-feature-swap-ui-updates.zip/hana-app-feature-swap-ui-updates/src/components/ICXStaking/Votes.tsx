import { VotesToAllocate } from '@/components/ICXStaking/VotesToAllocate';
import { DelegatedPRep } from '@/models/Delegation';
import { PRep } from '@/models/PRep';
import { useIconNetwork } from '@/stores/IconNetwork';
import { BigNumber } from '@/utils/bignumber';
import { WITHHOLD_BALANCE, ZERO } from '@/utils/constants';
import { formatAmount, formatNumber } from '@/utils/format';
import { isNil, orderBy } from 'lodash-es';
import React, { useMemo } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { PRepItem } from './PRepItem';

interface Props {
  onSelectedPRep: (pRep: PRep) => unknown;
  onChangeVoteAllocation: () => unknown;
  onAllocateNow: () => unknown;
}

export function Votes({ onSelectedPRep, onChangeVoteAllocation, onAllocateNow }: Props) {
  const { pReps: allPReps } = useIconNetwork();

  const { icxAssetsForWallet } = useIconNetwork();

  const assets = icxAssetsForWallet();

  const delegations = useMemo(
    () => orderBy(assets?.delegations ?? [], ['amount'], ['desc']),
    [assets]
  );

  const delegatedPReps: Array<DelegatedPRep> = useMemo(
    () =>
      delegations.map((delegation) => {
        const pRep = allPReps.find((pRep: PRep) => pRep.address === delegation.address);
        if (isNil(pRep)) return delegation as DelegatedPRep;
        return { ...pRep, amount: delegation.amount };
      }),
    [allPReps, delegations]
  );

  const totalVotes = useMemo(
    () => delegations.reduce((total, { amount }) => total.plus(amount), ZERO),
    [delegations]
  );
  const availableVotes = useMemo(
    () =>
      !isNil(assets?.balance)
        ? BigNumber.maximum(assets!.balance!.minus(WITHHOLD_BALANCE), totalVotes).integerValue(
            BigNumber.ROUND_FLOOR
          )
        : ZERO,
    [assets, totalVotes]
  );
  const unallocatedVotes = useMemo(
    () => BigNumber.maximum(availableVotes.minus(totalVotes), ZERO),
    [availableVotes, totalVotes]
  );

  return (
    <>
      <VotesToAllocate unallocatedVotes={unallocatedVotes} onAllocateNow={onAllocateNow} />
      <View style={styles.separator} />

      <FlatList
        data={delegatedPReps}
        renderItem={({ item: delegatedPRep }) => {
          const percentageOfVotes = availableVotes.gt(ZERO)
            ? delegatedPRep.amount.dividedBy(availableVotes).times(100)
            : ZERO;
          const percentageLabel =
            formatNumber(percentageOfVotes, 1, true, BigNumber.ROUND_HALF_UP) + '%';

          return (
            <PRepItem
              pRep={delegatedPRep}
              style={styles.marginVertical}
              description={`${formatAmount(delegatedPRep.amount)} ICX`}
              accessoryText={percentageLabel}
              onPress={() => onSelectedPRep(delegatedPRep)}
            />
          );
        }}
        keyExtractor={(item, index) => String(index)}
      />
    </>
  );
}

const styles = StyleSheet.create({
  separator: {
    marginBottom: 20,
  },
  marginVertical: { marginVertical: 7 },
});
