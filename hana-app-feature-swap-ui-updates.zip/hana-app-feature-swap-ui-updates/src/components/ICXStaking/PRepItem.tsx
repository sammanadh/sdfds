import { IconNextBlack, IconNextWhite } from '@/assets/icons';
import { PRepLogo } from '@/components/ICXStaking/PRepLogo';
import { Text } from '@/components/Typography';
import { PRep } from '@/models/PRep';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';

interface Props {
  pRep: PRep;
  description?: string | null;
  onPress: () => unknown;
  style?: StyleProp<ViewStyle>;
  accessoryText?: string;
}

export function PRepItem({ pRep, description, onPress, style, accessoryText }: Props) {
  const { isDarkMode } = useTheme();

  return (
    <TouchableOpacity onPress={onPress} style={style}>
      <View
        style={[
          styles.container,
          { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards },
        ]}
      >
        <PRepLogo pRep={pRep} />

        <View style={styles.labels}>
          <Text large bold numberOfLines={1}>
            {pRep.name}
          </Text>
          <Text small muted>
            {description}
          </Text>
        </View>

        {accessoryText && <Text style={styles.accessoryText}>{accessoryText}</Text>}
        {isDarkMode ? <IconNextWhite /> : <IconNextBlack />}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 80,
    paddingHorizontal: 20,
    justifyContent: 'center',
    flexDirection: 'row',
    alignItems: 'center',
  },
  labels: {
    flex: 1,
    justifyContent: 'space-between',
    flexDirection: 'column',
    marginHorizontal: 10,
  },
  accessoryText: {
    textAlign: 'right',
    color: colors.black,
    marginRight: 10,
  },
});
