import { useTheme } from '@/stores/Theme';
import { useMemo } from 'react';
import { StyleProp, View, ViewStyle } from 'react-native';
import { MaterialIndicator } from 'react-native-indicators';

type ActivityIndicatorSize = 'large' | 'small' | number;

interface Props {
  color?: string;
  size?: ActivityIndicatorSize;
  style?: StyleProp<ViewStyle>;
}

export function ActivityIndicator({ color, size = 'large', style = {} }: Props) {
  const { colors } = useTheme();
  const indicatorColor = useMemo(() => color ?? colors.foreground, [color, colors]);
  const indicatorSize = useMemo(
    () => (size === 'large' ? 40 : size === 'small' ? 20 : size),
    [size]
  );

  return (
    <View style={[{ width: indicatorSize, height: indicatorSize }, style]}>
      <MaterialIndicator color={indicatorColor} size={indicatorSize} />
    </View>
  );
}
