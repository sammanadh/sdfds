import { IconExternalLink } from '@/assets/icons';
import { HIT_SLOP_XLARGE } from '@/utils/constants';
import { common } from '@/utils/styles';
import * as WebBrowser from 'expo-web-browser';
import { isNil } from 'lodash-es';
import { TouchableOpacity, View } from 'react-native';

interface Props {
  url?: string;
  isDarkMode?: boolean;
}

export function OpenLinkButton({ url, isDarkMode }: Props) {
  function openURl() {
    if (!isNil(url)) {
      WebBrowser.openBrowserAsync(url);
    }
  }
  return (
    <View style={common.screen}>
      <TouchableOpacity onPress={openURl} hitSlop={HIT_SLOP_XLARGE} style={common.centerContent}>
        <IconExternalLink width={24} height={24} color={isDarkMode ? 'white' : 'black'} />
      </TouchableOpacity>
    </View>
  );
}
