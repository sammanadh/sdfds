import {
  ArrowDownIcon,
  ArrowDownWhiteIcon,
  IconAddBoldBlack,
  LockIcon,
  LockWhiteIcon,
  PlusIconBoldWhite,
} from '@/assets/icons';
import SettingsDrawerIcon from '@/assets/icons/settings-gear.svg';
import SettingsDarkIcon from '@/assets/icons/settings-gear-white.svg';
import { CloseButton } from '@/components/CloseButton';
import { ChangeNetworkModal } from '@/components/Modals/ChangeNetwork/ChangeNetworkModal';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { Heading, Text } from '@/components/Typography';
import { WalletAvatar } from '@/components/WalletAvatar';
import { CustomNetwork, RealmWallet, Wallet } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { HIT_SLOP_LARGE } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { dismissModal, presentModal } from '@/utils/modal';
import { TestnetConfig, networkDetailsForTestnet } from '@/utils/networks';
import { card, common } from '@/utils/styles';
import { DrawerContentComponentProps } from '@react-navigation/drawer';
import { isNil } from 'lodash-es';
import { ReactNode, useCallback, useEffect, useMemo, useRef } from 'react';
import {
  Dimensions,
  FlatList,
  ListRenderItem,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ModalTextItem } from './ModalTextItem';
import { WalletTypeBadge } from './Settings/WalletTypeBadge';
import { ToastType } from './Toast.types';

interface DrawerLink {
  title: string;
  handler(): void;
  icon?: ReactNode;
}
const { height: deviceHeight } = Dimensions.get('screen');

export function Drawer({ navigation }: DrawerContentComponentProps) {
  const { wallets, createWallet, isCreatingWallet, selectWallet, lockVault } = useVault();
  const { setHideTabBar } = useNavigationStore();

  const { otherNetwork } = useChainServices();
  const insets = useSafeAreaInsets();
  const refWallets = useRef<FlatList>(null);
  const { isDarkMode, styles: themeStyles } = useTheme();

  const { setToastMessage } = useNavigationStore();

  const renderAddWalletModal = useCallback((isWalletCreationInProgress: boolean) => {
    presentModal({
      title: 'Add a wallet',
      content: (
        <>
          <ModalTextItem
            title="Create a new wallet"
            onPress={() => {
              createWallet().then((wallet: RealmWallet) => {
                dismissModal();
                navigation.closeDrawer();
                setToastMessage(`${wallet.name} created`, ToastType.success);
              });
            }}
            isLoading={isWalletCreationInProgress}
          />
          <ModalTextItem
            title="Restore a private key"
            onPress={() => {
              setHideTabBar(true);
              dismissModal();
              navigation.navigate('SettingsStack', {
                screen: 'RestoreWallet',
                params: {
                  fromDrawer: true,
                },
              });
            }}
          />
          {/*          <ModalTextItem
            title="Connect your Ledger"
            onPress={() => {
              dismissModal();
              navigate('ConnectWithLedger');
            }}
          />*/}
        </>
      ),
    });
  }, [])

  function onAdd() {
    renderAddWalletModal(false)
  }

  useEffect(() => {
    if(isCreatingWallet) renderAddWalletModal(true);
  }, [isCreatingWallet])

  const links = useMemo<Array<DrawerLink>>(
    () => [
      {
        title: `Add a wallet`,
        icon: isDarkMode ? (
          <PlusIconBoldWhite width={17} height={17} />
        ) : (
          <IconAddBoldBlack width={17} height={17} />
        ),
        handler: onAdd,
      },

      {
        title: `Lock wallet`,
        icon: isDarkMode ? (
          <LockWhiteIcon width={17} height={17} />
        ) : (
          <LockIcon width={17} height={17} />
        ),
        handler: () => {
          lockVault();
          navigation.reset({ index: 0, routes: [{ name: 'UnlockStack' }] });
        },
      },
      {
        title: `Settings`,
        icon: isDarkMode ? (
          <SettingsDarkIcon width={17} height={17} />
        ) : (
          <SettingsDrawerIcon width={17} height={17} />
        ),
        handler: () => {
          navigation.toggleDrawer();
          navigation.navigate('SettingsStack', {
            screen: 'Settings',
          });
        },
      },
    ],
    [isDarkMode]
  );

  const maxHeightWalletList = useMemo(
    () => deviceHeight * 0.72 - (insets.bottom + insets.top),
    [insets]
  );

  async function handleSelectWallet(wallet: Wallet) {
    refWallets.current?.scrollToOffset({ animated: true, offset: 0 });
    if (!wallet.isActive) {
      await selectWallet(wallet.id);
    }
    navigation.navigate('Home');
    navigation.closeDrawer();
    setToastMessage(`Switch to ${wallet.name}`, ToastType.success);
  }

  const renderWallet: ListRenderItem<Wallet> = ({ item: wallet }) => {
    return (
      <View
        key={wallet.id}
        style={[
          styles.walletContainer,
          wallet.isActive && styles.walletActive,
          themeStyles.cards,
          isDarkMode ? !wallet.isActive && { borderColor: 'transparent' } : {},
        ]}
      >
        <TouchableOpacity onPress={() => handleSelectWallet(wallet)} style={styles.wallet}>
          <WalletAvatar isUseWalletName wallet={wallet} />
          <View style={styles.walletDetails}>
            <Text large bold numberOfLines={1}>
              {wallet.name}
            </Text>
          </View>
        </TouchableOpacity>
        <WalletTypeBadge wallet={wallet} />
        {wallet.isActive && (
          <View style={styles.labelSelected}>
            <Text bold style={styles.selected}>
              SELECTED
            </Text>
          </View>
        )}
      </View>
    );
  };

  function handlePressLink(link: DrawerLink) {
    link.handler();
  }

  const renderLink: ListRenderItem<DrawerLink> = ({ item: link }) => {
    return (
      <TouchableOpacity
        onPress={() => handlePressLink(link)}
        key={link.title}
        hitSlop={HIT_SLOP_LARGE}
        style={styles.link}
      >
        <View style={styles.icon}>{link.icon}</View>
        <Text bold numberOfLines={1} style={styles.linkTitle}>
          {link.title}
        </Text>
      </TouchableOpacity>
    );
  };

  const { refreshWalletBalances } = useVault();

  function onSelectNetwork() {
    navigation.closeDrawer();

    presentModal({
      title: 'Network',
      content: (
        <ChangeNetworkModal
          onClose={() => {
            dismissModal();
            refreshWalletBalances();
          }}
        />
      ),
    });
  }

  const selectedNetworkName = useMemo(() => {
    if (!isNil(otherNetwork)) {
      if ((otherNetwork as TestnetConfig)?.chainType) {
        const testnet = otherNetwork as TestnetConfig;
        const networkDetails = networkDetailsForTestnet(testnet);
        return networkDetails?.shortName;
      }

      if ((otherNetwork as CustomNetwork)?.id) {
        const customNetwork = otherNetwork as CustomNetwork;
        return customNetwork.name;
      }
    }

    return 'Mainnet';
  }, [otherNetwork]);

  return (
    <SafeAreaScreen style={themeStyles.screen} left={false}>
      <View style={{ flexGrow: 1 }}>
        <View style={styles.header}>
          <Heading>My wallets</Heading>
          <CloseButton onPress={navigation.closeDrawer} />
        </View>
        <TouchableOpacity onPress={() => onSelectNetwork()}>
          <View style={[styles.selectNetworkContainer, themeStyles.cards]}>
            <Text bold style={styles.selectNetworkText}>
              {selectedNetworkName}
            </Text>
            {isDarkMode ? <ArrowDownWhiteIcon /> : <ArrowDownIcon />}
          </View>
        </TouchableOpacity>
        <FlatList
          ref={refWallets}
          data={wallets}
          keyExtractor={(wallet) => wallet.id}
          renderItem={renderWallet}
          ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
          style={[styles.walletList, { maxHeight: maxHeightWalletList }]}
        />
      </View>

      <View style={[styles.separator, isDarkMode && { backgroundColor: colors.black }]} />
      <View>
        <FlatList
          data={links}
          keyExtractor={(link) => link.title}
          renderItem={renderLink}
          ItemSeparatorComponent={() => (
            <View style={{ height: 25, justifyContent: 'center' }}>
              <View style={[styles.separator, isDarkMode && { backgroundColor: colors.black }]} />
            </View>
          )}
          overScrollMode="never"
          bounces={false}
          style={styles.links}
        />
      </View>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginTop: 20,
  },

  labelSelected: {
    position: 'absolute',
    backgroundColor: colors.offPurple,
    bottom: 0,
    right: 0,
  },
  selected: {
    fontSize: 12,
    color: colors.primary,
    marginHorizontal: 6,
  },
  walletList: {
    paddingHorizontal: 20,
  },
  wallet: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  walletContainer: {
    ...card.base,
    padding: 12,
    borderColor: colors.white,
    borderWidth: 3,
    borderRadius: 0,
  },
  walletActive: {
    borderColor: colors.offPurple,
  },
  walletDetails: {
    flex: 1,
    marginLeft: 10,
  },
  separator: {
    height: 1,
    width: '100%',
    backgroundColor: colors.gray.cards,
    marginVertical: 22,
  },
  links: {
    paddingHorizontal: 12,
  },
  linkTitle: {
    fontSize: 17,
    marginTop: 4,
  },
  link: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 21,
  },
  icon: {
    ...common.centerContent,
    width: 30,
    height: 30,
    marginRight: 12,
  },
  selectNetworkContainer: {
    height: 40,
    justifyContent: 'center',
    borderRadius: 100,
    marginHorizontal: 21,
    marginTop: 24,
    marginBottom: 28,
    flexDirection: 'row',
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  selectNetworkText: {
    flex: 1,
  },
});
