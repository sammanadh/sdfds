import { useTheme } from '@/stores/Theme';
import { BlurView } from '@react-native-community/blur';
import React from 'react';
import { StyleSheet } from 'react-native';

export function Blur() {
  const { isDarkMode } = useTheme();

  return (
    <BlurView style={styles.absolute} blurType={isDarkMode ? 'dark' : 'light'} blurAmount={10} />
  );
}

const styles = StyleSheet.create({
  absolute: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
});
