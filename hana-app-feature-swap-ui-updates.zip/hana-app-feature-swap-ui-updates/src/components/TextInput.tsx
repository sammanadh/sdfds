import { IconWarning } from '@/assets/icons';
import { useTheme } from '@/stores/Theme';
import { colors, fonts } from '@/utils/designTokens';
import { common } from '@/utils/styles';
import { isEmpty, isNil } from 'lodash-es';
import {
  forwardRef,
  ForwardRefRenderFunction,
  MutableRefObject,
  ReactNode,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  Animated,
  Easing,
  Platform,
  StyleProp,
  StyleSheet,
  TextInput as RNTextInput,
  TextInputProps,
  TextStyle,
  TouchableOpacity,
  View,
  ViewStyle,
} from 'react-native';
import TextInputMask, { TextInputMaskProps } from 'react-native-text-input-mask';
import { closeTip, Tip } from 'react-native-tip';

export type TextInputRef = RNTextInput;

const INPUT_HEIGHT = 55;
const INPUT_PADDING_HORIZONTAL = 16;
const INPUT_FIX = Platform.select({ ios: 4, default: 5 });
const INPUT_RANGE = -INPUT_HEIGHT / Platform.select({ ios: 4.5, default: 3.9 });
const ANIMATION_DURATION = 200;

interface Props extends TextInputProps {
  prefix?: ReactNode;
  error?: boolean;
  msgError?: string | null;
  style?: StyleProp<ViewStyle>;
  accessory?: ReactNode;
  inputStyle?: StyleProp<TextStyle>;
  styleInputContainer?: StyleProp<ViewStyle>;
  label?: string;
  labelTitle?: string;
  inputBorderColor?: string;
  inputFocusBorderColor?: string;
  labelInputStyle?: StyleProp<TextStyle>;
  isDarkMode?: boolean;
}

const BaseTextInput: ForwardRefRenderFunction<TextInputRef, Props & TextInputMaskProps> = (
  {
    prefix,
    editable: isEditable = true,
    error: hasError = false,
    style = {},
    accessory,
    inputStyle,
    label,
    labelTitle,
    placeholder,
    placeholderTextColor,
    inputBorderColor = colors.gray.meta,
    inputFocusBorderColor = colors.offPurple,
    styleInputContainer,
    labelInputStyle = {},
    msgError = '-',
    onChangeText,
    onBlur,
    onFocus,
    ...props
  },
  outerRef
) => {
  const [isFocus, setIsFocus] = useState(false);
  const [value, setValue] = useState<string>();
  const innerRef = useRef<TextInputRef>(null);
  const [isChange, setIsChange] = useState<boolean>();
  const { isDarkMode } = useTheme();
  const labelAnim = useRef(new Animated.Value(INPUT_RANGE)).current;

  const ref = useMemo(
    () => (isNil(outerRef) ? innerRef : (outerRef as MutableRefObject<RNTextInput>)),
    [innerRef, outerRef]
  );
  const hasPrefix = useMemo(() => !isNil(prefix), [prefix]);
  const hasAccessory = useMemo(() => !isNil(accessory), [accessory]);

  const _onChangeText = (formatted: string, extracted?: string | undefined) => {
    setValue(formatted);
    if (formatted && !value) {
      Animated.timing(labelAnim, {
        toValue: 0,
        easing: Easing.inOut(Easing.ease),
        duration: ANIMATION_DURATION,
        useNativeDriver: true,
      }).start();
      setIsChange(true);
    } else if (!formatted) {
      Animated.timing(labelAnim, {
        toValue: INPUT_RANGE,
        easing: Easing.inOut(Easing.ease),
        duration: ANIMATION_DURATION,
        useNativeDriver: true,
      }).start();
      setIsChange(false);
    }
    onChangeText?.(formatted, extracted);
  };

  const labelStyle = {
    transform: [
      {
        translateY: labelAnim.interpolate({
          inputRange: [INPUT_RANGE, 0],
          outputRange: [0, INPUT_RANGE],
        }),
      },
    ],
  };

  useLayoutEffect(() => {
    if (props.value) {
      _onChangeText(props?.value);
    }
  }, []);

  return (
    <View style={style}>
      <View
        style={[
          styles.inputContainer,
          styleInputContainer,
          !isEditable && styles.inputDisabled,
          hasPrefix && styles.inputPrefixed,
          hasAccessory && styles.inputAccessorised,
          {
            borderColor: isFocus
              ? inputFocusBorderColor
              : inputBorderColor
              ? inputBorderColor
              : colors.black,
          },
          hasError && styles.inputError,
          isDarkMode && { backgroundColor: colors.black },
        ]}
      >
        <TextInputMask
          ref={ref}
          editable={isEditable}
          selectionColor={colors.brand.primary}
          underlineColorAndroid={'transparent'}
          style={[
            [
              styles.input,

              isDarkMode ? { color: colors.whiteSecond } : { color: colors.black },
              !value || !label
                ? { height: INPUT_HEIGHT }
                : {
                    marginTop: INPUT_HEIGHT - (INPUT_HEIGHT - 3),
                    height: INPUT_HEIGHT - 3,
                  },
              inputStyle,
              !hasAccessory && hasError ? { width: '90%' } : {},
            ],
          ]}
          onFocus={(e) => {
            setIsFocus(true);
            onFocus?.(e);
          }}
          onBlur={(e) => {
            setIsFocus(false);
            onBlur?.(e);
          }}
          onChangeText={_onChangeText}
          {...props}
          {...(!label
            ? {
                placeholder,
                ...(isDarkMode
                  ? { placeholderTextColor: colors.gray.meta }
                  : { placeholderTextColor }),
              }
            : {})}
        />
        {!isEmpty(label) && (
          <Animated.View
            pointerEvents="none"
            style={[
              StyleSheet.absoluteFill,
              styles.labelContainer,
              hasPrefix && styles.inputPrefixed,
              hasAccessory && styles.inputAccessorised,
            ]}
          >
            <Animated.Text
              numberOfLines={1}
              style={[
                styles.label,
                isChange ? {} : { fontFamily: fonts.semiBold, fontSize: 15 },
                labelStyle,
                labelInputStyle,
                !props?.value && !value ? {} : { opacity: value ? 1 : 0 },
              ]}
            >
              {!value ? label : labelTitle || label}
            </Animated.Text>
          </Animated.View>
        )}
        {!hasAccessory && hasError && (
          <View style={styles.iconWarning}>
            <Tip
              id={msgError || Math.random()}
              title={msgError || '-'}
              onTipPress={() => {
                closeTip();
              }}
              onPressItem={() => {
                closeTip();
              }}
              overlayOpacity={0}
            >
              <IconWarning width={INPUT_HEIGHT * 0.5} height={INPUT_HEIGHT * 0.5} />
            </Tip>
          </View>
        )}
      </View>
      {hasPrefix && (
        <TouchableOpacity onPress={() => ref.current?.focus()} style={styles.prefix}>
          {prefix}
        </TouchableOpacity>
      )}
      {hasAccessory && <View style={[styles.accessory]}>{accessory}</View>}
    </View>
  );
};

export const TextInput = forwardRef(BaseTextInput);

const styles = StyleSheet.create({
  inputContainer: {
    width: '100%',
    height: INPUT_HEIGHT,
    borderWidth: 2,
    borderRadius: 100,
    paddingVertical: 3,
    paddingHorizontal: INPUT_PADDING_HORIZONTAL,
  },
  input: {
    width: '100%',
    height: INPUT_HEIGHT - INPUT_FIX,
    fontSize: 15,
    color: colors.black,
    paddingVertical: 0,
  },
  iconWarning: {
    position: 'absolute',
    right: 12,
    height: INPUT_HEIGHT * 0.9,
    justifyContent: 'center',
  },
  inputDisabled: {
    opacity: 0.7,
  },
  inputError: {
    borderColor: colors.negative,
  },
  inputPrefixed: {
    paddingLeft: 48,
  },
  inputAccessorised: {
    paddingRight: 48,
  },
  prefix: {
    ...common.centerContent,
    position: 'absolute',
    top: 0,
    left: 0,
    width: 50,
    height: '100%',
    paddingLeft: 10,
  },
  accessory: {
    ...common.centerContent,
    position: 'absolute',
    top: 3,
    right: 0,
    width: 50,
    height: 50,
    paddingRight: 10,
  },
  labelContainer: {
    zIndex: -3,
    justifyContent: 'center',
    height: INPUT_HEIGHT - INPUT_FIX,
    paddingHorizontal: INPUT_PADDING_HORIZONTAL,
  },
  label: {
    fontSize: 12,
    fontFamily: fonts.semiBold,
    color: colors.gray.meta,
  },
});
