import { IconNextBlack, IconNextWhite } from '@/assets/icons';
import { Text } from '@/components/Typography';
import { ChainService } from '@/models/ChainService';
import { useTheme } from '@/stores/Theme';
import type { BigNumber } from '@/utils/bignumber';
import { ChainID, chains } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import { formatAddress, formatAmount } from '@/utils/format';
import { LedgerAddress } from '@/utils/ledger';
import React, { useEffect, useState } from 'react';
import { StyleProp, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';

interface Props {
  onPress: () => unknown;
  chainService?: ChainService | null;
  chainID: ChainID;
  ledgerAddress: LedgerAddress;
  style?: StyleProp<ViewStyle>;
}

export function AddressItem({ onPress, chainService, chainID, ledgerAddress, style }: Props) {
  const chain = chains.find((chain) => chain.id === chainID);
  const [balance, setBalance] = useState<BigNumber>(ZERO);
  const { isDarkMode, styles: themeStyles } = useTheme();

  useEffect(() => {
    if (chainService) {
      chainService.getBalance(ledgerAddress.address).then(setBalance);
    }
  }, [chainService, ledgerAddress]);

  return (
    <TouchableOpacity onPress={onPress} style={[styles.addressItem, themeStyles.cards, style]}>
      <Text large bold>
        {formatAddress(ledgerAddress.address, 6, 6)}
      </Text>
      <Text style={styles.balance}>
        {formatAmount(balance).toString()} {chain?.token.symbol}
      </Text>
      {isDarkMode ? <IconNextWhite /> : <IconNextBlack />}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  addressItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },

  balance: {
    flex: 1,
    textAlign: 'right',
    marginHorizontal: 15,
  },
});
