import { IconNextBlack, IconNextWhite } from '@/assets/icons';
import { AltHeading, Text } from '@/components/Typography';
import { Contact, RealmWallet, Wallet } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { ChainID } from '@/utils/chains';
import { formatAddress } from '@/utils/format';
import { isNil } from 'lodash-es';
import React, { useMemo } from 'react';
import { StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';
import { ContactAvatar } from '../ContactAvatar';
import { WalletAvatar } from '../WalletAvatar';

interface Props {
  contact?: Contact;
  wallet?: Wallet | RealmWallet;
  chainID?: ChainID;
  onPress: () => unknown;
  style?: StyleProp<ViewStyle>;
  showAvatar?: boolean;
  hasNextIcon?: boolean;
}

export function AddressBookItem({
  contact,
  wallet,
  chainID,
  onPress,
  style,
  showAvatar = true,
  hasNextIcon,
}: Props) {
  const { isDarkMode, styles: themeStyles } = useTheme();
  const chainWallet = useMemo(() => {
    if (wallet && chainID) {
      return wallet.chainWallets.find((cw) => cw.type === chainID);
    }
  }, [wallet, chainID]);

  const avatar = useMemo(() => {
    if (!isNil(chainWallet) && wallet) {
      return <WalletAvatar isUseWalletName wallet={wallet} />;
    } else if (contact) {
      return <ContactAvatar contact={contact} />;
    }

    return <View />;
  }, [wallet, contact]);

  return (
    <TouchableOpacity onPress={onPress} style={style}>
      <View style={[styles.container, themeStyles.cards]}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          {showAvatar ? avatar : <View />}
          <View style={[styles.labelsContainer, !hasNextIcon && { marginRight: 0 }]}>
            {contact && (
              <>
                <Text bold large numberOfLines={1}>
                  {contact.name}
                </Text>
                <AltHeading style={{ marginTop: 6 }}>{formatAddress(contact.address)}</AltHeading>
              </>
            )}

            {chainWallet && (
              <>
                <Text bold large numberOfLines={1}>
                  {wallet?.name}
                </Text>
                <AltHeading style={{ marginTop: 6 }}>
                  {formatAddress(chainWallet.address)}
                </AltHeading>
              </>
            )}
          </View>
        </View>

        {hasNextIcon && (isDarkMode ? <IconNextWhite /> : <IconNextBlack />)}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    width: '100%',
  },
  labelsContainer: {
    flexDirection: 'column',
    flex: 1,
    marginHorizontal: 15,
  },
});
