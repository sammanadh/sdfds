import { useTheme } from '@/stores/Theme';
import React from 'react';
import { StyleSheet, TouchableOpacity } from 'react-native';

interface Props {
  children: React.ReactNode;
  height?: number;
  onPress: () => unknown;
}

export function CardButton({ children, height = 50, onPress }: Props) {
  const { styles: themeStyles } = useTheme();

  return (
    <TouchableOpacity style={[styles.container, themeStyles.cards, { height }]} onPress={onPress}>
      {children}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginVertical: 7,
  },
});
