import { IconNextBlack, IconNextWhite } from '@/assets/icons';
import { ActivityIndicator } from '@/components/ActivityIndicator';
import { Text } from '@/components/Typography';
import { colors, fonts } from '@/utils/designTokens';
import { common } from '@/utils/styles';
import { forwardRef, ForwardRefRenderFunction, PropsWithChildren } from 'react';
import {
  GestureResponderEvent,
  StyleProp,
  StyleSheet,
  TextStyle,
  TouchableOpacity,
  View,
  ViewStyle,
} from 'react-native';

export enum ButtonVariant {
  Primary,
  Secondary,
  Danger,
  DangerSecondary,
  DangerTertiary,
  Purple,
  PurpleSecondary,
}

export enum ButtonSize {
  Regular,
  Small,
  Tiny,
}

export type ButtonRef = TouchableOpacity;

type Props = PropsWithChildren<{
  onPress?: ((event: GestureResponderEvent) => void) | (() => void);
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  working?: boolean;
  style?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  iconRight?: JSX.Element;
  iconLeft?: JSX.Element;
  hasNextIcon?: boolean;
  isDarkMode?: boolean;
}>;

const BaseButton: ForwardRefRenderFunction<ButtonRef, Props> = (
  {
    children,
    onPress,
    variant = ButtonVariant.Primary,
    size = ButtonSize.Regular,
    disabled: isDisabled = false,
    working: isWorking = false,
    style = {},
    textStyle = {},
    iconLeft,
    iconRight,
    hasNextIcon = false,
    isDarkMode,
  },
  ref
) => (
  <TouchableOpacity
    ref={ref}
    onPress={onPress}
    disabled={isDisabled || isWorking}
    style={[
      styles.base,
      variant === ButtonVariant.Primary && styles.primary,
      variant === ButtonVariant.Secondary && styles.secondary,
      variant === ButtonVariant.Danger && styles.danger,
      variant === ButtonVariant.DangerSecondary && styles.dangerSecondary,
      variant === ButtonVariant.Purple && styles.purple,
      variant === ButtonVariant.DangerTertiary && styles.dangerTertiary,
      variant === ButtonVariant.PurpleSecondary && {
        ...styles.purpleSecondary,
        ...(isDarkMode
          ? { backgroundColor: colors.purple.darkBlack, borderColor: colors.purple.darkBlack }
          : {}),
      },
      size === ButtonSize.Small && styles.small,
      size === ButtonSize.Tiny && styles.tiny,
      (isDisabled || isWorking) && styles.disabled,
      style,
    ]}
  >
    {hasNextIcon || iconRight || iconLeft ? (
      <View style={styles.box}>{iconLeft || null}</View>
    ) : (
      <></>
    )}
    <View style={styles.body}>
      {isWorking && (
        <ActivityIndicator
          color={variant === ButtonVariant.Secondary ? colors.brand.dark : colors.white}
          size={size === ButtonSize.Regular ? 'small' : 16}
          style={{ marginRight: size === ButtonSize.Regular ? 15 : 10 }}
        />
      )}

      {typeof children === 'string' ? (
        <Text
          bold
          style={[
            styles.textBase,
            variant === ButtonVariant.Secondary && styles.textSecondary,
            variant === ButtonVariant.DangerSecondary && styles.textDangerSecondary,
            variant === ButtonVariant.Purple && { color: colors.black },
            variant === ButtonVariant.DangerTertiary && styles.textDangerTertiary,
            variant === ButtonVariant.PurpleSecondary && {
              ...styles.textPurpleSecondary,
              ...(isDarkMode ? { color: colors.whiteSecond } : {}),
            },
            size === ButtonSize.Small && styles.textSmall,
            size === ButtonSize.Tiny && styles.textTiny,
            textStyle,
            isWorking && { opacity: 0, position: 'absolute', zIndex: -1000 },
            isDisabled && { color: '#b2aade' },
          ]}
        >
          {children}
        </Text>
      ) : (
        children
      )}
    </View>
    {hasNextIcon || iconRight || iconLeft ? (
      <View style={styles.box}>
        {(hasNextIcon &&
          ([ButtonVariant.DangerTertiary, ButtonVariant.PurpleSecondary].includes(variant) ? (
            <IconNextBlack />
          ) : (
            <IconNextWhite
              {...(isDisabled
                ? { opacity: 0.7, fill: '#b2aade', stroke: '#b2aade', color: '#b2aade' }
                : {})}
            />
          ))) ||
          iconRight ||
          null}
      </View>
    ) : null}
  </TouchableOpacity>
);

export const Button = forwardRef(BaseButton);

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    width: '100%',
    height: 55,
    borderRadius: 50,
  },
  primary: {
    backgroundColor: colors.primary,
  },
  secondary: {
    backgroundColor: colors.white,
    borderColor: colors.brand.primary,
    borderWidth: 1,
  },
  danger: {
    backgroundColor: colors.red,
  },
  dangerSecondary: {
    backgroundColor: colors.white,
    borderColor: colors.red,
    borderWidth: 1,
  },
  dangerTertiary: {
    backgroundColor: colors.negative,
    borderColor: colors.negative,
    borderWidth: 1,
  },
  purpleSecondary: {
    backgroundColor: 'rgb(244, 242, 249)',
    borderColor: 'rgb(244, 242, 249)',
    borderWidth: 1,
  },
  disabled: {
    opacity: 1,
  },
  small: {
    height: 40,
  },
  tiny: {
    height: 26,
    borderRadius: 13,
  },
  textBase: {
    ...common.centerText,
    lineHeight: 22,
    color: colors.white,
    fontFamily: fonts.heavy,
  },
  textSecondary: {
    color: colors.brand.dark,
  },
  textDangerSecondary: {
    color: colors.red,
  },
  textDangerTertiary: {
    color: colors.black,
  },
  textPurpleSecondary: {
    color: colors.black,
  },
  textSmall: {
    fontSize: 15,
    lineHeight: 20,
  },
  textTiny: {
    fontFamily: fonts.semiBold,
    fontSize: 12,
    lineHeight: 26,
    textTransform: 'uppercase',
  },
  body: {
    ...common.centerContent,
    flex: 1,
  },
  box: {
    width: 44,
    justifyContent: 'center',
  },
  purple: {
    backgroundColor: colors.offPurple,
  },
});
