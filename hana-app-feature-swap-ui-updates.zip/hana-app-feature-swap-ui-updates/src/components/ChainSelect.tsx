import { ArrowDownIcon, ArrowDownWhiteIcon } from '@/assets/icons';
import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { dismissModal, presentModal } from '@/utils/modal';
import React, { useMemo } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { ChainSelectModal } from './ChainSelectModal';
import { chains } from '@/utils/chains';
import { isNil } from 'lodash-es';

interface Props {
  chain?: ChainID | null;
  onSelectChain: (chain: ChainID | null) => void;
  filterByTokenSupport?: boolean;
  onClick?: any;
}

export const ChainSelect = ({ chain,onSelectChain, filterByTokenSupport, onClick }: Props) => {
  const { isDarkMode } = useTheme();

  const { getActiveChainWallets } = useVault();
  const activeChainWallets = getActiveChainWallets();

  const chainsSupportingTokens = chains
    .filter((chain) => !isNil(chain.tokenType))
    .map((chain) => chain.id);

  const selectableChains = useMemo(() => {
    const activeChains = activeChainWallets.filter((cw) => cw.isActive).map((cw) => cw.type);

    if (filterByTokenSupport) {
      return activeChains.filter((chain) => chainsSupportingTokens.includes(chain));
    }

    return activeChains;
  }, [activeChainWallets, filterByTokenSupport]);

  const showModal = () => {
    presentModal({
      title: 'Select a chain',
      content: (
        <View
          style={{
            marginTop: 20,
          }}
        >
          <ChainSelectModal
            chains={selectableChains}
            selectedChain={chain}
            onSelect={(chain) => {
              onSelectChain(chain);
              dismissModal();
            }}
          />
        </View>
      ),
    });
  };

  const handleClick = () => {
    showModal();
    if(onClick) onClick();
  }

  return (
    <TouchableOpacity onPress={handleClick}>
      <View style={[styles.selectNetworkContainer]}>
        <Text
          bold
          style={[
            styles.selectNetworkText,
            {
              color: !isDarkMode ? colors.purple.darkBlacker : colors.whiteSecond,
            },
          ]}
        >
          {chain || 'All chains'}
        </Text>
        {isDarkMode ? <ArrowDownWhiteIcon /> : <ArrowDownIcon />}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  selectNetworkContainer: {
    justifyContent: 'center',
    height: 56,
    width: 140,
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  selectNetworkText: {
    flex: 1,
    fontSize: 17,
    textAlign: 'right',
    paddingRight: 6,
  },
});
