import CheckIcon from '@/assets/icons/check-icon.svg';
import { TokenLogo } from '@/components/TokenLogo';
import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { ChainDetails } from '@/utils/chains';
import { isNil } from 'lodash-es';
import React, { useMemo } from 'react';
import { StyleSheet, TouchableOpacity, View, ActivityIndicator } from 'react-native';
import { palette } from '@/utils/designTokens';

interface Props {
  title?: string | null;
  onPress: () => unknown;
  chain?: ChainDetails;
  isActive?: boolean;
  isLoading?: boolean
}

export function ModalTextItem({ title, onPress, chain, isActive, isLoading }: Props) {
  const { isDarkMode, colors } = useTheme();
  const hasChain = useMemo(() => !isNil(chain), [chain]);

  return (
    <TouchableOpacity style={styles.container} onPress={() => (!isLoading && onPress())}>
      <View
        style={[
          styles.content,
          isDarkMode && { backgroundColor: colors.purple.darkBlack },
          !hasChain && { paddingLeft: 18 },
        ]}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
          {hasChain && <TokenLogo chain={chain} size={45} />}
          <Text
            bold
            style={[
              { marginHorizontal: chain ? 14 : 0 },
              isActive && { color: colors.foregroundHighlight },
            ]}
          >
            {title}
          </Text>
        </View>
        {isActive && <CheckIcon width={32} height={32} />}
        {
          isLoading && 
            <ActivityIndicator
              size={32}
              color={palette.black}
              style={{ marginLeft: 10, paddingBottom: 2 }}
            />
        }
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginVertical: 7,
  },
  content: {
    flexDirection: 'row',
    width: '100%',
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgb(244, 242, 249)',
    alignItems: 'center',
    paddingRight: 16,
    paddingLeft: 10,
  },
});
