import { Contact } from '@/models/Vault';
import { colors, fonts } from '@/utils/designTokens';
import { View } from 'react-native';
import { Text } from './Typography';

interface Props {
  contact: Contact;
  size?: number;
}

export function ContactAvatar({ contact, size = 55 }: Props) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: colors.offPurple,
      }}
    >
      <Text
        style={{
          fontFamily: fonts.heavy,
          fontSize: 13,
          textAlign: 'center',
          color: '#3308a8',
          textTransform: 'uppercase',
        }}
      >
        {contact.name?.slice(0, 3)}
      </Text>
    </View>
  );
}
