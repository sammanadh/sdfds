import { common } from '@/utils/styles';
import { PropsWithChildren, useMemo } from 'react';
import { StyleProp, View, ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

type Props = PropsWithChildren<{
  top?: boolean;
  bottom?: boolean;
  left?: boolean;
  right?: boolean;
  padTop?: boolean;
  style?: StyleProp<ViewStyle>;
}>;

export function SafeAreaScreen({
  children,
  top = false,
  bottom = true,
  left = true,
  right = true,
  padTop = true,
  style: styleOverride = {},
}: Props) {
  const insets = useSafeAreaInsets();
  const style = useMemo<StyleProp<ViewStyle>>(
    () => [
      common.fill,
      {
        paddingTop: top ? Math.max(insets.top, 30) : padTop ? 30 : 0,
        paddingBottom: bottom ? Math.max(insets.bottom, 20) : 0,
        paddingLeft: left ? insets.left : 0,
        paddingRight: right ? insets.right : 0,
      },
      styleOverride,
    ],
    [top, bottom, left, right, padTop, insets, styleOverride]
  );

  return <View children={children} style={style} />;
}
