import { IconAddBlack, IconAddWhite } from '@/assets/icons';
import { ModalTextItem } from '@/components/ModalTextItem';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { useNavigationStore } from '@/stores/Navigation';
import { useVault } from '@/stores/Vault';
import { HIT_SLOP_XLARGE } from '@/utils/constants';
import { dismissModal, presentModal } from '@/utils/modal';
import { common } from '@/utils/styles';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useCallback, useEffect } from 'react';
import { TouchableOpacity, View } from 'react-native';
import { ToastType } from './Toast.types';
import { RealmWallet } from '@/models/Vault';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'Settings'>,
  StackNavigationProp<RootStackParams>
>;

interface Props {
  isDarkMode?: boolean;
}

export function AddWalletButton({ isDarkMode }: Props) {
  const { navigate } = useNavigation<NavigationProps>();
  const { createWallet, isCreatingWallet } = useVault();
  const { setHideTabBar, setToastMessage } = useNavigationStore();

  const renderAddWalletModal = useCallback((isWalletCreationInProgress: boolean) => {
    presentModal({
      title: 'Add a wallet',
      content: (
        <>
          <ModalTextItem
            title="Create a new wallet"
            onPress={() => {
              createWallet().then((wallet: RealmWallet) => {
                dismissModal();
                setToastMessage(`${wallet.name} created`, ToastType.success);
              });
            }}
            isLoading={isWalletCreationInProgress}
          />
          <ModalTextItem
            title="Restore a private key"
            onPress={() => {
              setHideTabBar(true);
              dismissModal();
              navigate('RestoreWallet');
            }}
          />
{/*          <ModalTextItem
            title="Connect your Ledger"
            onPress={() => {
              dismissModal();
              navigate('ConnectWithLedger');
            }}
          />*/}
        </>
      ),
    });
  }, [])

  function onAdd() {
    renderAddWalletModal(false)
  }

  useEffect(() => {
    if(isCreatingWallet) renderAddWalletModal(true);
  }, [isCreatingWallet])

  return (
    <View style={common.screen}>
      <TouchableOpacity onPress={onAdd} hitSlop={HIT_SLOP_XLARGE} style={common.centerContent}>
        {isDarkMode ? <IconAddWhite /> : <IconAddBlack />}
      </TouchableOpacity>
    </View>
  );
}
