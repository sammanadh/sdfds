import { IconNextBlack, IconNextWhite } from '@/assets/icons';
import { Text } from '@/components/Typography';
import { DApp } from '@/models/DApp';
import { useTheme } from '@/stores/Theme';
import { common } from '@/utils/styles';
import React from 'react';
import { Image, StyleSheet, TouchableOpacity, View } from 'react-native';

interface Props {
  item: DApp;
  onPress: (a: string) => void;
}

const DAppsList = ({ item, onPress }: Props) => {
  const { isDarkMode, colors } = useTheme();

  return (
    <TouchableOpacity onPress={() => onPress(item.url)} style={styles.container}>
      <Image
        source={{ uri: item.logoUrl }}
        style={[styles.imageStyle, { borderColor: colors.divider }]}
        resizeMode="cover"
      />

      <View style={[common.fill, styles.cardText]}>
        <Text large bold>
          {item.title}
        </Text>
        <Text small muted style={{ marginTop: 6 }}>
          {item.description}
        </Text>
      </View>

      {isDarkMode ? <IconNextWhite /> : <IconNextBlack />}
    </TouchableOpacity>
  );
};

export default DAppsList;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
  },

  imageStyle: {
    flexShrink: 0,
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 1,
  },
  cardText: {
    flex: 1,
    marginHorizontal: 15,
  },
});
