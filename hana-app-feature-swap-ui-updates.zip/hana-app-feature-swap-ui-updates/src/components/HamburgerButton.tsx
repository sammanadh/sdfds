import HamburgerDarkModeIcon from '@/assets/icons/hamburger-dark-mode.svg';
import HamburgerLightModeIcon from '@/assets/icons/hamburger-light-mode.svg';
import { MainDrawerParams } from '@/components/Navigation';
import { HIT_SLOP_XLARGE } from '@/utils/constants';
import { common } from '@/utils/styles';
import { DrawerNavigationProp } from '@react-navigation/drawer';
import { useNavigation } from '@react-navigation/native';
import { TouchableOpacity, View } from 'react-native';

type NavigationProps = DrawerNavigationProp<MainDrawerParams, 'MainTab'>;

interface Props {
  isDarkMode?: boolean;
}

export function HamburgerButton({ isDarkMode }: Props) {
  const navigation = useNavigation<NavigationProps>();

  function handleOpenDrawer() {
    navigation.openDrawer();
  }

  return (
    <View style={common.screen}>
      <TouchableOpacity
        onPress={handleOpenDrawer}
        hitSlop={HIT_SLOP_XLARGE}
        style={common.centerContent}
      >
        {isDarkMode ? <HamburgerDarkModeIcon /> : <HamburgerLightModeIcon />}
      </TouchableOpacity>
    </View>
  );
}
