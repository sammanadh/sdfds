import { TokenLogo } from '@/components/TokenLogo';
import { AltHeading, Text } from '@/components/Typography';
import { TokenWithBalance } from '@/hooks/useTokens';
import { Token } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { chains } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import { formatNumber, formatPrice } from '@/utils/format';
import { isNil } from 'lodash-es';
import React, { useMemo } from 'react';
import {
  GestureResponderEvent,
  StyleProp,
  StyleSheet,
  TouchableOpacity,
  View,
  ViewStyle,
} from 'react-native';
import { IconNextBlack, IconNextWhite } from '@/assets/icons';

interface Props {
  token: TokenWithBalance;
  onPress?(event: GestureResponderEvent): void;
  isTrade?: boolean;
  style?: StyleProp<ViewStyle>;
  showBalance?: boolean;
}

export function TokenButton({
  token,
  onPress,
  isTrade = false,
  style = {},
  showBalance = true,
}: Props) {
  const chain = useMemo(() => chains.find((chain) => chain.id === token.chainId)!, [token]);
  const { styles: themeStyles, isDarkMode } = useTheme();

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={isNil(onPress)}
      style={[styles.container, themeStyles.cards, style]}
    >
      <TokenLogo chain={chain} token={!token.native ? (token as unknown as Token) : undefined} />

      <View style={styles.details}>
        <Text large bold numberOfLines={1}>
          {isTrade ? token.symbol : token.name}
        </Text>
        <AltHeading style={styles.subText}>
          {isTrade ? token.name : `${formatNumber(token.balance, 4)} ${token.symbol}`}
        </AltHeading>
      </View>

      {showBalance && (
        <Text large bold style={styles.value}>
          {isTrade
            ? `${formatNumber(token.balance, 4)} ${token.symbol}`
            : (token.usdBalance ?? ZERO).gt(0)
            ? formatPrice(token.usdBalance!, false)
            : null}
        </Text>
      )}

      {!showBalance && (isDarkMode ? <IconNextWhite /> : <IconNextBlack />)}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  details: {
    flex: 1,
    marginHorizontal: 15,
  },
  subText: {
    marginTop: 6,
  },
  value: {
    textAlign: 'right',
  },
});
