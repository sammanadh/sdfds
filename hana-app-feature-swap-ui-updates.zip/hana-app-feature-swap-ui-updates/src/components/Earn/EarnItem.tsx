import { IconNextBlack, IconNextWhite } from '@/assets/icons';
import { AltHeading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { chainForChainID, ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';
import { TokenLogo } from '../TokenLogo';

export enum EarnItemType {
  icxStaking,
  icxDApps,
  ethDApps,
}

interface Props {
  type: EarnItemType;
  onPress: () => unknown;
  style?: StyleProp<ViewStyle>;
}

export function EarnItem({ type, onPress, style }: Props) {
  const { isDarkMode } = useTheme();

  const icon = React.useMemo(() => {
    switch (type) {
      case EarnItemType.icxStaking:
        const chain = chainForChainID(ChainID.ICON);
        return chain && <TokenLogo chain={chain} />;
    }
  }, [type]);

  const title = React.useMemo(() => {
    switch (type) {
      case EarnItemType.icxStaking:
        return 'ICON staking';
      case EarnItemType.icxDApps:
        return 'ICON DApps';
      case EarnItemType.ethDApps:
        return 'Ethereum DApps';
    }
  }, [type]);

  const description = React.useMemo(() => {
    switch (type) {
      case EarnItemType.icxStaking:
        return 'Stake ICX and earn rewards';
    }
  }, [type]);

  return (
    <TouchableOpacity onPress={onPress} style={style}>
      <View
        style={[
          styles.container,
          { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards },
        ]}
      >
        <View style={styles.contentContainer}>
          {icon}

          <View style={styles.labels}>
            <Text large bold>
              {title}
            </Text>
            <AltHeading
              style={{
                color: isDarkMode ? colors.gray.subTitleDarkMode : colors.gray.subTitleLightMode,
                marginTop: 6,
              }}
            >
              {description}
            </AltHeading>
          </View>

          {isDarkMode ? <IconNextWhite /> : <IconNextBlack />}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    minHeight: 82,
    padding: 16,
    justifyContent: 'center',
  },
  contentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  labels: {
    marginHorizontal: 15,
    flex: 1,
  },
});
