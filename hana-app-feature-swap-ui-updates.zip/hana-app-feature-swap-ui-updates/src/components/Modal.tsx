import { Button, ButtonVariant } from '@/components/Button';
import { CloseButton } from '@/components/CloseButton';
import { Heading } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import * as NavigationBar from 'expo-navigation-bar';
import { isNil } from 'lodash-es';
import React, { ReactNode, useEffect, useMemo, useRef } from 'react';
import { ColorValue, Platform, StyleSheet, View, ViewStyle } from 'react-native';
import { Modalize, ModalizeProps } from 'react-native-modalize';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export interface ModalFooterButtonProps {
  title: string;
  onPress: () => unknown;
  disabled?: boolean;
  variant?: ButtonVariant;
}

export interface ModalProps extends ModalizeProps {
  open?: boolean;
  title?: string;
  onClose?: () => unknown;
  children?: ReactNode;
  style?: ViewStyle;
  withCloseButton?: boolean;
  confirmButton?: ModalFooterButtonProps;
  cancelButton?: ModalFooterButtonProps;
}

export function Modal({
  open,
  title,
  onClose,
  children,
  style,
  withCloseButton = true,
  confirmButton,
  cancelButton,
  ...props
}: ModalProps) {
  const ref = useRef<Modalize>(null);
  const { isDarkMode, styles: themeStyles } = useTheme();
  const navBarColor = useRef<ColorValue | null>(null);
  const navBarStyle = useRef<'light' | 'dark' | null>(null);
  const insets = useSafeAreaInsets();
  const paddingBottom = useMemo(() => Math.max(insets.bottom, 30), [insets.bottom]);

  const isAndroid = Platform.OS === 'android';

  useEffect(() => {
    if (open) {
      ref.current?.open();
      if (Platform.OS === 'android') {
        NavigationBar.getBackgroundColorAsync().then((color) => {
          navBarColor.current = color;
          NavigationBar.setBackgroundColorAsync(
            isDarkMode ? colors.purple.darkBlacker : colors.white
          );
        });
        NavigationBar.getButtonStyleAsync().then((style) => {
          navBarStyle.current = style;
          NavigationBar.setButtonStyleAsync(isDarkMode ? 'light' : 'dark');
        });
      }
    } else {
      ref.current?.close();
      if (Platform.OS === 'android') {
        if (navBarColor.current) {
          NavigationBar.setBackgroundColorAsync(navBarColor.current);
          navBarColor.current = null;
        }
        if (navBarStyle.current) {
          NavigationBar.setButtonStyleAsync(navBarStyle.current);
          navBarStyle.current = null;
        }
      }
    }
  }, [open]);

  const HeaderComponent = useMemo(
    () => (
      <View style={[styles.header, themeStyles.screen]}>
        <Heading style={styles.title}>{title}</Heading>
        {withCloseButton && <CloseButton onPress={onClose} style={styles.closeButton} />}
      </View>
    ),
    [isDarkMode, title, withCloseButton]
  );

  const FooterComponent = useMemo(() => {
    if (confirmButton && cancelButton) {
      return (
        <View style={[styles.footer, themeStyles.screen, { paddingBottom }]}>
          <Button
            style={{ width: '40%', backgroundColor: colors.gray.cards }}
            textStyle={{ color: colors.black }}
            onPress={cancelButton.onPress}
            disabled={cancelButton.disabled}
          >
            {cancelButton.title}
          </Button>

          <Button
            style={{ flex: 1, marginLeft: 12 }}
            onPress={confirmButton.onPress}
            disabled={confirmButton.disabled}
            variant={confirmButton.variant || ButtonVariant.Primary}
          >
            {confirmButton.title}
          </Button>
        </View>
      );
    }

    if (confirmButton) {
      return (
        <View style={[styles.footer, themeStyles.screen, { paddingBottom }]}>
          <Button
            variant={confirmButton.variant || ButtonVariant.Primary}
            style={{ flex: 1 }}
            onPress={confirmButton.onPress}
            disabled={confirmButton.disabled}
          >
            {confirmButton.title}
          </Button>
        </View>
      );
    }

    return undefined;
  }, [confirmButton, cancelButton]);

  // NOTE: using HeaderComponent and FooterComponent props on Android causes the modal to not scroll
  // properly. Current workaround for Android is to render the header and footer inside the modal content until there is a better solution.
  return (
    <Modalize
      ref={ref}
      withHandle={false}
      adjustToContentHeight
      onClosed={onClose}
      scrollViewProps={{ bounces: false }}
      HeaderComponent={!isAndroid && HeaderComponent}
      rootStyle={{ zIndex: 10 }} // NOTE: Need to make sure toast messages appear above the modal
      FooterComponent={!isAndroid && FooterComponent}
      {...props}
    >
      {isAndroid && HeaderComponent}
      <View style={[styles.container, themeStyles.screen, style]}>
        <View style={{ paddingBottom: !isNil(FooterComponent) ? 20 : paddingBottom }}>
          {children}
        </View>
      </View>
      {isAndroid && FooterComponent}
    </Modalize>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 30,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  title: {
    flex: 1,
    fontSize: formatPixel(22),
    lineHeight: formatPixel(26),
  },
  closeButton: {
    marginRight: -5,
  },
  footer: {
    flexDirection: 'row',
    paddingTop: 20,
    paddingHorizontal: 20,
  },
});
