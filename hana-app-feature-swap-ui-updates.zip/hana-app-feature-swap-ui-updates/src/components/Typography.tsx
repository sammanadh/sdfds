import { useTheme } from '@/stores/Theme';
import { fonts } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import { common } from '@/utils/styles';
import { StyleSheet, Text as RNText, TextProps as RNTextProps } from 'react-native';

export interface TextProps extends RNTextProps {
  bold?: boolean;
  large?: boolean;
  small?: boolean;
  brand?: boolean;
  muted?: boolean;
  danger?: boolean;
  error?: boolean;
  center?: boolean;
  space?: boolean;
}

export function Text({
  bold: isBold = false,
  large: isLarge = false,
  small: isSmall = false,
  brand: isBrand = false,
  muted: isMuted = false,
  danger: isDanger = false,
  error: isError = false,
  center = false,
  space = false,
  style = {},
  ...props
}: TextProps) {
  const { colors } = useTheme();

  return (
    <RNText
      style={[
        styles.text,
        {
          color: isBrand
            ? colors.foregroundHighlight
            : isMuted
            ? colors.foregroundMuted
            : isDanger || isError
            ? colors.negativeDarker
            : colors.foreground,
        },
        isBold && styles.textBold,
        isLarge && styles.textLarge,
        isSmall && styles.textSmall,
        isError && styles.error,
        center && styles.center,
        space && styles.space,
        style,
      ]}
      {...props}
    />
  );
}

interface HeadingProps extends RNTextProps {
  large?: boolean;
  center?: boolean;
}

export function Heading({ large = false, center = false, style = {}, ...props }: HeadingProps) {
  const { colors } = useTheme();

  return (
    <RNText
      style={[
        styles.heading,
        large && styles.headingLarge,
        center && common.centerText,
        { color: colors.foreground },
        style,
      ]}
      {...props}
    />
  );
}

interface AltHeadingProps extends RNTextProps {
  center?: boolean;
}

export function AltHeading({ center = false, style = {}, ...props }: AltHeadingProps) {
  const { colors } = useTheme();

  return (
    <RNText
      style={[
        styles.altHeading,
        center && common.centerText,
        { color: colors.foregroundMuted },
        style,
      ]}
      {...props}
    />
  );
}

export const styles = StyleSheet.create({
  text: {
    fontFamily: fonts.regular,
    fontSize: formatPixel(16),
    lineHeight: formatPixel(20),
  },
  textBold: {
    fontFamily: fonts.semiBold,
  },
  textLarge: {
    fontSize: formatPixel(18),
    lineHeight: formatPixel(22),
  },
  textSmall: {
    fontSize: formatPixel(14),
    lineHeight: formatPixel(18),
  },
  heading: {
    fontFamily: fonts.heavy,
    fontSize: formatPixel(26),
    lineHeight: formatPixel(34),
  },
  headingLarge: {
    fontSize: formatPixel(30),
    lineHeight: formatPixel(38),
  },
  altHeading: {
    fontFamily: fonts.semiBold,
    fontSize: formatPixel(12),
    lineHeight: formatPixel(13),
    letterSpacing: 0.2,
    textTransform: 'uppercase',
  },
  center: {
    ...common.centerText,
    maxWidth: 325,
  },
  error: {
    marginTop: 8,
    marginHorizontal: 21,
  },
  space: {
    marginTop: 15,
  },
});
