import { LogoHanaDarkText, LogoHanaLightText } from '@/assets/logos';
import { ColorSchemeSwitch } from '@/components/ColorSchemeSwitch';
import { Text } from '@/components/Typography';
import * as Application from 'expo-application';
import { View } from 'react-native';

interface Props {
  isDarkMode: boolean;
  showThemeSwitch?: boolean;
}

export function SupportFooter({ isDarkMode, showThemeSwitch = false }: Props) {
  return (
    <View
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginTop: 50,
        },
      ]}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        {isDarkMode ? <LogoHanaDarkText /> : <LogoHanaLightText />}
        <Text muted style={{ marginLeft: 20 }}>
          v{Application.nativeApplicationVersion} ({Application.nativeBuildVersion})
        </Text>
      </View>
      {showThemeSwitch && <ColorSchemeSwitch />}
    </View>
  );
}
