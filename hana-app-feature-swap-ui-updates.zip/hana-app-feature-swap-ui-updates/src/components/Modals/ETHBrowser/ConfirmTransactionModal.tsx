import DownArrowIcon from '@/assets/icons/down-arrow-black.svg';
import DownArrowGrayIcon from '@/assets/icons/down-arrow-gray.svg';
import UpArrowIcon from '@/assets/icons/up-arrow-black.svg';
import UpArrowGrayIcon from '@/assets/icons/up-arrow-gray.svg';
import { AltHeading, Text } from '@/components/Typography';
import { EthereumRequestSignTransaction } from '@/models/EthereumRequest';
import { Wallet } from '@/models/Vault';
import { EthereumService } from '@/services/chainServices/EthereumService';
import { serviceForChainWallet } from '@/stores/ChainServices';
import { usePrices } from '@/stores/Price';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import type { BigNumber } from '@/utils/bignumber';
import { getAuthorizedDApps } from '@/utils/browser';
import { chains } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import {
  convertAndFormatCurrency,
  formatAddress,
  formatAmount,
  formatNumber,
} from '@/utils/format';
import type { EthereumNetworkDetails } from '@/utils/networks';
import { isNil } from 'lodash-es';
import React, { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  Image,
  LayoutChangeEvent,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import Web3 from 'web3';

const COLLAPSE_DURATION = 300;
const MAX_COLLAPSED_HEIGHT = 90;

interface URL_DATA {
  title: string;
  url: string;
}

interface Props {
  urlData?: URL_DATA;
  network: EthereumNetworkDetails;
  payload: EthereumRequestSignTransaction;
  fromWallet: Wallet;
  sourceHost: string;
  onEstimatedFee: (success: boolean) => void;
}

export function ConfirmTransactionModal({
  urlData,
  network,
  payload,
  fromWallet,
  sourceHost,
  onEstimatedFee,
}: Props) {
  const { getNativePriceForNetwork } = usePrices();
  const usdtPrice = getNativePriceForNetwork(network);

  const { isDarkMode, styles: themeStyles } = useTheme();

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  const activeETHWallet = useMemo(() => {
    return activeWallet?.chainWallets.find((w) => w.type === network.chainType);
  }, [activeWallet]);

  const signFrom = payload.params[0].from;

  const isCorrectWallet = useMemo(
    () => activeETHWallet?.address.toLowerCase() === signFrom.toLowerCase(),
    [activeETHWallet, signFrom]
  );

  const chain = chains.find((chain) => chain.id === network.chainType);
  const service = activeETHWallet && (serviceForChainWallet(activeETHWallet) as EthereumService);

  const [estimatedFee, setEstimatedFee] = useState<BigNumber | null>(null);
  const [estimatingError, setEstimatingError] = useState<string | null>(null);
  const [estimatingFee, setEstimatingFee] = useState(true);
  const [txDataCollapsed, setTxDataCollapsed] = useState(true);
  const [txDataMaxHeight, setTxDataMaxHeight] = useState<number | null>(null);
  const [collapseAnim] = useState(new Animated.Value(MAX_COLLAPSED_HEIGHT));

  useEffect(() => {
    if (!isNil(estimatingError)) {
      onEstimatedFee(false);
    } else {
      onEstimatedFee(!isNil(estimatedFee));
    }
  }, [estimatedFee, estimatingError]);

  useEffect(() => {
    setEstimatingError(null);
    setEstimatingFee(true);

    service
      ?.estimateWeb3Transaction(payload.params[0])
      .then((estimate) => setEstimatedFee(estimate.amount.times(estimate.tokenPrice)))
      .catch((error) => {
        console.warn('Failed getting estimated fee.', error.message);
        setEstimatingError(error.message);
      })
      .then(() => setEstimatingFee(false));
  }, [payload]);

  const [image, setImage] = useState<string>();

  useEffect(() => {
    const authrizeDApps = getAuthorizedDApps();
    authrizeDApps?.map((item) => {
      item.host == sourceHost && setImage(item.faviconUrl);
    });
  }, []);

  useLayoutEffect(() => {
    if (!txDataMaxHeight) return;

    const config = {
      toValue: txDataCollapsed ? MAX_COLLAPSED_HEIGHT : txDataMaxHeight,
      duration: COLLAPSE_DURATION,
      useNativeDriver: false,
    };

    Animated.timing(collapseAnim, config).stop();
    Animated.timing(collapseAnim, config).start();
  }, [txDataCollapsed]);

  function getTxDataLayout(event: LayoutChangeEvent) {
    if (txDataMaxHeight == null) {
      setTxDataMaxHeight(event.nativeEvent.layout.height);
    }
  }

  const ethWallet = fromWallet.chainWallets.find((w) => w.type === network.chainType);

  const symbol = React.useMemo(() => {
    return network?.token?.symbol || chain?.token.symbol;
  }, [network]);

  return (
    <View>
      <View
        style={[
          styles.section,
          { paddingTop: 0 },
          isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode },
        ]}
      >
        <Text
          large
          muted
          style={[{ marginBottom: 20 }, isDarkMode && { color: colors.gray.altHeading }]}
        >
          This dApp wants you to sign a transaction
        </Text>
        <View style={isDarkMode ? styles.darkModeinnerContainer : styles.innerContainer}>
          <Image source={{ uri: image }} style={{ width: 40, height: 40 }} />
          <View style={{ flex: 1, marginLeft: 15 }}>
            <Text bold large numberOfLines={1}>
              {sourceHost}
            </Text>
            <AltHeading numberOfLines={1} style={{ marginTop: 6 }}>
              {urlData?.title}
            </AltHeading>
          </View>
        </View>
        {!isNil(estimatingError) && (
          <View style={isDarkMode ? styles.darModeErrorContainer : styles.errorContainer}>
            <View>
              <Text bold large style={isDarkMode && { color: colors.white }}>
                {'Failed estimating fee'}
              </Text>
              <Text style={[{ paddingTop: 4 }, isDarkMode && { color: colors.gray.altHeading }]}>
                {estimatingError}
              </Text>
            </View>
          </View>
        )}

        {!isCorrectWallet && (
          <View style={isDarkMode ? styles.darModeErrorContainer : styles.errorContainer}>
            <View>
                <Text large bold style={isDarkMode && { color: colors.white }}>
                Incorrect Wallet
                </Text>
                <Text style={[{ marginTop: 5 }, isDarkMode && { color: colors.gray.altHeading }]}>
                This dApp is requesting to sign with an address that is not your active wallet.
                </Text>
            </View>
          </View>
        )}

        <AltHeading>From</AltHeading>
        <View style={styles.wallet}>
          <View style={styles.walletDetails}>
            <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
              {fromWallet.name}
            </Text>
            <Text
              small
              muted
              style={[{ fontSize: 15 }, isDarkMode && { color: colors.gray.altHeading }]}
            >
              {ethWallet?.address && formatAddress(ethWallet.address)}
            </Text>
          </View>
          <Text bold style={{ fontSize: 17 }}>
            {formatAmount(ethWallet?.balance || 0)} {symbol}
          </Text>
        </View>
      </View>
      <View
        style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode }]}
      >
        <AltHeading>To</AltHeading>
        <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
          {payload.params[0].to && formatAddress(payload.params[0].to)}
        </Text>
      </View>
      <View
        style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode }]}
      >
        <AltHeading>Sending</AltHeading>
        <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
          {payload.params[0].value
            ? formatAmount(Web3.utils.fromWei(payload.params[0].value, 'ether'))
            : 0}{' '}
          {symbol}
        </Text>
        <Text
          small
          muted
          style={[{ marginTop: 2, fontSize: 15 }, isDarkMode && { color: colors.white }]}
        >
          {convertAndFormatCurrency(
            Web3.utils.fromWei(payload.params[0].value || '0', 'ether'),
            usdtPrice ?? ''
          )}
        </Text>
      </View>
      <View
        style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode }]}
      >
        <AltHeading>Gas</AltHeading>
        <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
          {payload.params[0].gas ? formatNumber(payload.params[0].gas) : 0}
        </Text>
      </View>
      <View
        style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode }]}
      >
        <AltHeading>Estimated Fee</AltHeading>

        {estimatingFee ? (
          <ActivityIndicator
            color={colors.black}
            style={[{ alignSelf: 'flex-start' }, styles.headingGap]}
          />
        ) : !isNil(estimatedFee) ? (
          <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
            {formatNumber(estimatedFee, 5)} {symbol}
          </Text>
        ) : (
          <Text small muted style={[styles.headingGap, { color: colors.gray.altHeading }]}>
            Failed estimating fee
          </Text>
        )}
      </View>
      <View style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.meta }]}>
        <View style={styles.dataHeader}>
          <AltHeading>Tx Data</AltHeading>
          <TouchableOpacity
            onPress={() => setTxDataCollapsed((collapsed) => !collapsed)}
            style={{ flexDirection: 'row', alignItems: 'center' }}
          >
            <Text style={[{ marginRight: 10 }, isDarkMode && { color: colors.gray.altHeading }]}>
              {txDataCollapsed ? 'Expand' : 'Collapse'}
            </Text>
            {txDataCollapsed ? (
              isDarkMode ? (
                <DownArrowGrayIcon style={{ marginTop: 3 }} />
              ) : (
                <DownArrowIcon style={{ marginTop: 3 }} />
              )
            ) : isDarkMode ? (
              <UpArrowGrayIcon style={{ marginTop: 3 }} />
            ) : (
              <UpArrowIcon style={{ marginTop: 3 }} />
            )}
          </TouchableOpacity>
        </View>
        <View style={[styles.dataContainer, styles.headingGap, themeStyles.cards]}>
          <Animated.View
            style={[!isNil(txDataMaxHeight) && { height: collapseAnim, overflow: 'hidden' }]}
          >
            <Text onLayout={getTxDataLayout}>{JSON.stringify(payload.params, null, 2)}</Text>
          </Animated.View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    paddingVertical: 20,
  },
  headingGap: {
    marginTop: 10,
  },
  wallet: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  walletDetails: {
    flex: 1,
    marginRight: 15,
  },
  dataHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dataContainer: {
    padding: 16,
  },
  innerContainer: {
    backgroundColor: colors.gray.cards,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginBottom: 20,
  },
  darkModeinnerContainer: {
    backgroundColor: colors.black,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginBottom: 20,
  },

  errorContainer: {
    backgroundColor: colors.gray.cards,
    flexDirection: 'row',
    alignItems: 'center',
    borderTopColor: colors.gray.border,
    borderBottomColor: colors.gray.border,
    borderRightColor: colors.gray.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.negative,
    marginBottom: 20,
  },
  darModeErrorContainer: {
    backgroundColor: colors.black,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.negative,
    marginBottom: 20,
  },
  error: {
    backgroundColor: colors.gray.cards,
    borderTopColor: colors.gray.border,
    borderBottomColor: colors.gray.border,
    borderRightColor: colors.gray.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.negative,
    marginBottom: 20,
  },
});
