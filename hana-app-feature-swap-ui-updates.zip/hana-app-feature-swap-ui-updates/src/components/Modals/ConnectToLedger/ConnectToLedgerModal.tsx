import { ActivityIndicator } from '@/components/ActivityIndicator';
import { ModalTextItem } from '@/components/ModalTextItem';
import { Text } from '@/components/Typography';
import { LedgerDevice } from '@/models/Ledger';
import { useLedgerStore } from '@/stores/Ledger';
import { useTheme } from '@/stores/Theme';
import { isEmpty } from 'lodash-es';
import { StyleSheet, View } from 'react-native';

interface Props {
  onSelectedDevice: (device: LedgerDevice) => unknown;
}

export function ConnectToLedgerModal({ onSelectedDevice }: Props) {
  const { availableDevices: devices } = useLedgerStore();
  const { colors } = useTheme();

  return (
    <>
      {!isEmpty(devices) ? (
        devices.map((device) => (
          <ModalTextItem
            key={device.id}
            title={device.name}
            onPress={() => onSelectedDevice(device)}
          />
        ))
      ) : (
        <View style={styles.loading}>
          <ActivityIndicator size="small" color={colors.foregroundMuted} />
          <Text muted style={{ marginLeft: 20 }}>
            Searching for devices
          </Text>
        </View>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  loading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: 60,
  },
});
