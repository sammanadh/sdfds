import { Wallet } from '@/models/Vault';
import { useVault } from '@/stores/Vault';
import React from 'react';
import { ChangeWalletModalItem } from './ChangeWalletModalItem';

interface Props {
  onChangedWallet: (wallet: Wallet) => unknown;
}

export function ChangeWalletModal({ onChangedWallet }: Props) {
  const { wallets, selectWallet, refreshWalletBalances } = useVault();

  async function handleSelectWallet(wallet: Wallet) {
    if (!wallet.isActive) {
      await selectWallet(wallet.id);
      refreshWalletBalances();

      onChangedWallet(wallet);
    }
  }

  return (
    <>
      {wallets.map((wallet) => (
        <ChangeWalletModalItem
          key={wallet.id}
          wallet={wallet}
          onPress={() => {
            handleSelectWallet(wallet);
          }}
        />
      ))}
    </>
  );
}
