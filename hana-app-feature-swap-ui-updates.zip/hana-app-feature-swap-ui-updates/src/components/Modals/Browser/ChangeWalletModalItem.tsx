import { Text } from '@/components/Typography';
import { WalletAvatar } from '@/components/WalletAvatar';
import { Wallet } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { colors, fonts } from '@/utils/designTokens';
import { card } from '@/utils/styles';
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

interface Props {
  wallet: Wallet;
  onPress: () => unknown;
}

export function ChangeWalletModalItem({ wallet, onPress }: Props) {
  const { isDarkMode } = useTheme();

  return (
    <TouchableOpacity onPress={onPress} style={{ marginBottom: 15 }}>
      <View
        key={wallet.id}
        style={[
          styles.walletContainer,

          wallet.isActive && styles.walletActive,
          isDarkMode ? !wallet.isActive && { borderColor: 'transparent' } : {},
          { backgroundColor: isDarkMode ? colors.black : colors.gray.cards },
        ]}
      >
        <TouchableOpacity onPress={onPress} style={styles.wallet}>
          <WalletAvatar isUseWalletName wallet={wallet} />
          <View style={styles.walletDetails}>
            <Text
              bold
              numberOfLines={1}
              large
              style={isDarkMode ? styles.walletNameDark : styles.walletName}
            >
              {wallet.name}
            </Text>
          </View>
        </TouchableOpacity>
        {wallet.isActive && (
          <View style={styles.labelSelected}>
            <Text bold style={styles.selected}>
              SELECTED
            </Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  labelSelected: {
    position: 'absolute',
    backgroundColor: colors.offPurple,
    bottom: 0,
    right: 0,
  },
  selected: {
    fontSize: 12,
    color: colors.primary,
    marginHorizontal: 6,
  },

  walletName: {
    color: colors.black,
  },
  walletNameDark: {
    color: '#fff',
  },

  wallet: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  walletContainer: {
    ...card.base,
    padding: 12,
    borderColor: colors.white,
    borderWidth: 3,
    borderRadius: 0,
  },
  walletActive: {
    borderColor: colors.offPurple,
  },
  walletDetails: {
    flex: 1,
    marginLeft: 10,
  },

  footer: {},

  linkTitle: {
    fontSize: 17,
    color: colors.black,
    fontFamily: fonts.semiBold,
    marginTop: 4,
  },
});
