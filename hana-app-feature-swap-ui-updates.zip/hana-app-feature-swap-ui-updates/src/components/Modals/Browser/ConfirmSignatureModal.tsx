import { Button } from '@/components/Button';
import { AltHeading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { getAuthorizedDApps } from '@/utils/browser';
import { ChainID, isSubstrateChain } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { formatAddress } from '@/utils/format';
import { getChainWalletForPolkadotSignerWallet } from '@/utils/polkadot';
import { isNil } from 'lodash-es';
import React, { useEffect, useMemo, useState } from 'react';
import { Image, StyleSheet, View } from 'react-native';

interface Props {
  chain: ChainID;
  data: any;
  signFrom: string;
  sourceHost: string;
  onCancel: () => unknown;
  onConfirm: () => unknown;
}

export function ConfirmSignatureModal({
  chain,
  data,
  signFrom,
  sourceHost,
  onCancel,
  onConfirm,
}: Props) {
  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  const chainWallet = activeWallet && activeWallet.chainWallets.find((w) => w.type === chain);
  const { isDarkMode, colors: themeColors } = useTheme();

  const isCorrectWallet = useMemo(() => {
    if (isSubstrateChain(chain)) {
      const cw = getChainWalletForPolkadotSignerWallet(signFrom);

      return !isNil(cw);
    }

    return chainWallet?.address.toLowerCase() === signFrom.toLowerCase();
  }, [chainWallet, signFrom]);

  const [image, setImage] = useState<string>();
  const [title, setTitle] = useState<string>();

  useEffect(() => {
    const authorizedDApps = getAuthorizedDApps();
    // authrizeDApps?.map((item) => {
    //   item.host == sourceHost && setImage(item.faviconUrl)
    // });

    const dApp = authorizedDApps?.find((item) => item.host == sourceHost);
    setImage(dApp?.faviconUrl);
    setTitle(dApp?.title);
  }, []);

  // Check if data is an ethereum transaction hash
  const isEthereumTransactionHash = useMemo(() => {
    return data?.length === 66 && data?.startsWith('0x');
  }, [data]);

  return (
    <View>
      <View style={styles.container}>
        <Text large muted style={[styles.text, isDarkMode && { color: colors.gray.altHeading }]}>
          This dApp wants you to sign a message
        </Text>
        <View style={[isDarkMode ? styles.darkModeinnerContainer : styles.innerContainer]}>
          <Image source={{ uri: image }} style={styles.image} />
          <View>
            <Text large style={isDarkMode && { color: colors.white }}>
              {sourceHost}
            </Text>
            <Text
              small
              style={[styles.paddingTop, isDarkMode && { color: colors.gray.altHeading }]}
            >
              {title}
            </Text>
          </View>
        </View>

        {!isCorrectWallet && (
          <View
            style={[
              styles.error,
              {
                backgroundColor: themeColors.cards,
                borderColor: themeColors.cards,
                borderLeftColor: themeColors.negative,
              },
            ]}
          >
            <Text large bold>
              Incorrect Wallet
            </Text>
            <Text style={styles.marginTop}>
              This dApp is requesting to sign with an address that is not your active wallet.
            </Text>
          </View>
        )}

        {isEthereumTransactionHash && (
          <View
            style={[
              styles.error,
              {
                backgroundColor: themeColors.cards,
                borderColor: themeColors.cards,
                borderLeftColor: themeColors.negative,
              },
            ]}
          >
            <Text large bold>
              Blind signing
            </Text>
            <Text style={styles.marginTop}>
              Be cautious signing this message. It could potentially perform any operation on your
              account including accessing all the assets. Only sign this message if you know what
              you're experienced and trust this website
            </Text>
          </View>
        )}

        <View style={styles.fromContainer}>
          <AltHeading>From</AltHeading>
          <View style={styles.wallet}>
            <View style={styles.walletDetails}>
              <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
                {activeWallet?.name}
              </Text>
              <Text
                small
                muted
                style={[styles.addressText, isDarkMode && { color: colors.gray.altHeading }]}
              >
                {chainWallet?.address && formatAddress(chainWallet.address)}
              </Text>
            </View>
          </View>
        </View>
        <View style={[styles.divider, { backgroundColor: themeColors.divider }]} />

        <AltHeading style={styles.fromContainer}>DATA</AltHeading>
        <View style={styles.dataContainer}>
          <Text style={[styles.dataText, isDarkMode && { color: colors.white }]}>{data}</Text>
        </View>
      </View>

      <View style={styles.footer}>
        <Button
          style={styles.cancelButtonStyle}
          textStyle={{ color: colors.black }}
          onPress={onCancel}
        >
          Cancel
        </Button>
        <Button onPress={onConfirm} style={styles.signButtonStyle} disabled={!isCorrectWallet}>
          Sign
        </Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingBottom: 20,
  },
  text: { marginBottom: 20 },
  image: { width: 40, height: 40, marginRight: 10 },
  paddingTop: { paddingTop: 4 },
  marginTop: { marginTop: 5 },
  fromContainer: { marginTop: 20 },
  addressText: { fontSize: 15 },
  dataText: { fontSize: 19 },
  cancelButtonStyle: { width: '40%', backgroundColor: colors.gray.cards },
  signButtonStyle: { flex: 1, marginLeft: 12 },
  innerContainer: {
    backgroundColor: colors.gray.cards,
    flexDirection: 'row',
    alignItems: 'center',
    borderTopColor: colors.gray.border,
    borderBottomColor: colors.gray.border,
    borderRightColor: colors.gray.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.gray.border,
  },
  darkModeinnerContainer: {
    backgroundColor: colors.black,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 4,
    padding: 15,
  },
  dataContainer: {
    marginVertical: 10,
  },
  divider: {
    height: StyleSheet.hairlineWidth,
    marginHorizontal: 20,
    marginTop: 20,
  },
  footer: {
    flexDirection: 'row',
  },
  wallet: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  walletDetails: {
    flex: 1,
    marginRight: 15,
  },
  headingGap: {
    marginTop: 10,
    fontSize: 17,
  },
  error: {
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    marginTop: 20,
  },
});
