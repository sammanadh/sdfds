import { Button, ButtonVariant } from '@/components/Button';
import { ModalTextItem } from '@/components/ModalTextItem';
import { Select } from '@/components/Select';
import { AltHeading, Text } from '@/components/Typography';
import { Wallet } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainID, chainForChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { dismissAltModal, presentAltModal } from '@/utils/modal';
import { isEthOrEvmChainID } from '@/utils/networks';
import { isNil } from 'lodash-es';
import React, { useEffect, useMemo } from 'react';
import { Image, StyleSheet, View } from 'react-native';

interface URL_DATA {
  title: string;
  url: string;
}
interface Props {
  sourceHost: string;
  faviconUrl?: string;
  wallet: Wallet;
  onCancel: () => unknown;
  onAuthorize: (selectedChainID?: ChainID | null) => unknown;
  urlData: URL_DATA;
  isEvm?: boolean;
}

export function AuthorizeDAppModal({
  faviconUrl,
  urlData,
  sourceHost,
  wallet,
  onCancel,
  onAuthorize,
  isEvm = false,
}: Props) {
  const { isDarkMode } = useTheme();
  const [selectedChain, setSelectedChain] = React.useState<ChainID | null>(null);

  const { realm, getActiveWallet, getActiveChainWallets } = useVault();

  const activeChainWallets = getActiveChainWallets();
  const activeChainIDs = useMemo(
    () => activeChainWallets.filter((cw) => cw.isActive).map((cw) => cw.type),
    [activeChainWallets]
  );
  const selectableChainIDs = useMemo(() => {
    return activeChainIDs.filter((chainID) => isEthOrEvmChainID(chainID));
  }, [activeChainIDs]);

  const modalContent = React.useMemo(() => {
    return (
      <View style={{ marginTop: 20 }}>
        {selectableChainIDs.map((_chainID) => {
          const chain = chainForChainID(_chainID);
          return (
            <ModalTextItem
              title={chain?.name}
              onPress={() => {
                setSelectedChain(_chainID);
                dismissAltModal();
              }}
              chain={chain}
              isActive={selectedChain === _chainID}
              key={_chainID}
            />
          );
        })}
      </View>
    );
  }, [selectableChainIDs, isDarkMode, selectedChain]);

  useEffect(() => {
    if (isNil(selectedChain)) {
      setSelectedChain(selectableChainIDs[0]);
    }
  }, [selectableChainIDs]);

  return (
    <View style={styles.column}>
      <View style={styles.container}>
        <Text muted style={[styles.text, isDarkMode && { color: colors.white }]}>
          This dApp wants to connect to Hana on{' '}
          <Text large bold>
            {wallet.name}
          </Text>
          . You will be asked to confirm all transactions.
        </Text>
        <View style={isDarkMode ? styles.darkModeinnerContainer : styles.innerContainer}>
          <Image source={{ uri: faviconUrl }} style={styles.image} />
          <View style={{ flex: 1, marginLeft: 15 }}>
            <Text large bold numberOfLines={1}>
              {sourceHost}
            </Text>
            <AltHeading numberOfLines={1} style={{ marginTop: 6 }}>
              {urlData?.title}
            </AltHeading>
          </View>
        </View>
        {isEvm && (
          <>
            <Text small muted style={{ marginTop: 24 }}>
              Default Chain
            </Text>
            <Select
              style={{
                marginTop: 8,
              }}
              placeholder="Chain"
              value={selectedChain ? chainForChainID(selectedChain)?.name : null}
              onPress={() => {
                presentAltModal({
                  title: 'Select a Chain',
                  content: modalContent,
                });
              }}
              chain={chainForChainID(selectedChain!)}
            />
          </>
        )}
      </View>

      <View style={styles.footer}>
        <Button
          style={styles.cancelButtonStyle}
          textStyle={{ color: colors.black }}
          onPress={onCancel}
        >
          Cancel
        </Button>
        <Button
          variant={ButtonVariant.Primary}
          style={styles.authorizeButtonStyle}
          onPress={() => onAuthorize(selectedChain)}
        >
          Authorize
        </Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { paddingBottom: 30 },
  column: {},
  text: {
    marginBottom: 20,
  },
  cancelButtonStyle: { width: '40%', backgroundColor: colors.gray.cards },
  authorizeButtonStyle: { flex: 1, marginLeft: 12 },
  image: { width: 40, height: 40 },
  innerContainer: {
    backgroundColor: colors.gray.cards,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  darkModeinnerContainer: {
    backgroundColor: colors.black,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  footer: {
    flexDirection: 'row',
  },
});
