import { Button, ButtonVariant } from '@/components/Button';
import { Text } from '@/components/Typography';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { StyleSheet, View } from 'react-native';

interface Props {
  sourceHost: string;
  networkName: string;
  onConfirm: () => unknown;
  onCancel: () => unknown;
}

export function ConfirmSwitchNetworkModal({ sourceHost, networkName, onConfirm, onCancel }: Props) {
  return (
    <>
      <View style={styles.container}>
        <View style={styles.innerContainer}>
          <Text>
            {sourceHost} would like to switch your network to <Text bold>{networkName}</Text>.
          </Text>
        </View>
      </View>

      <View style={styles.divider} />

      <View style={styles.footer}>
        <Button
          variant={ButtonVariant.Secondary}
          style={styles.cancelButtonStyle}
          onPress={onCancel}
        >
          Cancel
        </Button>
        <Button
          variant={ButtonVariant.Primary}
          style={styles.confirmButtonStyle}
          onPress={onConfirm}
        >
          Confirm
        </Button>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingBottom: 20,
  },
  innerContainer: {
    backgroundColor: colors.white,
    borderTopColor: colors.gray.border,
    borderBottomColor: colors.gray.border,
    borderRightColor: colors.gray.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.green,
  },
  divider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.gray.border,
    marginHorizontal: 20,
  },
  footer: {
    flexDirection: 'row',
    marginTop: 24,
  },
  cancelButtonStyle: { width: '40%', backgroundColor: colors.gray.cards },
  confirmButtonStyle: { flex: 1, marginLeft: 12 },
});
