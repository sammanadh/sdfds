import { Button, ButtonVariant } from '@/components/Button';
import { Text } from '@/components/Typography';
import { CustomNetwork } from '@/models/Vault';
import { colors } from '@/utils/designTokens';
import { StyleSheet, View } from 'react-native';

interface Props {
  network: CustomNetwork;
  onCancel: () => unknown;
  onConfirm: () => unknown;
}

export function ConfirmDeleteNetworkModal({ network, onCancel, onConfirm }: Props) {
  return (
    <View style={styles.content}>
      <Text>
        You are about to delete the network <Text bold>{network.name}</Text>.
      </Text>

      <View style={styles.footer}>
        <Button
          variant={ButtonVariant.PurpleSecondary}
          style={{ width: '40%', backgroundColor: colors.gray.cards }}
          textStyle={{ color: colors.black }}
          onPress={onCancel}
        >
          Cancel
        </Button>

        <Button
          variant={ButtonVariant.DangerTertiary}
          style={{ flex: 1, marginLeft: 12 }}
          onPress={onConfirm}
        >
          Delete
        </Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  content: {
    flexGrow: 1,
  },
  footer: {
    flexDirection: 'row',
    marginTop: 24,
  },
});
