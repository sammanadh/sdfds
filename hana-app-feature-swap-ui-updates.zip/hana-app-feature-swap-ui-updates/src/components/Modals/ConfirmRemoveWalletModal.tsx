import { Button, ButtonVariant } from '@/components/Button';
import { Text } from '@/components/Typography';
import { Wallet, WalletType } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';

interface Props {
  wallet: Wallet;
  onCancel: () => unknown;
  onConfirm: () => unknown;
}

export function ConfirmRemoveWalletModal({ wallet, onCancel, onConfirm }: Props) {
  const isLedgerWallet = useMemo(() => wallet.type === WalletType.Ledger, [wallet]);
  const removeButtonTitle = `${isLedgerWallet ? 'Disconnect' : 'Remove'}`;
  const { isDarkMode } = useTheme();

  return (
    <>
      <Text large style={[{ marginBottom: 20 }, isDarkMode ? { color: colors.whiteSecond } : {}]}>
        You are about to {isLedgerWallet ? 'disconnect' : 'remove'}{' '}
        <Text large bold>
          {wallet.name}
        </Text>
      </Text>
      {!isLedgerWallet && (
        <Text large style={[isDarkMode ? { color: colors.whiteSecond } : {}]}>
          Ensure you have backed up this wallet before continuing to avoid a loss of funds.
        </Text>
      )}

      <View style={styles.footer}>
        <Button
          style={{ width: '40%', backgroundColor: colors.gray.cards }}
          textStyle={{ color: colors.black }}
          variant={ButtonVariant.PurpleSecondary}
          onPress={onCancel}
        >
          Cancel
        </Button>
        <Button
          variant={ButtonVariant.Primary}
          style={{ flex: 1, marginLeft: 12, backgroundColor: '#fabdcf' }}
          onPress={onConfirm}
          textStyle={{ color: colors.black }}
        >
          {removeButtonTitle}
        </Button>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  footer: {
    flexDirection: 'row',
    marginTop: 24,
  },
});
