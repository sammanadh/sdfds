import { IconMinus, IconMinusWhite, IconPlus, IconPlusWhite } from '@/assets/icons';
import NetworkManageIcon from '@/assets/icons/network.svg';
import { TextButton } from '@/components/TextButton';
import { Text } from '@/components/Typography';
import { CustomNetwork } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { ChainDetails, ChainID, chains, isAffiliatedChain, testnetChainIds } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { getCustomNetworksForChain, TestnetConfig, testnets } from '@/utils/networks';
import { useNavigation } from '@react-navigation/native';
import { isNil, pick } from 'lodash-es';
import React, { useEffect, useMemo, useState } from 'react';
import { LayoutAnimation, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import { ChangeNetworkModalItem } from './ChangeNetworkModalItem';

interface Props {
  onClose: () => unknown;
}

export function ChangeNetworkModal({ onClose }: Props) {
  const { navigate } = useNavigation();
  const { setHideTabBar } = useNavigationStore();
  const { otherNetwork, selectOtherNetwork, connectedChains } = useChainServices();

  const { isDarkMode } = useTheme();

  const [expandedChainIDs, setExpandedChainIDs] = useState<ChainID[]>([]);

  const connectedChainIDs = useMemo(() => {
    return connectedChains.map((chain) => chain.id);
  }, [connectedChains]);

  useEffect(() => {
    // Testnet
    if ((otherNetwork as TestnetConfig)?.chainType) {
      const testnet = otherNetwork as TestnetConfig;
      if (!expandedChainIDs.includes(testnet.chainType)) {
        setExpandedChainIDs([testnet.chainType, ...expandedChainIDs]);
      }
    }

    // Custom network
    if ((otherNetwork as CustomNetwork)?.id) {
      const customNetwork = otherNetwork as CustomNetwork;
      if (!expandedChainIDs.includes(customNetwork.chain)) {
        setExpandedChainIDs([customNetwork.chain, ...expandedChainIDs]);
      }
    }
  }, [otherNetwork]);

  return (
    <ScrollView
      bounces={false}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
    >
      <ChangeNetworkModalItem
        label="Mainnet"
        onPress={() => {
          selectOtherNetwork(null);
          onClose();
        }}
        selected={isNil(otherNetwork)}
        style={styles.marginBottom}
        isDarkMode={isDarkMode}
      />
      {Object.keys(testnets)
        .filter(
          (chainId) =>
            (connectedChainIDs.includes(chainId as ChainID) ||
              (otherNetwork as TestnetConfig)?.chainType === chainId ||
              testnetChainIds.includes(chainId as ChainID)) &&
            !isAffiliatedChain(chainId as ChainID)
        )
        .map((chainId, index) => {
          const chain = chains.find((chain) => chain.id === chainId)!;

          const expanded = expandedChainIDs.includes(chain.id);

          return (
            <View key={`${chain.id}-${index}`} style={styles.marginTop}>
              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />
              <TouchableOpacity
                onPress={() => {
                  LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
                  if (expanded) {
                    setExpandedChainIDs(expandedChainIDs.filter((chainID) => chainID !== chain.id));
                  } else {
                    setExpandedChainIDs([chain.id, ...expandedChainIDs]);
                  }
                }}
              >
                <View style={styles.chainHeader}>
                  <Text large bold style={styles.chainLabel}>
                    {chain.name}
                  </Text>

                  {expanded ? (
                    isDarkMode ? (
                      <IconMinusWhite height={20} width={20} />
                    ) : (
                      <IconMinus height={20} width={20} />
                    )
                  ) : isDarkMode ? (
                    <IconPlusWhite height={20} width={20} />
                  ) : (
                    <IconPlus height={20} width={20} />
                  )}
                </View>
              </TouchableOpacity>
              {expanded &&
                testnets[chain.id]!.map((network, index) => {
                  return (
                    <ChangeNetworkModalItem
                      label={network.name}
                      key={`${network.name}-${index}`}
                      onPress={() => {
                        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
                        const testnetConfig: TestnetConfig = pick(network, ['chainType', 'ref']);
                        selectOtherNetwork(testnetConfig);

                        onClose();
                      }}
                      selected={(otherNetwork as TestnetConfig)?.ref === network.ref}
                      isDarkMode={isDarkMode}
                    />
                  );
                })}

              {expanded &&
                getCustomNetworksForChain(chain.id)?.map((network, index) => {
                  return (
                    <ChangeNetworkModalItem
                      label={network.name}
                      key={`${network.name}-${index}`}
                      onPress={() => {
                        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
                        selectOtherNetwork(network);

                        onClose();
                      }}
                      selected={(otherNetwork as CustomNetwork)?.id === network.id}
                      isDarkMode={isDarkMode}
                    />
                  );
                })}
            </View>
          );
        })}

      <TextButton
        prefix={<NetworkManageIcon color={colors.gray.meta} width={18} height={18} />}
        center
        style={[styles.manageButton, isDarkMode && { borderColor: colors.black }]}
        textStyle={styles.manageButtonText}
        onPress={() => {
          onClose();
          setHideTabBar(true);
          // @ts-expect-error not worth mapping navigation props to here
          navigate('ManageCustomNetworks');
        }}
      >
        Manage custom networks
      </TextButton>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  chainLabel: {
    flex: 1,
    lineHeight: 21,
  },
  chainHeader: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.gray.border,
    marginTop: 2,
    marginBottom: 30,
  },
  marginBottom: { marginBottom: 8 },
  marginTop: { marginTop: 20 },
  manageButton: {
    width: '100%',
    height: 50,
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.gray.cards,
    marginTop: 40,
  },
  manageButtonText: {
    color: colors.gray.meta,
  },
});
