import { Text } from '@/components/Typography';
import { colors, fonts } from '@/utils/designTokens';
import React from 'react';
import { StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';

interface Props {
  label: string;
  onPress: () => unknown;
  selected?: boolean;
  style?: ViewStyle;
  isDarkMode?: boolean;
}

export function ChangeNetworkModalItem({
  label,
  onPress,
  selected = false,
  style,
  isDarkMode,
}: Props) {
  return (
    <TouchableOpacity onPress={onPress} style={[style]}>
      <View
        style={[
          styles.container,
          { ...(selected ? styles.containerSelected : {}) },
          isDarkMode && { backgroundColor: colors.black },
        ]}
      >
        <Text bold style={[styles.label, isDarkMode && { color: colors.whiteSecond }]}>
          {label}
        </Text>

        {selected && (
          <View style={styles.labelSelected}>
            <Text style={styles.selected}>SELECTED</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.gray.cards,
    alignItems: 'center',
    paddingHorizontal: 20,
    flexDirection: 'row',
    marginTop: 10,
  },
  containerSelected: {
    backgroundColor: colors.gray.cards,
    borderStyle: 'solid',
    borderWidth: 2,
    borderColor: colors.offPurple,
  },
  label: {
    fontSize: 15,
    color: '#120f10',
    flex: 1,
  },
  labelSelected: {
    position: 'absolute',
    backgroundColor: colors.offPurple,
    bottom: 0,
    right: 20,
  },
  selected: {
    fontSize: 12,
    color: colors.primary,
    marginHorizontal: 8,
    marginTop: 4,
    lineHeight: 13,
    letterSpacing: 0.2,
  },
});
