import { Button } from '@/components/Button';
import { Text } from '@/components/Typography';
import { ChainWallet } from '@/models/Vault';
import { useLedgerStore } from '@/stores/Ledger';
import { getLedgerAppName } from '@/utils/ledger';
import React from 'react';
import { StyleSheet } from 'react-native';

interface Props {
  chainWallet: ChainWallet;
  onConnectToLedger: () => unknown;
}

export function ConfirmLedgerTransactionModal({ chainWallet, onConnectToLedger }: Props) {
  const { connectingToLedger } = useLedgerStore();

  return (
    <>
      <Text style={styles.message}>
        Check the transaction displayed on your device and confirm (or reject) it to continue. Make
        sure your Ledger is unlocked with the {getLedgerAppName(chainWallet.type)} app open.
      </Text>

      <Button onPress={onConnectToLedger} working={connectingToLedger}>
        Connect to Ledger
      </Button>
    </>
  );
}

const styles = StyleSheet.create({
  message: {
    marginBottom: 28,
  },
});
