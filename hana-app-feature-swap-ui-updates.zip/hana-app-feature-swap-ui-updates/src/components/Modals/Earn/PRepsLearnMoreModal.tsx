import { TextButton } from '@/components/TextButton';
import { Text } from '@/components/Typography';
import { colors, fonts } from '@/utils/designTokens';
import * as WebBrowser from 'expo-web-browser';
import React from 'react';

interface Props {
  isDarkMode: boolean;
}

export function PRepsLearnMoreModal({ isDarkMode }: Props) {
  function handleAnchorClick() {
    WebBrowser.openBrowserAsync('https://iconpreps.com');
  }

  return (
    <>
      <Text large style={[isDarkMode && { color: colors.gray.watermark }]}>
        As an owner of ICX, you can allocate votes to P-Reps on the ICON network to earn additional
        ICX rewards known as I-Score.
      </Text>
      <Text space large style={[isDarkMode && { color: colors.gray.watermark }]}>
        Public Representatives (P-Reps) are teams that are actively working to expand the ICON
        ecosystem.
      </Text>
      <Text space large style={[isDarkMode && { color: colors.gray.watermark }]}>
        Different teams focus on different areas of growing the ICON ecosystem, such as application
        and tool development, infrastructure, marketing, education, community engagement etc.
      </Text>
      <Text space large style={[isDarkMode && { color: colors.gray.watermark }]}>
        You can search through the list to discover P-Reps that you think are delivering value for
        ICON, and allocate them your votes.
      </Text>
      <Text space large style={[isDarkMode && { color: colors.gray.watermark }]}>
        Remember, when allocating votes your ICX is “staked” to the ICON network and there is a
        mandatory 5-20 days waiting period to unstake it.
      </Text>
      <Text space large style={[, isDarkMode && { color: colors.gray.watermark }]}>
        Once you’ve allocated votes you will start to earn rewards daily.
      </Text>
    </>
  );
}
