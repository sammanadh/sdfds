import CheckCircleIcon from '@/assets/icons/check-circle.svg';
import { Text } from '@/components/Typography';
import { GasPriceOption } from '@/models/GasPriceOption';
import { useTheme } from '@/stores/Theme';
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

interface Props {
  options: GasPriceOption[];
  selectedOption?: GasPriceOption | null;
  onSelectedOption?: (option: GasPriceOption) => unknown;
}

export function SelectGasPriceModal({ options, selectedOption, onSelectedOption }: Props) {
  const { styles: themeStyles } = useTheme();

  return (
    <View>
      {options.map((option) => {
        return (
          <TouchableOpacity
            key={option.label}
            style={[styles.container, themeStyles.cards, { marginBottom: 12 }]}
            onPress={() => {
              onSelectedOption && onSelectedOption(option);
            }}
          >
            <View style={{ flex: 1, paddingLeft: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View style={{ flexDirection: 'column', width: '60%' }}>
                  <Text>{option?.label}</Text>
                  {option?.label === 'Advanced' ? (
                    <Text small muted>
                      Set gas price manually
                    </Text>
                  ) : (
                    <Text small muted>
                      ~ {option?.estimatedWait?.toString()} seconds wait
                    </Text>
                  )}
                </View>
                <View style={{ flex: 1, alignItems: 'flex-end' }}>
                  {option.price && (
                    <Text small muted>
                      {option?.price?.toFixed(0)} GWEI
                    </Text>
                  )}
                </View>
                <View style={{ width: 30, marginLeft: 12 }}>
                  {selectedOption?.label === option.label && <CheckCircleIcon width={26} />}
                </View>
              </View>
            </View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 56,
    borderRadius: 28,
    paddingLeft: 10,
    paddingRight: 20,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
  },
});
