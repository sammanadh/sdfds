import DownArrowIcon from '@/assets/icons/down-arrow-black.svg';
import DownArrowGrayIcon from '@/assets/icons/down-arrow-gray.svg';
import UpArrowIcon from '@/assets/icons/up-arrow-black.svg';
import UpArrowGrayIcon from '@/assets/icons/up-arrow-gray.svg';
import { AltHeading, Text } from '@/components/Typography';
import { Wallet } from '@/models/Vault';
import { ICONService } from '@/services/chainServices/IconService';
import { serviceForChainWallet } from '@/stores/ChainServices';
import { usePrices } from '@/stores/Price';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import type { BigNumber } from '@/utils/bignumber';
import { getAuthorizedDApps } from '@/utils/browser';
import { ChainID } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import { convertIcxToUsdt, convertLoopToToken } from '@/utils/conversion';
import { colors } from '@/utils/designTokens';
import { formatAddress, formatAmount, formatNumber } from '@/utils/format';
import { IconNetworkDetails } from '@/utils/networks';
import { isNil } from 'lodash-es';
import React, { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  Image,
  LayoutChangeEvent,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';

const COLLAPSE_DURATION = 300;
const MAX_COLLAPSED_HEIGHT = 90;

interface URL_DATA {
  title: string;
  url: string;
}

interface Props {
  urlData?: URL_DATA;
  payload: any;
  fromWallet: Wallet;
  sourceHost: string;
  onEstimatedFee: (success: boolean) => void;
}

export function ConfirmTransactionModal({
  urlData,
  payload,
  fromWallet,
  sourceHost,
  onEstimatedFee,
}: Props) {
  const { getNativePriceForSymbol } = usePrices();
  const usdtPrice = getNativePriceForSymbol('ICX');

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  const activeICXWallet = useMemo(() => {
    return activeWallet?.chainWallets.find((w) => w.type === ChainID.ICON);
  }, [activeWallet]);

  const {
    params: { from },
  } = payload;

  const isCorrectWallet = useMemo(() => {
    return activeICXWallet?.address.toLowerCase() === from.toLowerCase();
  }, [activeICXWallet, from]);

  const service = activeICXWallet && (serviceForChainWallet(activeICXWallet) as ICONService);
  const network = service ? (service?.getNetworkDetails() as IconNetworkDetails) : undefined;

  const [estimatedFee, setEstimatedFee] = useState<BigNumber | null>(null);
  const [estimatingFee, setEstimatingFee] = useState(true);
  const [estimatingError, setEstimatingError] = useState<string | null>(null);
  const [txDataCollapsed, setTxDataCollapsed] = useState(true);
  const [txDataMaxHeight, setTxDataMaxHeight] = useState<number | null>(null);
  const [collapseAnim] = useState(new Animated.Value(MAX_COLLAPSED_HEIGHT));

  useEffect(() => {
    if (!isNil(estimatingError)) {
      onEstimatedFee(false);
    } else {
      onEstimatedFee(!isNil(estimatedFee));
    }
  }, [estimatedFee, estimatingError]);

  useEffect(() => {
    setEstimatingError(null);
    setEstimatingFee(true);
    service
      ?.getEstimatedFee(payload)
      .then((estimatedFee) => setEstimatedFee(estimatedFee))
      .catch((error) => {
        console.warn('Failed getting estimated fee.', error.message);
        setEstimatingError(error.message);
      })
      .then(() => setEstimatingFee(false));
  }, [payload]);

  useLayoutEffect(() => {
    if (!txDataMaxHeight) return;

    const config = {
      toValue: txDataCollapsed ? MAX_COLLAPSED_HEIGHT : txDataMaxHeight,
      duration: COLLAPSE_DURATION,
      useNativeDriver: false,
    };

    Animated.timing(collapseAnim, config).stop();
    Animated.timing(collapseAnim, config).start();
  }, [txDataCollapsed]);

  function getTxDataLayout(event: LayoutChangeEvent) {
    if (txDataMaxHeight == null) {
      setTxDataMaxHeight(event.nativeEvent.layout.height);
    }
  }

  const icxWallet = fromWallet.chainWallets.find((w) => w.type === ChainID.ICON);
  const { isDarkMode, styles: themeStyles } = useTheme();

  const [image, setImage] = useState<string>();
  useEffect(() => {
    const authrizeDApps = getAuthorizedDApps();
    authrizeDApps?.map((item) => {
      item.host == sourceHost && setImage(item.faviconUrl);
    });
  }, []);

  return (
    <View>
      <View
        style={[
          styles.section,
          { paddingTop: 0 },
          isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode },
        ]}
      >
        <Text
          large
          muted
          style={[{ marginBottom: 20 }, isDarkMode && { color: colors.gray.altHeading }]}
        >
          This dApp wants you to sign a transaction
        </Text>
        <View style={isDarkMode ? styles.darkModeinnerContainer : styles.innerContainer}>
          <Image source={{ uri: image }} style={{ width: 40, height: 40 }} />
          <View style={{ flex: 1, marginLeft: 15 }}>
            <Text large bold numberOfLines={1}>
              {sourceHost}
            </Text>
            <AltHeading numberOfLines={1} style={{ marginTop: 6 }}>
              {urlData?.title}
            </AltHeading>
          </View>
        </View>
        {!isNil(estimatingError) && (
          <View style={isDarkMode ? styles.darModeErrorContainer : styles.errorContainer}>
            <View>
              <Text large bold style={isDarkMode && { color: colors.white }}>
                {'Failed estimating fee'}
              </Text>
              <Text style={[{ paddingTop: 4 }, isDarkMode && { color: colors.gray.altHeading }]}>
                {'This transaction is likely to fail because fee estimation returned an error.'}
                {'\n'}
                {'Error:'} {estimatingError}
              </Text>
            </View>
          </View>
        )}

        {!isCorrectWallet && (
          <View style={isDarkMode ? styles.darModeErrorContainer : styles.errorContainer}>
            <View>
                <Text large bold>
                Incorrect Wallet
                </Text>
                <Text style={[{ marginTop: 5 }, isDarkMode && { color: colors.gray.altHeading }]}>
                This dApp is requesting to sign with an address that is not your active wallet.
                </Text>
            </View>
          </View>
        )}

        <AltHeading>From</AltHeading>
        <View style={styles.wallet}>
          <View style={styles.walletDetails}>
            <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
              {fromWallet.name}
            </Text>
            <Text
              small
              muted
              style={[{ fontSize: 15 }, isDarkMode && { color: colors.gray.altHeading }]}
            >
              {icxWallet?.address && formatAddress(icxWallet.address)}
            </Text>
          </View>
          <Text bold style={{ fontSize: 17 }}>
            {formatAmount(icxWallet?.balance || 0)} ICX
          </Text>
        </View>
      </View>
      <View
        style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode }]}
      >
        <AltHeading>To</AltHeading>
        <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
          {formatAddress(payload.params.to)}
        </Text>
      </View>
      <View
        style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode }]}
      >
        <AltHeading>Sending</AltHeading>
        <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
          {payload.params.value ? formatAmount(convertLoopToToken(payload.params.value)) : 0} ICX
        </Text>
        <Text
          small
          muted
          style={[{ marginTop: 2, fontSize: 15 }, isDarkMode && { color: colors.white }]}
        >
          $
          {payload.params.value
            ? convertIcxToUsdt(convertLoopToToken(payload.params.value) || ZERO, usdtPrice)
            : 0}{' '}
          USD
        </Text>
      </View>
      <View
        style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode }]}
      >
        <AltHeading>Step Limit</AltHeading>
        <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
          {payload.params.stepLimit ? formatNumber(payload.params.stepLimit) : 0}
        </Text>
      </View>
      <View
        style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.breakLineDarkMode }]}
      >
        <AltHeading>Estimated Fee</AltHeading>
        {estimatingFee ? (
          <ActivityIndicator
            color={colors.black}
            style={[{ alignSelf: 'flex-start' }, styles.headingGap]}
          />
        ) : !isNil(estimatedFee) ? (
          <Text style={[styles.headingGap, isDarkMode && { color: colors.white }]}>
            {formatAmount(convertLoopToToken(estimatedFee))} ICX
          </Text>
        ) : (
          <Text small muted style={[styles.headingGap, { color: colors.gray.altHeading }]}>
            Failed estimating fee
          </Text>
        )}
      </View>
      <View style={[styles.section, isDarkMode && { borderBottomColor: colors.gray.meta }]}>
        <View style={styles.dataHeader}>
          <AltHeading>Tx Data</AltHeading>
          <TouchableOpacity
            onPress={() => setTxDataCollapsed((collapsed) => !collapsed)}
            style={{ flexDirection: 'row', alignItems: 'center' }}
          >
            <Text style={[{ marginRight: 10 }, isDarkMode && { color: colors.gray.altHeading }]}>
              {txDataCollapsed ? 'Expand' : 'Collapse'}
            </Text>
            {txDataCollapsed ? (
              isDarkMode ? (
                <DownArrowGrayIcon style={{ marginTop: 3 }} />
              ) : (
                <DownArrowIcon style={{ marginTop: 3 }} />
              )
            ) : isDarkMode ? (
              <UpArrowGrayIcon style={{ marginTop: 3 }} />
            ) : (
              <UpArrowIcon style={{ marginTop: 3 }} />
            )}
          </TouchableOpacity>
        </View>
        <View style={[styles.dataContainer, styles.headingGap, themeStyles.cards]}>
          <Animated.View
            style={[!isNil(txDataMaxHeight) && { height: collapseAnim, overflow: 'hidden' }]}
          >
            <Text style={isDarkMode && { color: colors.white }} onLayout={getTxDataLayout}>
              {JSON.stringify(payload.params, null, 2)}
            </Text>
          </Animated.View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    paddingVertical: 20,
  },
  headingGap: {
    marginTop: 10,
    fontSize: 17,
  },
  wallet: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  walletDetails: {
    flex: 1,
    marginRight: 15,
  },
  dataHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dataContainer: {
    padding: 16,
  },
  innerContainer: {
    backgroundColor: colors.gray.cards,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 4,
    padding: 16,
    marginBottom: 20,
  },
  darkModeinnerContainer: {
    backgroundColor: colors.black,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginBottom: 20,
  },
  errorContainer: {
    backgroundColor: colors.gray.cards,
    flexDirection: 'row',
    alignItems: 'center',
    borderTopColor: colors.gray.border,
    borderBottomColor: colors.gray.border,
    borderRightColor: colors.gray.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.negative,
    marginBottom: 20,
  },
  darModeErrorContainer: {
    backgroundColor: colors.black,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.negative,
    marginBottom: 20,
  },
  error: {
    backgroundColor: colors.gray.cards,
    borderTopColor: colors.gray.border,
    borderBottomColor: colors.gray.border,
    borderRightColor: colors.gray.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.negative,
    marginBottom: 20,
  },
});
