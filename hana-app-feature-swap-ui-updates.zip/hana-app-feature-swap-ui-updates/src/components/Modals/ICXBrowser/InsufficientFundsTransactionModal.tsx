import DownArrowIcon from '@/assets/icons/down-arrow-black.svg';
import UpArrowIcon from '@/assets/icons/up-arrow-black.svg';
import { Button, ButtonVariant } from '@/components/Button';
import { AltHeading, Text } from '@/components/Typography';
import { ChainWallet } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { convertLoopToToken } from '@/utils/conversion';
import { colors } from '@/utils/designTokens';
import { formatAmount } from '@/utils/format';
import { isNil } from 'lodash-es';
import React, { useLayoutEffect, useState } from 'react';
import { Animated, LayoutChangeEvent, StyleSheet, TouchableOpacity, View } from 'react-native';

const COLLAPSE_DURATION = 300;
const MAX_COLLAPSED_HEIGHT = 90;

interface Props {
  payload: any;
  wallet: ChainWallet;
  onCancel: () => unknown;
}

export function InsufficientFundsTransactionModal({ payload, wallet, onCancel }: Props) {
  const [txDataCollapsed, setTxDataCollapsed] = useState(true);
  const [txDataMaxHeight, setTxDataMaxHeight] = useState<number | null>(null);
  const [collapseAnim] = useState(new Animated.Value(MAX_COLLAPSED_HEIGHT));

  function getTxDataLayout(event: LayoutChangeEvent) {
    if (txDataMaxHeight == null) {
      setTxDataMaxHeight(event.nativeEvent.layout.height);
    }
  }

  useLayoutEffect(() => {
    if (!txDataMaxHeight) return;

    const config = {
      toValue: txDataCollapsed ? MAX_COLLAPSED_HEIGHT : txDataMaxHeight,
      duration: COLLAPSE_DURATION,
      useNativeDriver: false,
    };

    Animated.timing(collapseAnim, config).stop();
    Animated.timing(collapseAnim, config).start();
  }, [txDataMaxHeight, txDataCollapsed]);

  const { styles: themeStyles } = useTheme();

  return (
    <>
      <View style={styles.container}>
        <View style={styles.innerContainer}>
          <Text>
            <Text>This site is requesting a transaction of </Text>
            <Text bold>{formatAmount(convertLoopToToken(payload.params.value))} ICX</Text>
            <Text> but you only have </Text>
            <Text bold>{formatAmount(wallet.balance)} ICX</Text>
            <Text> available.</Text>
          </Text>
          <Text bold style={[{ marginTop: 3 }]}>
            You cannot proceed with this transaction.
          </Text>
        </View>
      </View>

      <View style={styles.dataHeader}>
        <AltHeading>Tx data</AltHeading>
        <TouchableOpacity
          onPress={() => setTxDataCollapsed((collapsed) => !collapsed)}
          style={{ flexDirection: 'row', alignItems: 'center' }}
        >
          <Text style={{ marginRight: 10 }}>{txDataCollapsed ? 'Expand' : 'Collapse'}</Text>
          {txDataCollapsed ? (
            <DownArrowIcon style={{ marginTop: 3 }} />
          ) : (
            <UpArrowIcon style={{ marginTop: 3 }} />
          )}
        </TouchableOpacity>
      </View>
      <View style={[styles.dataContainer, themeStyles.cards]}>
        <Animated.View
          style={[!isNil(txDataMaxHeight) && { height: collapseAnim, overflow: 'hidden' }]}
        >
          <Text onLayout={getTxDataLayout}>{JSON.stringify(payload.params, null, 2)}</Text>
        </Animated.View>
      </View>

      <View style={styles.divider} />

      <View style={styles.footer}>
        <Button variant={ButtonVariant.Primary} style={{ flex: 1 }} onPress={onCancel}>
          Cancel transaction
        </Button>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingBottom: 20,
  },
  innerContainer: {
    backgroundColor: colors.white,
    borderTopColor: colors.gray.border,
    borderBottomColor: colors.gray.border,
    borderRightColor: colors.gray.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.red,
  },
  dataHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  dataContainer: {
    padding: 16,
    marginTop: 10,
    marginBottom: 20,
  },
  divider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.gray.border,
    marginHorizontal: 20,
  },
  footer: {
    flexDirection: 'row',
    marginTop: 24,
  },
});
