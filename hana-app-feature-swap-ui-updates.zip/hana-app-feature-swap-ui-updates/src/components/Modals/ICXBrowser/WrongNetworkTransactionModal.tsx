import DownArrowIcon from '@/assets/icons/down-arrow-black.svg';
import UpArrowIcon from '@/assets/icons/up-arrow-black.svg';
import { AltHeading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { IconNetworkDetails } from '@/utils/networks';
import IconSDK from 'icon-sdk-js';
import { isNil } from 'lodash-es';
import React, { useLayoutEffect, useState } from 'react';
import { Animated, LayoutChangeEvent, StyleSheet, TouchableOpacity, View } from 'react-native';

const { IconConverter } = IconSDK;

const COLLAPSE_DURATION = 300;
const MAX_COLLAPSED_HEIGHT = 90;

interface Props {
  payload: any;
  network: IconNetworkDetails;
  onCancel: () => unknown;
}

export function WrongNetworkTransactionModal({ payload, network, onCancel }: Props) {
  const [txDataCollapsed, setTxDataCollapsed] = useState(true);
  const [txDataMaxHeight, setTxDataMaxHeight] = useState<number | null>(null);
  const [collapseAnim] = useState(new Animated.Value(MAX_COLLAPSED_HEIGHT));

  function getTxDataLayout(event: LayoutChangeEvent) {
    if (txDataMaxHeight == null) {
      setTxDataMaxHeight(event.nativeEvent.layout.height);
    }
  }

  useLayoutEffect(() => {
    if (!txDataMaxHeight) return;

    const config = {
      toValue: txDataCollapsed ? MAX_COLLAPSED_HEIGHT : txDataMaxHeight,
      duration: COLLAPSE_DURATION,
      useNativeDriver: false,
    };

    Animated.timing(collapseAnim, config).stop();
    Animated.timing(collapseAnim, config).start();
  }, [txDataMaxHeight, txDataCollapsed]);

  const { isDarkMode, styles: themeStyles } = useTheme();

  return (
    <>
      <View style={styles.container}>
        <View style={[styles.innerContainer, isDarkMode && { backgroundColor: colors.black }]}>
          <Text style={isDarkMode && { color: 'white' }}>
            This site is requesting a transaction on network{' '}
            {IconConverter.toNumber(payload.params.nid)} but you are configured to use network{' '}
            {network.networkId} ({network.name}).
          </Text>
          <Text bold style={[{ marginTop: 3 }, isDarkMode && { color: 'white' }]}>
            You cannot proceed with this transaction.
          </Text>
        </View>
      </View>
      <View style={styles.dataHeader}>
        <AltHeading style={{ marginVertical: 10 }}>Tx data</AltHeading>
        <TouchableOpacity
          onPress={() => setTxDataCollapsed((collapsed) => !collapsed)}
          style={{ flexDirection: 'row', alignItems: 'center' }}
        >
          <Text style={[{ marginRight: 10 }, isDarkMode && { color: colors.white }]}>
            {txDataCollapsed ? 'Expand' : 'Collapse'}
          </Text>
          {txDataCollapsed ? (
            <DownArrowIcon style={{ marginTop: 3 }} />
          ) : (
            <UpArrowIcon style={{ marginTop: 3 }} />
          )}
        </TouchableOpacity>
      </View>
      <View style={[styles.dataContainer, themeStyles.cards]}>
        <Animated.View
          style={[!isNil(txDataMaxHeight) && { height: collapseAnim, overflow: 'hidden' }]}
        >
          <Text style={[isDarkMode && { color: colors.white }]} onLayout={getTxDataLayout}>
            {JSON.stringify(payload.params, null, 2)}
          </Text>
        </Animated.View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingBottom: 20,
  },
  innerContainer: {
    backgroundColor: colors.gray.cards,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.negative,
  },
  dataHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dataContainer: {
    padding: 16,
  },
});
