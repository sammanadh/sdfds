import { Button, ButtonSize } from '@/components/Button';
import { ToastType } from '@/components/Toast.types';
import { AltHeading, Text } from '@/components/Typography';
import { Wallet, WalletType } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { ChainID } from '@/utils/chains';
import { formatAddress } from '@/utils/format';
import Clipboard from '@react-native-clipboard/clipboard';
import { isNil } from 'lodash-es';
import React, { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';

interface Props {
  wallet: Wallet;
  onConnectLedger: (chainId: ChainID) => unknown;
}

export function WalletAddressesModal({ wallet, onConnectLedger }: Props) {
  const { connectedChains } = useChainServices();
  const { setToastMessage } = useNavigationStore();
  const { colors } = useTheme();

  const isLedgerWallet = useMemo(() => wallet.type === WalletType.Ledger, [wallet]);

  return (
    <>
      {connectedChains.map((chain, index) => {
        const chainWallet = wallet.chainWallets.find((w) => w.type === chain.id);
        const hasChainWallet = !isNil(chainWallet);

        return (
          <View
            key={chain.id}
            style={[
              styles.item,
              { backgroundColor: colors.background, borderColor: colors.gray.meta },
            ]}
          >
            <View>
              <AltHeading>{chain.name} address</AltHeading>
              <Text>
                {hasChainWallet
                  ? formatAddress(chainWallet.address)
                  : isLedgerWallet
                  ? chain.supportsLedger === false
                    ? 'Not supported'
                    : 'Not connected'
                  : 'No address'}
              </Text>
            </View>
            {hasChainWallet ? (
              <Button
                size={ButtonSize.Tiny}
                style={{ width: 56, backgroundColor: colors.offPurple }}
                textStyle={{ color: colors.black }}
                onPress={() => {
                  if (!chainWallet) return;

                  Clipboard.setString(chainWallet.address);
                  setToastMessage('Address copied', ToastType.success);
                }}
              >
                Copy
              </Button>
            ) : isLedgerWallet ? (
              <Button
                size={ButtonSize.Tiny}
                style={{ width: 80, backgroundColor: colors.offPurple }}
                textStyle={{ color: colors.black }}
                onPress={() => onConnectLedger(chain.id)}
                disabled={isLedgerWallet && chain.supportsLedger === false}
              >
                Connect
              </Button>
            ) : null}
          </View>
        );
      })}
    </>
  );
}

const styles = StyleSheet.create({
  item: {
    height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 100,
    borderWidth: 2,
    paddingLeft: 20,
    paddingRight: 10,
    marginTop: 14,
  },
});
