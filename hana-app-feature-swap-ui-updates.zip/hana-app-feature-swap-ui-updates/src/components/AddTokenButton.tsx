import { IconAddBlack, IconAddWhite } from '@/assets/icons';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { HIT_SLOP_XLARGE } from '@/utils/constants';
import { common } from '@/utils/styles';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'ManageTokens'>,
  StackNavigationProp<RootStackParams>
>;

interface Props {
  isDarkMode?: boolean;
}

export function AddTokenButton({ isDarkMode }: Props) {
  const { navigate } = useNavigation<NavigationProps>();

  return (
    <View style={common.screen}>
      <TouchableOpacity
        onPress={() => navigate('AddCustomToken')}
        hitSlop={HIT_SLOP_XLARGE}
        style={common.centerContent}
      >
        {isDarkMode ? <IconAddWhite /> : <IconAddBlack />}
      </TouchableOpacity>
    </View>
  );
}
