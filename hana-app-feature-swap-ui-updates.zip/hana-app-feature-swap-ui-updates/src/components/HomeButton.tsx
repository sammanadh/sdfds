import { LogoHanaDark, LogoHanaDarkHome, LogoHanaLight } from '@/assets/logos';
import { BrowserButton } from '@/components/BrowserButton';
import { HamburgerButton } from '@/components/HamburgerButton';
import { ChangeNetworkModal } from '@/components/Modals/ChangeNetwork/ChangeNetworkModal';
import { Text } from '@/components/Typography';
import { CustomNetwork } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { HIT_SLOP_SMALL, HIT_SLOP_XLARGE } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { dismissModal, presentModal } from '@/utils/modal';
import { networkDetailsForTestnet, TestnetConfig } from '@/utils/networks';
import { useNavigation } from '@react-navigation/native';
import { isNil } from 'lodash-es';
import React, { useMemo } from 'react';
import { TouchableOpacity, View, ViewStyle } from 'react-native';

interface Props {
  isHomeScreen?: boolean;
  styleContent?: ViewStyle;
  refreshing?: () => void;
}

export function HomeButton({ isHomeScreen, styleContent, refreshing }: Props) {
  const navigation = useNavigation();
  const { isDarkMode } = useTheme();

  const { refreshWalletBalances } = useVault();
  const { otherNetwork } = useChainServices();

  const selectedNetworkName = useMemo(() => {
    if (!isNil(otherNetwork)) {
      if ((otherNetwork as TestnetConfig)?.chainType) {
        const testnet = otherNetwork as TestnetConfig;
        const networkDetails = networkDetailsForTestnet(testnet);
        return networkDetails?.shortName;
      }

      if ((otherNetwork as CustomNetwork)?.id) {
        const customNetwork = otherNetwork as CustomNetwork;
        return customNetwork.name;
      }
    }

    return null;
  }, [otherNetwork]);

  function handleNavigateHome() {
    // @ts-expect-error not worth mapping navigation props to here
    navigation.navigate('Home');
    if (isHomeScreen && refreshing) {
      refreshing();
    }
  }

  function handlePressNetwork() {
    presentModal({
      title: 'Network',
      content: (
        <ChangeNetworkModal
          onClose={() => {
            dismissModal();
            refreshWalletBalances();
          }}
        />
      ),
    });
  }

  return (
    <View
      style={[
        {
          width: '100%',
          height: 50,
        },
        styleContent,
      ]}
    >
      <View
        style={{
          flexGrow: 1,
          marginLeft: 15,
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          backgroundColor: isDarkMode
            ? isHomeScreen
              ? colors.purple.darkBlack
              : colors.purple.darkOff
            : isHomeScreen
            ? colors.white
            : colors.offPurple,
        }}
      >
        <TouchableOpacity onPress={handleNavigateHome} hitSlop={HIT_SLOP_XLARGE}>
          {isDarkMode ? (
            isHomeScreen ? (
              <LogoHanaDarkHome height={50} />
            ) : (
              <LogoHanaDark height={50} />
            )
          ) : (
            <LogoHanaLight height={50} />
          )}
        </TouchableOpacity>
        <View />
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
          }}
        >
          {!isNil(selectedNetworkName) && (
            <TouchableOpacity
              onPress={handlePressNetwork}
              hitSlop={HIT_SLOP_SMALL}
              style={{ marginRight: 20 }}
            >
              <Text small style={!isHomeScreen && { color: colors.black }}>
                {selectedNetworkName}
              </Text>
            </TouchableOpacity>
          )}
          <BrowserButton isDarkMode={isDarkMode && isHomeScreen} />
          <HamburgerButton isDarkMode={isDarkMode && isHomeScreen} />
        </View>
      </View>
    </View>
  );
}
