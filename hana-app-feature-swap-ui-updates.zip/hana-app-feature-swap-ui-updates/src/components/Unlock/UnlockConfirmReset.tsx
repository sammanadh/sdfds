import { Button, ButtonVariant } from '@/components/Button';
import { Heading, Text } from '@/components/Typography';
import { useSettings } from '@/stores/Settings';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { dismissModal, presentModal } from '@/utils/modal';
import { useNavigation } from '@react-navigation/native';
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Footer } from '../Footer';
import { SafeAreaScreen } from '../SafeAreaScreen';
import {
  IconResetHana,
} from '@/assets/icons';

export function UnlockConfirmReset() {
  const navigation = useNavigation();

  const { colors } = useTheme();
  const { setBiometricsEnabled } = useSettings();
  const { resetVault } = useVault();

  function onContinue() {
    presentModal({
      title: 'Delete all wallets',
      content: (
        <View
          style={[
            styles.error,
            {
              backgroundColor: colors.cards,
              borderColor: colors.cards,
              borderLeftColor: colors.negative,
            },
          ]}
        >
          <Text bold>
            Final confirmation
          </Text>        
          <Text style={{ marginTop: 18 }}>
            Confirm you have backed up your private keys before deleting all your wallets.
          </Text>
          <Text style={{ marginTop: 18 }}>
            This action is not reversible.
          </Text>
        </View>
      ),
      options: {
        confirmButton: {
          variant: ButtonVariant.DangerTertiary,
          title: 'Delete wallets',
          onPress: async () => {
            try {
              dismissModal();

              await resetVault();
              setBiometricsEnabled(false);
              navigation.reset({ index: 0, routes: [{ name: 'OnboardingStack' }] });
            } catch (error: any) {
              console.warn('Failed resetting vault.', error.message);
            }
          },
        },
        cancelButton: {
          title: 'Cancel',
          onPress: () => dismissModal(),
        },
        withCloseButton: false,
      },
    });
  }

  return (
    <>
      <SafeAreaScreen top={false} bottom={false}>
        <IconResetHana
          width={40}
          height={40}
          style={{ backgroundColor: colors.negative, marginBottom: 10 }}
        />     
        <Heading>Delete wallets</Heading>
        <Text large style={{ marginTop: 18 }}>
          Resetting Hana will delete all the private keys and wallets from this device.
        </Text>
        <Text large style={{ marginTop: 18 }}>
          You can only recover your wallets from your existing backups.
        </Text>
        <Text large bold style={{ marginTop: 18 }}>
          This action is not reversible.
        </Text>        
        <Text large style={{ marginTop: 18 }}>If you have any questions you should reach out to support before continuing.</Text>
      </SafeAreaScreen>

      <Footer>
        <Button variant={ButtonVariant.DangerTertiary} onPress={onContinue}>
          Continue
        </Button>
      </Footer>
    </>
  );
}

const styles = StyleSheet.create({
  error: {
    borderWidth: 0,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
  },
});
