export enum ToastType {
  success,
  error,
  info,
}
