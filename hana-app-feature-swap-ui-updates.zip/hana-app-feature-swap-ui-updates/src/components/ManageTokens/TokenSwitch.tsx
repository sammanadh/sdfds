import CloseBlackIcon from '@/assets/icons/close-black.svg';
import CloseWhiteIcon from '@/assets/icons/close-white.svg';
import { Switch } from '@/components/Switch';
import { TokenLogo } from '@/components/TokenLogo';
import { Text } from '@/components/Typography';
import { ChainWallet, RealmChainWallet, Token } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainDetails, chains } from '@/utils/chains';
import { HIT_SLOP_LARGE } from '@/utils/constants';
import { colors, fonts } from '@/utils/designTokens';
import { card } from '@/utils/styles';
import { isNil } from 'lodash-es';
import React, { useMemo } from 'react';
import { StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';

interface Props {
  chainWallet?: ChainWallet | RealmChainWallet;
  chain?: ChainDetails;
  token?: Token; // TODO: specific token details here?
  style?: StyleProp<ViewStyle>;
  disabled?: boolean;
  onRemove?: (token?: any) => unknown;
  setRefresh?: React.Dispatch<React.SetStateAction<boolean>>;
}

export function TokenSwitch({
  chainWallet,
  chain: providedChain,
  token,
  style = {},
  disabled,
  onRemove,
  setRefresh,
}: Props) {
  const { realm } = useVault();
  const { isDarkMode } = useTheme();

  const chain = useMemo(() => {
    if (token) {
      return chains.find((chain) => chain.id === token.chainId);
    }

    return providedChain;
  }, [token]);

  return (
    <View
      style={[
        card.base,
        styles.container,
        style,
        {
          backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards,
          borderColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards,
        },
      ]}
    >
      {isNil(token) && chainWallet && chain && (
        <>
          <TokenLogo chain={chain} />
          <View style={styles.details}>
            <Text
              style={[
                styles.tokenName,
                { color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack },
              ]}
            >
              {chain.name}
            </Text>
            <Text small muted style={styles.tokenSymbol}>
              {chain.token.symbol}
            </Text>
          </View>
          <Switch
            value={chainWallet.isActive}
            onChange={(enabled) => {
              realm?.write(() => {
                chainWallet.isActive = enabled;
              });
            }}
            disabled={disabled}
          />
        </>
      )}

      {token && (
        <>
          <TokenLogo token={token} chain={chain} />

          <View style={styles.details}>
            <Text
              style={[
                styles.tokenName,
                { color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack },
              ]}
            >
              {token.name}
            </Text>
            <Text small muted style={styles.tokenSymbol}>
              {token.symbol}
            </Text>
          </View>
          {token.isCustom ? (
            <TouchableOpacity
              style={styles.removeButton}
              hitSlop={HIT_SLOP_LARGE}
              onPress={() => {
                if (typeof onRemove === 'function') {
                  onRemove(token);
                }
              }}
            >
              {isDarkMode ? <CloseWhiteIcon /> : <CloseBlackIcon />}
            </TouchableOpacity>
          ) : (
            <Switch
              value={token.isActive}
              onChange={(enabled) => {
                realm?.write(() => {
                  token.isActive = enabled;
                  if (typeof setRefresh === 'function') {
                    setRefresh((prev) => !prev);
                  }
                });
              }}
              disabled={disabled}
            />
          )}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 90,
  },
  details: {
    flex: 1,
    marginLeft: 10,
  },
  value: {
    fontFamily: fonts.regular,
    fontSize: 15,
  },
  removeButton: {
    width: 15,
    height: 15,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 5,
  },
  tokenName: {
    lineHeight: 22,
  },
  tokenSymbol: {
    marginTop: 1,
    fontSize: 12,
    lineHeight: 13,
  },
});
