import { DropdownIcon, DropdownIconWhite } from '@/assets/icons';
import { TokenLogo } from '@/components/TokenLogo';
import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { ChainDetails } from '@/utils/chains';
import { isEmpty } from 'lodash-es';
import React from 'react';
import { StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';

interface Props {
  value?: string | null;
  placeholder: string | null;
  onPress?: () => unknown;
  style?: StyleProp<ViewStyle>;
  innerStyle?: StyleProp<ViewStyle>;
  chain?: ChainDetails;
  disabled?: boolean;
  isRemoveDropdown?: boolean;
}

export function Select({
  value,
  placeholder,
  onPress,
  style,
  innerStyle,
  chain,
  disabled,
  isRemoveDropdown,
}: Props) {
  const { isDarkMode, styles: themeStyles } = useTheme();

  return (
    <TouchableOpacity onPress={onPress} style={style} disabled={disabled}>
      <View style={[styles.container, themeStyles.cards, innerStyle]}>
        {chain ? <TokenLogo chain={chain} size={40} /> : <></>}
        <View style={{ flex: 1, marginHorizontal: chain ? 18 : 0 }}>
          {!isEmpty(value) && <Text bold>{value}</Text>}
          {isEmpty(value) && <Text muted>{placeholder || 'Select...'}</Text>}
        </View>
        {!isRemoveDropdown &&
          (isDarkMode ? <DropdownIconWhite /> : <DropdownIcon color={'rgb(22, 7, 58)'} />)}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 56,
    borderRadius: 28,
    paddingLeft: 10,
    paddingRight: 20,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
  },
});
