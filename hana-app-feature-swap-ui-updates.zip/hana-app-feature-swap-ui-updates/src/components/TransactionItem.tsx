import { CollectableImage } from '@/components/Collectables/CollectableImage';
import Loading from '@/components/Loading';
import { TokenLogo } from '@/components/TokenLogo';
import { AltHeading, Text } from '@/components/Typography';
import { Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet, RealmChainWallet, Token } from '@/models/Vault';
import { chainForChainWallet } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { formatAmount } from '@/utils/format';
import { NetworkDetails } from '@/utils/networks';
import { formatDistanceToNow } from 'date-fns';
import { isEmpty, isNil } from 'lodash-es';
import React, { useMemo, useState } from 'react';
import {
  GestureResponderEvent,
  StyleProp,
  StyleSheet,
  TouchableOpacity,
  View,
  ViewStyle,
} from 'react-native';
import SwapIcon from '@/assets/icons/trade-swap.svg';
import { IconNextBlack } from '@/assets/icons';

interface Props {
  chainWallet: ChainWallet | RealmChainWallet;
  network?: NetworkDetails;
  token?: Token;
  transaction: Transaction;
  onPress?(event: GestureResponderEvent): void;
  style?: StyleProp<ViewStyle>;
  isDarkMode?: boolean;
  route?: string;
}

export function TransactionItem({
  chainWallet,
  network,
  token,
  transaction,
  onPress,
  style = {},
  isDarkMode,
}: Props) {
  const chain = chainForChainWallet(chainWallet);

  const isDeposit = transaction.to === chainWallet.address;

  const isNativeTransfer = transaction.type === TransactionType.SendNativeToken;

  const timeAgo = React.useMemo(() => {
    try {
      return formatDistanceToNow(transaction.date, { addSuffix: true });
    } catch (error) {
      console.debug('error: ', error);

      return '';
    }
  }, [transaction.date]);

  const symbol = React.useMemo(() => {
    if (transaction.type === TransactionType.CollectableTransfer) return '';

    if (isNativeTransfer && network?.token?.symbol) return network.token.symbol;

    return token?.symbol || transaction.tokenSymbol || chain?.token.symbol || '';
  }, [network, token, transaction]);

  const name = React.useMemo(() => {
    if (transaction.type === TransactionType.CollectableTransfer) return transaction.title;
    if (transaction.type === TransactionType.IScoreClaim) return 'I-Score Reward';

    if (isNativeTransfer && network?.token?.name) return network.token.name;

    return token?.name || transaction.token?.name || chain?.token.name || '';
  }, [network, token, transaction]);

  const title = useMemo(() => {
    if (transaction.type === TransactionType.TokenSwap) {
      return (
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
          }}
        >
          <Text large bold style={isDarkMode && { color: colors.whiteSecond }}>
            {transaction.tokenSymbol}
          </Text>
          <IconNextBlack
            width={15}
            height={15}
            style={{
              marginHorizontal: 5,
            }}
          />
          <Text large bold style={isDarkMode && { color: colors.whiteSecond }}>
            {transaction.toTokenSymbol}
          </Text>
        </View>
      );
    }

    return (
      <Text large bold numberOfLines={1} style={isDarkMode && { color: colors.whiteSecond }}>
        {name}
      </Text>
    );
  }, [name, transaction]);

  const [loading, setLoading] = useState<boolean>(true);

  React.useEffect(() => {
    const timeout = setTimeout(() => {
      if (transaction && chainWallet) {
        setLoading(false);
      }
    }, 500);
    return () => clearTimeout(timeout);
  }, [transaction, chainWallet]);

  const mathSign = useMemo(() => {
    if (transaction.type === TransactionType.IScoreClaim) return '+';

    return isDeposit ? '+' : '-';
  }, [isDeposit, transaction]);

  const icon = useMemo(() => {
    if (transaction.type === TransactionType.TokenSwap) {
      return (
        <View
          style={{
            borderRadius: 25,
            overflow: 'hidden',
          }}
        >
          <SwapIcon width={50} height={50} />
        </View>
      );
    }

    if (transaction.type === TransactionType.CollectableTransfer) {
      return <CollectableImage url={transaction.imageUrl} size={50} circle />;
    }

    return <TokenLogo chain={chain} token={token || transaction.token} />;
  }, [transaction, chain, token]);

  const statusText = useMemo(() => {
    if (transaction.type === TransactionType.TokenSwap) return transaction.statusLabel;

    if (transaction.isPending === true) {
      return 'Pending';
    }

    return '';
  }, [transaction]);

  return (
    <View style={{ width: '100%', marginBottom: 15 }}>
      {loading ? (
        <Loading height={90} width={'100%'} />
      ) : (
        <TouchableOpacity
          onPress={onPress}
          disabled={isNil(onPress)}
          style={[styles.container, isDarkMode && { backgroundColor: colors.black }, style]}
        >
          {icon}

          <View style={styles.details}>
            {title}
            <AltHeading style={{ marginTop: 6 }}>{timeAgo}</AltHeading>
          </View>

          <View style={styles.values}>
            <Text bold large style={isDarkMode && { color: colors.whiteSecond }}>
              {mathSign}
              {formatAmount(transaction.amount)} {symbol}
            </Text>

            {!isEmpty(statusText) && (
              <Text small muted style={{ marginTop: 2 }}>
                {statusText}
              </Text>
            )}
          </View>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.gray.cards,
    padding: 16,
  },
  details: {
    flex: 1,
    marginHorizontal: 15,
  },
  values: {
    flex: 1,
    alignItems: 'flex-end',
  },
});
