import { SearchIcon, SearchIconWhite } from '@/assets/icons';
import { TextInput } from '@/components/TextInput';
import { useTheme } from '@/stores/Theme';
import { colors, fonts } from '@/utils/designTokens';
import { StyleProp, StyleSheet, TextStyle, ViewStyle } from 'react-native';

interface Props {
  value?: string;
  onChangeText?(newValue: string): void;
  placeholder?: string;
  autoFocus?: boolean;
  style?: StyleProp<TextStyle>;
  styleInputContainer?: StyleProp<ViewStyle>;
  inputStyle?: TextStyle;
  inputFocusBorderColor?: string;
  placeholderTextColor?: string;
  inputBorderColor?: string;
}

export function SearchInput({
  placeholder = 'Search',
  placeholderTextColor = colors.gray.meta,
  ...props
}: Props) {
  const { isDarkMode } = useTheme();
  return (
    <TextInput
      {...props}
      isDarkMode={isDarkMode}
      placeholder={placeholder}
      placeholderTextColor={placeholderTextColor}
      prefix={
        isDarkMode ? (
          <SearchIconWhite width="100%" height={22} />
        ) : (
          <SearchIcon width="100%" height={22} />
        )
      }
      autoCapitalize="none"
      autoCompleteType="off"
      autoCorrect={false}
      styleInputContainer={[styles.container, props.styleInputContainer]}
      inputStyle={[styles.input, props.inputStyle]}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.gray.cards,
    paddingVertical: 0,
    borderWidth: 0,
  },
  input: {
    height: 55,
    fontFamily: fonts.heavy,
    margin: 0,
  },
});
