import InfoIcon from '@/assets/icons/toast-info.svg';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { colors, fonts } from '@/utils/designTokens';
import * as StatusBar from 'expo-status-bar';
import { isEmpty } from 'lodash-es';
import React, { useLayoutEffect, useMemo } from 'react';
import { StyleSheet } from 'react-native';
import FlashMessage, { showMessage } from 'react-native-flash-message';

export function Toast() {
  const { toastMessage, toastType, setToastMessage } = useNavigationStore();
  const { isDarkMode } = useTheme();

  const show = useMemo(() => !isEmpty(toastMessage), [toastMessage]);

  useLayoutEffect(() => {
    if (show) {
      StatusBar.setStatusBarStyle(isDarkMode ? 'light' : 'dark');
      showMessage({
        icon: 'success',
        renderFlashMessageIcon: () => <InfoIcon width={18} height={18} />,
        message: toastMessage || '',
      });
      setToastMessage(null);
    }
  }, [show, toastMessage, toastType, isDarkMode]);

  return (
    <FlashMessage
      position="top"
      onHide={() => {
        StatusBar.setStatusBarStyle(isDarkMode ? 'dark' : 'light');
      }}
      style={styles.container}
      titleStyle={styles.message}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.primary,
    zIndex: 999, // NOTE: Need to make sure toast messages appear above the modal
  },
  message: {
    color: colors.positive,
    marginLeft: 10,
    fontSize: 16,
    fontFamily: fonts.heavy,
  },
});
