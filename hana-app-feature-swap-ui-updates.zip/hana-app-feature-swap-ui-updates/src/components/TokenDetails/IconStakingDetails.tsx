import { Button, ButtonSize, ButtonVariant } from '@/components/Button';
import { ToastType } from '@/components/Toast.types';
import { Text } from '@/components/Typography';
import { ICONService } from '@/services/chainServices/IconService';
import { serviceForChainID } from '@/stores/ChainServices';
import { useIconNetwork } from '@/stores/IconNetwork';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import { ONE, ZERO } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { getErrorMessage } from '@/utils/errors';
import { formatAmount, formatNumber } from '@/utils/format';
import { dismissModal, presentModal } from '@/utils/modal';
import React, { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';

interface MetricRowProps {
  title: string;
  value: string;
  isDarkMode?: boolean;
}

function MetricRow({ title, value, isDarkMode }: MetricRowProps) {
  return (
    <View style={styles.metricRow}>
      <Text bold style={[styles.metricTitle, isDarkMode && { color: colors.whiteSecond }]}>
        {title}
      </Text>
      <Text bold style={[styles.metricValue, , isDarkMode && { color: colors.whiteSecond }]}>
        {value}
      </Text>
    </View>
  );
}

export function IconStakingDetails() {
  const { icxAssetsForWallet } = useIconNetwork();
  const walletAssets = icxAssetsForWallet();
  const { getActiveWallet } = useVault();

  const { setToastMessage } = useNavigationStore();

  const activeWallet = getActiveWallet();

  const chainService = serviceForChainID(ChainID.ICON) as ICONService;

  const staked = useMemo(() => walletAssets?.staked ?? ZERO, [walletAssets]);
  const available = useMemo(() => walletAssets?.availableBalance ?? ZERO, [walletAssets]);
  const unstaking = useMemo(() => walletAssets?.unstaking ?? ZERO, [walletAssets]);
  const iScore = useMemo(() => walletAssets?.iScore ?? ZERO, [walletAssets]);
  const iScoreEstimatedIcx = useMemo(
    () => walletAssets?.iScoreEstimatedIcx ?? ZERO,
    [walletAssets]
  );

  const hasStakingMetric = useMemo(
    () => staked.gt(ZERO) || unstaking.gt(ZERO) || iScore.gt(ONE),
    [staked, unstaking, iScore]
  );
  const { isDarkMode } = useTheme();

  const [isClaiming, setIsClaiming] = React.useState(false);

  const hasIScore = iScore.gt(ONE);

  async function handleClaimIScore() {
    setIsClaiming(true);

    try {
      await chainService.claimIScore(activeWallet!, {});
      setToastMessage('Your I-Score has been claimed', ToastType.success);
    } catch (error: any) {
      const errorMessage = getErrorMessage(error, 'Failed claiming I-Score');
      console.warn(errorMessage + '.', error.message);

      setToastMessage(errorMessage, ToastType.error);
    }

    setIsClaiming(false);
  }

  const onClaimIScore = React.useMemo(() => {
    return () => {
      if (isClaiming) return;

      const title = 'Claim I-Score';
      const content = (
        <>
          <Text
            large
            style={{
              color: isDarkMode ? 'white' : '#190a3d',
              marginVertical: 20,
            }}
          >
            You currently have{' '}
            <Text bold style={[isDarkMode ? { color: 'white' } : {}]}>
              {formatNumber(iScore)}
            </Text>{' '}
            unclaimed rewards which will convert to{' '}
            <Text bold style={[isDarkMode ? { color: 'white' } : {}]}>
              {formatAmount(iScoreEstimatedIcx)}
            </Text>{' '}
            ICX. Click "Continue" to claim now.
          </Text>

          <View
            style={{
              width: '100%',
              justifyContent: 'space-between',
              flexDirection: 'row',
              alignItems: 'center',
            }}
          >
            <Button
              style={{ width: '40%', backgroundColor: colors.gray.cards }}
              textStyle={{ color: colors.black }}
              variant={ButtonVariant.PurpleSecondary}
              onPress={() => dismissModal()}
            >
              Cancel
            </Button>
            <Button
              variant={ButtonVariant.Primary}
              style={{ flex: 1, marginLeft: 12 }}
              onPress={() => {
                dismissModal();
                handleClaimIScore();
              }}
            >
              Continue
            </Button>
          </View>
        </>
      );
      const options = {
        withCloseButton: false,
      };

      presentModal({
        title,
        content,
        options,
      });
    };
  }, [iScore, iScoreEstimatedIcx, isClaiming, isDarkMode]);

  return hasStakingMetric ? (
    <View style={[styles.container, isDarkMode && { backgroundColor: colors.purple.darkBlack }]}>
      <View style={{ paddingHorizontal: 20 }}>
        {available.gt(ZERO) && (
          <>
            <MetricRow
              title="Available"
              value={`${formatAmount(available)} ICX`}
              isDarkMode={isDarkMode}
            />
            {available.gt(ZERO) && (
              <View
                style={[
                  styles.line,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />
            )}
          </>
        )}
        {staked.gt(ZERO) && (
          <>
            <MetricRow
              title="Staked"
              value={`${formatAmount(staked)} ICX`}
              isDarkMode={isDarkMode}
            />
            {unstaking.gt(ZERO) && (
              <View
                style={[
                  styles.line,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />
            )}
          </>
        )}

        {unstaking.gt(ZERO) && (
          <MetricRow
            title="Unstaking"
            value={`${formatAmount(unstaking)} ICX`}
            isDarkMode={isDarkMode}
          />
        )}

        {hasIScore && (
          <>
            <View
              style={[
                styles.separator,
                isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
              ]}
            />
            <MetricRow
              title="I-Score"
              value={`${formatAmount(iScore)}`}
              isDarkMode={isDarkMode}
            />
          </>
        )}
      </View>
      {hasIScore && (
        <Button
          variant={ButtonVariant.Purple}
          size={ButtonSize.Regular}
          style={{ marginTop: 8, marginHorizontal: 0 }}
          onPress={onClaimIScore}
        >
          Claim I-Score
        </Button>
      )}
    </View>
  ) : (
    <></>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    borderRadius: 14,
    backgroundColor: colors.white,
    marginBottom: 20,
  },
  line: {
    width: '100%',
    backgroundColor: colors.gray.border,
    height: StyleSheet.hairlineWidth,
  },
  metricTitle: {
    fontSize: 12,
    color: '#7e8494',
    textTransform: 'uppercase',
  },
  metricValue: {
    fontSize: 15,
    color: '#100f10',
    textAlign: 'right',
    flex: 1,
  },
  metricRow: {
    width: '100%',
    flexDirection: 'row',
    marginVertical: 18,
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.gray.border,
  },
});
