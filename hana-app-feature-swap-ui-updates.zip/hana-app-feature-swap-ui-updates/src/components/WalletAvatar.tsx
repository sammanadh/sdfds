import { Wallet } from '@/models/Vault';
import { colors, fonts } from '@/utils/designTokens';
import { formatInitials } from '@/utils/format';
import { useMemo } from 'react';
import { Image, ImageStyle, StyleProp, View } from 'react-native';
import { alea } from 'seedrandom';
import { Text } from '@/components/Typography';

const walletImages = [
  require('@/assets/wallets/1.png'),
  require('@/assets/wallets/2.png'),
  require('@/assets/wallets/3.png'),
  require('@/assets/wallets/4.png'),
  require('@/assets/wallets/5.png'),
  require('@/assets/wallets/6.png'),
  require('@/assets/wallets/7.png'),
  require('@/assets/wallets/8.png'),
];

function getWalletImage(wallet: Wallet) {
  const rng = alea(wallet.id);
  return walletImages[Math.floor(rng() * walletImages.length)];
}

interface Props {
  wallet: Wallet;
  size?: number;
  style?: StyleProp<ImageStyle>;
  isUseWalletName?: boolean;
}

export function WalletAvatar({ wallet, size = 55, style = {}, isUseWalletName }: Props) {
  const image = useMemo(() => {
    if (isUseWalletName) {
      return formatInitials(wallet.name);
    }
    return getWalletImage(wallet);
  }, [wallet, isUseWalletName]);
  const imageStyle = useMemo<ImageStyle>(
    () => ({
      width: size,
      height: size,
      borderRadius: Math.ceil(size / 2),
    }),
    [size]
  );

  if (isUseWalletName) {
    return (
      <View
        style={{
          width: size,
          height: size,
          borderRadius: size / 2,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: colors.offPurple,
        }}
      >
        <Text
          style={{
            fontFamily: fonts.heavy,
            fontSize: 13,
            textAlign: 'center',
            color: '#3308a8',
            textTransform: 'uppercase',
          }}
        >
          {image}
        </Text>
      </View>
    );
  }

  return <Image source={image} style={[imageStyle, style]} />;
}
