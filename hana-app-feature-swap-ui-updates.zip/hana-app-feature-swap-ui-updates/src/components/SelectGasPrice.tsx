import { DropdownIcon } from '@/assets/icons';
import { Text } from '@/components/Typography';
import { GasPriceOption } from '@/models/GasPriceOption';
import { useTheme } from '@/stores/Theme';
import { isNil } from 'lodash-es';
import React from 'react';
import { StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';

interface Props {
  value?: GasPriceOption;
  onPress: () => unknown;
  style?: StyleProp<ViewStyle>;
  disabled?: boolean;
}

export function SelectGasPrice({ value, onPress, style, disabled }: Props) {
  const { styles: themeStyles } = useTheme();

  return (
    <TouchableOpacity onPress={onPress} style={style} disabled={disabled}>
      <View style={[styles.container, themeStyles.cards]}>
        <View style={{ flex: 1, paddingHorizontal: 12 }}>
          {!isNil(value) && (
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}
            >
              <View
                style={{
                  flexDirection: 'column',
                  flex: 1,
                }}
              >
                <Text>{value?.label}</Text>
                {value?.label === 'Advanced' && (
                  <Text small muted>
                    Set gas price manually
                  </Text>
                )}

                {!isNil(value?.estimatedWait) && (
                  <Text small muted>
                    ~ {value?.estimatedWait?.toString()} seconds wait
                  </Text>
                )}
              </View>
              <View
                style={{
                  flex: 1,
                  alignItems: 'flex-end',
                }}
              >
                {value.price && (
                  <Text small muted>
                    {value?.price?.toFixed(0)} GWEI
                  </Text>
                )}
              </View>
            </View>
          )}
          {isNil(value) && <Text muted>Select…</Text>}
        </View>

        <DropdownIcon color={'rgb(22, 7, 58)'} />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 56,
    borderRadius: 28,
    paddingLeft: 10,
    paddingRight: 20,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
  },
});
