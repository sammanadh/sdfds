import { IconDotHorizontal, IconDotHorizontalWhite } from '@/assets/icons';
import { useTheme } from '@/stores/Theme';
import { HIT_SLOP_XLARGE } from '@/utils/constants';
import { common } from '@/utils/styles';
import { TouchableOpacity, View } from 'react-native';

export function DotHorizontalButton() {
  const { isDarkMode } = useTheme();

  function onPress() {}

  return (
    <View style={common.screen}>
      <TouchableOpacity onPress={onPress} hitSlop={HIT_SLOP_XLARGE} style={common.centerContent}>
        {isDarkMode ? <IconDotHorizontalWhite /> : <IconDotHorizontal />}
      </TouchableOpacity>
    </View>
  );
}
