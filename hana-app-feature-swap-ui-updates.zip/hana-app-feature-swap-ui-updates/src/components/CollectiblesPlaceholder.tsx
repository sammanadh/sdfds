import ImagesStackIllustration from '@/assets/illustrations/images-stack.svg';
import { Text } from '@/components/Typography';
import React from 'react';
import { StyleSheet, View } from 'react-native';

interface Props {
  empty?: boolean;
}

export function CollectiblesPlaceholder({ empty = false }: Props) {
  return (
    <View style={styles.container}>
      <ImagesStackIllustration width={45} height={45} style={{ marginBottom: 8 }} />
      {empty ? (
        <Text muted style={styles.text}>
          You don't own any NFTs yet.
        </Text>
      ) : (
        <Text muted style={styles.text}>
          A new <Text bold>multi-chain</Text> {`home for your NFTs?!\nYep, it's coming soon!`}
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    alignItems: 'center',
    marginVertical: 100,
    paddingHorizontal: 30,
  },
  text: {
    textAlign: 'center',
    lineHeight: 19.5,
    paddingTop: 14,
  },
});
