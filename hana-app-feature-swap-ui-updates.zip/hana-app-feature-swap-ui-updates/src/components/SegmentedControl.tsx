import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { colors, fonts } from '@/utils/designTokens';
import { isNil } from 'lodash-es';
import React from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';

interface Props<T> {
  segments: T[];
  selectedSegment?: T | null;
  onSelectedSegment: (segment: T) => void;
}

export default function SegmentedControl<T>({
  segments,
  selectedSegment,
  onSelectedSegment,
}: Props<T>) {
  const { isDarkMode } = useTheme();

  return (
    <ScrollView
      horizontal
      contentContainerStyle={styles.container}
      alwaysBounceVertical={false}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
    >
      {segments.map((segment, index) => {
        const isSelected = isNil(selectedSegment) || selectedSegment === segment;

        return (
          <TouchableOpacity
            key={`${index}-${segment}`}
            style={{
              marginRight: 16,
              height: 30,
              justifyContent: 'flex-end',
              paddingHorizontal: 3,
            }}
            onPress={() => onSelectedSegment(segment)}
          >
            <View style={styles.segment}>
              <Text
                center
                style={[
                  styles.segmentTitle,
                  isSelected && {
                    color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlacker,
                  },
                ]}
              >
                {segment}
              </Text>
              <View
                style={[
                  styles.highlightBar,
                  isSelected
                    ? { backgroundColor: isDarkMode ? colors.purple.darkOff : colors.offPurple }
                    : { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards },
                ]}
              />
            </View>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
  },
  highlightBar: {
    height: 4,
    width: '100%',
  },
  segment: {
    flexDirection: 'column',
  },
  segmentTitle: {
    fontFamily: fonts.heavy,
    color: colors.gray.meta,
    letterSpacing: 0.2,
  },
});
