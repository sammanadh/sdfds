import { Text } from '@/components/Typography';
import { TokenWithBalance } from '@/hooks/useTokens';
import { BigNumber } from '@/utils/bignumber';
import { colors, fonts, palette } from '@/utils/designTokens';
import React, { useEffect, useMemo, useState } from 'react';
import { StyleSheet, TextInput as RNTextInput, View } from 'react-native';
import { ActivityIndicator } from '@/components/ActivityIndicator';
import { styles as typographyStyles } from '@/components/Typography';
import { chains } from '@/utils/chains';
import { formatNumber, formatPixel, formatPrice } from '@/utils/format';
import { TokenSelect } from '../TokenSelect';
import { usePrices } from '@/stores/Price';
import { TouchableOpacity } from 'react-native-gesture-handler';

function getFontSize(characters: number) {
  // TODO: work out a formula for this?
  if (characters < 5) return 30;
  if (characters < 6) return 27;
  if (characters < 7) return 24;
  if (characters < 8) return 21;
  if (characters < 9) return 18;
  if (characters < 10) return 15;
  return 12;
}
interface Props {
  title?: string;
  token: TokenWithBalance;
  //   price: BigNumber;
  value: string;
  onValueChanged: (value: string) => unknown;
  //   maxEnabled: boolean;
  onSelectToken: () => unknown;
  //   totalUSD: BigNumber;
  isDarkMode?: boolean;
  editable?: boolean;
  amountLoading?: boolean;
  onBalanceClick?: () => void;
}

export function SwapInput({
  title,
  token,
  value,
  onValueChanged,
  onSelectToken,
  isDarkMode,
  editable,
  amountLoading,
  onBalanceClick,
}: Props) {
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = React.useRef<RNTextInput>(null);
  const { getTokenPrice, getNativePrice } = usePrices();
  const [amountPriceString, setAmountPriceString] = React.useState('');

  useEffect(() => {
    const fromTokenChain = chains.find((chain) => chain.id === token.chainId)!;
    const fromTokenPrice = token.contract
      ? getTokenPrice(token.contract)
      : getNativePrice(fromTokenChain);
    if (!Number(value)) {
      return setAmountPriceString('');
    }
    const fromTokenAmountPrice = fromTokenPrice.times(value);
    if (fromTokenAmountPrice < new BigNumber(0.01)) {
      return setAmountPriceString('< $0.01');
    } else {
      return setAmountPriceString(formatPrice(fromTokenAmountPrice, false));
    }
  }, [token, value]);

  return (
    <View
      style={[
        styles.container,
        styles.column,
        isFocused && styles.inputFocused,
        isDarkMode && { backgroundColor: colors.black },
      ]}
      // onTouchStart={() => {
      //   inputRef.current?.focus();
      // }}
    >
      {title && (
        <View>
          <Text style={styles.title}>{title}</Text>
        </View>
      )}
      <View style={styles.row}>
        <View style={styles.textInputContainer}>
          {amountLoading ? (
            <ActivityIndicator
              size={32}
            />
          ) : (
            <RNTextInput
              ref={inputRef}
              style={[
                {
                  flex: 1,
                  fontFamily: fonts.heavy,
                  fontSize: getFontSize(value.length),
                },
                isDarkMode ? { color: colors.whiteSecond } : { color: colors.black },
              ]}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              value={value}
              placeholderTextColor={isDarkMode ? colors.whiteSecond : colors.black}
              onChangeText={(text) => onValueChanged(text)}
              keyboardType="decimal-pad"
              autoFocus
              // placeholder={`0`}
              editable={editable}
            />
          )}
        </View>

        <TokenSelect
          token={token}
          onPress={() => {
            onSelectToken();
          }}
        />
      </View>
      <View style={styles.amountInfoContainer}>
        <Text style={styles.price}> {!amountLoading && (amountPriceString || '')} </Text>
        {onBalanceClick ? (
          <TouchableOpacity onPress={onBalanceClick}>
            <Text style={styles.balance}>{`${formatNumber(token.balance, 4)} ${token.symbol}`}</Text>
          </TouchableOpacity>
        ) : (
          <Text style={styles.balance}>{`${formatNumber(token.balance, 4)} ${token.symbol}`}</Text>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
  },
  column: {
    flexDirection: 'column',
  },
  container: {
    width: '100%',
    height: 140,
    backgroundColor: colors.white,
    borderColor: '#736b88',
    borderWidth: 1,
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 5,
    justifyContent: 'space-around',
  },
  title: {
    color: '#736b88',
  },
  price: {
    color: '#736b88',
  },
  balance: {
    color: '#736b88',
  },
  textInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 10,
  },
  symbol: {
    marginRight: 0,
  },
  inputFocused: {
    borderColor: colors.offPurple,
  },
  accessoryContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  btnTokenSelect: {
    backgroundColor: colors.offPurple,
    width: 106,
    height: 40,
    borderRadius: 100,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 5,
    alignItems: 'center',
  },
  txtTokenSelect: {
    color: colors.black,
  },
  amountInfoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
});
