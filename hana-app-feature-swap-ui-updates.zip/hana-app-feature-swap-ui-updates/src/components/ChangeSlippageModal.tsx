import { StyleSheet, View } from 'react-native';
import { Text } from '@/components/Typography';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { colors } from '@/utils/designTokens';
import { useTheme } from '@/stores/Theme';
import BigNumber from 'bignumber.js';
import { isEqual } from 'lodash-es';

interface SlippageOptions {
  label: string;
  slippage: BigNumber;
}

interface Props {
  onChange: (item: SlippageOptions) => unknown;
  items: SlippageOptions[];
  selectedItem: SlippageOptions;
}

export function ChangeSlippageModal({ items, selectedItem, onChange }: Props) {
  const { isDarkMode } = useTheme();

  return (
    <View>
      {items.map((item, id) => (
        <View key={`slippage-${id}`}>
          <SlippageItem
            isDarkMode={isDarkMode}
            selected={isEqual(item, selectedItem)}
            onChange={onChange}
            item={item}
          />
        </View>
      ))}
    </View>
  );
}

function SlippageItem({ onChange, item, selected, isDarkMode }: SlippageItemProps) {
  return (
    <TouchableOpacity
      style={[
        styles.container,
        selected ? styles.containerSelected : {},
        isDarkMode && { backgroundColor: colors.black },
      ]}
      onPress={() => onChange(item)}
    >
      <Text bold style={isDarkMode && { color: colors.whiteSecond }}>
        {item.label}
      </Text>
      {selected && (
        <View style={styles.labelSelected}>
          <Text style={styles.selected}>SELECTED</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 50,
    borderRadius: 20,
    backgroundColor: colors.gray.cards,
    alignItems: 'center',
    paddingHorizontal: 20,
    flexDirection: 'row',
    marginTop: 10,
  },
  containerSelected: {
    backgroundColor: colors.gray.cards,
    borderStyle: 'solid',
    borderWidth: 2,
    borderColor: colors.offPurple,
  },
  labelSelected: {
    position: 'absolute',
    backgroundColor: colors.offPurple,
    bottom: 0,
    right: 20,
  },
  selected: {
    fontSize: 12,
    color: colors.primary,
    marginHorizontal: 8,
    marginTop: 4,
    lineHeight: 13,
    letterSpacing: 0.2,
  },
});

interface SlippageItemProps {
  onChange: (item: SlippageOptions) => unknown;
  item: SlippageOptions;
  selected: boolean;
  isDarkMode: boolean;
}
