import { common } from '@/utils/styles';
import { useIsFocused } from '@react-navigation/native';
import { isArray } from 'lodash-es';
import debounce from 'lodash/debounce';
import React, { useEffect, useRef } from 'react';
import { ScrollView, ScrollViewProps } from 'react-native';

export function ScrollViewScreen({
  style = {},
  contentContainerStyle = {},
  ...props
}: ScrollViewProps) {
  const scrollRef = useRef<ScrollView>(null);
  const isFocused = useIsFocused();

  useEffect(() => {
    if (!isFocused) {
      scrollViewToTop();
    }
  }, [isFocused]);

  const scrollViewToTop = () => {
    debounce(() => {
      scrollRef.current?.scrollTo({ x: 0, y: 0, animated: false });
    }, 800)();
  };

  return (
    <ScrollView
      ref={scrollRef}
      style={[common.negateScreen, ...(isArray(style) ? style : [style])]}
      contentContainerStyle={[
        common.screen,
        { paddingBottom: 30 },
        ...(isArray(contentContainerStyle) ? contentContainerStyle : [contentContainerStyle]),
      ]}
      {...props}
    />
  );
}
