import { IconBack, IconBackWhite } from '@/assets/icons';
import { AddTokenButton } from '@/components/AddTokenButton';
import { AddWalletButton } from '@/components/AddWalletButton';
import { HamburgerButton } from '@/components/HamburgerButton';
import { RealmContact, Wallet } from '@/models/Vault';
import { DisclaimerScreen } from '@/screens/help/Disclaimer';
import { HelpAndSupportScreen } from '@/screens/help/HelpAndSupport';
import { AddCustomToken } from '@/screens/home/AddCustomToken';
import { ManageTokens } from '@/screens/home/ManageTokens';
import { AddContact } from '@/screens/settings/AddContact';
import { AddressBook } from '@/screens/settings/AddressBook';
import { AdvancedScreen } from '@/screens/settings/Advanced';
import { AuthorizedDAppsScreen } from '@/screens/settings/AuthorizedDApps';
import { BackupMethodScreen } from '@/screens/settings/BackupMethod';
import { BackupPrivateKeyScreen } from '@/screens/settings/BackupPrivateKey';
import { BackupSeedPhraseScreen } from '@/screens/settings/BackupSeedPhrase';
import { BackupWalletScreen } from '@/screens/settings/BackupWallet';
import { ChangePasswordScreen } from '@/screens/settings/ChangePassword';
import { ConfigureChainsScreen } from '@/screens/settings/ConfigureChains';
import { ConfirmPasswordScreen } from '@/screens/settings/ConfirmPassword';
import { ConnectWithLedger } from '@/screens/settings/ConnectWithLedger';
import { EditContact } from '@/screens/settings/EditContact';
import { ImportPrivateKeyScreen } from '@/screens/settings/ImportPrivateKey';
import { ManageWallets } from '@/screens/settings/ManageWallets';
import { RenameWallet } from '@/screens/settings/RenameWallet';
import { ResetConfirm } from '@/screens/settings/ResetConfirm';
import { ResetHana } from '@/screens/settings/ResetHana';
import { ResetWithImported } from '@/screens/settings/ResetWithImported';
import { RestoreKeystoreFileScreen } from '@/screens/settings/RestoreKeystoreFile';
import { RestoreKeystorePassword } from '@/screens/settings/RestoreKeystorePassword';
import { RestoreWallet } from '@/screens/settings/RestoreWallet';
import { SaveKeystoreFileScreen } from '@/screens/settings/SaveKeystoreFile';
import { SettingsScreen } from '@/screens/settings/Settings';
import { WalletDetails } from '@/screens/settings/WalletDetails';
import { useTheme } from '@/stores/Theme';
import { Keystore } from '@/utils/keystoreFile';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import React, { useMemo } from 'react';
import { View } from 'react-native';
import {
  defaultStackScreenOptions,
  navigationStyles,
  transparentHeaderStackScreenOptions,
  useHanaLogo,
} from './utils';

export type SettingsStackParams = {
  Settings: undefined;
  ManageTokens: undefined;
  AddCustomToken: undefined;
  AddressBook: undefined;
  AddContact: {
    contact?: RealmContact | null;
  };
  EditContact: {
    contact?: RealmContact | null;
  };
  ConfigureChains: undefined;
  ManageWallets: undefined;
  RestoreWallet:
    | {
        fromDrawer?: boolean;
      }
    | undefined;
  ConnectWithLedger: undefined;
  HelpAndSupportScreen: undefined;
  Disclaimer: undefined;
  WalletDetails: {
    wallet: Wallet;
  };
  RenameWallet: {
    wallet: Wallet;
  };
  BackupWallet: {
    wallet: Wallet;
  };
  BackupMethod: {
    wallet: Wallet;
    passcode: string;
  };
  BackupSeedPhrase: {
    passcode: string;
  };
  SaveKeystoreFile: {
    wallet: Wallet;
    passcode: string;
  };
  BackupPrivateKey: {
    wallet: Wallet;
    passcode: string;
  };
  RestoreKeystoreFile: undefined;
  RestoreKeystorePassword: {
    keystore: Keystore;
  };
  ImportPrivateKey: undefined;
  ChangePassword: undefined;
  ConfirmPassword: { setIsBiometricVerified: any; setBiometricsEnabled: any };
  AuthorizedDApps: undefined;
  ResetHana: undefined;
  ResetWithImported: undefined;
  ResetConfirm: undefined;
  Advanced: undefined;
};
const SettingsStack = createStackNavigator<SettingsStackParams>();

export function SettingsStackNavigator() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerTitle: () => null,
      headerStyle: [navigationStyles.transparentHeader, themeStyles.screen],
      headerBackImage: () => (
        <View style={navigationStyles.headerLeft}>
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </View>
      ),
      headerRight: () => (
        <View style={navigationStyles.headerRight}>
          <HamburgerButton />
        </View>
      ),
      cardStyle: [navigationStyles.transparentHeaderCard, themeStyles.screen],
    }),
    [isDarkMode]
  );

  return (
    <SettingsStack.Navigator initialRouteName="Settings" screenOptions={screenOptions}>
      <SettingsStack.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          headerShown: false,
          cardStyle: [screenOptions.cardStyle, { paddingHorizontal: 0 }],
        }}
      />
      <SettingsStack.Screen
        name="ManageTokens"
        component={ManageTokens}
        options={{
          headerRight: () => (
            <View style={navigationStyles.headerRight}>
              <AddTokenButton isDarkMode={isDarkMode} />
            </View>
          ),
        }}
      />
      <SettingsStack.Screen name="AddCustomToken" component={AddCustomToken} />
      <SettingsStack.Screen
        name="AddressBook"
        component={AddressBook}
        options={{
          headerRight: () => (
            <View style={navigationStyles.headerRight}>
              <AddWalletButton isDarkMode={isDarkMode} />
            </View>
          ),
        }}
      />
      <SettingsStack.Screen name="AddContact" component={AddContact} />
      <SettingsStack.Screen name="EditContact" component={EditContact} />
      <SettingsStack.Screen name="ConfigureChains" component={ConfigureChainsScreen} />
      <SettingsStack.Screen
        name="ManageWallets"
        component={ManageWallets}
        options={{
          headerRight: () => (
            <View style={navigationStyles.headerRight}>
              <AddWalletButton isDarkMode={isDarkMode} />
            </View>
          ),
        }}
      />
      <SettingsStack.Screen name="RestoreWallet" component={RestoreWallet} />
      <SettingsStack.Screen
        name="ConnectWithLedger"
        component={ConnectWithLedger}
        options={{
          headerTitle: () => useHanaLogo(),
          headerRight: () => null,
        }}
      />
      <SettingsStack.Screen name="WalletDetails" component={WalletDetails} />
      <SettingsStack.Screen
        name="RenameWallet"
        component={RenameWallet}
        options={{ headerRight: () => null }}
      />
      <SettingsStack.Screen name="BackupWallet" component={BackupWalletScreen} />
      <SettingsStack.Screen name="BackupMethod" component={BackupMethodScreen} />
      <SettingsStack.Screen name="BackupSeedPhrase" component={BackupSeedPhraseScreen} />
      <SettingsStack.Screen name="SaveKeystoreFile" component={SaveKeystoreFileScreen} />
      <SettingsStack.Screen name="BackupPrivateKey" component={BackupPrivateKeyScreen} />
      <SettingsStack.Screen name="RestoreKeystoreFile" component={RestoreKeystoreFileScreen} />
      <SettingsStack.Screen name="RestoreKeystorePassword" component={RestoreKeystorePassword} />
      <SettingsStack.Screen name="ImportPrivateKey" component={ImportPrivateKeyScreen} />
      <SettingsStack.Screen name="ChangePassword" component={ChangePasswordScreen} />
      <SettingsStack.Screen name="ConfirmPassword" component={ConfirmPasswordScreen} />
      <SettingsStack.Screen name="AuthorizedDApps" component={AuthorizedDAppsScreen} />
      <SettingsStack.Screen name="ResetHana" component={ResetHana} />
      <SettingsStack.Screen name="ResetWithImported" component={ResetWithImported} />
      <SettingsStack.Screen name="HelpAndSupportScreen" component={HelpAndSupportScreen} />
      <SettingsStack.Screen
        name="ResetConfirm"
        component={ResetConfirm}
        options={{ headerRight: () => null }}
      />
      <SettingsStack.Screen name="Disclaimer" component={DisclaimerScreen} />
      <SettingsStack.Screen name="Advanced" component={AdvancedScreen} />
    </SettingsStack.Navigator>
  );
}
