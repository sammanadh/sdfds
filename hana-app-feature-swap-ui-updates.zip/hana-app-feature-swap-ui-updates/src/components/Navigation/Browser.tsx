import { Browser } from '@/screens/browser/Browser';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import { useMemo } from 'react';
import { defaultStackScreenOptions } from './utils';

export type BrowserStackParams = {
  Browser: {
    url?: string;
  };
};
const BrowserStack = createStackNavigator<BrowserStackParams>();

export function BrowserStackNavigator() {
  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      headerShown: false,
    }),
    []
  );

  return (
    <BrowserStack.Navigator initialRouteName="Browser" screenOptions={screenOptions}>
      <BrowserStack.Screen name="Browser" component={Browser} />
    </BrowserStack.Navigator>
  );
}
