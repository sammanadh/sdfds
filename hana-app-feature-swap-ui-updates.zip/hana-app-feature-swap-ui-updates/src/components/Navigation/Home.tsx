import { IconBack, IconBackWhite } from '@/assets/icons';
import { AddTokenButton } from '@/components/AddTokenButton';
import { HamburgerButton } from '@/components/HamburgerButton';
import { Text } from '@/components/Typography';
import { TokenWithBalance } from '@/hooks/useTokens';
import { Collectable, Collection } from '@/models/Collectable';
import { DApp } from '@/models/DApp';
import { Transaction } from '@/models/Transaction';
import { ChainWallet, CustomNetwork } from '@/models/Vault';
import { Browser } from '@/screens/browser/Browser';
import { AddCustomToken } from '@/screens/home/AddCustomToken';
import { CollectableDetailsScreen } from '@/screens/home/CollectableDetails';
import {
  CollectionDetailsScreen,
  CollectionDetailsScreenParams,
} from '@/screens/home/CollectionDetails';
import DApps from '@/screens/home/DApps';
import { HomeScreen } from '@/screens/home/Home';
import { ManageTokens } from '@/screens/home/ManageTokens';
import { TokenDetails } from '@/screens/home/TokenDetails';
import { TransactionDetails } from '@/screens/home/TransactionDetails';
import { EditCustomNetworkScreen } from '@/screens/networks/EditCustomNetwork';
import { ManageCustomNetworksScreen } from '@/screens/networks/ManageCustomNetworks';
import { NetworkDetailsScreen } from '@/screens/networks/NetworkDetails';
import { QRCodeScanner } from '@/screens/QRCodeScanner';
import { ConnectWithLedger } from '@/screens/settings/ConnectWithLedger';
import { ImportPrivateKeyScreen } from '@/screens/settings/ImportPrivateKey';
import { RestoreKeystoreFileScreen } from '@/screens/settings/RestoreKeystoreFile';
import { RestoreWallet } from '@/screens/settings/RestoreWallet';
import { AmountToSend } from '@/screens/trade/AmountToSend';
import { Receive } from '@/screens/trade/Receive';
import { ReviewSend } from '@/screens/trade/ReviewSend';
import {
  ReviewSendCollectableScreen,
  ReviewSendCollectableScreenParams,
} from '@/screens/trade/ReviewSendCollectable';
import { Send, SendScreenParams } from '@/screens/trade/Send';
import { useTheme } from '@/stores/Theme';
import { ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import { common } from '@/utils/styles';
import { getFocusedRouteNameFromRoute, useRoute } from '@react-navigation/native';
import {
  createStackNavigator,
  StackNavigationOptions,
  TransitionPresets,
} from '@react-navigation/stack';
import React, { useMemo } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { OpenLinkButton } from '../OpenLinkButton';
import {
  defaultStackScreenOptions,
  navigationStyles as baseNavigationStyles,
  transparentHeaderStackScreenOptions,
  useHanaLogo,
  useSafeAreaHeading,
} from './utils';
import { SwapTransactionDetails } from '@/screens/home/SwapTransactionDetails';

export type HomeStackParams = {
  Home: undefined;
  ManageTokens: undefined;
  AddCustomToken: undefined;
  TokenDetails: {
    wallet: ChainWallet;
    token: TokenWithBalance;
  };
  TransactionDetails: {
    transaction: Transaction;
  };
  SwapTransactionDetails: {
    transaction: Transaction;
  };
  Send: SendScreenParams;
  QRCodeScanner: {
    onScan: (code: string) => unknown;
  };
  Receive: {
    wallet: ChainWallet;
    token: TokenWithBalance;
  };
  AmountToSend: {
    wallet: ChainWallet;
    token: TokenWithBalance;
    toAddress: string;
  };
  ReviewSend: {
    wallet: ChainWallet;
    token: TokenWithBalance;
    toAddress: string;
    amount: number;
  };
  RestoreKeystoreFile: undefined;
  ImportPrivateKey: undefined;
  ReviewSendCollectable: ReviewSendCollectableScreenParams;
  ManageCustomNetworks: undefined;
  EditCustomNetwork:
    | {
        network: CustomNetwork;
      }
    | undefined;
  NetworkDetails: {
    network: CustomNetwork;
  };
  RestoreWallet: undefined;
  ConnectWithLedger: {
    initialChainId: ChainID;
  };
  Browser:
    | {
        url?: string;
      }
    | undefined;
  CollectionDetails: CollectionDetailsScreenParams;
  CollectableDetails: {
    collection: Collection;
    collectable: Collectable;
  };
  DApps: {
    dAppsData: Array<DApp>;
  };
};

const HomeStack = createStackNavigator<HomeStackParams>();

export function HomeStackNavigator() {
  const route = useRoute();
  const routeName = getFocusedRouteNameFromRoute(route)
    ? getFocusedRouteNameFromRoute(route)
    : 'Home';
  const { isDarkMode, styles: themeStyles } = useTheme();

  const navigationStyles = StyleSheet.create({
    solidHeader: {
      backgroundColor: isDarkMode ? colors.purple.darkBlacker : colors.white,
    },
    solidHeaderHomeScreen: {
      backgroundColor: isDarkMode ? colors.purple.darkOff : colors.offPurple,
    },
    solidHeaderCard: {
      ...common.screen,
      backgroundColor: isDarkMode ? colors.purple.darkBlacker : colors.white,
    },
    solidHeaderCardHomeScreen: {
      ...common.screen,
      backgroundColor: isDarkMode ? colors.purple.darkOff : colors.offPurple,
    },
  });

  const headerHomeStackScreenOptions: StackNavigationOptions = {
    headerStyle: navigationStyles.solidHeader,
    headerTitle: () => null,
    headerTitleAlign: 'left',
    headerBackImage: () => (
      <View style={baseNavigationStyles.headerLeft}>
        {isDarkMode ? <IconBackWhite /> : <IconBack />}
      </View>
    ),
    headerBackTitleVisible: false,
    headerShadowVisible: false,
    headerRight: () => (
      <View
        style={[
          baseNavigationStyles.headerRight,
          routeName === 'Home' && { justifyContent: 'flex-end' },
        ]}
      >
        <HamburgerButton isDarkMode={isDarkMode} />
      </View>
    ),
    cardStyle: navigationStyles.solidHeaderCard,
  };

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...headerHomeStackScreenOptions,
    }),
    [isDarkMode]
  );

  const transparentHeaderScreenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerStyle: [baseNavigationStyles.transparentHeader, themeStyles.screen],
      headerBackImage: () => (
        <View style={baseNavigationStyles.headerLeft}>
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </View>
      ),
      cardStyle: [baseNavigationStyles.transparentHeaderCard, themeStyles.screen],
    }),
    [isDarkMode]
  );

  // For Browser
  const headerHeight = useSafeAreaHeading();

  const headerScreenOptions: StackNavigationOptions = {
    headerShown: false,
  };

  const browserScreenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      headerShown: false,
      cardStyle: [
        headerScreenOptions.cardStyle,
        Platform.OS === 'ios' && { paddingTop: headerHeight },
        { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards },
      ],
    }),
    [headerHeight, isDarkMode]
  );

  return (
    <HomeStack.Navigator initialRouteName="Home" screenOptions={screenOptions}>
      <HomeStack.Screen
        name="Home"
        component={HomeScreen}
        options={{
          headerShown: false,
          cardStyle: navigationStyles.solidHeaderCardHomeScreen,
        }}
      />
      <HomeStack.Screen
        name="ManageTokens"
        component={ManageTokens}
        options={{
          headerRight: () => (
            <View style={baseNavigationStyles.headerRight}>
              <AddTokenButton isDarkMode={isDarkMode} />
            </View>
          ),
        }}
      />
      <HomeStack.Screen
        name="AddCustomToken"
        component={AddCustomToken}
        options={{ headerRight: () => null }}
      />
      <HomeStack.Screen name="TokenDetails" component={TokenDetails} />
      <HomeStack.Screen
        name="TransactionDetails"
        component={TransactionDetails}
        options={{
          headerRight: () => null,
        }}
      />
      <HomeStack.Screen
        name="SwapTransactionDetails"
        component={SwapTransactionDetails}
        options={{
          headerRight: () => null,
        }}
      />
      <HomeStack.Screen name="Send" component={Send} />
      <HomeStack.Screen
        name="QRCodeScanner"
        component={QRCodeScanner}
        options={{
          cardStyle: [themeStyles.screen, { paddingHorizontal: 0 }],
        }}
      />

      <HomeStack.Screen name="Receive" component={Receive} />
      <HomeStack.Screen name="AmountToSend" component={AmountToSend} />
      <HomeStack.Screen
        name="ReviewSend"
        component={ReviewSend}
        options={{ headerRight: () => false }}
      />
      <HomeStack.Screen name="ManageCustomNetworks" component={ManageCustomNetworksScreen} />
      <HomeStack.Screen
        name="EditCustomNetwork"
        component={EditCustomNetworkScreen}
        options={{ headerRight: () => null }}
      />
      <HomeStack.Screen
        name="NetworkDetails"
        component={NetworkDetailsScreen}
        options={{ headerRight: () => null }}
      />
      <HomeStack.Screen name="RestoreWallet" component={RestoreWallet} />
      <HomeStack.Screen
        name="ConnectWithLedger"
        component={ConnectWithLedger}
        options={{
          ...transparentHeaderScreenOptions,
          headerTitle: () => useHanaLogo(),
          headerRight: () => null,
        }}
      />
      <HomeStack.Screen name="CollectionDetails" component={CollectionDetailsScreen} />
      <HomeStack.Screen
        name="CollectableDetails"
        component={CollectableDetailsScreen}
        options={({ route }) => ({
          headerRight: () => (
            <View style={baseNavigationStyles.headerRight}>
              <OpenLinkButton
                isDarkMode={isDarkMode}
                url={route.params.collectable.originalImageUrl ?? route.params.collectable.imageUrl}
              />
            </View>
          ),
          headerTitle: () => (
            <Text bold style={{ fontSize: formatPixel(18) }}>
              {route.params.collection.name}
            </Text>
          ),
          headerTitleAlign: 'center',
        })}
      />
      <HomeStack.Screen name="ReviewSendCollectable" component={ReviewSendCollectableScreen} />
      <HomeStack.Screen name="RestoreKeystoreFile" component={RestoreKeystoreFileScreen} />

      <HomeStack.Screen name="ImportPrivateKey" component={ImportPrivateKeyScreen} />
      <HomeStack.Group screenOptions={browserScreenOptions}>
        <HomeStack.Screen
          name="Browser"
          component={Browser}
          options={
            Platform.OS === 'ios'
              ? TransitionPresets.ModalSlideFromBottomIOS
              : TransitionPresets.RevealFromBottomAndroid
          }
        />
      </HomeStack.Group>
      <HomeStack.Screen
        name="DApps"
        component={DApps}
        options={{
          ...transparentHeaderStackScreenOptions,
          headerBackImage: headerHomeStackScreenOptions.headerBackImage,
          headerRight: () => null,
          headerStyle: navigationStyles.solidHeader,
          cardStyle: navigationStyles.solidHeaderCard,
        }}
      />
    </HomeStack.Navigator>
  );
}
