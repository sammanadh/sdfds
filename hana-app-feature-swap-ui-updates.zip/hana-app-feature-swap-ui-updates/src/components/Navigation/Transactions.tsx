import { IconBack, IconBackWhite } from '@/assets/icons';
import { Transaction } from '@/models/Transaction';
import { TransactionDetails } from '@/screens/home/TransactionDetails';
import { TransactionsScreen } from '@/screens/transactions/Transactions';
import { useTheme } from '@/stores/Theme';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import React, { useMemo } from 'react';
import { View } from 'react-native';
import {
  defaultStackScreenOptions,
  navigationStyles,
  transparentHeaderStackScreenOptions,
} from './utils';
import { SwapTransactionDetails } from '@/screens/home/SwapTransactionDetails';

export type TransactionsStackParams = {
  Transactions: undefined;
  TransactionDetails: {
    transaction: Transaction;
  };
  SwapTransactionDetails: {
    transaction: Transaction;
  };
};
const TransactionsStack = createStackNavigator<TransactionsStackParams>();

export function TransactionsStackNavigator() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerTitle: () => null,
      headerStyle: [navigationStyles.transparentHeader, themeStyles.screen],
      headerBackImage: () => (
        <View style={navigationStyles.headerLeft}>
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </View>
      ),
      cardStyle: [navigationStyles.transparentHeaderCard, themeStyles.screen],
    }),
    [isDarkMode]
  );

  return (
    <TransactionsStack.Navigator initialRouteName="Transactions" screenOptions={screenOptions}>
      <TransactionsStack.Screen
        name="Transactions"
        component={TransactionsScreen}
        options={{
          headerShown: false,
          cardStyle: [screenOptions.cardStyle, { paddingHorizontal: 0 }],
        }}
      />
      <TransactionsStack.Screen name="TransactionDetails" component={TransactionDetails} />
      <TransactionsStack.Screen name="SwapTransactionDetails" component={SwapTransactionDetails} />
    </TransactionsStack.Navigator>
  );
}
