import { IconBack, IconBackWhite } from '@/assets/icons';
import { HamburgerButton } from '@/components/HamburgerButton';
import { DisclaimerScreen } from '@/screens/help/Disclaimer';
import { HelpAndSupportScreen } from '@/screens/help/HelpAndSupport';
import { useTheme } from '@/stores/Theme';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import { useMemo } from 'react';
import { View } from 'react-native';
import {
  defaultStackScreenOptions,
  navigationStyles,
  transparentHeaderStackScreenOptions,
} from './utils';

export type HelpStackParams = {
  HelpAndSupport: undefined;
  Disclaimer: undefined;
};
const HelpStack = createStackNavigator<HelpStackParams>();

export function HelpStackNavigator() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerTitle: () => null,
      headerStyle: [navigationStyles.transparentHeader, themeStyles.screen],
      headerBackImage: () => (
        <View style={navigationStyles.headerLeft}>
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </View>
      ),
      headerRight: () => (
        <View style={navigationStyles.headerRight}>
          <HamburgerButton />
        </View>
      ),
      cardStyle: [navigationStyles.transparentHeaderCard, themeStyles.screen],
    }),
    [isDarkMode]
  );

  return (
    <HelpStack.Navigator initialRouteName="HelpAndSupport" screenOptions={screenOptions}>
      <HelpStack.Screen name="HelpAndSupport" component={HelpAndSupportScreen} />
      <HelpStack.Screen name="Disclaimer" component={DisclaimerScreen} />
    </HelpStack.Navigator>
  );
}
