import { IconBack, IconBackWhite } from '@/assets/icons';
import { HamburgerButton } from '@/components/HamburgerButton';
import { TokenWithBalance } from '@/hooks/useTokens';
import { ChainWallet, RealmChainWallet, Wallet } from '@/models/Vault';
import {
  CollectionDetailsScreen,
  CollectionDetailsScreenParams,
} from '@/screens/home/CollectionDetails';
import { QRCodeScanner } from '@/screens/QRCodeScanner';
import { AmountToSend } from '@/screens/trade/AmountToSend';
import { Receive } from '@/screens/trade/Receive';
import { ReviewSend } from '@/screens/trade/ReviewSend';
import { SelectToken } from '@/screens/trade/SelectToken';
import { Send, SendScreenParams } from '@/screens/trade/Send';
import { TradeScreen } from '@/screens/trade/Trade';
import { useTheme } from '@/stores/Theme';
import type { BigNumber } from '@/utils/bignumber';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import { useMemo } from 'react';
import { View } from 'react-native';
import {
  defaultStackScreenOptions,
  navigationStyles,
  transparentHeaderStackScreenOptions,
} from './utils';
import { SwapFrom } from '@/screens/trade/SwapFrom';
import { SwapTo } from '@/screens/trade/SwapTo';
import { SwapAmount } from '@/screens/trade/SwapAmount';
import { SwapReview } from '@/screens/trade/SwapReview';
import { SwapServiceProvider, SwappableToken } from '@/models/SwapService';

export enum SelectTokenType {
  send,
  receive,
  swap,
}

export type TradeStackParams = {
  Trade: undefined;
  SelectToken: {
    type: SelectTokenType;
    isTrade?: boolean;
  };
  Send: SendScreenParams;
  AmountToSend: {
    wallet: ChainWallet | RealmChainWallet;
    token: TokenWithBalance;
    toAddress: string;
    toWallet?: Wallet | null;
  };
  ReviewSend: {
    wallet: ChainWallet | RealmChainWallet;
    token: TokenWithBalance;
    toAddress: string;
    toWallet?: Wallet | null;
    amount: BigNumber;
    dotTransferKeepAlive?: boolean;
    useMaxAmount?: boolean;
  };
  Receive: {
    wallet: ChainWallet;
    token: TokenWithBalance;
  };
  QRCodeScanner: {
    onScan: (code: string) => unknown;
  };
  CollectionDetails: CollectionDetailsScreenParams;
  SwapFrom: undefined;
  SwapTo: {
    fromToken: TokenWithBalance;
    fromSwappable: SwappableToken;
  };
  SwapAmount: {
    fromToken: TokenWithBalance;
    fromSwappable: SwappableToken;
    toToken: TokenWithBalance;
    toSwappable: SwappableToken;
  };
  SwapReview: {
    fromToken: TokenWithBalance;
    fromSwappable: SwappableToken;
    toToken: TokenWithBalance;
    toSwappable: SwappableToken;
    fromAmount: BigNumber;
    toAmount: BigNumber;
    useMaxAmount?: boolean;
    provider: SwapServiceProvider;
    slippage?: BigNumber;
  };
};
const TradeStack = createStackNavigator<TradeStackParams>();

export function TradeStackNavigator() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerTitle: () => null,
      headerStyle: [navigationStyles.transparentHeader, themeStyles.screen],
      headerBackImage: () => (
        <View style={navigationStyles.headerLeft}>
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </View>
      ),
      headerRight: () => (
        <View style={navigationStyles.headerRight}>
          <HamburgerButton />
        </View>
      ),
      cardStyle: [navigationStyles.transparentHeaderCard, themeStyles.screen],
    }),
    [isDarkMode]
  );

  return (
    <TradeStack.Navigator initialRouteName="Trade" screenOptions={screenOptions}>
      <TradeStack.Group>
        <TradeStack.Screen
          name="Trade"
          component={TradeScreen}
          options={{
            headerShown: false,
            cardStyle: [screenOptions.cardStyle, { paddingHorizontal: 0 }],
          }}
        />
        <TradeStack.Screen name="SelectToken" component={SelectToken} />
        <TradeStack.Screen name="Send" component={Send} />
        <TradeStack.Screen name="AmountToSend" component={AmountToSend} />
        <TradeStack.Screen
          name="ReviewSend"
          component={ReviewSend}
          options={{ headerRight: () => null }}
        />
        <TradeStack.Screen name="Receive" component={Receive} />
        <TradeStack.Screen name="CollectionDetails" component={CollectionDetailsScreen} />
        <TradeStack.Screen
          name="SwapFrom"
          component={SwapFrom}
          options={{ headerRight: () => null }}
        />
        <TradeStack.Screen name="SwapTo" component={SwapTo} options={{ headerRight: () => null }} />
        <TradeStack.Screen
          name="SwapAmount"
          component={SwapAmount}
          options={{ headerRight: () => null }}
        />
        <TradeStack.Screen
          name="SwapReview"
          component={SwapReview}
          options={{ headerRight: () => null }}
        />
      </TradeStack.Group>
      <TradeStack.Group screenOptions={{ headerRight: () => null }}>
        <TradeStack.Screen
          name="QRCodeScanner"
          component={QRCodeScanner}
          options={{ cardStyle: [screenOptions.cardStyle, { paddingHorizontal: 0 }] }}
        />
      </TradeStack.Group>
    </TradeStack.Navigator>
  );
}
