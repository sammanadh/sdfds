import { IconBack, IconBackWhite } from '@/assets/icons';
import { HamburgerButton } from '@/components/HamburgerButton';
import { TokenWithBalance } from '@/hooks/useTokens';
import { useTheme } from '@/stores/Theme';
import type { BigNumber } from '@/utils/bignumber';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import { useMemo } from 'react';
import { View } from 'react-native';
import {
  defaultStackScreenOptions,
  navigationStyles,
  transparentHeaderStackScreenOptions,
} from './utils';
import { SwapForm } from '@/screens/swap/SwapForm';
import { SwapReview } from '@/screens/trade/SwapReview';
import { SwapServiceProvider, SwappableToken } from '@/models/SwapService';
import { AddCustomToken } from '@/screens/home/AddCustomToken';
import { SwapFrom } from '@/screens/swap/SwapFrom';
import { SwapTo } from '@/screens/swap/SwapTo';

export enum SwapSelectTokenType {
  send,
  receive,
  swap,
}

export type SwapStackParams = {
  SwapForm: {
    fromToken: TokenWithBalance;
    fromSwappable: SwappableToken;
    toToken: TokenWithBalance;
    toSwappable: SwappableToken;
  };
  SwapFrom: undefined;
  SwapTo: {
    fromToken: TokenWithBalance;
    fromSwappable: SwappableToken;
  };
  SwapReview: {
    fromToken: TokenWithBalance;
    fromSwappable: SwappableToken;
    toToken: TokenWithBalance;
    toSwappable: SwappableToken;
    fromAmount: BigNumber;
    toAmount: BigNumber;
    useMaxAmount?: boolean;
    provider: SwapServiceProvider;
    slippage?: BigNumber;
  };
  AddCustomToken: undefined;
};
const SwapStack = createStackNavigator<SwapStackParams>();

export function SwapStackNavigator() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerTitle: () => null,
      headerStyle: [navigationStyles.transparentHeader, themeStyles.screen],
      headerBackImage: () => (
        <View style={navigationStyles.headerLeft}>
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </View>
      ),
      headerRight: () => (
        <View style={navigationStyles.headerRight}>
          <HamburgerButton />
        </View>
      ),
      cardStyle: [navigationStyles.transparentHeaderCard, themeStyles.screen],
    }),
    [isDarkMode]
  );

  return (
    <SwapStack.Navigator initialRouteName="SwapForm" screenOptions={screenOptions}>
      <SwapStack.Screen
        name="SwapForm"
        component={SwapForm}
        options={{
          headerShown: false,
          cardStyle: [screenOptions.cardStyle, { paddingHorizontal: 0 }],
        }}
      />
      <SwapStack.Screen
        name="SwapFrom"
        component={SwapFrom}
        options={{
          headerRight: () => null,
          gestureDirection: 'vertical',
          cardStyleInterpolator: ({ current, layouts }) => {
            return {
              cardStyle: {
                transform: [
                  {
                    translateY: current.progress.interpolate({
                      inputRange: [0, 1],
                      outputRange: [layouts.screen.height, 0],
                    }),
                  },
                ],
              },
            };
          },
        }}
      />
      <SwapStack.Screen
        name="SwapTo"
        component={SwapTo}
        options={{
          headerRight: () => null,
          gestureDirection: 'vertical',
          cardStyleInterpolator: ({ current, layouts }) => {
            return {
              cardStyle: {
                transform: [
                  {
                    translateY: current.progress.interpolate({
                      inputRange: [0, 1],
                      outputRange: [layouts.screen.height, 0],
                    }),
                  },
                ],
              },
            };
          },
        }}
      />
      <SwapStack.Screen
        name="SwapReview"
        component={SwapReview}
        options={{ headerRight: () => null }}
      />
      <SwapStack.Screen name="AddCustomToken" component={AddCustomToken} />
    </SwapStack.Navigator>
  );
}
