import { IconBack, IconBackWhite } from '@/assets/icons';
import { UnlockScreen } from '@/screens/Unlock';
import { useTheme } from '@/stores/Theme';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import { useMemo } from 'react';
import { View } from 'react-native';
import { UnlockConfirmReset } from '../Unlock/UnlockConfirmReset';
import {
  defaultStackScreenOptions,
  navigationStyles,
  transparentHeaderStackScreenOptions,
} from './utils';

export type UnlockStackParams = {
  Unlock: undefined;
  UnlockConfirmReset: undefined;
};
const UnlockStack = createStackNavigator<UnlockStackParams>();

export function UnlockStackNavigator() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerBackImage: () => (
        <View style={navigationStyles.headerLeft}>
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </View>
      ),
      headerStyle: [transparentHeaderStackScreenOptions.headerStyle, themeStyles.screen],
      cardStyle: [transparentHeaderStackScreenOptions.cardStyle, themeStyles.screen],
    }),
    [isDarkMode]
  );

  return (
    <UnlockStack.Navigator initialRouteName="Unlock" screenOptions={screenOptions}>
      <UnlockStack.Screen
        name="Unlock"
        component={UnlockScreen}
        options={{
          headerBackImage: () => null,
        }}
      />
      <UnlockStack.Screen name="UnlockConfirmReset" component={UnlockConfirmReset} />
    </UnlockStack.Navigator>
  );
}
