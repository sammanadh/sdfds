import { IconBack } from '@/assets/icons';
import { LogoHana, LogoHanaNewLight } from '@/assets/logos';
import { BrowserButton } from '@/components/BrowserButton';
import { HamburgerButton } from '@/components/HamburgerButton';
import { HomeButton } from '@/components/HomeButton';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { common } from '@/utils/styles';
import type {
  StackCardInterpolatedStyle,
  StackCardInterpolationProps,
} from '@react-navigation/stack';
import { StackNavigationOptions } from '@react-navigation/stack';
import { Animated, Platform, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { add, multiply } = Animated;

export function useSafeAreaHeading() {
  const insets = useSafeAreaInsets();
  return insets.top;
}

export function useHanaLogo() {
  const { isDarkMode } = useTheme();

  return isDarkMode ? <LogoHanaNewLight /> : <LogoHana />;
}

export const navigationStyles = StyleSheet.create({
  solidHeader: {
    backgroundColor: colors.brand.dark,
  },
  solidHeaderCard: {
    ...common.screen,
    backgroundColor: colors.white,
  },
  transparentHeader: {
    backgroundColor: colors.white,
    // These properties fix an issue with the header shadow
    borderBottomWidth: 0,
    borderBottomColor: 'transparent',
    shadowColor: 'transparent',
    elevation: 0,
  },
  transparentHeaderCard: {
    ...common.screen,
    backgroundColor: colors.white,
  },
  headerLeft: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 55,
    height: 45,
    marginLeft: Platform.OS === 'ios' ? 5 : -6,
  },
  headerRight: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 45,
  },
});

export function forHorizontalIOSCustom({
  current,
  next,
  inverted,
  layouts: { screen },
}: StackCardInterpolationProps): StackCardInterpolatedStyle {
  const translateFocused = multiply(
    current.progress.interpolate({
      inputRange: [0, 1],
      outputRange: [screen.width, 0],
      extrapolate: 'clamp',
    }),
    inverted
  );

  const translateUnfocused = next
    ? multiply(
        next.progress.interpolate({
          inputRange: [0, 1],
          outputRange: [0, -screen.width],
          extrapolate: 'clamp',
        }),
        inverted
      )
    : 0;

  const overlayOpacity = current.progress.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 0.07],
    extrapolate: 'clamp',
  });

  const shadowOpacity = current.progress.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 0.3],
    extrapolate: 'clamp',
  });

  return {
    cardStyle: {
      transform: [
        // Translation for the animation of the current card
        { translateX: translateFocused },
        // Translation for the animation of the card on top of this
        { translateX: translateUnfocused },
      ],
    },
    overlayStyle: { opacity: overlayOpacity },
    shadowStyle: { shadowOpacity },
  };
}

export const defaultStackScreenOptions: StackNavigationOptions = {
  cardStyleInterpolator: forHorizontalIOSCustom,
  gestureDirection: 'horizontal',
  gestureEnabled: true,
  headerMode: 'float',
  headerTransparent: false,
  headerBackTitleVisible: false,
  headerShadowVisible: false,
};

export const solidHeaderStackScreenOptions: StackNavigationOptions = {
  headerTitle: () => <HomeButton />,
  headerTitleAlign: 'left',
  headerBackImage: () => (
    <View style={navigationStyles.headerLeft}>
      <IconBack />
    </View>
  ),
  headerRight: () => (
    <View style={navigationStyles.headerRight}>
      <BrowserButton />
      <HamburgerButton />
    </View>
  ),
  headerStyle: navigationStyles.solidHeader,
  cardStyle: navigationStyles.solidHeaderCard,
};

export const transparentHeaderStackScreenOptions: StackNavigationOptions = {
  headerTitle: () => useHanaLogo(),
  headerTitleStyle: { alignSelf: 'flex-end' },
  headerTitleContainerStyle: { alignSelf: 'flex-end' },
  headerTitleAlign: 'center',
  headerBackImage: () => (
    <View style={navigationStyles.headerLeft}>
      <IconBack />
    </View>
  ),
  headerRight: () => <View style={navigationStyles.headerRight} />,
  headerStyle: navigationStyles.transparentHeader,
  cardStyle: navigationStyles.transparentHeaderCard,
};
