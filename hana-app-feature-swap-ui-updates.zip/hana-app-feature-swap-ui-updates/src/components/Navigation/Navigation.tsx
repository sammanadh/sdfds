import { useEnvironment } from '@/hooks/useEnvironment';
import { useVault } from '@/stores/Vault';
import { useNavigation } from '@react-navigation/native';
import {
  CardStyleInterpolators,
  createStackNavigator,
  StackNavigationOptions,
} from '@react-navigation/stack';
import { useEffect, useMemo } from 'react';
import { AppState, AppStateStatus } from 'react-native';
import BackgroundTimer from 'react-native-background-timer';
import { BrowserStackNavigator } from './Browser';
import { EnvironmentWarningStackNavigator } from './EnvironmentWarning';
import { MainDrawerNavigator } from './Main';
import { OnboardingStackNavigator } from './Onboarding';
import { UnlockStackNavigator } from './Unlock';

const APP_LOCK_TIME = 600000; // 10 (minutes) * 60 (seconds) * 1000

declare global {
  namespace ReactNavigation {
    interface RootParamList extends RootStackParams {}
  }
}

export type RootStackParams = {
  EnviromentWarning: undefined;
  OnboardingStack: undefined;
  UnlockStack: undefined;
  MainDrawer: undefined;
  BrowserStack: undefined;
};
const RootStack = createStackNavigator<RootStackParams>();

export function Navigation() {
  const navigation = useNavigation();
  const { isReady: isEnvironmenReady, isEmulator, isJailBroken } = useEnvironment();
  const { hasVault, isUnlocked, lockVault } = useVault();
  const initialRouteName = useMemo<keyof RootStackParams>(
    () =>
      isEmulator || isJailBroken
        ? 'EnviromentWarning'
        : hasVault
        ? isUnlocked
          ? 'MainDrawer'
          : 'UnlockStack'
        : 'OnboardingStack',
    [isEmulator, isJailBroken, hasVault, isUnlocked]
  );
  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      headerShown: false,
      cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
      gestureEnabled: false,
    }),
    []
  );

  useEffect(() => {
    AppState.addEventListener('change', handleAppStateChange);
    return () => AppState.removeEventListener('change', handleAppStateChange);
  }, []);
  function handleAppStateChange(appState: AppStateStatus) {
    // NOTE: Need to access the state here to get the latest value as the function is bound to the event listener
    const { isUnlocked, hasVault } = useVault.getState();

    if (appState === 'background' && isUnlocked && hasVault) {
      BackgroundTimer.runBackgroundTimer(async () => {
        BackgroundTimer.stopBackgroundTimer();
        lockVault();
        navigation.reset({ index: 0, routes: [{ name: 'UnlockStack' }] });
      }, APP_LOCK_TIME);
    }

    if (appState === 'active') {
      BackgroundTimer.stopBackgroundTimer();
    }
  }

  if (!isEnvironmenReady) return null;

  return (
    <RootStack.Navigator initialRouteName={initialRouteName}>
      <RootStack.Screen
        name="EnviromentWarning"
        component={EnvironmentWarningStackNavigator}
        options={screenOptions}
      />
      <RootStack.Screen
        name="OnboardingStack"
        component={OnboardingStackNavigator}
        options={screenOptions}
      />
      <RootStack.Screen
        name="UnlockStack"
        component={UnlockStackNavigator}
        options={screenOptions}
      />
      <RootStack.Screen name="MainDrawer" component={MainDrawerNavigator} options={screenOptions} />
      <RootStack.Screen
        name="BrowserStack"
        component={BrowserStackNavigator}
        options={screenOptions}
      />
    </RootStack.Navigator>
  );
}
