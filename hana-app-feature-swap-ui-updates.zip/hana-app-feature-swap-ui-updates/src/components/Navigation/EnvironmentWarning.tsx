import { EnvironmentWarning } from '@/screens/EnvironmentWarning';
import { useTheme } from '@/stores/Theme';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import { useMemo } from 'react';
import { defaultStackScreenOptions, transparentHeaderStackScreenOptions } from './utils';

export type EnvironmentWarningStackParams = {
  EnvironmentWarning: undefined;
};
const EnvironmentWarningStack = createStackNavigator<EnvironmentWarningStackParams>();

export function EnvironmentWarningStackNavigator() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerStyle: [transparentHeaderStackScreenOptions.headerStyle, themeStyles.screen],
      cardStyle: [transparentHeaderStackScreenOptions.cardStyle, themeStyles.screen],
    }),
    [isDarkMode]
  );

  return (
    <EnvironmentWarningStack.Navigator
      initialRouteName="EnvironmentWarning"
      screenOptions={screenOptions}
    >
      <EnvironmentWarningStack.Screen name="EnvironmentWarning" component={EnvironmentWarning} />
    </EnvironmentWarningStack.Navigator>
  );
}
