import { Drawer } from '@/components/Drawer';
import { TabBar } from '@/components/TabBar';
import { colors } from '@/utils/designTokens';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { createDrawerNavigator, DrawerNavigationOptions } from '@react-navigation/drawer';
import { useMemo } from 'react';
import { Dimensions } from 'react-native';
import { EarnStackNavigator } from './Earn';
import { HelpStackNavigator } from './Help';
import { HomeStackNavigator } from './Home';
import { SettingsStackNavigator } from './Settings';
import { TradeStackNavigator } from './Trade';
import { TransactionsStackNavigator } from './Transactions';
import { SwapStackNavigator } from './Swap';

export type MainTabParams = {
  HomeStack: undefined;
  TradeStack: undefined;
  SwapStack: undefined;
  EarnStack: undefined;
  TransactionsStack: undefined;
  SettingsStack: undefined;
};

const MainTab = createMaterialTopTabNavigator<MainTabParams>();

export type MainDrawerParams = {
  MainTab: undefined;
  SettingsStack: undefined;
  HelpStack: undefined;
  NetworksStack: undefined;
};
const MainDrawer = createDrawerNavigator<MainDrawerParams>();

function MainTabNavigator() {

  return (
    <MainTab.Navigator
      initialRouteName="HomeStack"
      screenOptions={{ lazy: false }}
      tabBarPosition='bottom'
      tabBar={(props) => <TabBar {...props} />}
    >
      <MainTab.Screen
        name="HomeStack"
        component={HomeStackNavigator}
        options={{ title: 'Portfolio', lazy: false }}
      />
      <MainTab.Screen
        name="TradeStack"
        component={TradeStackNavigator}
        options={{
          title: 'Trade',
          lazy: false,
        }}
      />
      <MainTab.Screen
        name="SwapStack"
        component={SwapStackNavigator}
        options={{
          title: 'Swap',
          lazy: false,
        }}
      />
      <MainTab.Screen
        name="EarnStack"
        component={EarnStackNavigator}
        options={{ title: 'Earn', lazy: false }}
      />
      <MainTab.Screen
        name="TransactionsStack"
        component={TransactionsStackNavigator}
        options={{ title: 'History', lazy: false }}
      />
      <MainTab.Screen
        name="SettingsStack"
        component={SettingsStackNavigator}
        options={{ title: 'Settings', lazy: false }} // unmountOnBlur: true
      />
    </MainTab.Navigator>
  );
}

export function MainDrawerNavigator() {
  const screenOptions = useMemo<DrawerNavigationOptions>(
    () => ({
      headerShown: false,
      drawerPosition: 'right',
      drawerType: 'front',
      drawerStyle: {
        width: Math.max(Math.ceil(Dimensions.get('screen').width * 0.8), 300),
        backgroundColor: colors.gray.background,
        borderTopLeftRadius: 20,
        borderBottomLeftRadius: 20,
      },
    }),
    []
  );

  return (
    <MainDrawer.Navigator
      initialRouteName="MainTab"
      screenOptions={screenOptions}
      drawerContent={(props) => <Drawer {...props} />}
    >
      <MainDrawer.Screen name="MainTab" component={MainTabNavigator} />
      <MainDrawer.Screen name="HelpStack" component={HelpStackNavigator} />
    </MainDrawer.Navigator>
  );
}
