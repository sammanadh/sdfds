import { IconBack, IconBackWhite } from '@/assets/icons';
import { HamburgerButton } from '@/components/HamburgerButton';
import { PRep } from '@/models/PRep';
import { EarnScreen } from '@/screens/earn/Earn';
import { AllocateVotes } from '@/screens/icxStaking/AllocateVotes';
import { ICXStaking } from '@/screens/icxStaking/ICXStaking';
import { PRepDetails } from '@/screens/icxStaking/PRepDetails';
import { useTheme } from '@/stores/Theme';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import React, { useMemo } from 'react';
import { View } from 'react-native';
import {
  defaultStackScreenOptions,
  navigationStyles,
  transparentHeaderStackScreenOptions,
} from './utils';

export type EarnStackParams = {
  Earn: undefined;
  ICXStaking:
    | {
        skipRefreshingData?: boolean;
        showVotes?: boolean;
      }
    | undefined;
  PRepDetails: {
    pRep: PRep;
  };
  AllocateVotes: undefined;
};

const EarnStack = createStackNavigator<EarnStackParams>();

export function EarnStackNavigator() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerTitle: () => null,
      headerStyle: [navigationStyles.transparentHeader, themeStyles.screen],
      headerBackImage: () => (
        <View style={navigationStyles.headerLeft}>
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </View>
      ),
      headerRight: () => (
        <View style={navigationStyles.headerRight}>
          <HamburgerButton />
        </View>
      ),
      cardStyle: [navigationStyles.transparentHeaderCard, themeStyles.screen],
    }),
    [isDarkMode]
  );

  return (
    <EarnStack.Navigator initialRouteName="Earn" screenOptions={screenOptions}>
      <EarnStack.Screen
        name="Earn"
        component={EarnScreen}
        options={{
          headerShown: false,
          cardStyle: [screenOptions.cardStyle, { paddingHorizontal: 0 }],
        }}
      />
      <EarnStack.Screen name="ICXStaking" component={ICXStaking} />
      <EarnStack.Screen name="PRepDetails" component={PRepDetails} />
      <EarnStack.Screen name="AllocateVotes" component={AllocateVotes} />
    </EarnStack.Navigator>
  );
}
