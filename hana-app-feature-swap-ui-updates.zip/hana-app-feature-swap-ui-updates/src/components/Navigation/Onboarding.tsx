import { IconBack, IconBackWhite } from '@/assets/icons';
import { ConfigureChainsScreen } from '@/screens/onboarding/ConfigureChains';
import { ConfirmSeedPhraseScreen } from '@/screens/onboarding/ConfirmSeedPhrase';
import { CreatePasscodeScreen } from '@/screens/onboarding/CreatePasscode';
import { DisclaimerScreen } from '@/screens/onboarding/Disclaimer';
import { EntryScreen } from '@/screens/onboarding/Entry';
import { ImportSeedPhraseScreen } from '@/screens/onboarding/ImportSeedPhrase';
import { ShowSeedPhraseScreen } from '@/screens/onboarding/ShowSeedPhrase';
import { useTheme } from '@/stores/Theme';
import { JOURNEY } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { createStackNavigator, StackNavigationOptions } from '@react-navigation/stack';
import { useMemo } from 'react';
import { View } from 'react-native';
import {
  defaultStackScreenOptions,
  navigationStyles,
  transparentHeaderStackScreenOptions,
} from './utils';

export type OnboardingStackParams = {
  Entry: undefined;
  CreatePasscode:
    | { journey: JOURNEY.CREATE_SEED_PHRASE }
    | { journey: JOURNEY.IMPORT_SEED_PHRASE; seedPhrase: string };
  ImportSeedPhrase: undefined;
  ShowSeedPhrase: { seedPhrase: string };
  ConfirmSeedPhrase: { seedPhrase: string };
  ConfigureChains: undefined;
  Disclaimer: undefined;
};
const OnboardingStack = createStackNavigator<OnboardingStackParams>();

export function OnboardingStackNavigator() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const screenOptions = useMemo<StackNavigationOptions>(
    () => ({
      ...defaultStackScreenOptions,
      ...transparentHeaderStackScreenOptions,
      headerStyle: [navigationStyles.transparentHeader, themeStyles.screen],
      headerBackImage: () => (
        <View style={navigationStyles.headerLeft}>
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </View>
      ),
      cardStyle: [navigationStyles.transparentHeaderCard, themeStyles.screen],
    }),
    [isDarkMode]
  );

  return (
    <OnboardingStack.Navigator initialRouteName="Entry" screenOptions={screenOptions}>
      <OnboardingStack.Screen
        name="Entry"
        component={EntryScreen}
        options={{
          headerShown: false,
          cardStyle: [
            navigationStyles.transparentHeaderCard,
            { backgroundColor: isDarkMode ? colors.purple.darkBlacker : colors.offPurple },
          ],
        }}
      />
      <OnboardingStack.Screen name="CreatePasscode" component={CreatePasscodeScreen} />
      <OnboardingStack.Screen name="ImportSeedPhrase" component={ImportSeedPhraseScreen} />
      <OnboardingStack.Screen name="ShowSeedPhrase" component={ShowSeedPhraseScreen} />
      <OnboardingStack.Screen name="ConfirmSeedPhrase" component={ConfirmSeedPhraseScreen} />
      <OnboardingStack.Screen name="ConfigureChains" component={ConfigureChainsScreen} />
      <OnboardingStack.Screen name="Disclaimer" component={DisclaimerScreen} />
    </OnboardingStack.Navigator>
  );
}
