import { common } from '@/utils/styles';
import React, { forwardRef, useState } from 'react';
import { RefreshControl, ScrollView, StyleProp, ViewStyle } from 'react-native';
import WebView, { WebViewProps } from 'react-native-webview';

interface Props extends WebViewProps {
  isRefreshing: boolean;
  onRefresh: () => unknown;
  style: StyleProp<ViewStyle>;
}

function RefreshableWebView({ isRefreshing, onRefresh, style = {}, ...props }: Props, ref: any) {
  const [isEnabled, setIsEnabled] = useState(typeof onRefresh === 'function');

  return (
    <ScrollView
      refreshControl={
        <RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} enabled={isEnabled} />
      }
      style={common.fill}
      contentContainerStyle={{ minHeight: '100%' }}
    >
      <WebView
        ref={ref}
        onScroll={(event) =>
          setIsEnabled(typeof onRefresh === 'function' && event.nativeEvent.contentOffset.y === 0)
        }
        style={[common.fill, style]}
        {...props}
      />
    </ScrollView>
  );
}

export default forwardRef(RefreshableWebView);
