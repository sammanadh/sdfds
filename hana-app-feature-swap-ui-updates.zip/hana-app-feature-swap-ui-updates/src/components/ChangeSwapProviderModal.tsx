import { SwapServiceProvider } from '@/models/SwapService';
import { StyleSheet, View } from 'react-native';
import { Text } from '@/components/Typography';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { colors } from '@/utils/designTokens';
import { useTheme } from '@/stores/Theme';

interface Props {
  onChange: (item: SwapServiceProvider) => unknown;
  items: SwapServiceProvider[];
  selectedItem: SwapServiceProvider;
}

export function ChangeSwapProviderModal({ items, selectedItem, onChange }: Props) {
  const { isDarkMode } = useTheme();

  return (
    <View>
      {items.map((item, id) => (
        <View key={`provider-${id}`}>
          <SwapProviderItem
            isDarkMode={isDarkMode}
            selected={item === selectedItem}
            onChange={onChange}
            item={item}
          />
        </View>
      ))}
    </View>
  );
}

function SwapProviderItem({ onChange, item, selected, isDarkMode }: SwapProviderItemProps) {
  return (
    <TouchableOpacity
      style={[
        styles.container,
        selected ? styles.containerSelected : {},
        isDarkMode && { backgroundColor: colors.black },
      ]}
      onPress={() => onChange(item)}
    >
      <Text bold style={isDarkMode && { color: colors.whiteSecond }}>
        {item}
      </Text>
      {selected && (
        <View style={styles.labelSelected}>
          <Text style={styles.selected}>SELECTED</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 50,
    borderRadius: 20,
    backgroundColor: colors.gray.cards,
    alignItems: 'center',
    paddingHorizontal: 20,
    flexDirection: 'row',
    marginTop: 10,
  },
  containerSelected: {
    backgroundColor: colors.gray.cards,
    borderStyle: 'solid',
    borderWidth: 2,
    borderColor: colors.offPurple,
  },
  labelSelected: {
    position: 'absolute',
    backgroundColor: colors.offPurple,
    bottom: 0,
    right: 20,
  },
  selected: {
    fontSize: 12,
    color: colors.primary,
    marginHorizontal: 8,
    marginTop: 4,
    lineHeight: 13,
    letterSpacing: 0.2,
  },
});

interface SwapProviderItemProps {
  onChange: (item: SwapServiceProvider) => any;
  item: SwapServiceProvider;
  selected: boolean;
  isDarkMode: boolean;
}
