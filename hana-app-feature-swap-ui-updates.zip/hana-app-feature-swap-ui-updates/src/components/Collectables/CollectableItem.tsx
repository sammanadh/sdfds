import { CollectableImage } from '@/components/Collectables/CollectableImage';
import { Collectable, CollectionDetails } from '@/models/Collectable';
import { colors } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

interface Props {
  item: Collectable;
  onPress: () => unknown;
  size: number;
  index: number;
  detail: CollectionDetails;
}

export function CollectableItem({ item, index, size, onPress, detail }: Props) {
  return (
    <TouchableOpacity onPress={onPress}>
      <View
        style={[
          styles.container,
          {
            marginLeft: index % 2 !== 0 ? formatPixel(15) : undefined,
            width: size,
            height: size,
          },
        ]}
      >
        {item?.imageUrl ? (
          <CollectableImage url={item?.imageUrl ?? ''} size={size} detail={detail} showChainLogo />
        ) : (
          <View
            style={{
              width: size,
              height: size,
            }}
          />
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    overflow: 'hidden',
    backgroundColor: colors.gray.cards,
  },
});
