import { CollectiblesPlaceholder } from '@/components/CollectiblesPlaceholder';
import { useCurrentNetworkName } from '@/hooks/useCurrentNetworkName';
import { CollectionDetails } from '@/models/Collectable';
import { collectablesForActiveWallet, useCollectables } from '@/stores/Collectables';
import { useVault } from '@/stores/Vault';
import React, { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import { Dimensions, StyleSheet, View } from 'react-native';
import Loading from '../Loading';
import { CollectionItem } from './CollectionItem';

interface Props {
  onSelectCollectionDetails: (details: CollectionDetails) => unknown;
}

export function CollectionsList({ onSelectCollectionDetails }: Props) {
  const service = useCurrentNetworkName();
  const screenWidth = Dimensions.get('window').width;

  const collectionItemWidth = useMemo(() => screenWidth / 2 - 30, [screenWidth]);

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  const { refreshCollectablesForActiveWallet, collectables } = useCollectables();

  const walletCollectables = React.useMemo(() => {
    return collectablesForActiveWallet();
  }, [activeWallet?.id, collectables]);

  const [loading, setLoading] = useState(false);

  useLayoutEffect(() => {
    if (!walletCollectables) {
      setLoading(true);
    } else {
      setLoading(false);
    }
  }, [walletCollectables]);

  useEffect(() => {
    refreshCollectablesForActiveWallet();
  }, [activeWallet?.id]);

  return (
    <View
      style={[
        styles.collectiblesContent,
        { justifyContent: walletCollectables.length % 2 !== 0 ? undefined : 'center' },
      ]}
    >
      {loading && (
        <View style={styles.bottom}>
          <Loading height={collectionItemWidth} width={collectionItemWidth} />
        </View>
      )}
      {walletCollectables.length && service === 'Mainnet' ? (
        walletCollectables.map((c, index) => (
          <CollectionItem
            key={c.collection.contract}
            details={c}
            onPress={() => onSelectCollectionDetails(c)}
            index={index}
            size={collectionItemWidth}
          />
        ))
      ) : (
        <View style={styles.collectiblesPlaceholder}>
          <CollectiblesPlaceholder />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  collectiblesContent: {
    flex: 1,
    flexWrap: 'wrap',
    flexDirection: 'row',
    paddingTop: 20,
  },
  collectiblesPlaceholder: { flex: 1, justifyContent: 'center' },
  bottom: { marginBottom: 15 },
});
