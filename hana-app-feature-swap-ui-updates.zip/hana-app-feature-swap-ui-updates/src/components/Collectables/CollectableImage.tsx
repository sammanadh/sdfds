import { CollectionDetails } from '@/models/Collectable';
import { useTheme } from '@/stores/Theme';
import { chainForChainID, ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { Video } from 'expo-av';
import { isEmpty, isNil } from 'lodash';
import React, { useEffect, useMemo, useState } from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import FastImage from 'react-native-fast-image';
import { SvgCss } from 'react-native-svg';
import { TokenLogo } from '../TokenLogo';

const atob = require('base-64').decode;

enum LoadingState {
  Idle,
  Loading,
  Failed,
}

interface Props {
  url?: string;
  size: number;
  circle?: boolean;
  forceImage?: boolean;
  style?: StyleProp<ViewStyle>;
  detail?: CollectionDetails;
  route?: string;
  showChainLogo?: boolean;
}

const SvgXmlBase64Prefix = 'data:image/svg+xml;base64,';

export function CollectableImage({
  url,
  size,
  circle: isCircle = false,
  forceImage = false,
  style,
  detail,
  route,
  showChainLogo,
}: Props) {
  const chain = useMemo(() => {
    const type = detail?.collection.chain.type;
    const chain = chainForChainID(type as ChainID);
    return chain;
  }, []);

  const imageUrl = useMemo(
    () =>
      transformImageUrl(
        url,
        `c_fit,w_${Math.ceil(size) * 2},h_${Math.ceil(size) * 2}${forceImage ? '/f_jpg' : ''}`
      ),
    [url, size, forceImage]
  );

  const isVideo = useMemo(
    () => !isNil(imageUrl) && (imageUrl.includes('video') || imageUrl.includes('.mp4')),
    [imageUrl]
  );

  const isSvgXmlBase64 = useMemo(
    () => imageUrl?.startsWith(SvgXmlBase64Prefix) === true,
    [imageUrl]
  );
  const svgXmlBase64 = useMemo(() => imageUrl?.replace(SvgXmlBase64Prefix, ''), [imageUrl]);
  const svgXml = useMemo(() => {
    if (isSvgXmlBase64 && svgXmlBase64) {
      // Make sure to remove/disable font-family as it causes issues with the SVG
      return atob(svgXmlBase64).replace('font-family', 'disabled-unsupported-property');
    }

    return undefined;
  }, [svgXmlBase64]);

  const [imageLoading, setImageLoading] = useState(LoadingState.Idle);
  const hasImage = useMemo(
    () => !isEmpty(imageUrl) && imageLoading !== LoadingState.Failed,
    [imageUrl, imageLoading]
  );

  useEffect(() => {
    if (!isEmpty(imageUrl) && !isSvgXmlBase64) setImageLoading(LoadingState.Loading);
  }, [imageUrl]);

  const { isDarkMode } = useTheme();

  return (
    <View
      style={[
        { borderRadius: isCircle ? Math.ceil(size / 2) : undefined, overflow: 'hidden' },
        style,
      ]}
    >
      {hasImage ? (
        isVideo && !forceImage ? (
          <>
            {showChainLogo && (
              <View
                style={[
                  styles.tinyLogo,
                  isDarkMode
                    ? { backgroundColor: colors.purple.darkBlack }
                    : { backgroundColor: colors.gray.cards },
                ]}
              >
                <TokenLogo chain={chain} size={25} />
              </View>
            )}

            <Video
              source={{
                uri: imageUrl!,
              }}
              style={[
                {
                  width: size,
                  height: size,
                },
                isCircle && { borderRadius: size / 2 },
              ]}
              onLoad={() => setImageLoading(LoadingState.Idle)}
              onError={() => setImageLoading(LoadingState.Failed)}
              shouldPlay
              isLooping
            />
          </>
        ) : svgXml ? (
          <>
            {showChainLogo && (
              <View
                style={[
                  styles.tinyLogo,
                  isDarkMode
                    ? { backgroundColor: colors.purple.darkBlack }
                    : { backgroundColor: colors.gray.cards },
                ]}
              >
                <TokenLogo chain={chain} size={25} />
              </View>
            )}

            <View style={isCircle && styles.isCircle}>
              <SvgCss
                xml={svgXml}
                style={[
                  {
                    width: size,
                    height: size,
                    backgroundColor: 'red',
                    borderRadius: 10,
                  },
                  isCircle && { borderRadius: size / 2 },
                ]}
              />
            </View>
          </>
        ) : (
          <>
            {showChainLogo && (
              <View
                style={[
                  styles.tinyLogo,
                  isDarkMode
                    ? { backgroundColor: colors.purple.darkBlack }
                    : { backgroundColor: colors.gray.cards },
                ]}
              >
                <TokenLogo chain={chain} size={25} />
              </View>
            )}
            <FastImage
              source={{
                uri: imageUrl,
                priority: FastImage.priority.normal,
              }}
              style={[
                {
                  width: size,
                  height: size,
                },
                isCircle && { borderRadius: size / 2 },
              ]}
              onLoad={() => setImageLoading(LoadingState.Idle)}
              onError={() => setImageLoading(LoadingState.Failed)}
              resizeMode="cover"
            />
          </>
        )
      ) : (
        <View
          style={{
            width: size,
            height: size,
          }}
        />
      )}
    </View>
  );
}

function transformImageUrl(imageUrl: string | undefined, transformations: string) {
  if (isNil(imageUrl) || !imageUrl.includes('/res.cloudinary.com/')) return imageUrl;

  const urlParts = imageUrl.split('/');
  const versionRegexp = /^v\d+$/;
  const versionIndex = urlParts.findIndex((part) => versionRegexp.test(part));
  if (versionIndex < 0) return imageUrl;

  return [
    ...urlParts.slice(0, versionIndex),
    transformations,
    ...urlParts.slice(versionIndex),
  ].join('/');
}

const styles = StyleSheet.create({
  tinyLogo: {
    position: 'absolute',
    bottom: 5,
    right: 5,
    zIndex: 1,
    borderRadius: 50,
    padding: 2,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  isCircle: {
    backgroundColor: 'transparent',
    width: 50,
    height: 50,
    borderRadius: 100,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
});
