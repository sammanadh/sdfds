import { Text } from '@/components/Typography';
import { CollectionDetails } from '@/models/Collectable';
import { useTheme } from '@/stores/Theme';
import { chainForChainID, ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import React, { useMemo } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { TokenLogo } from '../TokenLogo';
import { CollectableImage } from './CollectableImage';

interface Props {
  details: CollectionDetails;
  onPress: () => void;
  size: number;
  index: number;
}

export function CollectionItem({ details, index, size, onPress }: Props) {
  const { isDarkMode } = useTheme();

  const chain = useMemo(() => {
    const type = details?.collection.chain.type;
    const chain = chainForChainID(type as ChainID);
    return chain;
  }, []);

  return (
    <View>
      {
        <TouchableOpacity
          onPress={() => onPress()}
          style={[
            styles.item,
            {
              width: size,
              marginLeft: index % 2 !== 0 ? 20 : undefined,
            },
          ]}
        >
          {details?.coverImage ? (
            <View>
              <View
                style={[
                  styles.tinyLogo,
                  isDarkMode
                    ? { backgroundColor: colors.purple.darkBlack }
                    : { backgroundColor: colors.gray.cards },
                ]}
              >
                <TokenLogo chain={chain} size={25} />
              </View>
              <CollectableImage url={details?.coverImage ?? ''} size={size} forceImage />
            </View>
          ) : (
            <View style={{ width: size, height: size }} />
          )}
          <View
            style={[styles.itemInfo, isDarkMode && { backgroundColor: colors.purple.darkBlack }]}
          >
            <Text
              bold
              numberOfLines={1}
              style={[styles.cardName, isDarkMode && { color: colors.whiteSecond }]}
            >
              {details?.collection?.name ?? ''}
            </Text>
            <Text muted style={[styles.cardQuantity, isDarkMode && { color: colors.whiteSecond }]}>
              {details?.tokensCount ?? ''}
            </Text>
          </View>
        </TouchableOpacity>
      }
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    marginBottom: formatPixel(15),
    overflow: 'hidden',
    backgroundColor: colors.gray.cards,
  },
  itemInfo: {
    flex: 1,
    flexDirection: 'row',
    paddingHorizontal: formatPixel(10),
    paddingVertical: formatPixel(10),
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardName: {
    flex: 8,
    fontSize: formatPixel(14),
    color: colors.black,
  },
  cardQuantity: {
    flex: 2,
    textAlign: 'right',
    fontSize: formatPixel(12),
  },
  tinyLogo: {
    position: 'absolute',
    bottom: 5,
    right: 5,
    zIndex: 1,
    borderRadius: 50,
    padding: 2,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
