import { IconDarkMode, IconLightMode } from '@/assets/icons';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import React, { useLayoutEffect, useMemo, useRef } from 'react';
import {
  Animated,
  Insets,
  Pressable,
  StyleProp,
  StyleSheet,
  TouchableWithoutFeedback,
  View,
  ViewStyle,
} from 'react-native';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const ANIMATION_DEFAULTS: Animated.SpringAnimationConfig = {
  toValue: 0,
  bounciness: 0,
  useNativeDriver: true,
};
const HIT_SLOP_LARGE: Insets = { top: 10, right: 10, bottom: 10, left: 10 };

type Props = {
  // isDarkMode: boolean;
  // onChange: (newValue: boolean) => void;
  disabled?: boolean;
  switchSize?: number;
  barWidth?: number;
  barHeight?: number;
  switchColor?: string;
  activeColor?: string;
  inactiveColor?: string;
  style?: StyleProp<ViewStyle>;
};

const ColorSchemeSwitch = ({
  // isDarkMode,
  // onChange,
  disabled: isDisabled = false,
  switchSize = 30,
  barWidth = 48,
  barHeight = 18,
  switchColor = colors.purple.darkPrimary,
  activeColor = colors.purple.darkPrimary,
  inactiveColor = colors.gray.watermark,
  style = {},
}: Props) => {
  const { isDarkMode, setTheme } = useTheme();
  const barStyle = useMemo<ViewStyle>(
    () => ({
      width: barWidth,
      height: barHeight,
      borderRadius: Math.ceil(barHeight / 2),
    }),
    [barWidth, barHeight]
  );
  const switchStyle = useMemo<ViewStyle>(
    () => ({
      width: switchSize,
      height: switchSize,
      borderWidth: 3,
      borderRadius: Math.ceil(switchSize / 2),
      padding: 0,
    }),
    [switchSize, switchColor]
  );
  const activeOffset = useMemo(() => barWidth - switchSize, [barWidth]);
  const inactiveOffset = useMemo(() => 0, []);
  const slideAnimation = useRef(
    new Animated.Value(isDarkMode ? activeOffset : inactiveOffset)
  ).current;
  const colorAnimation = useRef(new Animated.Value(isDarkMode ? 1 : 0)).current;
  // const opacityAnimation = useRef(new Animated.Value(isDarkMode ? 1 : 0)).current;
  const barInterpolation: Animated.InterpolationConfigType = useMemo(
    () => ({
      inputRange: [0, 1],
      outputRange: [inactiveColor, activeColor],
    }),
    [activeColor, inactiveColor]
  );
  const switchInterpolation: Animated.InterpolationConfigType = useMemo(
    () => ({
      inputRange: [0, 1],
      outputRange: [colors.white, switchColor],
    }),
    [switchColor]
  );
  const switchBorderInterpolation: Animated.InterpolationConfigType = useMemo(
    () => ({
      inputRange: [0, 1],
      outputRange: [inactiveColor, switchColor],
    }),
    [inactiveColor, switchColor]
  );

  useLayoutEffect(() => {
    Animated.spring(slideAnimation, {
      ...ANIMATION_DEFAULTS,
      toValue: isDarkMode ? activeOffset : inactiveOffset,
    }).start();
    Animated.spring(colorAnimation, {
      ...ANIMATION_DEFAULTS,
      toValue: isDarkMode ? 1 : 0,
      useNativeDriver: false,
    }).start();
    // Animated.spring(opacityAnimation, {
    //   ...ANIMATION_DEFAULTS,
    //   toValue: isDarkMode ? 1 : 0,
    //   useNativeDriver: false,
    // }).start();
  }, [isDarkMode]);

  function handleChange() {
    setTheme(isDarkMode ? 'light' : 'dark');
  }

  return (
    <View style={[styles.centerContent, { width: barWidth, height: switchSize }, style]}>
      <TouchableWithoutFeedback
        onPress={handleChange}
        disabled={isDisabled}
        hitSlop={HIT_SLOP_LARGE}
        style={{}}
      >
        <Animated.View
          style={[
            barStyle,
            { backgroundColor: colorAnimation.interpolate(barInterpolation) },
            isDisabled && styles.barDisabled,
          ]}
        />
      </TouchableWithoutFeedback>

      <Animated.View
        style={[styles.switchContainer, { transform: [{ translateX: slideAnimation }] }]}
      >
        <AnimatedPressable
          onPress={handleChange}
          disabled={isDisabled}
          style={[
            styles.shadow,
            styles.centerContent,
            switchStyle,
            {
              // backgroundColor: colorAnimation.interpolate(switchInterpolation),
              borderColor: colorAnimation.interpolate(switchBorderInterpolation),
              backgroundColor: isDarkMode ? colors.purple.darkPrimary : colors.gray.watermark,
            },
            isDisabled && styles.switchDisabled,
          ]}
        >
          <Animated.View style={[styles.centerContent]}>
            {isDarkMode ? (
              <IconDarkMode width={20} height={20} color={colors.purple.darkOff} />
            ) : (
              <IconLightMode width={20} height={20} color={colors.yellow} />
            )}
          </Animated.View>
        </AnimatedPressable>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  switchContainer: {
    position: 'absolute',
    left: 0,
  },
  switchDisabled: {
    opacity: 1,
    backgroundColor: colors.gray.inactive,
  },
  barDisabled: {
    opacity: 0.5,
  },
  shadow: {
    backgroundColor: colors.white,
    borderRadius: 14,
    padding: 20,
    shadowColor: colors.shadow,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.08,
    shadowRadius: 3,
    elevation: 0,
  },
  centerContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export { ColorSchemeSwitch };
