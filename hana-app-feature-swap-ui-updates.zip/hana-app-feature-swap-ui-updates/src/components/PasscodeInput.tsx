import { TextInput, TextInputRef } from '@/components/TextInput';
import { PINCODE_LENGTH } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { isEmpty, isNil } from 'lodash-es';
import {
  forwardRef,
  ForwardRefRenderFunction,
  MutableRefObject,
  useEffect,
  useMemo,
  useRef,
} from 'react';
import {
  NativeSyntheticEvent,
  StyleSheet,
  TextInput as RNTextInput,
  TextInputProps,
  TextInputSubmitEditingEventData,
  View,
} from 'react-native';
import { CodeField, RenderCellOptions } from 'react-native-confirmation-code-field';

export enum PasscodeType {
  Pincode,
  Password,
}
interface Props extends TextInputProps {
  type?: PasscodeType;
  error?: boolean;
}

const BasePasscodeInput: ForwardRefRenderFunction<TextInputRef, Props> = (
  { type = PasscodeType.Pincode, style = {}, ...props }: Props,
  outerRef
) => {
  const innerRef = useRef<TextInputRef>(null);
  const ref = useMemo(
    () => (isNil(outerRef) ? innerRef : (outerRef as MutableRefObject<RNTextInput>)),
    [innerRef, outerRef]
  );

  useEffect(() => {
    if (type !== PasscodeType.Pincode) return;
    if (props.value?.length === PINCODE_LENGTH && !isNil(props.onSubmitEditing)) {
      props.onSubmitEditing({
        nativeEvent: { text: props.value },
      } as NativeSyntheticEvent<TextInputSubmitEditingEventData>);
    }
  }, [props.value]);

  function renderPincodeCell({ symbol, isFocused, index }: RenderCellOptions) {
    return (
      <View
        key={index}
        style={[
          styles.cell,
          !isEmpty(symbol) && styles.cellFilled,
          isFocused && styles.cellFocused,
        ]}
      />
    );
  }

  function renderPincode() {
    return (
      <CodeField
        ref={ref}
        value={props.value}
        cellCount={PINCODE_LENGTH}
        renderCell={renderPincodeCell}
        keyboardType="number-pad"
        rootStyle={[styles.pincode, style]}
        {...props}
      />
    );
  }

  function renderPassword() {
    return (
      <TextInput
        ref={ref}
        placeholder="Enter your password"
        secureTextEntry
        autoCapitalize="none"
        autoCompleteType="off"
        autoCorrect={false}
        style={style}
        {...props}
      />
    );
  }

  return type === PasscodeType.Pincode ? renderPincode() : renderPassword();
};

export const PasscodeInput = forwardRef(BasePasscodeInput);

const styles = StyleSheet.create({
  pincode: {
    width: 250,
    height: 50,
    alignSelf: 'center',
    alignItems: 'center',
  },
  cell: {
    width: 25,
    height: 25,
    backgroundColor: colors.white,
    borderColor: colors.black,
    borderWidth: 1.5,
    borderRadius: 25,
  },
  cellFilled: {
    backgroundColor: colors.brand.dark,
    borderColor: colors.brand.dark,
  },
  cellFocused: {
    backgroundColor: colors.brand.light,
  },
});
