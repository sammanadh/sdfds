import { IconClose, IconCloseWhite } from '@/assets/icons';
import { useTheme } from '@/stores/Theme';
import { common } from '@/utils/styles';
import {
  GestureResponderEvent,
  StyleProp,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
} from 'react-native';

interface Props {
  onPress?(event: GestureResponderEvent): void;
  style?: StyleProp<ViewStyle>;
}

export function CloseButton({ onPress, style }: Props) {
  const { isDarkMode } = useTheme();

  return (
    <TouchableOpacity onPress={onPress} style={[common.centerContent, styles.container, style]}>
      {isDarkMode ? <IconCloseWhite /> : <IconClose />}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: 30,
    height: 30,
  },
});
