import { Text } from '@/components/Typography';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { StyleSheet, View } from 'react-native';

interface Props {
  children: React.ReactNode;
}

export function Badge({ children }: Props) {
  return (
    <View style={styles.container}>
      <Text small style={styles.title}>
        {children}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.purple.light,
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  title: {
    color: colors.purple.dark,
  },
});
