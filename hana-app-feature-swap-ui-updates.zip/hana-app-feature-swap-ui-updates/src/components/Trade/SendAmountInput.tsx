import { Text } from '@/components/Typography';
import type { BigNumber } from '@/utils/bignumber';
import { colors } from '@/utils/designTokens';
import React, { useState } from 'react';
import { StyleSheet, TextInput as RNTextInput, TouchableOpacity, View } from 'react-native';

interface Props {
  symbol: string;
  value: string;
  onValueChanged: (value: string) => unknown;
  maxEnabled: boolean;
  onMax: () => unknown;
  totalUSD: BigNumber;
  isDarkMode?: boolean;
}

export function SendAmountInput({
  symbol,
  value,
  onValueChanged,
  maxEnabled,
  onMax,
  totalUSD,
  isDarkMode,
}: Props) {
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = React.useRef<RNTextInput>(null);

  return (
    <View
      style={[
        styles.container,
        isFocused && styles.inputFocused,
        isDarkMode && { backgroundColor: colors.black },
      ]}
      onTouchStart={() => {
        inputRef.current?.focus();
      }}
    >
      <View style={styles.textInputContainer}>
        <RNTextInput
          ref={inputRef}
          style={[{ flex: 1 }, isDarkMode && { color: colors.whiteSecond }]}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          value={`${String(value)}`}
          placeholderTextColor="#9690a6"
          onChangeText={(text) => onValueChanged(text)}
          keyboardType="decimal-pad"
          autoFocus
          placeholder={`${symbol}`}
        />
        <Text style={styles.symbol}>{symbol}</Text>
      </View>

      <View style={styles.accessoryContainer}>
        <TouchableOpacity style={styles.btnMax} onPress={onMax}>
          <Text bold style={styles.txtMax}>
            MAX
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 50,
    backgroundColor: colors.white,
    borderColor: colors.black,
    borderWidth: 2,
    borderRadius: 25,
    paddingVertical: 0,
    paddingLeft: 20,
    paddingRight: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  textInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 10,
  },
  symbol: {
    marginRight: 0,
  },
  inputFocused: {
    borderColor: colors.offPurple,
  },
  accessoryContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  btnMax: {
    backgroundColor: colors.offPurple,
    width: 50,
    height: 26,
    borderRadius: 13,
    justifyContent: 'center',
    alignItems: 'center',
  },
  txtMax: {
    color: colors.black,
    fontSize: 12,
    letterSpacing: 0.2,
  },
});
