import { IconNextBlack, IconNextWhite } from '@/assets/icons';
import { TokenWithBalance } from '@/hooks/useTokens';
import { Token } from '@/models/Vault';
import { usePrices } from '@/stores/Price';
import { useTheme } from '@/stores/Theme';
import { BigNumber } from '@/utils/bignumber';
import { chains } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import { colors, paletteDark } from '@/utils/designTokens';
import { formatAmount, formatPrice } from '@/utils/format';
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { ActivityIndicator } from '../ActivityIndicator';
import { TokenLogo } from '../TokenLogo';
import { Heading, Text } from '../Typography';

interface Props {
  fromToken: TokenWithBalance;
  fromAmount: BigNumber;
  toToken: TokenWithBalance;
  toAmount: BigNumber;
  loading?: boolean;
  showTokenNameAndSymbol?: boolean;
}

export function SwapAmountHeader({
  fromToken,
  fromAmount,
  toToken,
  toAmount,
  loading,
  showTokenNameAndSymbol,
}: Props) {
  const { isDarkMode } = useTheme();
  const { getTokenPrice, getNativePrice } = usePrices();

  const fromTokenChain = chains.find((chain) => chain.id === fromToken.chainId)!;
  const toTokenChain = chains.find((chain) => chain.id === toToken.chainId)!;

  const fromTokenPrice = fromToken.contract
    ? getTokenPrice(fromToken.contract)
    : getNativePrice(fromTokenChain);
  const toTokenPrice = toToken.contract
    ? getTokenPrice(toToken.contract)
    : getNativePrice(toTokenChain);

  const fromTokenBalancePrice = fromTokenPrice.times(fromAmount);
  const toTokenBalancePrice = toTokenPrice.times(toAmount);

  const fromTokenBalancePriceString = formatPrice(fromTokenBalancePrice, false);
  const toTokenBalancePriceString = formatPrice(toTokenBalancePrice, false);

  return (
    <View style={styles.container}>
      <View style={styles.tokenContainer}>
        <TokenLogo
          chain={fromTokenChain}
          token={!fromToken.native ? (fromToken as unknown as Token) : undefined}
          size={70}
        />
        <Heading style={styles.amount}>{formatAmount(fromAmount)}</Heading>
        <Text bold muted style={styles.price}>
          {fromTokenBalancePriceString}
        </Text>

        {showTokenNameAndSymbol && (
          <>
            <Text bold style={styles.symbol}>
              {fromToken.symbol}
            </Text>
            <Text bold muted style={styles.name}>
              {fromTokenChain.name}
            </Text>
          </>
        )}
      </View>

      <View
        style={{
          width: 40,
          height: 40,
          marginTop: 25,
        }}
      >
        {loading ? (
          <ActivityIndicator color={isDarkMode ? paletteDark.foreground : colors.black} size={30} />
        ) : isDarkMode ? (
          <IconNextWhite />
        ) : (
          <IconNextBlack />
        )}
      </View>

      <View style={styles.tokenContainer}>
        <TokenLogo
          chain={toTokenChain}
          token={!toToken.native ? (toToken as unknown as Token) : undefined}
          size={70}
        />
        <Heading style={styles.amount}>{formatAmount(toAmount)}</Heading>
        <Text bold muted style={styles.price}>
          {toTokenBalancePriceString}
        </Text>

        {showTokenNameAndSymbol && (
          <>
            <Text bold style={styles.symbol}>
              {toToken.symbol}
            </Text>
            <Text bold muted style={styles.name}>
              {toTokenChain.name}
            </Text>
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
  },
  tokenContainer: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  amount: {
    marginTop: 5,
    marginBottom: 2,
  },
  symbol: {
    fontSize: 14,
    marginTop: 14,
  },
  price: {
    fontSize: 12,
  },
  name: {
    fontSize: 12,
  },
});
