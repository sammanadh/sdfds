import { IconNextBlack, IconNextWhite } from '@/assets/icons';
import BuyIcon from '@/assets/icons/trade-buy.svg';
import SwapIcon from '@/assets/icons/trade-swap.svg';
import { LogoReceive, LogoSend } from '@/assets/logos';
import { AltHeading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { useMemo } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

export enum ButtonType {
  send,
  receive,
  buy,
  swap,
}

interface Props {
  type: ButtonType;
  onPress: () => unknown;
}

function getIconImage(type: ButtonType) {
  switch (type) {
    case ButtonType.send:
      return <LogoSend width={40} height={40} />;
    case ButtonType.receive:
      return <LogoReceive width={40} height={40} />;
    case ButtonType.buy:
      return <BuyIcon width={40} height={40} />;
    case ButtonType.swap:
      return <SwapIcon width={40} height={40} />;
  }
}

function getTitle(type: ButtonType) {
  switch (type) {
    case ButtonType.send:
      return 'Send';
    case ButtonType.receive:
      return 'Receive';
    case ButtonType.buy:
      return 'Buy';
    case ButtonType.swap:
      return 'Swap';
  }
}

function getSubtitle(type: ButtonType) {
  switch (type) {
    case ButtonType.send:
      return 'Send tokens to an address';
    case ButtonType.receive:
      return 'Receive tokens to your wallet';
    case ButtonType.buy:
      return 'Buy tokens right from Hana';
    case ButtonType.swap:
      return 'Swap your tokens for another';
  }
}

export default function Button({ type, onPress }: Props) {
  const { isDarkMode } = useTheme();

  const badge = useMemo(() => {
    if (type === ButtonType.swap) {
      return 'BETA';
    }

    return null;
  }, [type]);

  return (
    <TouchableOpacity onPress={onPress}>
      <View
        style={[
          styles.container,
          { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards },
        ]}
      >
        <View style={styles.icon}>{getIconImage(type)}</View>
        <View style={styles.titlesContainer}>
          <View style={styles.titleAndBadgeContainer}>
            <Text large bold style={isDarkMode && { color: colors.whiteSecond }}>
              {getTitle(type)}
            </Text>

            {badge && (
              <View
                style={[
                  styles.badge,
                  { backgroundColor: isDarkMode ? '#AC95E5' : colors.offPurple },
                ]}
              >
                <Text bold style={styles.badgeTitle}>
                  {badge}
                </Text>
              </View>
            )}
          </View>

          <AltHeading
            style={{
              marginTop: 6,
            }}
          >
            {getSubtitle(type)}
          </AltHeading>
        </View>
        {isDarkMode ? <IconNextWhite /> : <IconNextBlack />}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 82,
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 16,
  },
  icon: {
    width: 40,
    height: 40,
  },
  titlesContainer: {
    flex: 1,
    marginHorizontal: 15,
  },
  titleAndBadgeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  badge: {
    borderRadius: 16,
    marginLeft: 8,
    paddingHorizontal: 12,
    paddingVertical: 2,
  },
  badgeTitle: {
    fontSize: 12,
    color: colors.foreground,
  },
});
