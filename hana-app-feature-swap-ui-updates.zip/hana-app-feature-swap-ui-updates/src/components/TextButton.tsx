import { Text, TextProps } from '@/components/Typography';
import { HIT_SLOP_LARGE, HIT_SLOP_SMALL } from '@/utils/constants';
import { isNil } from 'lodash-es';
import { PropsWithChildren, ReactNode } from 'react';
import {
  GestureResponderEvent,
  StyleProp,
  StyleSheet,
  TextStyle,
  TouchableOpacity,
  View,
} from 'react-native';

interface Props extends PropsWithChildren<TextProps> {
  onPress?: ((event: GestureResponderEvent) => void) & (() => void);
  disabled?: boolean;
  prefix?: ReactNode;
  hitSlop?: 'small' | 'large';
  inline?: boolean;
  textStyle?: StyleProp<TextStyle>;
}

export function TextButton({
  onPress,
  disabled,
  prefix,
  hitSlop = 'large',
  inline = false,
  center = false,
  style,
  textStyle,
  ...props
}: Props) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      hitSlop={hitSlop === 'large' ? HIT_SLOP_LARGE : HIT_SLOP_SMALL}
      style={[styles.container, center && styles.center, inline && styles.inline, style]}
    >
      {!isNil(prefix) && <View style={styles.prefix}>{prefix}</View>}
      <Text small bold brand style={textStyle} {...props} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  prefix: {
    marginRight: 7,
  },
  center: {
    alignSelf: 'center',
  },
  inline: {
    marginBottom: -3,
  },
});
