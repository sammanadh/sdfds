import { StyleSheet, View, ViewStyle } from 'react-native';
import { useMemo } from 'react';
import { formatInitials } from '@/utils/format';
import { colors, fonts } from '@/utils/designTokens';
import { Text } from '@/components/Typography';

interface EntityProps {
  name?: string;
  size?: number;
  style?: ViewStyle;
}

export function EntityImage({ name = '1', size = 50 }: EntityProps) {
  const initials = useMemo(() => formatInitials(name), [name]);
  return (
    <View
      style={[
        {
          width: size,
          height: size,
          borderRadius: size / 2,
        },
        styles.container,
      ]}
    >
      <Text style={styles.text}>{initials}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.offPurple,
  },
  text: {
    color: '#321ea8',
    textTransform: 'uppercase',
    fontSize: 12,
    lineHeight: 50,
    fontFamily: fonts.heavy,
  },
});
