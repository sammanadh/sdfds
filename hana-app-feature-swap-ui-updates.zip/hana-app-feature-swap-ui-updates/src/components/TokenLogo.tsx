import BinanceLogo from '@/assets/logos/binance-white.svg';
import EthereumLogo from '@/assets/logos/ethereum-white.svg';
import HarmonyLogo from '@/assets/logos/harmony-white.svg';
import HAVAHLogo from '@/assets/logos/havah-white.svg';
import IconLogo from '@/assets/logos/icon-white.svg';
import KusamaLogo from '@/assets/logos/kusama-white.svg';
import PolkadotLogo from '@/assets/logos/polkadot-white.svg';
import SnowEvmLogo from '@/assets/logos/snow-icon-evm.svg';
import WanchainLogo from '@/assets/logos/wanchain.svg';
import ShidenLogo from '@/assets/logos/shiden.svg';
import { Text } from '@/components/Typography';
import { Token } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainDetails, ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { getTokenLogo } from '@/utils/token';
import { gt, isNil } from 'lodash-es';
import { useEffect, useMemo, useState } from 'react';
import { Image, StyleSheet, TextStyle, View, ViewStyle } from 'react-native';

interface Props {
  chain?: ChainDetails;
  token?: Token;
  size?: number;
  showChainLogo?: boolean;
}

export function TokenLogo({ chain, token, size = 50, showChainLogo = true }: Props) {
  const [tokenLogoUrl, setTokenLogoUrl] = useState<string | null | undefined>(null);
  const { realm } = useVault();

  const { isDarkMode } = useTheme();
  const existingToken = useMemo(() => {
    if (!token?.contract) return undefined;

    // Find existing token if available
    // Curated tokens may contain logoUrl
    const existingTokens = realm
      ?.objects<Token>('Token')
      .filtered('contract ==[c] $0', token.contract);

    if (existingTokens && existingTokens[0]) {
      const existingToken = existingTokens[0];
      return existingToken;
    }

    return undefined;
  }, [token]);

  const isNativeToken = isNil(token);

  const chainLogoContainerSize = useMemo(() => size * 0.5, [size]);

  useEffect(() => {
    async function fetchTokenLogoUrl() {
      if (existingToken && existingToken.logoUrl) {
        setTokenLogoUrl(existingToken.logoUrl);
        return;
      }

      if (token) {
        const logoUrl = token.logoUrl || (await getTokenLogo(token));
        setTokenLogoUrl(logoUrl);
      }
    }

    fetchTokenLogoUrl();
  }, [token, existingToken]);

  const symbol = useMemo(() => token?.symbol || chain?.token.symbol || '', [chain, token]);

  const logoBackgroundColor = useMemo(() => {
    if (!isNativeToken) {
      return !isNil(tokenLogoUrl)
        ? 'transparent'
        : !isNil(chain)
        ? getBrandColor(chain.id)
        : 'transparent';
    }

    return chain && isNativeToken ? getBrandColor(chain.id) : 'transparent';
  }, [chain, token, isNativeToken, tokenLogoUrl]);

  const logoStyle = useMemo<ViewStyle>(
    () => ({
      width: size,
      height: size,
      borderRadius: Math.ceil(size / 2),
      backgroundColor: logoBackgroundColor,
    }),
    [chain, token, tokenLogoUrl, size, logoBackgroundColor]
  );

  const textStyle = useMemo<TextStyle>(
    () => ({
      fontSize: gt(symbol.length, 4) ? 11 : gt(symbol.length, 3) ? 13 : 15,
      color: colors.whiteSecond,
    }),
    [chain, token]
  );

  function renderLogoOrSymbol() {
    if (token) {
      if (tokenLogoUrl) {
        return (
          <Image
            source={{ uri: tokenLogoUrl }}
            style={{
              aspectRatio: 1,
              borderRadius: size / 2,
              overflow: 'hidden',
              width: size,
              height: size,
            }}
            width={size}
            height={size}
          />
        );
      } else {
        return (
          <Text bold style={textStyle}>
            {symbol}
          </Text>
        );
      }
    }

    if (!isNil(chain)) {
      switch (chain.id) {
        case ChainID.ICON:
          return <IconLogo width="100%" height="50%" />;

        case ChainID.HAVAH:
          return <HAVAHLogo width="100%" height="80%" />;

        case ChainID.Ethereum:
          return <EthereumLogo width="100%" height="60%" />;

        case ChainID.Polkadot:
          return <PolkadotLogo width="100%" height="64%" />;

        case ChainID.Kusama:
          return <KusamaLogo width="100%" height="43%" />;

        case ChainID.Moonbeam:
          return (
            <Image
              source={require('@/assets/logos/moonbeam.png')}
              style={{
                width: '76%',
                height: undefined,
                aspectRatio: 1,
              }}
            />
          );

        case ChainID.Moonriver:
          return (
            <Image
              source={require('@/assets/logos/moonriver.png')}
              style={{
                width: '76%',
                height: undefined,
                aspectRatio: 1,
              }}
            />
          );

        case ChainID.Binance:
          return <BinanceLogo width="100%" height="60%" />;

        case ChainID.Harmony:
          return <HarmonyLogo width="100%" height="65%" />;

        case ChainID.SNOW:
        case ChainID.Arctic:
          // NOTE the SVG version is not supported by react-native-svg (No stops in gradient error)
          return (
            <Image
              source={require('@/assets/logos/snow-icon.png')}
              style={{ width: '70%', height: undefined, aspectRatio: 1 }}
            />
          );

        case ChainID.SNOW_EVM:
        case ChainID.Arctic_EVM:
          return <SnowEvmLogo width="100%" height="70%" />;

        case ChainID.Wanchain:
          return <WanchainLogo width="100%" height="80%" />;

        case ChainID.Avalanche:
          return (
            <Image
              source={require('@/assets/logos/avaxc.png')}
              style={{
                width: '103%',
                height: undefined,
                aspectRatio: 1,
              }}
            />
          );

        case ChainID.Polygon:
          return (
            <Image
              source={require('@/assets/logos/polygon.png')}
              style={{
                width: '103%',
                height: undefined,
                aspectRatio: 1,
              }}
            />
          );

        case ChainID.Arbitrum:
          return (
            <Image
              source={require('@/assets/logos/arbitrum.png')}
              style={{
                width: '76%',
                height: undefined,
                aspectRatio: 1,
              }}
            />
          );

        case ChainID.Optimism:
          return (
            <Image
              source={require('@/assets/logos/optimism.png')}
              style={{
                width: '103%',
                height: undefined,
                aspectRatio: 1,
              }}
            />
          );

        case ChainID.Astar:
          return (
            <Image
              source={require('@/assets/logos/astar.png')}
              style={{ width: '103%', height: undefined, aspectRatio: 1 }}
            />
          );
        case ChainID.Astar_EVM:
          return (
            <Image
              source={require('@/assets/logos/astar-grayscale.png')}
              style={{ width: '103%', height: undefined, aspectRatio: 1 }}
            />
          );

        case ChainID.Shiden:
        case ChainID.Shibuya:
          return <ShidenLogo width="100%" height="60%" />;

        case ChainID.Shiden_EVM:
        case ChainID.Shibuya_EVM:
          return (
            <Image
              source={require('@/assets/logos/shiden-grayscale.png')}
              style={{ width: '76%', height: undefined, aspectRatio: 1 }}
            />
          );
      }
    }

    return (
      <Text bold style={textStyle}>
        {symbol}
      </Text>
    );
  }

  return (
    <View style={[styles.container, logoStyle]}>
      {renderLogoOrSymbol()}

      {!isNativeToken && showChainLogo && (
        <View
          style={[
            styles.tinyChainLogo,
            {
              width: chainLogoContainerSize,
              height: chainLogoContainerSize,
            },
            isDarkMode
              ? { backgroundColor: colors.purple.darkBlack, borderColor: colors.purple.darkBlack }
              : { backgroundColor: colors.gray.cards, borderColor: colors.gray.cards },
          ]}
        >
          <TokenLogo chain={chain} size={chainLogoContainerSize * 0.92} />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingLeft: 1,
  },
  tinyChainLogo: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    borderRadius: 50,
    padding: 1.5,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

function getBrandColor(chainId: ChainID) {
  switch (chainId) {
    case ChainID.ICON:
      return '#1aaaba';
    case ChainID.Ethereum:
      return '#5e79e3';
    case ChainID.Polkadot:
      return '#e6007a';
    case ChainID.Kusama:
      return 'rgb(230, 0, 122)';
    case ChainID.Moonbeam:
      return '#0D1126';
    case ChainID.Moonriver:
      return '#0E122F';
    case ChainID.Binance:
      return 'rgb(240, 185, 11)';
    case ChainID.Harmony:
      return '#00aee9';
    case ChainID.Arctic:
    case ChainID.SNOW:
      return '#2B23B4';
    case ChainID.Arctic_EVM:
    case ChainID.SNOW_EVM:
    case ChainID.Astar:
    case ChainID.Astar_EVM:
    case ChainID.Shiden:
    case ChainID.Shiden_EVM:
    case ChainID.Shibuya:
    case ChainID.Shibuya_EVM:
      return '#FFFFFF';
    case ChainID.Wanchain:
      return '#FFFFFF';
    case ChainID.HAVAH:
      return '#202225';
    case ChainID.Arbitrum:
      return '#2c374b';
    case ChainID.Arbitrum:
      return '#2c374b';
    case ChainID.Polygon:
      return '#2c374b';
    case ChainID.Arbitrum:
      return '#2c374b';
    case ChainID.Optimism:
      return '#2c374b';
    default:
      return colors.brand.primary;
  }
}
