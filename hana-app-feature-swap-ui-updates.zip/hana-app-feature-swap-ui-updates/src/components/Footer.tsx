import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { common } from '@/utils/styles';
import { PropsWithChildren, useMemo } from 'react';
import { StyleProp, StyleSheet, ViewStyle } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';

type Props = PropsWithChildren<{
  containerStyle?: StyleProp<ViewStyle>;
}>;

export function Footer({ containerStyle, children }: Props) {
  const insets = useSafeAreaInsets();
  const paddingBottom = useMemo(() => Math.max(20 - insets.bottom, 0), [insets]);
  const { isDarkMode } = useTheme();

  return (
    <SafeAreaView
      style={[
        common.negateScreen,
        common.screen,
        styles.container,
        isDarkMode && styles.containerDark,
        { paddingBottom },
        containerStyle,
      ]}
      edges={['bottom', 'left', 'right']}
    >
      {children}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.white,
    paddingTop: 20,
  },
  containerDark: {
    backgroundColor: colors.purple.darkBlacker,
  },
});
