import { DropdownIcon, DropdownIconWhite } from '@/assets/icons';
import { TokenLogo } from '@/components/TokenLogo';
import { Text } from '@/components/Typography';
import { TokenWithBalance } from '@/hooks/useTokens';
import { Token } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { ChainDetails, chains } from '@/utils/chains';
import { isEmpty } from 'lodash-es';
import React, { useMemo } from 'react';
import { StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';

interface Props {
  token: TokenWithBalance;
  onPress?: () => unknown;
  style?: StyleProp<ViewStyle>;
  innerStyle?: StyleProp<ViewStyle>;
  disabled?: boolean;
  isRemoveDropdown?: boolean;
}

export function TokenSelect({
  token,
  onPress,
  style,
  innerStyle,
  disabled,
  isRemoveDropdown,
}: Props) {
  const { isDarkMode, styles: themeStyles } = useTheme();

  const chain = useMemo(() => chains.find((chain) => chain.id === token.chainId)!, [token]);

  return (
    <TouchableOpacity onPress={onPress} style={style} disabled={disabled}>
      <View style={[styles.container, themeStyles.cards, innerStyle]}>
        {chain ? (
          <TokenLogo
            chain={chain}
            token={!token.native ? (token as unknown as Token) : undefined}
            size={36}
          />
        ) : (
          <></>
        )}
        <View style={{ marginHorizontal: chain ? 18 : 0 }}>
          <Text bold>{token.symbol}</Text>
        </View>
        {!isRemoveDropdown &&
          (isDarkMode ? (
            <DropdownIconWhite style={styles.dropdownIcon} />
          ) : (
            <DropdownIcon color={'rgb(22, 7, 58)'} style={styles.dropdownIcon} />
          ))}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 50,
    borderRadius: 100,
    paddingHorizontal: 8,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
  },
  dropdownIcon: {
    maxWidth: 12,
    marginEnd: 2
  },
});
