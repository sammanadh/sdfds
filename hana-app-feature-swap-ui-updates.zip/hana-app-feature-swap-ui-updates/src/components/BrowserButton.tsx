import BrowserDarkModeIcon from '@/assets/icons/browser-dark-mode.svg';
import BrowserLightModeIcon from '@/assets/icons/browser-light-mode.svg';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { DApp } from '@/models/DApp';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { chains } from '@/utils/chains';
import { HIT_SLOP_XLARGE } from '@/utils/constants';
import {
  NetworkDetails,
  TestnetConfig,
  networkDetailsForChainID,
  networkDetailsForTestnet,
} from '@/utils/networks';
import { common } from '@/utils/styles';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isNil } from 'lodash-es';
import React, { useEffect, useState } from 'react';
import { TouchableOpacity } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'Home'>,
  StackNavigationProp<RootStackParams>
>;

interface Props {
  isDarkMode?: boolean;
}
export function BrowserButton({ isDarkMode }: Props) {
  const { navigate } = useNavigation<NavigationProps>();
  const { servicesUpdatedAt } = useChainServices.getState();
  const { setHideTabBar } = useNavigationStore();

  const [dApps, setDApps] = useState<Array<DApp>>([]);

  const { otherNetwork, connectedChains } = useChainServices();

  useEffect(() => {
    let networks: Array<NetworkDetails> = [];
    if (!isNil(otherNetwork)) {
      const network = networkDetailsForTestnet(otherNetwork as TestnetConfig);
      if (!isNil(network?.aggregationApi)) {
        networks.push(network!);
      }
    } else {
      connectedChains.forEach((chain) => {
        const network = networkDetailsForChainID(chain.id);
        if (!isNil(network?.aggregationApi)) {
          networks.push(network!);
        }
      });

      // Sort networks by order of chains
      networks = networks.sort((a, b) => {
        const aIndex = chains.findIndex((chain) => chain.id === a.chainType);
        const bIndex = chains.findIndex((chain) => chain.id === b.chainType);
        return aIndex - bIndex;
      });
    }

    async function fetchDApps() {
      const result = await Promise.all(
        networks.map(async (network) => {
          try {
            const url = `${network.aggregationApi}/dapps`;
            const response = await fetch(url);
            const data = await response.json();

            return data;
          } catch (error) {
            return [];
          }
        })
      );

      const dApps = result.flat();

      setDApps(dApps);
    }

    fetchDApps();
  }, [servicesUpdatedAt?.getTime(), otherNetwork, connectedChains]);

  function handleOpenBrowser() {
    setHideTabBar(true);
    navigate('DApps', {
      dAppsData: dApps,
    });
  }

  return (
    <TouchableOpacity
      onPress={handleOpenBrowser}
      hitSlop={HIT_SLOP_XLARGE}
      style={common.centerContent}
    >
      {isDarkMode ? <BrowserDarkModeIcon /> : <BrowserLightModeIcon />}
    </TouchableOpacity>
  );
}
