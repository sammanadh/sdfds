import EarnActiveDarkIcon from '@/assets/icons/earn-active-dark.svg';
import EarnActiveIcon from '@/assets/icons/earn-active.svg';
import EarnDarkIcon from '@/assets/icons/earn-dark.svg';
import EarnIcon from '@/assets/icons/earn.svg';
import SwapIcon from '@/assets/icons/swaps.svg';
import SwapDarkIcon from '@/assets/icons/swaps-dark.svg';
import TransactionsActiveIcon from '@/assets/icons/history-active.svg';
import TransactionsDarkIcon from '@/assets/icons/history-dark.svg';
import TransactionsIcon from '@/assets/icons/history.svg';
import PortfolioActiveDarkIcon from '@/assets/icons/portfolio-active-dark.svg';
import PortfolioActiveIcon from '@/assets/icons/portfolio-active.svg';
import PortfolioDarkIcon from '@/assets/icons/portfolio-dark.svg';
import PortfolioIcon from '@/assets/icons/portfolio.svg';
import TradeActiveIcon from '@/assets/icons/trade-active.svg';
import TradeDarkIcon from '@/assets/icons/trade-dark.svg';
import TradeIcon from '@/assets/icons/trade.svg';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { HIT_SLOP_XLARGE } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import * as NavigationBar from 'expo-navigation-bar';
import { isNil } from 'lodash-es';
import { ReactNode, useEffect, useMemo, useState } from 'react';
import { Keyboard, Platform, StyleSheet, TouchableOpacity, View, ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Text } from './Typography';
import { MaterialTopTabBarProps } from '@react-navigation/material-top-tabs';

const TAB_HEIGHT = 36;
const ICON_WIDTH = 36;

type RouteName =
  | 'HomeStack'
  | 'TradeStack'
  | 'SwapStack'
  | 'EarnStack'
  | 'TransactionsStack'
  | 'SettingsStack';

function getTabIcon(name: RouteName, isFocused: boolean, isDarkMode: boolean): ReactNode {
  switch (name) {
    case 'HomeStack':
      return isFocused && !isDarkMode ? (
        <PortfolioActiveIcon
          width={ICON_WIDTH * 0.65}
          height={TAB_HEIGHT * 0.65}
          style={{ marginVertical: ICON_WIDTH * 0.1 }}
        />
      ) : isFocused && isDarkMode ? (
        <PortfolioActiveDarkIcon
          width={ICON_WIDTH * 0.65}
          height={TAB_HEIGHT * 0.65}
          style={{ marginVertical: ICON_WIDTH * 0.1 }}
        />
      ) : isDarkMode ? (
        <PortfolioDarkIcon
          width={ICON_WIDTH * 0.65}
          height={TAB_HEIGHT * 0.65}
          style={{ marginVertical: ICON_WIDTH * 0.1 }}
        />
      ) : (
        <PortfolioIcon
          width={ICON_WIDTH * 0.65}
          height={TAB_HEIGHT * 0.65}
          style={{ marginVertical: ICON_WIDTH * 0.1 }}
        />
      );
    case 'TradeStack':
      return isFocused ? (
        <TradeActiveIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      ) : isDarkMode ? (
        <TradeDarkIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      ) : (
        <TradeIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      );
    case 'SwapStack':
      return !isDarkMode ? (
        <SwapIcon width={ICON_WIDTH / 1.2} height={TAB_HEIGHT} />
      ) : (
        <SwapDarkIcon width={ICON_WIDTH / 1.2} height={TAB_HEIGHT} />
      );

    case 'EarnStack':
      return isFocused && !isDarkMode ? (
        <EarnActiveIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      ) : isFocused && isDarkMode ? (
        <EarnActiveDarkIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      ) : isDarkMode ? (
        <EarnDarkIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      ) : (
        <EarnIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      );
    case 'TransactionsStack':
      return isFocused ? (
        <TransactionsActiveIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      ) : isDarkMode ? (
        <TransactionsDarkIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      ) : (
        <TransactionsIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
      );
    // case 'SettingsStack':
    //   return isFocused ? (
    //     <SettingsActiveIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
    //   ) : isDarkMode ? (
    //     <SettingsDarkIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
    //   ) : (
    //     <SettingsIcon width={ICON_WIDTH} height={TAB_HEIGHT} />
    //   );
  }
}

export function TabBar({ descriptors, navigation, state }: MaterialTopTabBarProps) {
  const { hideTabBar } = useNavigationStore();
  const { isDarkMode } = useTheme();

  const insets = useSafeAreaInsets();
  const [keyboardShowing, setKeyboardShowing] = useState(false);
  const dimensions: ViewStyle = useMemo(() => {
    const paddingTop = 25;
    const paddingBottom = Math.max(insets.bottom, 25);
    const height = TAB_HEIGHT + paddingTop + paddingBottom;
    return { height, paddingTop, paddingBottom };
  }, [insets.bottom]);

  useEffect(() => {
    if (Platform.OS !== 'android') return;
    if (hideTabBar) {
      NavigationBar.setBackgroundColorAsync(isDarkMode ? colors.purple.darkBlacker : colors.white);
      NavigationBar.setButtonStyleAsync(isDarkMode ? 'light' : 'dark');
    } else {
      NavigationBar.setBackgroundColorAsync(colors.purple.darkBlack);
      NavigationBar.setButtonStyleAsync('light');
    }
  }, [hideTabBar, isDarkMode]);

  useEffect(() => {
    if (Platform.OS !== 'android') return;

    Keyboard.addListener('keyboardDidShow', handleKeyboardDidShow);
    Keyboard.addListener('keyboardDidHide', handleKeyboardDidHide);

    return () => {
      Keyboard.removeListener('keyboardDidShow', handleKeyboardDidShow);
      Keyboard.removeListener('keyboardDidHide', handleKeyboardDidHide);
    };
  }, []);

  function handleKeyboardDidShow() {
    setKeyboardShowing(true);
  }

  function handleKeyboardDidHide() {
    setKeyboardShowing(false);
  }

  return (
    <View style={[styles.container, (keyboardShowing || hideTabBar) && { display: 'none' }]}>
      {state.routes
        .filter((route) => route.name !== 'SettingsStack') // don't show settings on tabBar
        .map((route, index) => {
          const { options } = descriptors[route.key];
          const label = !isNil(options.tabBarLabel)
            ? options.tabBarLabel
            : !isNil(options.title)
            ? options.title
            : route.name;

          const isFocused = state.index === index;

          function onPress() {
            const event = navigation.emit({
              type: 'tabPress',
              target: route.key,
              canPreventDefault: true,
            });

            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          }

          function onLongPress() {
            navigation.emit({
              type: 'tabLongPress',
              target: route.key,
            });
          }

          return (
            <View
              style={[
                styles.touchableContent,
                dimensions,
                {
                  backgroundColor:
                    isDarkMode && isFocused
                      ? colors.purple.darkOff
                      : !isDarkMode && isFocused
                      ? colors.offPurple
                      : colors.black,
                },
              ]}
              key={route.key}
            >
              <TouchableOpacity
                onPress={onPress}
                onLongPress={onLongPress}
                accessibilityRole="button"
                accessibilityState={isFocused ? { selected: true } : {}}
                accessibilityLabel={options.tabBarAccessibilityLabel}
                hitSlop={HIT_SLOP_XLARGE}
                style={styles.tab}
              >
                {getTabIcon(route.name as RouteName, isFocused, isDarkMode)}
                <Text
                  bold
                  style={[styles.label, { color: isFocused ? colors.black : colors.offPurple }]}
                >
                  {label}
                </Text>
              </TouchableOpacity>
            </View>
          );
        })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    backgroundColor: colors.black,
    shadowColor: colors.shadow,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowOpacity: 0.12,
    shadowRadius: 4,
    elevation: 9,
  },
  touchableContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.offPurple,
  },
  tab: {
    height: TAB_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    fontSize: 12,
    letterSpacing: 0.01,
    marginTop: 2,
  },
});
