import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { StyleSheet, View } from 'react-native';

export function SavePrivateKeyWarning({ content }: { content?: string }) {
  const { isDarkMode } = useTheme();

  const txtContent =
    content ||
    'Private keys for this wallet are different on each chain. It is recommended that you backup your seed phrase instead.';

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: isDarkMode ? colors.purple.darkBlack : '#f3f2f8',
        },
      ]}
    >
      <View style={styles.content}>
        <Text bold large>
          Warning
        </Text>

        <Text style={{ marginTop: 4 }}>{txtContent}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    borderRadius: 4,
    borderStyle: 'solid',
    borderLeftColor: '#fbbccf',
    borderLeftWidth: 5,
    paddingLeft: 20,
    paddingRight: 15,
    marginVertical: 16,
    paddingVertical: 12,
  },
  content: {
    flex: 1,
    width: '100%',
    flexDirection: 'column',
  },
});
