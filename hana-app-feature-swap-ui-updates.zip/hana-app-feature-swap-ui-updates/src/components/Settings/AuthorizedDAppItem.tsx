import { Button, ButtonSize } from '@/components/Button';
import { AltHeading, Text } from '@/components/Typography';
import { AuthorizedDApp } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import React, { useEffect, useState } from 'react';
import { Image, StyleSheet, View } from 'react-native';

interface Props {
  dapp: AuthorizedDApp;
  onRevoke: () => unknown;
}

export function AuthorizedDAppItem({ dapp, onRevoke }: Props) {
  const { styles: themeStyles } = useTheme();
  const [image, setImage] = useState<string>('');

  useEffect(() => {
    dapp.faviconUrl && setImage(dapp.faviconUrl);
  }, [dapp]);

  return (
    <View style={[styles.item, themeStyles.cards]}>
      <View style={styles.left}>
        <Image source={{ uri: image }} style={{ width: 40, height: 40 }} />
        <View style={styles.textBox}>
          <Text bold large numberOfLines={1}>
            {dapp.host}
          </Text>
          <AltHeading numberOfLines={1} style={{ marginTop: 6 }}>
            {dapp.title}
          </AltHeading>
        </View>
      </View>

      <Button
        style={styles.revokeButton}
        size={ButtonSize.Small}
        textStyle={{ color: colors.black, fontSize: 12 }}
        onPress={onRevoke}
      >
        Revoke
      </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    padding: 16,
    justifyContent: 'space-between',
    overflow: 'hidden',
  },
  revokeButton: {
    width: 80,
    backgroundColor: colors.negative,
  },
  left: {
    flexDirection: 'row',
    flex: 1,
    overflow: 'hidden',
    marginRight: 10,
    alignItems: 'center',
  },
  textBox: {
    flex: 1,
    marginLeft: 15,
  },
});
