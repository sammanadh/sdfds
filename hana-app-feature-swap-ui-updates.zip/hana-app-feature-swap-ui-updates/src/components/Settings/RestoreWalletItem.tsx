import { FileLockIcon, KeysIcon, IconNextBlack, IconNextWhite  } from '@/assets/icons';
import { Text } from '@/components/Typography';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { Image, StyleSheet, TouchableOpacity, View } from 'react-native';

export enum RestoreWalletItemType {
  KeystoreFile,
  PrivateKey,
  Ledger,
}

interface Props {
  type: RestoreWalletItemType;
  onPress: () => unknown;
  isDarkMode?: boolean;
}

export function RestoreWalletItem({ type, onPress, isDarkMode }: Props) {
  const icon = React.useMemo(() => {
    switch (type) {
      case RestoreWalletItemType.KeystoreFile:
        return <FileLockIcon style={styles.icon} />;
      case RestoreWalletItemType.PrivateKey:
        return <KeysIcon style={styles.icon} />;
      case RestoreWalletItemType.Ledger:
        return (
          <Image source={require('@/assets/icons/ledger.png')} style={{ width: 20, height: 20 }} />
        );
    }
  }, [type, isDarkMode]);

  const title = React.useMemo(() => {
    switch (type) {
      case RestoreWalletItemType.KeystoreFile:
        return 'Keystore file';
      case RestoreWalletItemType.PrivateKey:
        return 'Private key';
      case RestoreWalletItemType.Ledger:
        return 'Connect with your Ledger';
    }
  }, [type]);

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={[styles.content, isDarkMode && { backgroundColor: colors.black }]}>
        <View style={styles.iconContainer}>{icon}</View>
        <Text bold style={[styles.title, isDarkMode && { color: colors.whiteSecond }]}>
          {title}
        </Text>
        {isDarkMode ? <IconNextWhite /> : <IconNextBlack />}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 7,
  },
  content: {
    width: '100%',
    padding: 16,
    alignItems: 'center',
    flexDirection: 'row',
    backgroundColor: colors.gray.cards,
  },
  icon: {
    color: colors.black,
    width: 24,
    height: 24,
  },
  iconContainer: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.offPurple,
  },
  title: {
    marginLeft: 16,
    flex: 1,
  },
});
