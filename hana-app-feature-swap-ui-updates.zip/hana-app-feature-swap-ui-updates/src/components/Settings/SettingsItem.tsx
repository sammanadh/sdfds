import {
  ConfigureChainIcon,
  DAppsIcon,
  IconAddressBook,
  IconAddressBookDark,
  IconChangePassword,
  IconManageTokens,
  IconManageTokensDark,
  IconManageWallet,
  IconManageWalletDark,
  IconNextBlack,
  IconNextWhite,
  IconResetHana,
  QuestionIcon,
  Slider,
} from '@/assets/icons';
import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import React, { useMemo } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

export enum SettingsItemType {
  ManageWallet,
  AddressBook,
  ManageTokens,
  ConfigureChains,
  AuthorizedDApps,
  Advanced,
  ChangePassword,
  ResetHana,
  HelpAndSupport,
}

interface Props {
  type: SettingsItemType;
  onPress: () => unknown;
}

export function SettingsItem({ type, onPress }: Props) {
  const { isDarkMode, colors, styles: themeStyles } = useTheme();

  const icon = useMemo(() => {
    switch (type) {
      case SettingsItemType.ManageWallet:
        return isDarkMode ? (
          <IconManageWalletDark width={30} height={30} />
        ) : (
          <IconManageWallet width={30} height={30} />
        );
      case SettingsItemType.AddressBook:
        return isDarkMode ? (
          <IconAddressBookDark width={30} height={30} />
        ) : (
          <IconAddressBook width={30} height={30} />
        );
      case SettingsItemType.ManageTokens:
        return isDarkMode ? (
          <IconManageTokensDark width={30} height={30} />
        ) : (
          <IconManageTokens width={30} height={30} />
        );
      case SettingsItemType.ConfigureChains:
        return <ConfigureChainIcon width={20} height={20} color={'black'} />;
      case SettingsItemType.AuthorizedDApps:
        return <DAppsIcon width={20} height={20} />;
      case SettingsItemType.Advanced:
        return <Slider width={20} height={20} color={'black'} />;
      case SettingsItemType.ChangePassword:
        return <IconChangePassword width={30} height={30} />;
      case SettingsItemType.HelpAndSupport:
        return <QuestionIcon width={20} height={20} />;
      case SettingsItemType.ResetHana:
        return <IconResetHana width={30} height={30} style={{ backgroundColor: colors.negative}} />;
    }
  }, [type, isDarkMode]);

  const title = useMemo(() => {
    switch (type) {
      case SettingsItemType.ManageWallet:
        return 'Wallets';
      case SettingsItemType.AddressBook:
        return 'Address book';
      case SettingsItemType.ManageTokens:
        return 'Tokens';
      case SettingsItemType.ConfigureChains:
        return 'Connected chains';
      case SettingsItemType.AuthorizedDApps:
        return 'Authorized dApps';
      case SettingsItemType.Advanced:
        return 'Advanced';
      case SettingsItemType.HelpAndSupport:
        return 'Help & support';
      case SettingsItemType.ChangePassword:
        return 'Change password';
      case SettingsItemType.ResetHana:
        return 'Reset Hana';
    }
  }, [type]);

  return (
    <TouchableOpacity style={[styles.card, themeStyles.cards]} onPress={onPress}>
      <View style={[styles.icon, { backgroundColor: colors.offPurple }]}>{icon}</View>
      <Text large bold style={styles.title}>
        {title}
      </Text>
      {isDarkMode ? <IconNextWhite /> : <IconNextBlack />}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginBottom: 16,
  },
  title: {
    flex: 1,
    marginHorizontal: 16,
  },
  icon: {
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
