import { KeysIcon } from '@/assets/icons';
import Ledger from '@/assets/icons/ledger.svg';
import { Wallet, WalletType } from '@/models/Vault';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { View, ViewStyle } from 'react-native';

interface Props {
  wallet: Wallet;
  floating?: boolean;
  style?: ViewStyle;
}

export function WalletTypeBadge({ wallet, floating = false, style }: Props) {
  if (wallet.type === WalletType.PK || wallet.type === WalletType.Ledger) {
    return (
      <View
        style={{
          backgroundColor: 'rgb(212, 197, 249)',
          width: 24,
          height: 24,
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          top: 0,
          right: 0,
        }}
      >
        {wallet.type === WalletType.PK ? (
          <KeysIcon width={14} height={14} color="rgb(22, 7, 58)" />
        ) : wallet.type === WalletType.Ledger ? (
          <Ledger width={20} height={20} color={colors.black} />
        ) : (
          <Ledger width={20} height={20} color={colors.black} />
        )}
      </View>
    );
  }

  return <></>;
}
