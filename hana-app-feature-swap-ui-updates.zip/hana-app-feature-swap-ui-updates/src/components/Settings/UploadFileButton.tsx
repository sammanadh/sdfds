import { UploadIconWhite } from '@/assets/icons';
import UploadIcon from '@/assets/icons/upload.svg';
import { Text } from '@/components/Typography';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

interface Props {
  onPress: () => unknown;
  isDarkMode?: boolean;
}

export function UploadFileButton({ onPress, isDarkMode }: Props) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={[styles.content, isDarkMode && { borderColor: colors.white }]}>
        <View style={styles.iconContainer}>
          {isDarkMode ? (
            <UploadIconWhite width={20} height={20} />
          ) : (
            <UploadIcon width={20} height={20} />
          )}
        </View>
        <Text bold style={[styles.title, isDarkMode && { color: colors.whiteSecond }]}>
          Upload file
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 20,
  },
  content: {
    width: '100%',
    paddingVertical: 12,
    paddingHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 1,
    borderRadius: 25,
    borderColor: colors.purple.darkBlack,
  },
  iconContainer: {
    width: 22,
    height: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    marginLeft: 22,
    flex: 1,
  },
});
