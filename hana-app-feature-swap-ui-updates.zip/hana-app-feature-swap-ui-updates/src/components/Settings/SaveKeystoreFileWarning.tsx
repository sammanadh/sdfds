import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { StyleSheet, View } from 'react-native';

export function SaveKeystoreFileWarning() {
  const { isDarkMode, styles: themeStyles } = useTheme();

  return (
    <View
      style={[
        styles.container,
        themeStyles.cards,
        { borderColor: isDarkMode ? undefined : '#f4f2f9' },
      ]}
    >
      <View style={styles.content}>
        <Text bold>Warning</Text>

        <Text style={{ marginTop: 4 }}>
          It is recommended that you backup your seed phrase instead.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    borderStyle: 'solid',
    borderLeftColor: colors.negative,
    borderLeftWidth: 5,
    paddingLeft: 20,
    paddingRight: 15,
    marginVertical: 16,
    paddingVertical: 12,
  },
  content: {
    flex: 1,
    width: '100%',
    flexDirection: 'column',
  },
});
