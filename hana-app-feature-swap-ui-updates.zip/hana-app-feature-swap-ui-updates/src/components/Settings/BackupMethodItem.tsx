import { FileLockIcon, SeedingIcon, IconNextBlack, IconNextWhite  } from '@/assets/icons';
import KeysIcon from '@/assets/icons/keys.svg';
import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { colors, fonts } from '@/utils/designTokens';
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

export enum BackupMethodItemType {
  SeedPhrase,
  KeystoreFile,
  PrivateKey,
}

interface Props {
  type: BackupMethodItemType;
  onPress: () => unknown;
}

export function BackupMethodItem({ type, onPress }: Props) {
  const { isDarkMode } = useTheme();

  const icon = React.useMemo(() => {
    switch (type) {
      case BackupMethodItemType.SeedPhrase:
        return <SeedingIcon style={styles.icon} />;
      case BackupMethodItemType.KeystoreFile:
        return <FileLockIcon style={styles.icon} />;
      case BackupMethodItemType.PrivateKey:
        return <KeysIcon style={styles.icon} />;
    }
  }, [type]);

  const title = React.useMemo(() => {
    switch (type) {
      case BackupMethodItemType.SeedPhrase:
        return 'Seed phrase';
      case BackupMethodItemType.KeystoreFile:
        return 'Keystore file';
      case BackupMethodItemType.PrivateKey:
        return 'Private key';
    }
  }, [type]);

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={[styles.content, isDarkMode && { backgroundColor: colors.black }]}>
        <View style={styles.iconContainer}>{icon}</View>
        <Text style={[styles.title, isDarkMode && { color: colors.whiteSecond }]}>{title}</Text>
        {isDarkMode ? <IconNextWhite /> : <IconNextBlack />}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 7,
  },
  content: {
    width: '100%',
    padding: 16,
    alignItems: 'center',
    flexDirection: 'row',
    backgroundColor: colors.gray.cards,
  },
  iconContainer: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.offPurple,
  },
  icon: {
    color: colors.black,
    width: 24,
    height: 24,
  },
  title: {
    fontFamily: fonts.heavy,
    marginLeft: 22,
    flex: 1,
  },
});
