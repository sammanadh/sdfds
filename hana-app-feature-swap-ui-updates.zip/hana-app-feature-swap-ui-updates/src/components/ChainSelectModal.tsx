import CheckIcon from '@/assets/icons/check-icon.svg';
import BinanceLogo from '@/assets/logos/binance-white.svg';
import EthereumLogo from '@/assets/logos/ethereum-white.svg';
import HarmonyLogo from '@/assets/logos/harmony-white.svg';
import HAVAHLogo from '@/assets/logos/havah-white.svg';
import IconLogo from '@/assets/logos/icon-white.svg';
import KusamaLogo from '@/assets/logos/kusama-white.svg';
import PolkadotLogo from '@/assets/logos/polkadot-white.svg';
import WanchainLogo from '@/assets/logos/wanchain.svg';
import ShidenLogo from '@/assets/logos/shiden.svg';
import { Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import React from 'react';
import { Image, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';

interface Props {
  chains: ChainID[];
  selectedChain?: ChainID | null;
  onSelect: (chain: ChainID | null) => void;
}

function iconForChain(chain: ChainID) {
  switch (chain) {
    case ChainID.ICON:
      return (
        <View style={[styles.icon, { backgroundColor: '#33aaba' }]}>
          <IconLogo width={30} height={30} />
        </View>
      );

    case ChainID.HAVAH:
      return (
        <View style={[styles.icon, { backgroundColor: '#202225' }]}>
          <HAVAHLogo width={40} height={40} />
        </View>
      );

    case ChainID.Ethereum:
      return (
        <View style={[styles.icon, { backgroundColor: '#5d79e3' }]}>
          <EthereumLogo width={30} height={30} />
        </View>
      );

    case ChainID.Polkadot:
      return (
        <View style={[styles.icon, { backgroundColor: '#e6007a' }]}>
          <PolkadotLogo width={30} height={30} />
        </View>
      );

    case ChainID.Kusama:
      return (
        <View style={[styles.icon, { backgroundColor: 'rgb(230, 0, 122)' }]}>
          <KusamaLogo width={30} height={30} />
        </View>
      );

    case ChainID.Westend:
      return (
        <View style={[styles.icon, { backgroundColor: colors.brand.primary }]}>
          <EthereumLogo width={30} height={30} />
        </View>
      );

    case ChainID.Moonbeam:
      return (
        <View style={[styles.icon, { backgroundColor: '#0D1126' }]}>
          <Image
            source={require('@/assets/logos/moonbeam.png')}
            style={{ width: 30, height: 30, aspectRatio: 1 }}
          />
        </View>
      );

    case ChainID.Moonriver:
      return (
        <View style={[styles.icon, { backgroundColor: '#0E122F' }]}>
          <Image
            source={require('@/assets/logos/moonriver.png')}
            style={{ width: 30, height: 30, aspectRatio: 1 }}
          />
        </View>
      );

    case ChainID.Binance:
      return (
        <View style={[styles.icon, { backgroundColor: 'rgb(240, 185, 11)' }]}>
          <BinanceLogo width={30} height={30} />
        </View>
      );

    case ChainID.Harmony:
      return (
        <View style={[styles.icon, { backgroundColor: '#00aee9' }]}>
          <HarmonyLogo width={30} height={30} />
        </View>
      );

    case ChainID.Arctic:
      return (
        <Image
          resizeMode="contain"
          source={require('@/assets/icons/ice-token.png')}
          style={{ width: 30, height: 30 }}
        />
      );

    case ChainID.SNOW:
      return (
        <Image
          source={require('@/assets/logos/snow-icon.png')}
          style={{ width: 35, height: undefined, aspectRatio: 1 }}
        />
      );

    case ChainID.NEAR:
      return (
        <View style={[styles.icon, { backgroundColor: '#009DBE' }]}>
          <Text bold style={{ color: 'white' }}>
            NEAR
          </Text>
        </View>
      );

    case ChainID.Wanchain:
      return (
        <View style={[styles.icon, { backgroundColor: '#FFFFFF' }]}>
          <WanchainLogo width={30} height={30} />
        </View>
      );

    case ChainID.Avalanche:
      return (
        <View style={[styles.icon]}>
          <Image
            source={require('@/assets/logos/avaxc.png')}
            style={{ width: 50, height: 50, aspectRatio: 1 }}
          />
        </View>
      );

    case ChainID.Polygon:
      return (
        <View style={[styles.icon]}>
          <Image
            source={require('@/assets/logos/polygon.png')}
            style={{ width: 50, height: 50, aspectRatio: 1 }}
          />
        </View>
      );

    case ChainID.Arbitrum:
      return (
        <View style={[styles.icon, { backgroundColor: '#2c374b' }]}>
          <Image
            source={require('@/assets/logos/arbitrum.png')}
            style={{ width: 35, height: 35, aspectRatio: 1 }}
          />
        </View>
      );

    case ChainID.Optimism:
      return (
        <View style={[styles.icon]}>
          <Image
            source={require('@/assets/logos/optimism.png')}
            style={{ width: 50, height: 50, aspectRatio: 1 }}
          />
        </View>
      );

    case ChainID.Astar:
      return (
        <View style={[styles.icon, { backgroundColor: '#FFFFFF' }]}>
          <Image
            source={require('@/assets/logos/astar.png')}
            style={{ width: 50, height: 50, aspectRatio: 1 }}
          />
        </View>
      );

    case ChainID.Astar_EVM:
      return (
        <View style={[styles.icon, { backgroundColor: '#FFFFFF' }]}>
          <Image
            source={require('@/assets/logos/astar-grayscale.png')}
            style={{ width: 50, height: 50, aspectRatio: 1 }}
          />
        </View>
      );

    case ChainID.Shiden:
    case ChainID.Shibuya:
      return (
        <View style={[styles.icon, { backgroundColor: '#FFFFFF' }]}>
          <ShidenLogo width={30} height={30} />
        </View>
      );

    case ChainID.Shiden_EVM:
    case ChainID.Shibuya_EVM:
      return (
        <View style={[styles.icon]}>
          <Image
            source={require('@/assets/logos/shiden-grayscale.png')}
            style={{ width: 30, height: 30, aspectRatio: 1 }}
          />
        </View>
      );

    default:
      return <View />;
  }
}

export const ChainSelectModal = ({ chains, selectedChain, onSelect }: Props) => {
  const { isDarkMode } = useTheme();

  const renderChain = (chain: ChainID) => {
    const icon = iconForChain(chain);

    return (
      <TouchableOpacity key={chain} onPress={() => onSelect(chain)}>
        <View
          style={[styles.chain, { backgroundColor: isDarkMode ? colors.black : colors.gray.cards }]}
        >
          {icon}
          <Text
            bold
            style={[styles.chainName, { color: isDarkMode ? colors.whiteSecond : colors.black }]}
          >
            {chain}
          </Text>
          {selectedChain === chain ? <CheckIcon width={32} height={32} /> : <></>}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <ScrollView
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
      style={styles.container}
    >
      {/* All chains */}
      <TouchableOpacity key={'all_chains'} onPress={() => onSelect(null)}>
        <View
          style={[styles.chain, { backgroundColor: isDarkMode ? colors.black : colors.gray.cards }]}
        >
          <Text
            bold
            style={[styles.chainName, { color: isDarkMode ? colors.whiteSecond : colors.black }]}
          >
            All chains
          </Text>
          {!selectedChain && <CheckIcon width={32} height={32} />}
        </View>
      </TouchableOpacity>

      {/* Chains */}
      <View>{chains.map(renderChain)}</View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
  },
  chainName: {
    color: colors.whiteSecond,
    flex: 1,
    marginLeft: 16,
  },
  icon: {
    width: 50,
    height: 50,
    borderRadius: 50 / 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chain: {
    alignItems: 'center',
    paddingHorizontal: 8,
    height: 62,
    borderRadius: 100,
    marginVertical: 6,
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
});
