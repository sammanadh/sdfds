let polkadotNextId = 0;

const responseEvent = 'HANA_POLKADOT_RESPONSE';

function polkadotRandomID() {
  return (Math.random() + 1).toString(36).substring(2);
}

class Signer {
  async signPayload(payload) {
    return new Promise((resolve, reject) => {
      const requestId = polkadotRandomID();

      window.ReactNativeWebView.postMessage(
        'polkadot:' +
          btoa(
            JSON.stringify({
              payload,
              id: requestId,
              method: 'polkadot_signer_sign_payload',
            })
          )
      );

      // const event =
      //   new CustomEvent() <
      //   PolkadotSignerSignPayloadRequest >
      //   ('POLKADOT_RELAY_REQUEST',
      //   {
      //     detail: {
      //       method: 'polkadot_signer_sign_payload',
      //       id: requestId,
      //       payload,
      //     },
      //   });
      // window.dispatchEvent(event);

      window.addEventListener(responseEvent, handleResponse);
      function handleResponse(event) {
        if (event.detail.id !== requestId) return;

        // TODO: Errors?

        const { signature } = event.detail;

        const id = ++polkadotNextId;

        resolve({
          signature,
          id,
        });

        // @ts-expect-error not happy with handler event type
        window.removeEventListener(responseEvent, handleResponse);
      }

      // we add an internal id (number) - should have a mapping from the
      // extension id (string) -> internal id (number) if we wish to provide
      // updated via the update functionality (noop at this point)
    });
  }

  async signRaw(payload) {
    return new Promise((resolve, reject) => {
      const requestId = polkadotRandomID();

      window.ReactNativeWebView.postMessage(
        'polkadot:' +
          btoa(
            JSON.stringify({
              payload,
              id: requestId,
              method: 'polkadot_signer_sign_raw',
            })
          )
      );

      // const event =
      //   new CustomEvent() <
      //   PolkadotSignerSignRawRequest >
      //   ('POLKADOT_RELAY_REQUEST',
      //   {
      //     detail: {
      //       method: 'polkadot_signer_sign_raw',
      //       id: requestId,
      //       payload,
      //     },
      //   });
      // window.dispatchEvent(event);

      // @ts-expect-error not happy with handler event type
      window.addEventListener(responseEvent, handleResponse);
      function handleResponse(event) {
        if (event.detail.id !== requestId) return;

        // TODO: Errors?

        const { signature } = event.detail;

        const id = ++polkadotNextId;

        resolve({
          signature,
          id,
        });

        // @ts-expect-error not happy with handler event type
        window.removeEventListener(responseEvent, handleResponse);
      }

      // we add an internal id (number) - should have a mapping from the
      // extension id (string) -> internal id (number) if we wish to provide
      // updated via the update functionality (noop at this point)
    });
  }
}

class PostMessageProvider {
  /**
   * @description Returns a clone of the object
   */
  clone() {
    return new PostMessageProvider();
  }

  /**
   * @description Manually disconnect from the connection, clearing autoconnect logic
   */
  // eslint-disable-next-line @typescript-eslint/require-await
  async connect() {
    // FIXME This should see if the extension's state's provider can disconnect
    console.error('PostMessageProvider.disconnect() is not implemented.');
  }

  /**
   * @description Manually disconnect from the connection, clearing autoconnect logic
   */
  // eslint-disable-next-line @typescript-eslint/require-await
  async disconnect() {
    // FIXME This should see if the extension's state's provider can disconnect
    console.error('PostMessageProvider.disconnect() is not implemented.');
  }

  /**
   * @summary `true` when this provider supports subscriptions
   */
  get hasSubscriptions() {
    // FIXME This should see if the extension's state's provider has subscriptions
    return true;
  }

  /**
   * @summary Whether the node is connected or not.
   * @return {boolean} true if connected
   */
  get isConnected() {
    return true; // TODO
  }

  listProviders() {
    return null;
  }

  /**
   * @summary Listens on events after having subscribed using the [[subscribe]] function.
   * @param  {ProviderInterfaceEmitted} type Event
   * @param  {ProviderInterfaceEmitCb}  sub  Callback
   * @return unsubscribe function
   */
  on(type, sub) {
    return () => {};
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async send(method, params, _, subscription) {}

  /**
   * @summary Spawn a provider on the extension background.
   */
  async startProvider(key) {
    return null;
  }

  subscribe(type, method, params, callback) {
    return this.send(method, params, false, { callback, type });
  }

  /**
   * @summary Allows unsubscribing to subscriptions made with [[subscribe]].
   */
  async unsubscribe(type, method, id) {
    return true;
  }
}

class Metadata {
  async get() {
    return new Promise((resolve, reject) => {
      const id = polkadotRandomID();

      window.ReactNativeWebView.postMessage(
        'polkadot:' +
          btoa(
            JSON.stringify({
              id,
              method: 'polkadot_metadata_get',
            })
          )
      );

      // const event = new CustomEvent('POLKADOT_RELAY_REQUEST', {
      //   detail: {
      //     method: 'polkadot_metadata_get',
      //     id,
      //   },
      // });
      // window.dispatchEvent(event);

      // @ts-expect-error not happy with handler event type
      window.addEventListener(responseEvent, handleResponse);
      function handleResponse(event) {
        if (event.detail.id !== id) return;

        // TODO: Errors?

        const { metadata } = event.detail;

        resolve(metadata);

        // @ts-expect-error not happy with handler event type
        window.removeEventListener(responseEvent, handleResponse);
      }
    });
  }

  async provide(definition) {
    return new Promise((resolve, reject) => {
      const id = polkadotRandomID();

      window.ReactNativeWebView.postMessage(
        'polkadot:' +
          btoa(
            JSON.stringify({
              definition,
              id,
              method: 'polkadot_metadata_provide',
            })
          )
      );

      // const event = new CustomEvent('POLKADOT_RELAY_REQUEST', {
      //   detail: {
      //     method: 'polkadot_metadata_provide',
      //     id,
      //     definition,
      //   },
      // });
      // window.dispatchEvent(event);

      // @ts-expect-error not happy with handler event type
      window.addEventListener(responseEvent, handleResponse);
      function handleResponse(event) {
        if (event.detail.id !== id) return;

        // TODO: Errors?

        resolve(true);

        // @ts-expect-error not happy with handler event type
        window.removeEventListener(responseEvent, handleResponse);
      }
    });
  }
}

class Accounts {
  async get(anyType) {
    console.debug('accounts get');

    return new Promise((resolve, reject) => {
      const id = polkadotRandomID();

      window.ReactNativeWebView.postMessage(
        'polkadot:' +
          btoa(
            JSON.stringify({
              id,
              method: 'polkadot_accounts_get',
            })
          )
      );

      // const event = new CustomEvent('POLKADOT_RELAY_REQUEST', {
      //   detail: {
      //     method: 'polkadot_accounts_get',
      //     id,
      //   },
      // });
      // window.dispatchEvent(event);

      // @ts-expect-error not happy with handler event type
      window.addEventListener(responseEvent, handleResponse);
      function handleResponse(event) {
        if (event.detail.id !== id) return;

        // TODO: Errors?

        const accounts = event.detail.params;

        resolve(accounts);

        // @ts-expect-error not happy with handler event type
        window.removeEventListener(responseEvent, handleResponse);
      }
    });
  }

  subscribe(cb) {
    console.debug('accounts subscribe: ', cb);

    const id = polkadotRandomID();

    console.debug('id: ', id);

    window.ReactNativeWebView.postMessage(
      'polkadot:' +
        btoa(
          JSON.stringify({
            id,
            method: 'polkadot_accounts_subscribe',
          })
        )
    );

    // const event = new CustomEvent('POLKADOT_RELAY_REQUEST', {
    //   detail: {
    //     method: 'polkadot_accounts_subscribe',
    //     id,
    //   },
    // });
    // window.dispatchEvent(event);

    window.addEventListener(responseEvent, handleResponse);

    function handleResponse(event) {
      console.debug('handleResponse: ', event);

      if (event.detail.id !== id) return;

      // TODO: Errors?

      const accounts = event.detail.params;

      cb(accounts);

      // @ts-expect-error not happy with handler event type
      window.removeEventListener(responseEvent, handleResponse);
    }

    // return () => {
    //   // FIXME we need the ability to unsubscribe
    // };
  }
}

class Injected {
  constructor() {
    console.debug('Injected constructor');
    this.accounts = new Accounts();
    this.metadata = new Metadata();
    this.provider = new PostMessageProvider();
    this.signer = new Signer();
  }
}

// the enable function, called by the dapp to allow access
async function polkadotEnable(origin) {
  return new Injected();
}

function injectPolkadotExtension(enable, options) {
  const { name, version } = options;
  // small helper with the typescript types, just cast window
  const windowInject = window;

  // don't clobber the existing object, we will add it (or create as needed)
  windowInject.injectedWeb3 = windowInject.injectedWeb3 || {};

  // add our enable function
  windowInject.injectedWeb3[name] = {
    enable: (origin) => enable(origin),
    version,
  };
}

injectPolkadotExtension(polkadotEnable, {
  name: 'polkadot-js',
  version: '0.1-hana',
});
