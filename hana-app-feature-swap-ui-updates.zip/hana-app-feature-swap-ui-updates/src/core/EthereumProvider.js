class EthereumProvider {
  _accounts = [];

  events = [];

  isMetaMask = true;

  async request(payload) {
    return new Promise((resolve, reject) => {
      const { method } = payload;
      const id = (Math.random() + 1).toString(36).substring(2);

      if (payload) {
        window.ReactNativeWebView.postMessage(
          'ethereum:' +
            btoa(
              JSON.stringify({
                ...payload,
                id,
              })
            )
        );

        console.debug('payload: ', payload);

        function handleResponse(event) {
          console.debug('handleResponse event: ', event);

          if (event.detail.id !== id) return;

          if (event.detail.error) {
            const error = event.detail.error;
            reject({
              code: error.code,
              message: error.message,
              stack: error.data,
            });
          }

          if (['eth_accounts', 'eth_requestAccounts'].includes(event.detail.method)) {
            this._accounts = event.detail.params;
          }

          window.removeEventListener('HANA_ETHEREUM_RESPONSE', handleResponse);

          console.debug('handleResponse value: ', event.detail.params);

          resolve(event.detail.params);
        }

        window.addEventListener('HANA_ETHEREUM_RESPONSE', handleResponse);
      }
    });
  }

  isConnected() {
    return true;
  }

  /**
   * Attach a listener for a specific event
   *
   * @param {string} event - Event name
   * @param {Function} listener - Callback invoked when event triggered
   * @returns {InpageBridge}
   */
  on(event, listener) {
    console.debug('*** on event: ', event);
    if (!Array.isArray(this.events[event])) {
      this.events[event] = [];
    }

    this.events[event].push(listener);
  }

  /**
   * Remove a listener for a specific event
   *
   * @param {string} event - Event name
   * @param {Function} listener - Callback to remove
   */
  off(event, listener) {
    if (!Array.isArray(this.events[event])) return;
    this.events[event].forEach((cachedListener, i) => {
      if (cachedListener === listener) {
        this.events[event].splice(i, 1);
      }
    });
  }

  /**
   * Emit data for a given event
   *
   * @param {string} event - Event name
   * @param  {...any} args - Data to emit
   */
  emit(event, ...args) {
    console.debug('emit event: ', event);
    console.debug('args: ', args);
    if (!Array.isArray(this.events[event])) return;
    this.events[event].forEach((listener) => {
      console.debug('listener: ', listener);
      listener(...args);
    });
  }

  /**
   * @deprecated
   */
  enable() {
    console.debug('enable');
    return this.request({ method: 'eth_requestAccounts' });
  }

  /**
   * @deprecated
   */
  send(methodOrPayload, paramsOrCallback) {
    console.debug('send: ', methodOrPayload);
    console.debug('send params: ', paramsOrCallback);

    if (
      typeof methodOrPayload === 'string' &&
      (paramsOrCallback === undefined || Array.isArray(paramsOrCallback))
    ) {
      return this.request({ method: methodOrPayload, params: paramsOrCallback });
    }
    if (typeof methodOrPayload === 'object' && typeof paramsOrCallback === 'function') {
      this.request(methodOrPayload)
        .then((result) => paramsOrCallback(null, this.rpcify(methodOrPayload, result)))
        .catch(paramsOrCallback);
    } else {
      throw new Error('Hana - Invalid use of EthereumProvider.send()');
    }
  }

  /**
   * @deprecated
   */
  sendAsync(payload, callback) {
    console.debug('sendAsync: ', payload);
    console.debug('sendAsync callback: ', callback);
    this.request(payload)
      .then((result) => callback(null, this.rpcify(payload, result)))
      .catch(callback);
  }

  rpcify(payload, result) {
    console.debug('rpcify payload: ', payload);
    console.debug('rpcify result: ', result);
    return { ...payload, result, params: null };
  }
}

const provider = new EthereumProvider();
Object.defineProperty(window.hanaWallet, 'ethereum', { value: provider, writable: false });
window.ethereum = provider;

true; // prevents potential silent failures
