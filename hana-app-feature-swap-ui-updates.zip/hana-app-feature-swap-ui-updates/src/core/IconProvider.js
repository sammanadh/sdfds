if (!window.hanaWallet.icon) {
  function Hana_relayRequestHandler(event) {
    const { type, payload } = event.detail;
    switch (type) {
      case 'REQUEST_HAS_ACCOUNT':
      case 'REQUEST_HAS_ADDRESS':
      case 'REQUEST_ADDRESS':
      case 'REQUEST_SIGNING':
      case 'REQUEST_JSON-RPC':
        window.ReactNativeWebView.postMessage(
          'icon:' + type + (payload ? `:${btoa(JSON.stringify(payload))}` : '')
        );
        break;

      default:
    }
  }
  window.addEventListener('ICONEX_RELAY_REQUEST', Hana_relayRequestHandler);

  Object.defineProperty(window.hanaWallet, 'icon', { value: true, writable: false });

  // Legacy globals
  window.chrome = true; // iconbet.io checks window.chrome
  window.MIW_isInjected = true; // legacy MIW script injection check
}

true; // prevents potential silent failures
