import { Blur } from '@/components/Blur';
import { Modal } from '@/components/Modal';
import { Navigation } from '@/components/Navigation';
import { Toast } from '@/components/Toast';
import { Wallet, WalletType } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useAltModal, useModal } from '@/stores/Modal';
import { useOnboardingFlags } from '@/stores/OnboardingFlags';
import { useSettings } from '@/stores/Settings';
import { useTheme } from '@/stores/Theme';
import { ChainWalletCreationStatus, createChainWallet, useVault } from '@/stores/Vault';
import { testnetChains } from '@/utils/chains';
import { fontAssets } from '@/utils/designTokens';
import { isChainWalletValid } from '@/utils/wallet';
import { useFonts } from '@expo-google-fonts/lato';
import { DarkTheme, DefaultTheme, NavigationContainer } from '@react-navigation/native';
import AppLoading from 'expo-app-loading';
import * as StatusBar from 'expo-status-bar';
import { isEmpty, isNil } from 'lodash-es';
import { useEffect, useMemo, useState } from 'react';
import { AppState, AppStateStatus, Platform, PermissionsAndroid } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import KeyboardManager from 'react-native-keyboard-manager';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import TipProvider from 'react-native-tip';

export default function App() {
  // console.log(`V8 version is ${global._v8runtime().version}`);

  const { initialize: initVault, realm, ready: vaultLoaded, isUnlocked } = useVault();
  const { initialize: initOnboardingFlags, ready: onboardingLoaded } = useOnboardingFlags();
  const {
    initialize: initChainServices,
    ready: chainServicesLoaded,
    connectedChains,
  } = useChainServices();
  const { initialize: initSettings, substrateKeyDerivationMethod } = useSettings();
  const { isDarkMode, initialize: initTheme } = useTheme();

  const {
    modalOpen,
    modalTitle,
    modalContent,
    modalOptions,
    setModalOpen,
    modalOnClose,
    setModalOnClose,
    setModalOptions,
  } = useModal();

  const {
    modalOpen: altModalOpen,
    modalTitle: altModalTitle,
    modalContent: altModalContent,
    modalOptions: altModalOptions,
    setModalOpen: setAltModalOpen,
    modalOnClose: altModalOnClose,
    setModalOnClose: setAltModalOnClose,
    setModalOptions: setAltModalOptions,
  } = useAltModal();

  const [isBackground, setIsBackground] = useState(false);
  useEffect(() => {
    AppState.addEventListener('change', handleAppStateChange);
    return () => AppState.removeEventListener('change', handleAppStateChange);
  }, [isUnlocked]);
  function handleAppStateChange(appState: AppStateStatus) {
    setIsBackground(appState === 'background' || appState === 'inactive');
  }

  const [fontsLoaded] = useFonts(fontAssets);

  const isLoaded = useMemo(
    () => fontsLoaded && onboardingLoaded && chainServicesLoaded && vaultLoaded,
    [fontsLoaded, onboardingLoaded, chainServicesLoaded, vaultLoaded]
  );

  useEffect(() => {
    initSettings();
    initVault();
    initOnboardingFlags();
    initChainServices();
    initTheme();
  }, []);

  useEffect(() => {
    if (isNil(realm) || isEmpty(connectedChains)) return;

    useVault.setState({
      chainWalletCreatingStatus: ChainWalletCreationStatus.LOADING,
    });

    // Make sure all wallets have a chain wallet for the connected chains
    const wallets = realm.objects<Wallet>(Wallet.schema.name);

    const walletPromises: Promise<any>[] = [];
    wallets.forEach((wallet) => {
      const chainWallets = wallet.chainWallets;

      const chains = connectedChains.concat(testnetChains);

      chains.forEach((chain) => {
        let chainWallet = chainWallets.find((chainWallet) => chainWallet.type === chain.id);

        if (
          (isNil(chainWallet) || !isChainWalletValid(chainWallet)) &&
          wallet.type !== WalletType.Ledger
        ) {
          walletPromises.push(createChainWallet(wallet, chain));
        }
      });
    });

    Promise.all(walletPromises).then(() => {
      useVault.setState({
        chainWalletCreatingStatus: ChainWalletCreationStatus.CREATED,
      });
    });
  }, [realm, connectedChains, substrateKeyDerivationMethod]);

  useEffect(() => {
    if (Platform.OS === 'ios') {
      KeyboardManager.setEnable(true);
      KeyboardManager.setEnableAutoToolbar(false);
      KeyboardManager.setShouldResignOnTouchOutside(true);
      KeyboardManager.setKeyboardDistanceFromTextField(25);
    }
  }, []);

  return !isLoaded ? (
    <AppLoading />
  ) : (
    <SafeAreaProvider>
      <StatusBar.StatusBar style={isDarkMode ? 'light' : 'dark'} translucent />
      <GestureHandlerRootView style={{ flex: 1 }}>
        <NavigationContainer theme={isDarkMode ? DarkTheme : DefaultTheme} onStateChange={() => {}}>
          <Navigation />
          <Modal
            open={modalOpen}
            onClose={() => {
              modalOnClose && modalOnClose();
              setModalOpen(false);
              setModalOnClose(null);

              // Reset options
              setModalOptions({});
            }}
            title={modalTitle}
            {...modalOptions}
          >
            {modalContent}
          </Modal>

          <Modal
            open={altModalOpen}
            onClose={() => {
              altModalOnClose && altModalOnClose();
              setAltModalOpen(false);
              setAltModalOnClose(null);

              // Reset options
              setAltModalOptions({});
            }}
            title={altModalTitle}
            {...altModalOptions}
          >
            {altModalContent}
          </Modal>

          <Toast />
          <TipProvider showItemPulseAnimation />
          {isBackground && <Blur />}
        </NavigationContainer>
      </GestureHandlerRootView>
    </SafeAreaProvider>
  );
}
