import { EarnItem, EarnItemType } from '@/components/Earn/EarnItem';
import { HomeButton } from '@/components/HomeButton';
import { EarnStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { Heading } from '@/components/Typography';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { ChainID } from '@/utils/chains';
import { CompositeNavigationProp, useIsFocused, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import debounce from 'lodash/debounce';
import React, { useMemo, useRef } from 'react';
import { LayoutAnimation, Platform, ScrollView, StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<EarnStackParams, 'Earn'>,
  StackNavigationProp<RootStackParams>
>;

export function EarnScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const { isDarkMode } = useTheme();

  const isFocused = useIsFocused();
  const { setHideTabBar } = useNavigationStore();

  const { connectedChains } = useChainServices();

  const isIconEnabled = useMemo(() => {
    return connectedChains.map((chain) => chain.id).includes(ChainID.ICON);
  }, [connectedChains]);
  const scrollRef = useRef<ScrollView>(null);

  React.useEffect(() => {
    if (isFocused) {
      setHideTabBar(false);
    } else {
      scrollViewToTop();
    }
  }, [isFocused]);

  const scrollViewToTop = () => {
    debounce(() => {
      scrollRef.current?.scrollTo({ x: 0, y: 0, animated: false });
    }, 1000)();
  };

  return (
    <SafeAreaScreen top padTop={false} bottom={false}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ flexGrow: 1 }} ref={scrollRef}>
        <HomeButton />
        <View style={styles.scrollViewContainer}>
          <Heading large style={styles.heading}>
            Earn
          </Heading>

          {isIconEnabled && (
            <EarnItem
              type={EarnItemType.icxStaking}
              style={{ marginBottom: 7 }}
              onPress={() => {
                Platform.OS === 'ios' &&
                  LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
                setHideTabBar(true);
                navigate('ICXStaking');
              }}
            />
          )}
        </View>
      </ScrollView>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  scrollViewContainer: {
    flexGrow: 1,
    paddingHorizontal: 20,
  },
  heading: {
    marginVertical: 25,
  },
});
