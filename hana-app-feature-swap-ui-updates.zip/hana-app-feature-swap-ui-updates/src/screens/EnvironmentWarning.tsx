import { Button, ButtonVariant } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Heading, Text } from '@/components/Typography';
import { useVault } from '@/stores/Vault';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

type NavigationProps = StackNavigationProp<RootStackParams, 'EnviromentWarning'>;

export function EnvironmentWarning() {
  const { navigate } = useNavigation<NavigationProps>();
  const { hasVault } = useVault();

  async function handleContinue() {
    navigate(hasVault ? 'UnlockStack' : 'OnboardingStack');
  }

  return (
    <>
      <SafeAreaScreen top={false} bottom={false}>
        <ScrollViewScreen>
          <Heading large>Unsupported environment detected</Heading>

          <Text large style={{ marginTop: 30 }}>
            We’ve detected you’re running Hana in an emulated, development or system-rooted
            environment.
          </Text>
          <Text large bold space>
            Your funds may be at a higher risk of loss in your operating environment. Due to the
            higher risks Hana is not recommended or supported.
          </Text>
          <Text large space>
            If you have any questions reach out to us for support.
          </Text>
        </ScrollViewScreen>
      </SafeAreaScreen>

      <Footer>
        <Button variant={ButtonVariant.DangerTertiary} onPress={handleContinue}>
          Continue
        </Button>
      </Footer>
    </>
  );
}
