import { IconAddBlack, IconAddWhite } from '@/assets/icons';
import { CardButton } from '@/components/CardButton';
import { ChainSelect } from '@/components/ChainSelect';
import { EntityImage } from '@/components/EntityImage';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { AltHeading, Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { ChainID } from '@/utils/chains';
import { getCustomNetworks, getCustomNetworksForChain } from '@/utils/networks';
import { common } from '@/utils/styles';
import {
  CompositeNavigationProp,
  RouteProp,
  useFocusEffect,
  useNavigation,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isNil } from 'lodash-es';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'ManageCustomNetworks'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'ManageCustomNetworks'>;

export function ManageCustomNetworksScreen() {
  const { navigate, setOptions } = useNavigation<NavigationProps>();
  const { isDarkMode } = useTheme();
  const [selectedChain, setSelectedChain] = React.useState<ChainID | null>(null);
  const [refresh, setRefresh] = useState(Date.now());

  const networks = useMemo(() => {
    const networks = !isNil(selectedChain)
      ? getCustomNetworksForChain(selectedChain)
      : getCustomNetworks();
    return networks ?? [];
  }, [selectedChain, refresh]);

  useFocusEffect(
    useCallback(() => {
      setRefresh(Date.now());
    }, [])
  );

  useEffect(() => {
    setOptions({
      headerRight: () => (
        <TouchableOpacity style={{ marginRight: 16 }} onPress={() => navigate('EditCustomNetwork')}>
          {isDarkMode ? <IconAddWhite /> : <IconAddBlack />}
        </TouchableOpacity>
      ),
    });
  }, [isDarkMode]);

  return (
    <SafeAreaScreen>
      <Heading>Custom networks</Heading>

      <View style={styles.chainSelect}>
        <ChainSelect chain={selectedChain} onSelectChain={setSelectedChain} />
      </View>

      {(networks ?? []).map((network) => (
        <CardButton
          onPress={() => navigate('NetworkDetails', { network })}
          height={80}
          key={network.id}
        >
          <View style={styles.button}>
            <EntityImage name={network.name} />

            <View style={styles.buttonTitles}>
              <Text large bold>
                {network.name}
              </Text>
              <AltHeading style={{ marginTop: 6 }}>{network.providerRpcUrl}</AltHeading>
            </View>
          </View>
        </CardButton>
      ))}

      {networks.length === 0 && (
        <View style={[common.fill, common.centerContent]}>
          <Text muted>
            You have no custom{' '}
            {!isNil(selectedChain)
              ? `${selectedChain.charAt(0).toUpperCase()}${selectedChain.substring(1)}`
              : ''}{' '}
            networks.
          </Text>
        </View>
      )}
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  chainSelect: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  button: {
    flexDirection: 'row',
    flex: 1,
    alignItems: 'center',
  },
  buttonTitles: {
    flex: 1,
    marginLeft: 15,
  },
});
