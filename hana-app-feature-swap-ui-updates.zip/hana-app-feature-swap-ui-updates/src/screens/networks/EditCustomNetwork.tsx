import { Button, ButtonVariant } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { ModalTextItem } from '@/components/ModalTextItem';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Select } from '@/components/Select';
import { TextInput } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { CustomNetwork } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainID, ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { dismissModal, presentModal } from '@/utils/modal';
import { isValidNetworkId, isValidSymbol, isValidUrl } from '@/utils/validation';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty, isNil } from 'lodash-es';
import React, { useMemo, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { v4 as uuid } from 'uuid';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'EditCustomNetwork'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'EditCustomNetwork'>;

export function EditCustomNetworkScreen() {
  const { params } = useRoute<RouteProps>();
  const network = useMemo(() => params?.network ?? null, []);
  const isCreate = useMemo(() => isNil(network), [network]);
  const { isDarkMode } = useTheme();

  const { goBack } = useNavigation<NavigationProps>();
  const { setToastMessage } = useNavigationStore();

  const { realm } = useVault();

  const [chainID, setChainID] = useState<ChainID>(network?.chain ?? ChainID.ICON);
  const [networkName, setNetworkName] = useState(network?.name ?? '');
  const [providerRpcUrl, setProviderRpcUrl] = useState(network?.providerRpcUrl ?? '');
  const [networkId, setNetworkId] = useState(
    !isNil(network?.networkId) ? String(network?.networkId) : ''
  );
  const [currencySymbol, setCurrencySymbol] = useState(network?.symbol ?? '');
  const [blockExplorerUrl, setBlockExplorerUrl] = useState(network?.blockExplorerUrl ?? '');
  const [blockExplorerApi, setBlockExplorerApi] = useState(network?.blockExplorerApi ?? '');

  const [networkNameError, setNetworkNameError] = useState<string | null>(null);
  const [providerRpcError, setProviderRpcError] = useState<string | null>(null);
  const [networkIdError, setNetworkIdError] = useState<string | null>(null);
  const [currencySymbolError, setCurrencySymbolError] = useState<string | null>(null);
  const [blockExplorerUrlError, setBlockExplorerUrlError] = useState<string | null>(null);
  const [blockExplorerApiError, setBlockExplorerApiError] = useState<string | null>(null);

  const ALL_CHAINS_SEGMENT: String[] = [];
  const { getActiveWallet, getActiveChainWallets } = useVault();
  const activeWallet = getActiveWallet();

  const _getActiveChainWallets = getActiveChainWallets();

  const segments = React.useMemo(() => {
    const activeChainWallets = _getActiveChainWallets.filter((cw) => cw.isActive);
    const activeChains = activeChainWallets?.map((cw) => cw.type.toUpperCase());
    return ALL_CHAINS_SEGMENT.concat(activeChains);
  }, [_getActiveChainWallets, activeWallet]);

  const ChainIDs: string[] = [];

  for (const iterator in ChainID) {
    const small = iterator.toLowerCase();
    segments?.find((item) => small == item.toLowerCase() && ChainIDs.push(iterator));
  }

  const [savingNetwork, setSavingNetwork] = useState(false);

  const { otherNetwork, selectOtherNetwork } = useChainServices();

  const modalContent = React.useMemo(
    () =>
      ChainIDs.map((_chainID) => {
        const chain = chainForChainID(_chainID as ChainID);
        return (
          <ModalTextItem
            title={chain?.name}
            onPress={() => {
              setChainID(_chainID as ChainID);
              dismissModal();
            }}
            chain={chain}
            isActive={chainID === _chainID}
            key={_chainID}
          />
        );
      }),
    [chainID, isDarkMode]
  );

  function resetErrors() {
    setNetworkNameError(null);
    setProviderRpcError(null);
    setNetworkIdError(null);
    setCurrencySymbolError(null);
    setBlockExplorerUrlError(null);
    setBlockExplorerApiError(null);
  }

  function verifyFields() {
    let errors = false;

    if (isEmpty(networkName.trim())) {
      setNetworkNameError('Please enter the network name');
      errors = true;
    }

    if (!isValidUrl(providerRpcUrl, 'provider')) {
      setProviderRpcError('Please enter a valid provider URL');
      errors = true;
    }

    if (!isValidNetworkId(networkId)) {
      setNetworkIdError('Please enter a valid network ID');
      errors = true;
    }

    if (!isValidSymbol(currencySymbol)) {
      setCurrencySymbolError('Please enter a valid symbol');
      errors = true;
    }

    if (!isEmpty(blockExplorerUrl.trim()) && !isValidUrl(blockExplorerUrl)) {
      setBlockExplorerUrlError('Please enter a valid URL');
      errors = true;
    }

    if (!isEmpty(blockExplorerApi.trim()) && !isValidUrl(blockExplorerApi)) {
      setBlockExplorerApiError('Please enter a valid URL');
      errors = true;
    }

    return !errors;
  }

  function onSaveNetwork() {
    if (!realm) {
      throw new Error('Realm not available');
    }

    resetErrors();

    if (!verifyFields()) {
      return;
    }

    setSavingNetwork(true);

    if (network) {
      realm.write(() => {
        network.chain = chainID;
        network.name = networkName;
        network.providerRpcUrl = providerRpcUrl.trim();
        network.networkId = +networkId;
        network.symbol = currencySymbol;
        network.blockExplorerUrl = blockExplorerUrl.trim();
        network.blockExplorerApi = blockExplorerApi.trim();
      });

      console.debug('updated to network: ', network);

      setToastMessage('Updated network', ToastType.info);

      // Update current network if needed
      if ((otherNetwork as CustomNetwork)?.id === network.id) {
        selectOtherNetwork(network);
      }
    } else {
      realm.write(() => {
        realm.create('CustomNetwork', {
          id: uuid(),
          chain: chainID,
          name: networkName,
          providerRpcUrl: providerRpcUrl.trim(),
          networkId: +networkId,
          symbol: currencySymbol,
          blockExplorerUrl: blockExplorerUrl.trim(),
          blockExplorerApi: blockExplorerApi.trim(),
        });
      });

      setToastMessage('Added new network', ToastType.info);
    }

    setSavingNetwork(false);

    goBack();
  }

  return (
    <SafeAreaScreen bottom={false}>
      <ScrollViewScreen>
        <Heading>{isCreate ? 'Add a network' : network!.name}</Heading>

        {!isCreate && (
          <Text muted style={{ marginTop: 10 }}>
            {network!.providerRpcUrl}
          </Text>
        )}

        <Select
          placeholder="Chain"
          value={chainID ? chainForChainID(chainID)?.name : null}
          chain={chainForChainID(chainID)}
          onPress={() => {
            presentModal({
              title: 'Select Chain',
              content: (
                <ScrollView contentContainerStyle={{ marginTop: 20 }}>{modalContent}</ScrollView>
              ),
            });
          }}
          style={{ marginTop: 30 }}
        />

        <TextInput
          label="Network name"
          value={networkName}
          onChangeText={(text) => setNetworkName(text)}
          msgError={networkNameError}
          error={!!networkNameError}
          style={{ marginTop: 14 }}
          autoFocus
        />

        <TextInput
          label="Provider RPC URL"
          value={providerRpcUrl}
          msgError={providerRpcError}
          error={!!providerRpcError}
          onChangeText={(text) => setProviderRpcUrl(text)}
          autoCapitalize="none"
          style={{ marginTop: 14 }}
        />

        <TextInput
          label="Network ID"
          value={networkId}
          onChangeText={(text) => setNetworkId(text)}
          msgError={networkIdError}
          error={!!networkIdError}
          style={{ marginTop: 14 }}
        />

        <TextInput
          label="Currency symbol"
          value={currencySymbol}
          onChangeText={(text) => setCurrencySymbol(text)}
          error={!!currencySymbolError}
          msgError={currencySymbolError}
          style={{ marginTop: 14 }}
        />
        <TextInput
          label="Block explorer URL (optional)"
          value={blockExplorerUrl}
          onChangeText={(text) => setBlockExplorerUrl(text)}
          style={{ marginTop: 14 }}
          msgError={blockExplorerUrlError}
          error={!!blockExplorerUrlError}
          autoCapitalize="none"
        />

        <TextInput
          label="Block explorer API (optional)"
          value={blockExplorerApi}
          onChangeText={(text) => setBlockExplorerApi(text)}
          error={!!blockExplorerApiError}
          msgError={blockExplorerApiError}
          autoCapitalize="none"
          style={{ marginTop: 14 }}
        />
      </ScrollViewScreen>

      <Footer>
        <View style={styles.footer}>
          {!isCreate && (
            <Button
              variant={ButtonVariant.PurpleSecondary}
              onPress={goBack}
              style={{ width: '40%', backgroundColor: colors.gray.cards }}
              textStyle={{ color: colors.black }}
            >
              Cancel
            </Button>
          )}

          <Button
            onPress={onSaveNetwork}
            working={savingNetwork}
            style={{ flex: 1, marginLeft: 12 }}
          >
            Save
          </Button>
        </View>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
});
