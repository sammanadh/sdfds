import { IconEdit, IconEditWhite } from '@/assets/icons';
import { Button, ButtonVariant } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { ConfirmDeleteNetworkModal } from '@/components/Modals/ConfirmDeleteNetworkModal';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Select } from '@/components/Select';
import { TextInput } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import type { CustomNetwork } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainID } from '@/utils/chains';
import { dismissModal, presentModal } from '@/utils/modal';
import { isCustomNetwork } from '@/utils/types';
import { wait } from '@/utils/wait';
import {
  CompositeNavigationProp,
  RouteProp,
  useIsFocused,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty, isNil } from 'lodash-es';
import React, { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import { TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'NetworkDetails'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'NetworkDetails'>;

export function NetworkDetailsScreen() {
  const {
    params: { network: providedNetwork },
  } = useRoute<RouteProps>();

  const isFocused = useIsFocused();

  const [refreshNetworkDetails, setRefreshNetworkDetails] = useState(new Date());

  // This is used to trigger a refresh of network details ONLY if the screen is focused
  // If it triggers when screen loses focus, it can cause a crash due to Realm deletion
  useEffect(() => {
    if (isFocused) {
      setRefreshNetworkDetails(new Date());
    }
  }, [isFocused]);

  // This isn't ideal, but we can't render the network details on this screen after they've been deleted from Realm
  // This way we're rendering data which is a clone of the Realm object, and unaffected by removal from Realm
  const network = useMemo(() => {
    return (providedNetwork as any).toJSON() as CustomNetwork;
  }, [refreshNetworkDetails]);

  const { isDarkMode } = useTheme();

  const { goBack, navigate, setOptions } = useNavigation<NavigationProps>();

  const { setToastMessage } = useNavigationStore();

  const { realm } = useVault();

  const [isDeleting, setIsDeleting] = useState(false);

  const { otherNetwork, selectOtherNetwork } = useChainServices();

  function handleConfirmDeleteNetwork() {
    if (isDeleting) return;

    presentModal({
      title: 'Delete network',
      content: (
        <ConfirmDeleteNetworkModal
          network={network}
          onConfirm={handleDeleteNetwork}
          onCancel={dismissModal}
        />
      ),
      options: {
        withCloseButton: false,
      },
    });
  }

  async function handleDeleteNetwork() {
    setIsDeleting(true);

    // Check if this network is currently selected
    // Reset to mainnet if it is
    if (isCustomNetwork(otherNetwork) && otherNetwork.id === network.id) {
      selectOtherNetwork(null);
    }

    realm?.write(() => {
      realm.delete(providedNetwork);
    });
    await wait();

    dismissModal();
    setToastMessage('Network deleted', ToastType.info);
    goBack();
  }

  useLayoutEffect(() => {
    setOptions({
      headerRight: () => (
        <TouchableOpacity
          onPress={() => {
            navigate('EditCustomNetwork', {
              network: providedNetwork,
            });
          }}
        >
          <View style={{ width: 45 }}>
            {isDarkMode ? (
              <IconEditWhite width={25} height={25} />
            ) : (
              <IconEdit width={25} height={25} />
            )}
          </View>
        </TouchableOpacity>
      ),
    });
  }, [isDarkMode]);

  return (
    <SafeAreaScreen bottom={false}>
      <ScrollViewScreen>
        <Heading>{network.name}</Heading>
        <Text muted style={{ marginTop: 10 }}>
          {network.providerRpcUrl}
        </Text>

        <Select
          placeholder="Chain"
          value={network.chain ? chainForChainID(network.chain)?.name : null}
          chain={chainForChainID(network.chain)}
          onPress={() => {}}
          disabled
          isRemoveDropdown
          style={{ marginTop: 30 }}
        />

        <TextInput
          label="Network name"
          value={network.name}
          style={{ marginTop: 14 }}
          editable={false}
        />

        <TextInput
          label="Provider RPC URL"
          value={network.providerRpcUrl}
          style={{ marginTop: 14 }}
          editable={false}
        />

        <TextInput
          label="Network ID"
          value={String(network.networkId)}
          style={{ marginTop: 14 }}
          editable={false}
        />

        <TextInput
          label="Currency symbol"
          value={network.symbol}
          style={{ marginTop: 14 }}
          editable={false}
        />

        {!isEmpty(network.blockExplorerUrl) && (
          <TextInput
            label="Block explorer URL (optional)"
            value={network.blockExplorerUrl}
            style={{ marginTop: 14 }}
            editable={false}
          />
        )}

        {!isEmpty(network.blockExplorerApi) && (
          <TextInput
            label="Block explorer API (optional)"
            value={network.blockExplorerApi}
            style={{ marginTop: 14 }}
            editable={false}
          />
        )}
      </ScrollViewScreen>

      <Footer>
        <Button
          variant={ButtonVariant.DangerTertiary}
          onPress={handleConfirmDeleteNetwork}
          working={isDeleting}
        >
          Delete this network
        </Button>
      </Footer>
    </SafeAreaScreen>
  );
}
