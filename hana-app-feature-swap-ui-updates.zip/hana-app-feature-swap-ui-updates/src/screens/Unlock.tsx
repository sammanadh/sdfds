import { Button, ButtonVariant } from '@/components/Button';
import { RootStackParams, UnlockStackParams } from '@/components/Navigation';
import { TextButton } from '@/components/TextButton';
import { TextInput, TextInputRef } from '@/components/TextInput';
import { Heading, Text } from '@/components/Typography';
import { useOnboardingFlags } from '@/stores/OnboardingFlags';
import { useSettings } from '@/stores/Settings';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import { wait } from '@/utils/wait';
import {
  CompositeNavigationProp,
  NavigationState,
  PartialState,
  useNavigation,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as Haptics from 'expo-haptics';
import * as LocalAuthentication from 'expo-local-authentication';
import * as NavigationBar from 'expo-navigation-bar';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Dimensions, KeyboardAvoidingView, Platform, View } from 'react-native';

interface FormErrors {
  password?: string | null;
}

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<UnlockStackParams, 'Unlock'>,
  StackNavigationProp<RootStackParams>
>;

export function UnlockScreen() {
  const navigation = useNavigation<NavigationProps>();
  const onboardingFlags = useOnboardingFlags();
  const { backupVault, unlockVault } = useVault();

  const [password, setPassword] = useState('');
  const passwordInput = useRef<TextInputRef>(null);
  const [attempts, setAttempts] = useState(0);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isWorking, setIsWorking] = useState(false);
  const { isDarkMode } = useTheme();
  const { biometricsEnabled } = useSettings();
  const [isBiometricSupported, setIsBiometricSupported] = useState(false);
  const [isBiometricVerified, setIsBiometricVerified] = useState(false);
  const marginTop = useMemo(() => Dimensions.get('screen').height * 0.075, []);

  useEffect(() => {
    if (Platform.OS !== 'android') return;
    NavigationBar.setBackgroundColorAsync(isDarkMode ? colors.purple.darkBlacker : colors.white);
    NavigationBar.setButtonStyleAsync(isDarkMode ? 'light' : 'dark');
  }, [isDarkMode]);

  useEffect(() => {
    (async () => {
      const compatible = await LocalAuthentication.hasHardwareAsync();
      setIsBiometricSupported(compatible);
    })();
  }, []);

  useEffect(() => {
    async function checkBiometrics() {
      const savedBiometrics = await LocalAuthentication.isEnrolledAsync();

      if (savedBiometrics) {
        const biometricAuth = await LocalAuthentication.authenticateAsync({
          promptMessage: 'Login with Biometrics',
          disableDeviceFallback: true,
          cancelLabel: 'Cancel',
        });

        if (biometricAuth.success === true) {
          setIsBiometricVerified(true);
        }
      }
    }

    if (isBiometricSupported && biometricsEnabled) {
      checkBiometrics();
    }
  }, [isBiometricSupported, biometricsEnabled]);

  useEffect(() => {
    if (isBiometricVerified) {
      handleUnlock();
      // setPasscode('000000'); // Just for UX
    }
  }, [isBiometricVerified]);

  async function handleUnlock() {
    if (isWorking) return;

    const thisAttempt = attempts + 1;
    setAttempts(thisAttempt);
    setIsWorking(true);
    await wait(); // ensure loading UI shows

    try {
      let nextRouteName: keyof ReactNavigation.RootParamList = 'MainDrawer';
      let nextRouteState: PartialState<NavigationState> | undefined;
      await unlockVault({ passcode: password, useBiometrics: isBiometricVerified });

      if (!onboardingFlags.confirmSeedPhrase) {
        const seedPhrase = await backupVault({ passcode: password });
        nextRouteName = 'OnboardingStack';

        nextRouteState = { index: 0, routes: [{ name: 'ShowSeedPhrase', params: { seedPhrase } }] };
      } else {
        if (!onboardingFlags.configureChains) {
          nextRouteName = 'OnboardingStack';
          nextRouteState = { index: 0, routes: [{ name: 'ConfigureChains' }] };
        } else if (!onboardingFlags.acceptDisclaimer) {
          nextRouteName = 'OnboardingStack';
          nextRouteState = { index: 0, routes: [{ name: 'Disclaimer' }] };
        }
      }

      navigation.reset({ index: 0, routes: [{ name: nextRouteName, state: nextRouteState }] });

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error: any) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      errors.password = `Incorrect passcode. You've had ${thisAttempt} attempt${
        thisAttempt !== 1 ? 's' : ''
      }.`;
      setPassword('');
      wait().then(() => passwordInput.current?.focus());
      setIsWorking(false);
    }
  }

  function onResetWallet() {
    navigation.navigate('UnlockConfirmReset');
  }

  return (
    <KeyboardAvoidingView behavior="padding">
      <Heading center style={{ marginTop }}>
        Welcome back!
      </Heading>
      <Text center style={[{ marginTop: 18 }, isDarkMode && { color: colors.whiteSecond }]}>
        Enter your password to access your wallet.
      </Text>

      <TextInput
        ref={passwordInput}
        value={password}
        onChangeText={(text) => {
          if (errors.password) setErrors({ password: null });
          setPassword(text);
        }}
        onSubmitEditing={handleUnlock}
        editable={!isWorking}
        autoFocus
        style={{ marginTop: 50, marginBottom: 25 }}
        label="Enter your password"
        secureTextEntry
      />

      {errors.password && (
        <Text center small error style={{ marginBottom: 25 }}>
          {errors.password}
        </Text>
      )}

      <Button
        variant={ButtonVariant.Primary}
        style={{ width: '100%' }}
        onPress={handleUnlock}
        working={isWorking}
      >
        Unlock
      </Button>

      <View
        style={{
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: 50,
        }}
      >
        <TextButton
          textStyle={[isDarkMode && { color: colors.whiteSecond }]}
          onPress={onResetWallet}
        >
          Reset wallet
        </TextButton>
      </View>
    </KeyboardAvoidingView>
  );
}
