import { Button, ButtonVariant } from '@/components/Button';
import { PReps } from '@/components/ICXStaking/PReps';
import { Votes } from '@/components/ICXStaking/Votes';
import { EarnStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import SegmentedControl from '@/components/SegmentedControl';
import { ToastType } from '@/components/Toast.types';
import { Text } from '@/components/Typography';
import { ICONService } from '@/services/chainServices/IconService';
import { serviceForChainID } from '@/stores/ChainServices';
import { useIconNetwork } from '@/stores/IconNetwork';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import { ONE, ZERO } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { getErrorMessage } from '@/utils/errors';
import { formatAmount, formatNumber } from '@/utils/format';
import { dismissModal, presentModal } from '@/utils/modal';
import {
  CompositeNavigationProp,
  RouteProp,
  useIsFocused,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { gt } from 'lodash-es';
import React, { useEffect, useMemo } from 'react';
import { View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<EarnStackParams, 'ICXStaking'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<EarnStackParams, 'ICXStaking'>;

export function ICXStaking() {
  const { params } = useRoute<RouteProps>();

  const { isDarkMode } = useTheme();

  const skipRefresh = params?.skipRefreshingData || false;
  const showVotes = params?.showVotes || false;

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();
  const { setToastMessage } = useNavigationStore();

  const { icxAssetsForWallet, icxAssets } = useIconNetwork();
  const walletAssets = icxAssetsForWallet();

  const { refreshICXAssets, refreshPReps } = useIconNetwork();

  const isFocused = useIsFocused();

  const iScore = React.useMemo(() => walletAssets?.iScore ?? ZERO, [walletAssets]);
  const hasIScore = iScore.gt(ONE);

  const hasDelegations = useMemo(
    () => gt(walletAssets?.delegations?.length ?? 1, 0),
    [walletAssets]
  );

  const { navigate } = useNavigation<NavigationProps>();

  const chainService = serviceForChainID(ChainID.ICON) as ICONService;

  const segments = React.useMemo(() => {
    return ['My votes', 'Validators'];
  }, []);

  const [selectedSegment, setSelectedSegment] = React.useState(segments[1]);
  const [claimingIScore, setClaimingIScore] = React.useState(false);
  const iScoreEstimatedIcx = useMemo(
    () => walletAssets?.iScoreEstimatedIcx ?? ZERO,
    [walletAssets]
  );
  useEffect(() => {
    setSelectedSegment(hasDelegations ? segments[0] : segments[1]);
  }, [hasDelegations]);

  useEffect(() => {
    // NOTE: Reason to skip refresh is sometimes after allocating votes, the data fetched does not reflect the new votes yet
    if (isFocused && !skipRefresh) {
      refreshPReps();
      refreshICXAssets();
    }

    // if (isFocused) {
    //   setSelectedSegment(hasDelegations ? segments[0] : segments[1]);
    // }
  }, [isFocused]);

  useEffect(() => {
    if (showVotes && isFocused) {
      setSelectedSegment(segments[0]);
    }
  }, [showVotes, isFocused]);

  async function onClaimIScore() {
    setClaimingIScore(true);

    try {
      await chainService.claimIScore(activeWallet!, {});
      setToastMessage('Your I-Score has been claimed', ToastType.info);
    } catch (error: any) {
      const errorMessage = getErrorMessage(error, 'Failed claiming I-Score');
      console.warn(errorMessage + '.', error.message);

      setToastMessage(errorMessage, ToastType.error);
    }

    setClaimingIScore(false);
  }

  const _onClaimIScore = React.useMemo(() => {
    return () => {
      if (claimingIScore) return;

      const content = (
        <>
          <Text
            large
            style={{
              color: isDarkMode ? 'white' : '#190a3d',
              marginVertical: 20,
              paddingBottom: 10,
            }}
          >
            You currently have{' '}
            <Text bold style={[isDarkMode ? { color: 'white' } : {}]}>
              {formatNumber(iScore)}
            </Text>{' '}
            unclaimed rewards which will convert to{' '}
            <Text bold style={[isDarkMode ? { color: 'white' } : {}]}>
              {formatAmount(iScoreEstimatedIcx)}
            </Text>{' '}
            ICX. Click "Continue" to claim now.
          </Text>

          <View
            style={{
              width: '100%',
              justifyContent: 'space-between',
              flexDirection: 'row',
              alignItems: 'center',
            }}
          >
            <Button
              style={{ width: '40%', backgroundColor: colors.gray.cards }}
              textStyle={{ color: colors.black }}
              onPress={() => dismissModal()}
            >
              Cancel
            </Button>
            <Button
              variant={ButtonVariant.Primary}
              style={{ flex: 1, marginLeft: 12 }}
              onPress={() => {
                dismissModal();
                onClaimIScore();
              }}
            >
              Continue
            </Button>
          </View>
        </>
      );

      presentModal({
        title: 'Claim I-Score',
        content,
        options: {
          withCloseButton: false,
        },
      });
    };
  }, [iScore, iScoreEstimatedIcx, claimingIScore, isDarkMode]);

  return (
    <SafeAreaScreen top={false}>
      <View>
        <SegmentedControl
          segments={segments}
          selectedSegment={selectedSegment}
          onSelectedSegment={setSelectedSegment}
        />
      </View>

      {selectedSegment === 'My votes' && (
        <Votes
          onSelectedPRep={(pRep) => navigate('PRepDetails', { pRep })}
          onAllocateNow={() => navigate('AllocateVotes')}
          onChangeVoteAllocation={() => navigate('AllocateVotes')}
        />
      )}
      {selectedSegment === 'Validators' && (
        <PReps onSelectedPRep={(pRep) => navigate('PRepDetails', { pRep })} />
      )}

      {selectedSegment === 'My votes' && hasIScore && (
        <Button onPress={_onClaimIScore} working={claimingIScore}>
          Claim I-Score
        </Button>
      )}
    </SafeAreaScreen>
  );
}
