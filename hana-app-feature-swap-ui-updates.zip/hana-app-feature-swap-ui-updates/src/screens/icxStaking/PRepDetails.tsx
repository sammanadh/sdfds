import { IconTwitter, IconWeb } from '@/assets/icons';
import { Button } from '@/components/Button';
import { PRepLogo } from '@/components/ICXStaking/PRepLogo';
import { EarnStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Heading, Text } from '@/components/Typography';
import { useIconNetwork } from '@/stores/IconNetwork';
import { useTheme } from '@/stores/Theme';
import { ZERO } from '@/utils/constants';
import { colors, fonts } from '@/utils/designTokens';
import { formatLargeNumber } from '@/utils/format';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as WebBrowser from 'expo-web-browser';
import { isEmpty } from 'lodash-es';
import ordinal from 'ordinal';
import React from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<EarnStackParams, 'PRepDetails'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<EarnStackParams, 'PRepDetails'>;

enum SocialButtonVariant {
  twitter,
  web,
}

interface SocialButtonProps {
  variant: SocialButtonVariant;
  onPress: () => unknown;
}

function SocialButton({ variant, onPress }: SocialButtonProps) {
  const icon = React.useMemo(() => {
    switch (variant) {
      case SocialButtonVariant.twitter:
        return <IconTwitter />;
      case SocialButtonVariant.web:
        return <IconWeb />;
    }
  }, [variant]);

  return (
    <TouchableOpacity onPress={onPress}>
      <View style={styles.socialButton}>{icon}</View>
    </TouchableOpacity>
  );
}

export function PRepDetails() {
  const {
    params: { pRep },
  } = useRoute<RouteProps>();

  const { navigate } = useNavigation<NavigationProps>();

  const { isDarkMode } = useTheme();

  const { icxAssetsForWallet, delegateNewPRep } = useIconNetwork();

  const assets = icxAssetsForWallet();

  const isDelegated = React.useMemo(
    () =>
      (assets?.delegations ?? []).some(
        (delegation) => delegation.address === pRep.address && delegation.amount.gt(ZERO)
      ),
    [pRep, assets]
  );

  function handleVote() {
    if (!isDelegated) {
      delegateNewPRep(pRep);
    }

    navigate('ICXStaking', {
      showVotes: true,
    });
  }

  return (
    <SafeAreaScreen bottom={false} top={false}>
      <ScrollViewScreen contentContainerStyle={styles.scrollViewContainer}>
        <View style={styles.detailsContainer}>
          <PRepLogo pRep={pRep} size={80} />
          <Heading style={styles.prepName}>{pRep.name}</Heading>
          <Text
            muted
            small
            bold
            style={[styles.prepCountry, isDarkMode && { color: colors.whiteSecond }]}
          >
            {pRep.city}, {pRep.country}
          </Text>

          <View style={styles.dataContainer}>
            <View style={styles.data}>
              <Text
                bold
                style={[
                  styles.prepValue,
                  { color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack },
                ]}
              >
                {ordinal(pRep.rank)}
              </Text>
              <Text muted bold large style={styles.prepValueName}>
                Rank
              </Text>
            </View>

            <View
              style={[
                styles.dataSeparator,
                { backgroundColor: isDarkMode ? colors.gray.breakLineDarkMode : colors.gray.cards },
              ]}
            />

            <View style={styles.data}>
              <Text
                bold
                style={[
                  styles.prepValue,
                  { color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack },
                ]}
              >
                {formatLargeNumber(pRep.votes)}
              </Text>
              <Text muted bold large style={styles.prepValueName}>
                Votes
              </Text>
            </View>

            <View
              style={[
                styles.dataSeparator,
                { backgroundColor: isDarkMode ? colors.gray.breakLineDarkMode : colors.gray.cards },
              ]}
            />

            <View style={styles.data}>
              <Text
                bold
                style={[
                  styles.prepValue,
                  { color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack },
                ]}
              >
                {formatLargeNumber(pRep.voters)}
              </Text>
              <Text muted bold large style={styles.prepValueName}>
                Voters
              </Text>
            </View>
          </View>

          <View style={styles.socialButtonsContainer}>
            {!isEmpty(pRep.twitter) && (
              <SocialButton
                variant={SocialButtonVariant.twitter}
                onPress={() => {
                  WebBrowser.openBrowserAsync(pRep.twitter!);
                }}
              />
            )}

            {!isEmpty(pRep.website) && (
              <SocialButton
                variant={SocialButtonVariant.web}
                onPress={() => {
                  WebBrowser.openBrowserAsync(pRep.website);
                }}
              />
            )}
          </View>
        </View>
      </ScrollViewScreen>
      <Button style={{ marginBottom: 26 }} onPress={handleVote}>
        {isDelegated ? 'Change votes' : 'Vote'}
      </Button>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  scrollViewContainer: {
    paddingTop: 0,
    paddingHorizontal: 20,
  },
  detailsContainer: {
    alignItems: 'center',
    paddingTop: 5,
  },
  dataContainer: {
    marginVertical: 5,
    marginTop: 40,
    flexDirection: 'row',
    alignItems: 'center',
  },
  dataSeparator: {
    width: 1,
    height: '100%',
  },
  data: {
    flexDirection: 'column',
    alignItems: 'center',
    flex: 1,
    paddingVertical: 5,
  },
  socialButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.gray.cards,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 10,
  },
  socialButtonsContainer: {
    flexDirection: 'row',
    marginTop: 45,
  },
  prepName: {
    fontFamily: fonts.heavy,
    fontSize: 26,
    lineHeight: 34.3,
    marginTop: 20,
  },
  prepCountry: {
    lineHeight: 19.5,
    marginTop: 8,
  },
  prepValue: {
    fontFamily: fonts.heavy,
    lineHeight: 21,
  },
  prepValueName: {
    lineHeight: 21.9,
    marginTop: 3,
  },
});
