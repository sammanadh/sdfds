import IconBlue from '@/assets/logos/icon-blue-background.svg';
import { Button, ButtonSize, ButtonVariant } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { AllocateVotesPRepItem } from '@/components/ICXStaking/AllocateVotesPRepItem';
import { EarnStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { DelegatedPRep, Delegation } from '@/models/Delegation';
import { PRep } from '@/models/PRep';
import { WalletType } from '@/models/Vault';
import {
  ICONService,
  RawTxResponse,
  SetDelegationsParams,
  SetStakeParams,
} from '@/services/chainServices/IconService';
import { serviceForChainID } from '@/stores/ChainServices';
import { useIconNetwork } from '@/stores/IconNetwork';
import { useLedgerStore } from '@/stores/Ledger';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { BigNumber, toNumber } from '@/utils/bignumber';
import { ChainID } from '@/utils/chains';
import { WITHHOLD_BALANCE, ZERO } from '@/utils/constants';
import { colors, fonts } from '@/utils/designTokens';
import { getErrorMessage } from '@/utils/errors';
import { formatAmount, formatNumber, formatPixel } from '@/utils/format';
import { AppType, getLedgerApp, LedgerAddress, signTransaction } from '@/utils/ledger';
import { dismissModal, presentModal } from '@/utils/modal';
import Transport from '@ledgerhq/hw-transport';
import TransportHID from '@ledgerhq/react-native-hid';
import type * as TransportBLEType from '@ledgerhq/react-native-hw-transport-ble';
import { CompositeNavigationProp, useIsFocused, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import produce from 'immer';
import { gt, isEmpty, isNil, orderBy } from 'lodash-es';
import React, { useEffect, useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';

// NOTE: BLE module is imported lazily so that the Bluetooth permissions don't prompt when app first loads
let TransportBLE: typeof TransportBLEType.default | undefined = undefined;

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<EarnStackParams, 'AllocateVotes'>,
  StackNavigationProp<RootStackParams>
>;

enum WorkingState {
  Idle,
  IncreasingStake,
  DecreasingStake,
  SavingVotes,
}

export function AllocateVotes() {
  const { goBack, navigate } = useNavigation<NavigationProps>();
  const { isDarkMode } = useTheme();

  const { refreshPReps, pReps: allPReps } = useIconNetwork();
  const { refreshICXAssets, icxAssetsForWallet } = useIconNetwork();
  const { getActiveWallet } = useVault();

  const activeWallet = getActiveWallet();
  const activeICXWallet = useMemo(
    () => activeWallet?.chainWallets.find((cw) => cw.type === ChainID.ICON),
    [activeWallet]
  );
  const isLedgerWallet = activeWallet?.type === WalletType.Ledger;

  const { setToastMessage } = useNavigationStore();
  const { setConnectingToLedger, transport, setTransport, setLedgerBleId } = useLedgerStore();

  const isFocused = useIsFocused();

  const assets = icxAssetsForWallet();

  const chainService = serviceForChainID(ChainID.ICON) as ICONService;

  const [delegatedPReps, setDelegatedPReps] = useState<Array<DelegatedPRep>>([]);
  const [workingState, setWorkingState] = useState(WorkingState.Idle);
  const [hasChanged, setHasChanged] = useState(false);

  React.useEffect(() => {
    if (isFocused) {
      refreshPReps();
      refreshICXAssets();
    }
  }, [isFocused]);

  const delegations = useMemo(
    () => orderBy(assets?.delegations ?? [], ['amount'], ['desc']),
    [assets]
  );

  useEffect(() => {
    initializeDelegations();
  }, [allPReps, delegations]);

  function initializeDelegations() {
    // Only initialise once to avoid potential "reset" of values when submitting new allocation
    if (isEmpty(delegatedPReps)) {
      setDelegatedPReps(
        delegations.map((delegation) => {
          const pRep = allPReps.find((pRep: PRep) => pRep.address === delegation.address);
          if (isNil(pRep)) return delegation as DelegatedPRep;
          return { ...pRep, amount: delegation.amount };
        })
      );
    }
  }

  const totalVotes = useMemo(
    () => delegatedPReps.reduce((total, { amount }) => total.plus(amount), ZERO),
    [delegatedPReps]
  );
  const availableVotes = useMemo(
    () =>
      !isNil(assets?.balance)
        ? BigNumber.maximum(assets!.balance!.minus(WITHHOLD_BALANCE), totalVotes).integerValue(
            BigNumber.ROUND_FLOOR
          )
        : ZERO,
    [assets, totalVotes]
  );
  const unallocatedVotes = useMemo(
    () => BigNumber.maximum(availableVotes.minus(totalVotes), ZERO),
    [availableVotes, totalVotes]
  );
  const unallocatedPercentage = useMemo(
    () => (availableVotes.gt(ZERO) ? unallocatedVotes.dividedBy(availableVotes).times(100) : ZERO),
    [unallocatedVotes, availableVotes]
  );

  const changeStake = useMemo(() => {
    const newStake = totalVotes;
    const prevStake = assets?.staked || ZERO;
    return !newStake.eq(prevStake);
  }, [totalVotes, assets]);

  function onConfirmAllocation() {
    const newStake = totalVotes;
    const prevStake = assets?.staked || ZERO;
    if (newStake.eq(prevStake)) return handleSaveAllocation();

    const title = `${gt(newStake, prevStake) ? 'Increase' : 'Decrease'} staked ICX`;

    const isIncrease = gt(newStake, prevStake);

    const content = (
      <>
        <Text style={isDarkMode && { color: 'white' }}>
          To allocate your votes we will need to{' '}
          <Text bold style={isDarkMode && { color: 'white' }}>
            {isIncrease ? 'increase' : 'decrease'}
          </Text>{' '}
          your number of staked ICX to&nbsp;
          <Text bold style={isDarkMode && { color: 'white' }}>
            {formatAmount(newStake)}
          </Text>
          .
        </Text>
        <Text space style={isDarkMode && { color: 'white' }}>
          {isIncrease
            ? 'Remember, when unstaking ICX there is a mandatory 5-20 day waiting period.'
            : 'Remember, unallocated votes do not earn rewards.'}
        </Text>
        {isLedgerWallet && (
          <Text space style={isDarkMode && { color: 'white' }}>
            Check the transaction{changeStake ? 's' : ''} displayed on your device and confirm (or
            reject) {changeStake ? 'them' : 'it'}. Make sure your Ledger is connected with the{' '}
            <Text bold style={isDarkMode && { color: 'white' }}>
              ICON
            </Text>{' '}
            app open.
          </Text>
        )}

        <View
          style={{ marginTop: 20, flexDirection: 'row', flex: 1, justifyContent: 'space-between' }}
        >
          <Button
            style={{ width: '30%', backgroundColor: colors.gray.cards }}
            textStyle={{ color: colors.black }}
            onPress={() => dismissModal()}
          >
            Cancel
          </Button>

          <Button
            variant={ButtonVariant.Primary}
            style={{ flex: 1, marginLeft: 12 }}
            onPress={() => {
              dismissModal();
              handleSaveAllocation();
            }}
          >
            Confirm votes
          </Button>
        </View>
      </>
    );

    presentModal({
      title,
      content,
      options: {
        withCloseButton: false,
      },
    });
  }

  async function connectToLedgerAndSign(rawTxResponse: RawTxResponse) {
    if (!activeWallet || !activeICXWallet) throw new Error('No active wallet');

    if (transport) {
      await transport.close();
    }

    setConnectingToLedger(true);

    let thisTransport: any;

    if (activeWallet.ledgerBleId) {
      if (!TransportBLE) {
        TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
      }

      thisTransport = await TransportBLE.open(activeWallet.ledgerBleId);
      thisTransport.on('disconnect', () => {
        console.debug('BLE disconnected');
      });

      setTransport(thisTransport);
      setLedgerBleId(activeWallet.ledgerBleId);
    } else {
      thisTransport = await TransportHID.create();
      thisTransport.on('disconnect', () => {
        console.debug('HID disconnected');
      });

      setTransport(thisTransport);
    }

    const ledgerApp = await getLedgerApp(thisTransport, AppType.ICX);
    const ledgerAddress = {
      index: activeICXWallet.hdIndex,
      hdPath: activeICXWallet.hdPath,
      address: activeICXWallet.address,
    } as LedgerAddress;

    const { rawTx, serializedTx } = rawTxResponse;

    const signature = await signTransaction(ledgerApp, AppType.ICX, ledgerAddress, serializedTx);
    return signature;
  }

  async function handleSaveAllocation() {
    const newStake = totalVotes;
    const prevStake = assets?.staked || ZERO;
    const delegations: Array<Delegation> = delegatedPReps
      .filter(({ amount }) => amount.gt(ZERO))
      .map(({ address, amount }) => ({ address, amount }));

    const isStakeIncrease = newStake.gt(prevStake);
    const isStakeDecrease = !isStakeIncrease && prevStake.gt(newStake);

    if (isStakeIncrease) {
      try {
        setWorkingState(WorkingState.IncreasingStake);

        const params: SetStakeParams = { amount: newStake };

        if (isLedgerWallet) {
          const transaction = await chainService.setStake(activeWallet!, params, {
            wait: true,
            getRawTx: true,
          });

          if ((transaction as RawTxResponse).rawTx) {
            const response = transaction as RawTxResponse;
            const signature = await connectToLedgerAndSign(response);
            await chainService.setStake(activeWallet!, params, {
              wait: true,
              signature,
              rawTx: response.rawTx,
            });
          }
        } else {
          await chainService.setStake(activeWallet!, params, { wait: true });
        }
      } catch (error: any) {
        const errorMessage = getErrorMessage(error, 'Failed increasing staked ICX');
        console.warn(errorMessage + '.', error.message);
        setToastMessage(errorMessage, ToastType.error);
        return setWorkingState(WorkingState.Idle);
      }
    }

    try {
      setWorkingState(WorkingState.SavingVotes);

      const params: SetDelegationsParams = { delegations };

      if (isLedgerWallet) {
        const transaction = await chainService.setDelegations(activeWallet!, params, {
          wait: isStakeDecrease,
          getRawTx: true,
        });

        if ((transaction as RawTxResponse).rawTx) {
          const response = transaction as RawTxResponse;
          const signature = await connectToLedgerAndSign(response);
          await chainService.setDelegations(activeWallet!, params, {
            wait: isStakeDecrease,
            signature,
            rawTx: response.rawTx,
          });
        }
      } else {
        await chainService.setDelegations(activeWallet!, params, { wait: isStakeDecrease });
      }
    } catch (error: any) {
      const errorMessage = getErrorMessage(error, 'Failed allocating votes');
      console.warn(errorMessage + '.', error.message);
      setToastMessage(errorMessage, ToastType.error);
      return setWorkingState(WorkingState.Idle);
    }

    if (isStakeDecrease) {
      try {
        setWorkingState(WorkingState.DecreasingStake);

        const params: SetStakeParams = { amount: newStake };

        if (isLedgerWallet) {
          const transaction = await chainService.setStake(activeWallet!, params, {
            wait: true,
            getRawTx: true,
          });

          if ((transaction as RawTxResponse).rawTx) {
            const response = transaction as RawTxResponse;
            const signature = await connectToLedgerAndSign(response);
            await chainService.setStake(activeWallet!, params, {
              wait: true,
              signature,
              rawTx: response.rawTx,
            });
          }
        } else {
          await chainService.setStake(activeWallet!, params);
        }
      } catch (error: any) {
        const errorMessage = getErrorMessage(error, 'Failed decreasing staked ICX');
        console.warn(errorMessage + '.', error.message);
        setToastMessage(errorMessage, ToastType.error);
        return setWorkingState(WorkingState.Idle);
      }
    }

    handleComplete();
  }

  function handleComplete() {
    setToastMessage('Your votes have been allocated!', ToastType.info);

    navigate('ICXStaking', {
      skipRefreshingData: true,
    });
  }

  function handleSplitEvenly() {
    const split = availableVotes
      .dividedBy(delegatedPReps.length)
      // TODO: better fix for allocating too many votes when spltting evenly
      .decimalPlaces(10, BigNumber.ROUND_FLOOR);

    setDelegatedPReps(
      produce(delegatedPReps, (draft) => {
        draft.forEach((thisPRep) => {
          thisPRep.amount = split;
        });
      })
    );

    setHasChanged(true);
  }

  return (
    <SafeAreaScreen top={false} bottom={false} style={{ paddingHorizontal: 10 }}>
      <ScrollViewScreen>
        <Heading style={styles.heading}>Allocate votes</Heading>
        <Text large muted style={styles.altHeading}>
          You have{' '}
          <Text bold style={{ color: colors.primary }}>
            {formatAmount(unallocatedVotes)}
          </Text>{' '}
          votes to allocate.
        </Text>

        <Button
          size={ButtonSize.Tiny}
          style={styles.btnSplitEvenly}
          textStyle={styles.txtBtnSplitEvenly}
          onPress={handleSplitEvenly}
        >
          Split evenly
        </Button>

        <View style={styles.itemsContainer}>
          <View style={styles.unallocatedVotes}>
            <IconBlue />

            <View style={{ marginLeft: 9, flex: 1 }}>
              <Text large bold>
                Unallocated votes
              </Text>
              <Text bold muted style={styles.itemDescription}>
                {formatAmount(unallocatedVotes)} ICX
              </Text>
            </View>

            <Text style={styles.unallocatedVotesValue}>
              {formatNumber(unallocatedPercentage, 1, true, BigNumber.ROUND_HALF_UP)}%
            </Text>
          </View>
          <View style={styles.separator} />

          {delegatedPReps.map((delegatedPRep, index) => {
            const totalVotesForOtherPReps = delegatedPReps
              .filter((prep) => prep.address !== delegatedPRep.address)
              .reduce((total, { amount }) => total.plus(amount), ZERO);

            const maxAllowedVotesForThisPRep = availableVotes.minus(totalVotesForOtherPReps);

            return (
              <>
                <AllocateVotesPRepItem
                  key={delegatedPRep.address}
                  pRep={delegatedPRep}
                  maxSliderValue={toNumber(availableVotes)}
                  maxAllowedValue={toNumber(maxAllowedVotesForThisPRep)}
                  onVotesChanged={(votes) => {
                    setDelegatedPReps(
                      produce(delegatedPReps, (draft) => {
                        const thisDelegatedPrep = draft.find(
                          (prep) => prep.address === delegatedPRep.address
                        );
                        if (thisDelegatedPrep) {
                          thisDelegatedPrep.amount = new BigNumber(votes);
                        }
                      })
                    );
                    setHasChanged(true);
                  }}
                  availableVotes={availableVotes}
                  disabled={workingState !== WorkingState.Idle}
                />
                {index !== delegatedPReps.length - 1 && <View style={styles.separator} />}
              </>
            );
          })}
        </View>
      </ScrollViewScreen>
      <Footer>
        <Button
          onPress={onConfirmAllocation}
          working={workingState !== WorkingState.Idle}
          disabled={!hasChanged}
        >
          Confirm votes
        </Button>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    fontSize: 30,
    fontFamily: fonts.heavy,
    lineHeight: 38,
  },
  altHeading: {
    marginVertical: 20,
    lineHeight: 19,
  },
  itemDescription: {
    fontSize: 12,
    lineHeight: 13,
    letterSpacing: 0.2,
    marginTop: 7,
    textTransform: 'uppercase',
  },
  unallocatedVotesValue: {
    paddingHorizontal: 0,
    textAlign: 'right',
    lineHeight: 21,
    fontFamily: fonts.heavy,
  },
  itemsContainer: {
    marginTop: 27,
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.gray.border,
  },
  unallocatedVotes: {
    height: 90,
    width: '100%',
    paddingHorizontal: 0,
    alignItems: 'center',
    flexDirection: 'row',
  },
  btnSplitEvenly: {
    backgroundColor: colors.offPurple,
    width: formatPixel(140, 'wWidth'),
    height: 40,
    borderRadius: 20,
  },
  txtBtnSplitEvenly: {
    color: colors.black,
  },
});
