import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { OnboardingStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { SearchInput } from '@/components/SearchInput';
import { Switch } from '@/components/Switch';
import { TokenLogo } from '@/components/TokenLogo';
import { AltHeading, Heading, Text } from '@/components/Typography';
import { useChainServices } from '@/stores/ChainServices';
import { useOnboardingFlags } from '@/stores/OnboardingFlags';
import { useTheme } from '@/stores/Theme';
import { ChainWalletCreationStatus, useVault } from '@/stores/Vault';
import { ChainDetails, chainFilter, ChainID, chains, isSubstrateChain } from '@/utils/chains';
import { card } from '@/utils/styles';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty, isEqual, isNil, without } from 'lodash-es';
import { useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<OnboardingStackParams, 'ConfigureChains'>,
  StackNavigationProp<RootStackParams>
>;

const availableChains = chains.filter(
  (chain) => chain.enabled && !chain.isTestnet && isNil(chain.affiliatedChainID)
);

export function ConfigureChainsScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const { styles: themeStyles } = useTheme();
  const onboardingFlags = useOnboardingFlags();
  const chainServices = useChainServices();
  const [selectedChainIds, setSelectedChainIds] = useState<Array<ChainID>>([ChainID.ICON]);
  const [query, setQuery] = useState('');
  const { getActiveWallet, chainWalletCreatingStatus } = useVault();
  const filteredChains = useMemo(
    () =>
      !isEmpty(query)
        ? availableChains.filter((chain) => chainFilter(chain, query))
        : availableChains,
    [query]
  );
  const [selectingChains, setSelectingChains] = useState<boolean>(false);
  const [chainSelectionComplete, setChainSelectionComplete] = useState<boolean>(false);

  useEffect(() => {
    if (chainSelectionComplete && chainWalletCreatingStatus === ChainWalletCreationStatus.CREATED) {
      setSelectingChains(false);
      navigate('Disclaimer');
    }
  }, [chainSelectionComplete, chainWalletCreatingStatus]);

  async function handleContinue() {
    if (isEmpty(selectedChainIds)) return;

    const hasChanged = !isEqual(
      selectedChainIds.sort(),
      chainServices.connectedChains.map((chain) => chain.id).sort()
    );

    if (!hasChanged) {
      return navigate('Disclaimer');
    }

    setSelectingChains(true);
    await chainServices.selectChains(selectedChainIds);
    onboardingFlags.update('configureChains', true);
    try {
      await getActiveWallet();
    } catch (error) {}

    setChainSelectionComplete(true);
  }

  function handleToggle(chain: ChainDetails, enabled: boolean) {
    if (enabled) {
      setSelectedChainIds((selectedChainIds) => [...selectedChainIds, chain.id]);
    } else {
      setSelectedChainIds((selectedChainIds) => without(selectedChainIds, chain.id));
    }
  }

  return (
    <>
      <SafeAreaScreen bottom={false}>
        <ScrollViewScreen>
          <Heading large>{'Select chains\nto connect'}</Heading>
          <Text muted style={styles.description}>
            Select the chains you would you like to use with Hana. You can easily add more later.
          </Text>

          <SearchInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search"
            style={{ marginTop: 20 }}
          />

          {filteredChains.map((chain, index) => {
            const isEnabled = selectedChainIds.includes(chain.id);

            return (
              <View
                key={chain.id}
                style={[
                  card.base,
                  styles.item,
                  themeStyles.cards,
                  index === 0 && { marginTop: 20 },
                ]}
              >
                <TokenLogo chain={chain} />
                <View style={styles.content}>
                  <Text large bold numberOfLines={1}>
                    {chain.name}
                  </Text>
                  <AltHeading style={{ marginTop: 6 }}>{chain.token.symbol}</AltHeading>
                </View>
                <Switch
                  value={isEnabled}
                  onChange={(enabled: boolean) => handleToggle(chain, enabled)}
                  disabled={isEnabled && selectedChainIds.length <= 1}
                />
              </View>
            );
          })}
        </ScrollViewScreen>
      </SafeAreaScreen>

      <Footer>
        <Button
          onPress={handleContinue}
          disabled={isEmpty(selectedChainIds)}
          hasNextIcon
          working={selectingChains}
        >
          Continue
        </Button>
      </Footer>
    </>
  );
}

const styles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 14,
    borderRadius: 0,
  },
  content: {
    flex: 1,
    marginHorizontal: 10,
  },
  description: {
    marginTop: 10,
  },
});
