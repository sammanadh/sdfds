import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { OnboardingStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Heading, Text } from '@/components/Typography';
import { useOnboardingFlags } from '@/stores/OnboardingFlags';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as WebBrowser from 'expo-web-browser';
import { StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<OnboardingStackParams, 'Disclaimer'>,
  StackNavigationProp<RootStackParams>
>;

export function DisclaimerScreen() {
  const navigation = useNavigation();
  const { isDarkMode } = useTheme();
  const onboardingFlags = useOnboardingFlags();

  async function handleContinue() {
    onboardingFlags.update('acceptDisclaimer', true);
    navigation.reset({ index: 0, routes: [{ name: 'MainDrawer' }] });
  }

  return (
    <>
      <SafeAreaScreen>
        <ScrollViewScreen>
          <Heading large>Terms of use</Heading>

          <View style={[{ marginTop: 20 }]}>
            <Text large muted style={styles.privacy}>
              As the user of Hana you are solely responsible for managing and keeping your private
              keys safe. Private keys for Hana are stored on your device. The developer does not
              store and/or manage private keys.
            </Text>
            <Text space large muted style={styles.privacy}>
              The developer is not responsible for any loss of private keys.
            </Text>
            <Text space large muted style={styles.privacy}>
              The developer provides Hana "as is", with no guarantee of security, integrity,
              completeness, accuracy, timeliness or of the results obtained from the use of the app,
              and without warranty of any kind, express or implied, including, but not limited to
              warranties of performance, security and fitness for a particular purpose.
            </Text>
            <Text space large muted style={styles.privacy}>
              The developer is not responsible for any direct or indirect bugs, issues,
              malfunctions, hacks, third-party transactions, viruses, malware or any loss from the
              use of Hana.
            </Text>
          </View>
        </ScrollViewScreen>
      </SafeAreaScreen>

      <Footer>
        <Button hasNextIcon onPress={handleContinue}>Accept & continue</Button>
        <View>
          <Text center small muted style={styles.description}>
            By accepting you also accept our{' '}
            <Text
              small
              brand
              onPress={() => WebBrowser.openBrowserAsync('https://hanawallet.io/privacy.html')}
              style={isDarkMode && { color: colors.whiteSecond }}
            >
              Privacy Policy
            </Text>
          </Text>
        </View>
      </Footer>
    </>
  );
}

const styles = StyleSheet.create({
  description: {
    marginTop: 10,
  },
  privacy: {
    lineHeight: 22,
  },
});
