import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { OnboardingStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { TextInput, TextInputRef } from '@/components/TextInput';
import { Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { JOURNEY } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { validateMnemonic } from 'bip39';
import * as Haptics from 'expo-haptics';
import * as NavigationBar from 'expo-navigation-bar';
import { isEmpty } from 'lodash-es';
import { useEffect, useRef, useState } from 'react';
import { Platform, StyleSheet } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<OnboardingStackParams, 'ImportSeedPhrase'>,
  StackNavigationProp<RootStackParams>
>;

interface FormErrors {
  seedPhrase?: string | null;
}

export function ImportSeedPhraseScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const { isDarkMode } = useTheme();

  const [seedPhrase, setSeedPhrase] = useState('');
  const seedPhraseInput = useRef<TextInputRef>(null);
  const [errors, setErrors] = useState<FormErrors>({});

  useEffect(() => {
    if (Platform.OS !== 'android') return;
    NavigationBar.setBackgroundColorAsync(isDarkMode ? colors.purple.darkBlacker : colors.white);
  }, [isDarkMode]);

  function handleContinue() {
    const seedPhraseToUse = seedPhrase.trim().replaceAll(/\s+/g, ' ');
    if (validate(seedPhraseToUse)) {
      navigate('CreatePasscode', {
        journey: JOURNEY.IMPORT_SEED_PHRASE,
        seedPhrase: seedPhraseToUse,
      });
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  }

  function validate(seedPhrase: string) {
    const errors: FormErrors = {};
    let valid = false;

    if (isEmpty(seedPhrase)) {
      errors.seedPhrase = 'Please enter your seed phrase';
    } else if (!validateMnemonic(seedPhrase)) {
      errors.seedPhrase = 'Please enter a valid seed phrase';
    }

    if (errors.seedPhrase) {
      seedPhraseInput.current?.focus();
    } else {
      valid = true;
    }

    setErrors(errors);
    return valid;
  }

  return (
    <>
      <SafeAreaScreen>
        <ScrollViewScreen>
          <Heading large style={styles.heading}>
            {`Import\nseed phrase.`}
          </Heading>
          <Text muted style={styles.content}>
            Enter your existing 12 word seed phrase, and set a password to protect your Hana
            wallets.
          </Text>

          <TextInput
            label="Seed Phrase"
            labelTitle="Seed Phrase"
            ref={seedPhraseInput}
            value={seedPhrase}
            onChangeText={(text) => {
              if (errors.seedPhrase) setErrors({ seedPhrase: null });
              setSeedPhrase(text);
            }}
            onSubmitEditing={handleContinue}
            blurOnSubmit={false}
            autoCapitalize="none"
            autoCompleteType="off"
            autoCorrect={false}
            autoFocus
            error={!isEmpty(errors.seedPhrase)}
            msgError={errors.seedPhrase}
            isDarkMode={isDarkMode}
          />
        </ScrollViewScreen>
      </SafeAreaScreen>

      <Footer>
        <Button onPress={handleContinue} hasNextIcon>
          Continue
        </Button>
      </Footer>
    </>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginBottom: 10,
  },
  content: {
    marginBottom: 40,
  },
});
