import { Button } from '@/components/Button';
import { OnboardingStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { MNEMONIC_WORDS } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useMemo } from 'react';
import { Dimensions, StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<OnboardingStackParams, 'ShowSeedPhrase'>,
  StackNavigationProp<RootStackParams>
>;
type RouteProps = RouteProp<OnboardingStackParams, 'ShowSeedPhrase'>;

const WORD_LIST_COLUMNS = 2;
const WORD_LIST_SIZE = Math.floor(MNEMONIC_WORDS / WORD_LIST_COLUMNS);
const WORD_WIDTH = Dimensions.get('screen').width / WORD_LIST_COLUMNS - 30;

export function ShowSeedPhraseScreen() {
  const { isDarkMode } = useTheme();

  const {
    params: { seedPhrase },
  } = useRoute<RouteProps>();
  const words = useMemo(() => seedPhrase.split(' '), [seedPhrase]);
  const wordLists = useMemo(
    () =>
      Array.from(Array(WORD_LIST_COLUMNS), (_, index) =>
        words.slice(WORD_LIST_SIZE * index, WORD_LIST_SIZE * (index + 1))
      ),
    [words]
  );

  function handleContinue() {
    navigate('ConfirmSeedPhrase', { seedPhrase });
  }

  const { navigate } = useNavigation<NavigationProps>();

  return (
    <>
      <SafeAreaScreen>
        <ScrollViewScreen>
          <Heading large>Seed phrase</Heading>
          <Text muted style={styles.content}>
            These 12 words are the only way to recover your account. Store them somewhere safe!
          </Text>

          <View style={styles.wordsContainer}>
            {wordLists.map((wordList, listIndex) => (
              <View key={listIndex}>
                {wordList.map((word, wordIndex) => {
                  const wordNumber = wordIndex + 1 + listIndex * WORD_LIST_SIZE;
                  return (
                    <View
                      key={`${listIndex}-${wordIndex}-${word}`}
                      style={[
                        styles.wordContainer,
                        wordIndex !== 0 && { marginTop: 10 },
                        isDarkMode && {
                          backgroundColor: colors.black,
                        },
                      ]}
                    >
                      <View
                        style={[
                          styles.containerNumber,
                          isDarkMode && { backgroundColor: colors.purple.darkBlacker },
                        ]}
                      >
                        <Text bold style={isDarkMode && { color: colors.whiteSecond }}>
                          {wordNumber}
                        </Text>
                      </View>
                      <Text bold style={[styles.word, isDarkMode && { color: colors.whiteSecond }]}>
                        {word}
                      </Text>
                    </View>
                  );
                })}
              </View>
            ))}
          </View>
        </ScrollViewScreen>
        <Button onPress={handleContinue} hasNextIcon>
          Continue
        </Button>
      </SafeAreaScreen>
    </>
  );
}

const styles = StyleSheet.create({
  wordsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: formatPixel(30, 'wHeight'),
  },
  wordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: WORD_WIDTH,
    height: 46,
    backgroundColor: colors.gray.cards,
    borderRadius: 24,
    overflow: 'hidden',
    paddingHorizontal: 8,
  },
  word: {
    lineHeight: 19,
    color: colors.black,
    marginLeft: 8,
  },
  containerNumber: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    marginTop: 10,
  },
});
