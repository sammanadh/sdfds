import { Button, ButtonVariant } from '@/components/Button';
import { OnboardingStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { TextInput, TextInputRef } from '@/components/TextInput';
import { Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { JOURNEY, PINCODE_LENGTH, VALIDATE_PASSWORD_REGEXP } from '@/utils/constants';
import { colors, fonts } from '@/utils/designTokens';
import { wait } from '@/utils/wait';
import {
  CompositeNavigationProp,
  RouteProp,
  useFocusEffect,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as Haptics from 'expo-haptics';
import * as NavigationBar from 'expo-navigation-bar';
import { isEmpty, lt } from 'lodash-es';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { LayoutAnimation, Platform, StyleSheet } from 'react-native';
import { showMessage } from 'react-native-flash-message';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<OnboardingStackParams, 'CreatePasscode'>,
  StackNavigationProp<RootStackParams>
>;
type RouteProps = RouteProp<OnboardingStackParams, 'CreatePasscode'>;

interface FormErrors {
  passcode?: string | null;
}

//New

const CreatePasscodeScreen = () => {
  const navigation = useNavigation<NavigationProps>();
  const { params } = useRoute<RouteProps>();

  const passcodeInput = useRef<TextInputRef>(null);
  const confirmPasscodeInput = useRef<TextInputRef>(null);
  const { createVault, importVault } = useVault();
  const { isDarkMode } = useTheme();

  // state
  const [passcode, setPasscode] = useState('');
  const [confirmPasscode, setConfirmPasscode] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [isWorking, setIsWorking] = useState(false);
  const [isFocus, setIsFocus] = useState(false);
  const [changeState, setChangeState] = useState(false);

  useEffect(() => {
    if (Platform.OS !== 'android') return;
    NavigationBar.setBackgroundColorAsync(isDarkMode ? colors.purple.darkBlacker : colors.white);
  }, [isDarkMode]);

  useFocusEffect(
    useCallback(() => {
      setPasscode('');
      setErrors({});
      passcodeInput.current?.focus();
    }, [])
  );

  function validatePassword(passcode: string) {
    const errors: FormErrors = {};
    let valid = false;

    if (isEmpty(passcode.trim())) {
      errors.passcode = 'Please enter a password';
    } else if (lt(passcode.length, PINCODE_LENGTH)) {
      errors.passcode = `Your password should be at least 8 characters`;
    } else if (!VALIDATE_PASSWORD_REGEXP.test(passcode)) {
      errors.passcode =
        'Your password should contain uppercase, lowercase, numeric and non-letter characters';
    }

    if (!errors.passcode) {
      valid = true;
    }
    setErrors((prev) => ({ ...prev, ...errors }));
    return valid;
  }

  function validateConfirmPassword(confirmPasscode: string) {
    const errors: FormErrors = {};
    let valid = false;

    if (isEmpty(confirmPasscode.trim())) {
      errors.passcode = 'Please confirm the password';
    } else if (confirmPasscode !== passcode) {
      errors.passcode = 'The passwords you entered are different';
    }

    if (errors.passcode) {
      // setConfirmPasscode('');
      // confirmPasscodeInput.current?.focus();
    } else {
      valid = true;
    }

    setErrors((prev) => ({ ...prev, ...errors }));
    return valid;
  }

  const onEndEditing = (type: 'passcode' | 'confirmPasscode') => {
    return () => {
      if (type === 'passcode') {
        return validatePassword(passcode);
      }
      if (type === 'confirmPasscode') {
        return validateConfirmPassword(confirmPasscode);
      }
    };
  };

  const handleContinue = async () => {
    // if (validatePassword(passcode)) {
    //   navigate('ConfirmPasscode', { ...params, passcode });
    // } else {
    //   Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    // }

    onEndEditing('passcode')();
    if (!onEndEditing('confirmPasscode')()) return;

    if (isWorking) return;

    if (!validateConfirmPassword(confirmPasscode) || !validatePassword(passcode)) {
      return Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }

    setIsWorking(true);
    await wait(); // ensure loading UI shows

    try {
      if (params.journey === JOURNEY.CREATE_SEED_PHRASE) {
        const seedPhrase = await createVault({ passcode });

        navigation.reset({
          index: 0,
          routes: [{ name: 'ShowSeedPhrase', params: { seedPhrase } }],
        });
      } else {
        await importVault({ passcode, seedPhrase: params.seedPhrase });
        navigation.reset({ index: 0, routes: [{ name: 'ConfigureChains' }] });
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error: any) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      console.warn('Failed creating Vault.', error.message);
      setIsWorking(false);
      showMessage({
        message: 'Failed creating Vault. ' + error.message,
        type: 'danger',
        duration: 4e3,
        titleStyle: {
          color: 'white',
          fontSize: 16,
          fontFamily: fonts.heavy,
        },
        style: {
          backgroundColor: 'red',
        },
      });
    }
  };

  return (
    <SafeAreaScreen>
      <Heading large style={styles.title}>
        {!VALIDATE_PASSWORD_REGEXP.test(passcode)
          ? 'Let’s secure\nyour account.'
          : 'Please confirm\nyour password.'}
      </Heading>
      <Text muted>Choose a password for accessing Hana.</Text>

      <TextInput
        ref={passcodeInput}
        value={passcode}
        onChangeText={(text) => {
          if (errors.passcode) setErrors({ passcode: null });
          setPasscode(text);
          if (text.length == 6) {
            setChangeState(true);
          }
        }}
        onSubmitEditing={() => confirmPasscodeInput.current?.focus()}
        autoFocus
        blurOnSubmit={false}
        style={{ marginTop: 20 }}
        onFocus={() => {
          LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          setIsFocus(true);
        }}
        onBlur={() => {
          LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          setIsFocus(false);
        }}
        label="Enter a password"
        secureTextEntry
      />

      <TextInput
        ref={confirmPasscodeInput}
        value={confirmPasscode}
        onChangeText={(text) => {
          setConfirmPasscode(text);
          if (errors.passcode) {
            setErrors(({ passcode }) => ({ passcode, confirmPasscode: null }));
          }
        }}
        editable={!isWorking}
        autoFocus
        style={{ marginTop: 16 }}
        blurOnSubmit={false}
        onFocus={() => {
          LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          setIsFocus(true);
        }}
        onBlur={() => {
          LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          setIsFocus(false);
        }}
        onSubmitEditing={handleContinue}
        label="Confirm your password"
        secureTextEntry
      />

      {errors.passcode && (
        <Text error center style={{ marginTop: 20 }}>
          {errors.passcode}
        </Text>
      )}

      <Button hasNextIcon
        variant={ButtonVariant.Primary}
        style={{ width: '100%', marginVertical: 20 }}
        onPress={handleContinue}
        working={isWorking}
      >
        Continue
      </Button>
    </SafeAreaScreen>
  );
};

const styles = StyleSheet.create({
  title: {
    marginBottom: 10,
  },
});

export { CreatePasscodeScreen };
