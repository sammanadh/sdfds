import { Button } from '@/components/Button';
import { OnboardingStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { HIT_SLOP_SMALL } from '@/utils/constants';
import { colors, fonts } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import { wait } from '@/utils/wait';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as Haptics from 'expo-haptics';
import { isEmpty, shuffle } from 'lodash-es';
import ordinal from 'ordinal';
import { useState } from 'react';
import { Dimensions, StyleSheet, TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<OnboardingStackParams, 'ConfirmSeedPhrase'>,
  StackNavigationProp<RootStackParams>
>;
type RouteProps = RouteProp<OnboardingStackParams, 'ConfirmSeedPhrase'>;

const WORD_WIDTH = Dimensions.get('screen').width / 2 - 30;

interface FormErrors {
  confirmSeedPhrase?: string | null;
}

type SelectedWord = {
  word: string;
  index: number;
};

export function ConfirmSeedPhraseScreen() {
  const { isDarkMode } = useTheme();

  const { navigate } = useNavigation<NavigationProps>();
  const {
    params: { seedPhrase },
  } = useRoute<RouteProps>();
  const { confirmVault } = useVault();
  const [availableWords, setAvailableWords] = useState<Array<string>>(
    shuffle((seedPhrase || '').split(' '))
  );
  const [selectedWords, setSelectedWords] = useState<Array<SelectedWord>>([]);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isWorking, setIsWorking] = useState(false);

  const findIndexWordSelected = (word: string, index: number) => {
    return selectedWords.findIndex(
      (wordSelected) => wordSelected.word === word && wordSelected.index === index
    );
  };

  async function handleContinue() {
    if (isWorking) return;
    const mapSelectedWords = selectedWords.map((item) => item.word);
    if (!validate(mapSelectedWords)) {
      return Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }

    setIsWorking(true);
    await wait(); // ensure loading UI shows

    try {
      await confirmVault(seedPhrase);
      navigate('ConfigureChains');
    } catch (error: any) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      console.warn('Failed confirming Vault.', error.message);
    } finally {
      setIsWorking(false);
    }
  }

  function validate(selectedWords: Array<string>) {
    const errors: FormErrors = {};
    let valid = false;

    if (isEmpty(selectedWords)) {
      errors.confirmSeedPhrase = 'Please confirm the seed phrase';
    } else if (selectedWords.join(' ') !== seedPhrase) {
      errors.confirmSeedPhrase = 'You have entered the seed phrase incorrectly';
    }

    if (!errors.confirmSeedPhrase) {
      valid = true;
    }

    setErrors(errors);
    return valid;
  }

  function handleAddWord(word: string, index: number) {
    // setAvailableWords((availableWords) => {
    //   const wordIndex = availableWords.findIndex((availableWord) => availableWord === word);
    //   return [...availableWords.slice(0, wordIndex), ...availableWords.slice(wordIndex + 1)];
    // });
    setSelectedWords((selectedWords) => [...selectedWords, { word, index }]);
  }

  function handleRemoveWord(word: string, index: number) {
    setSelectedWords((selectedWords) => {
      const wordIndex = findIndexWordSelected(word, index);
      return [...selectedWords.slice(0, wordIndex), ...selectedWords.slice(wordIndex + 1)];
    });
    // setAvailableWords((availableWords) => [...availableWords, word]);
  }

  const styleItemDarkMode = (isSelected: boolean) => {
    if (isDarkMode) {
      if (isSelected) {
        return {
          backgroundColor: colors.purple.darkBlack,
          borderColor: colors.offPurple,
          borderWidth: 0,
        };
      }
      return {
        backgroundColor: colors.purple.darkBlacker,
      };
    }
    return {};
  };

  return (
    <>
      <SafeAreaScreen>
        <ScrollViewScreen>
          <Heading large>{'Confirm\nseed phrase.'}</Heading>
          <Text muted style={styles.content}>
            Click the words below in the correct order
          </Text>

          <Text style={[styles.suggest, isDarkMode && { color: colors.offPurple }]}>
            {selectedWords.length < availableWords.length
              ? `Tap the ${ordinal(selectedWords.length + 1)} word`
              : 'All words selected'}
          </Text>

          <View style={styles.wordsList}>
            {availableWords.map((word, index) => {
              const indexSelected = findIndexWordSelected(word, index);
              const isSelected = indexSelected !== -1;
              return (
                <TouchableOpacity
                  key={`${index}-${word}`}
                  onPress={() => {
                    if (errors.confirmSeedPhrase) setErrors({ confirmSeedPhrase: null });
                    if (isSelected) {
                      handleRemoveWord(word, index);
                    } else {
                      handleAddWord(word, index);
                    }
                  }}
                  style={[
                    isSelected ? styles.wordContainerSelected : styles.wordContainer,
                    styleItemDarkMode(isSelected),
                  ]}
                  hitSlop={HIT_SLOP_SMALL}
                >
                  {isSelected ? (
                    <View
                      style={[
                        styles.containerNumber,
                        isDarkMode && { backgroundColor: colors.purple.darkBlacker },
                      ]}
                    >
                      <Text bold style={isDarkMode ? { color: colors.whiteSecond } : {}}>
                        {indexSelected + 1}
                      </Text>
                    </View>
                  ) : null}
                  <Text
                    bold
                    style={[
                      styles.word,
                      isSelected && { color: colors.black },
                      isDarkMode && { color: colors.whiteSecond },
                    ]}
                  >
                    {word}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </ScrollViewScreen>

        <Button
          onPress={handleContinue}
          working={isWorking}
          hasNextIcon
          disabled={selectedWords.length < 12}
        >
          Continue
        </Button>
        {errors.confirmSeedPhrase && (
          <Text small error center style={[isDarkMode && { color: colors.negative }]}>
            {errors.confirmSeedPhrase}
          </Text>
        )}
      </SafeAreaScreen>
    </>
  );
}

const styles = StyleSheet.create({
  wordsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  wordContainer: {
    backgroundColor: colors.white,
    borderColor: colors.offPurple,
    borderWidth: 2,
    width: WORD_WIDTH,
    height: 46,
    borderRadius: 24,
    paddingHorizontal: 8,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  wordContainerSelected: {
    flexDirection: 'row',
    alignItems: 'center',
    width: WORD_WIDTH,
    height: 46,
    backgroundColor: colors.gray.cards,
    borderRadius: 24,
    overflow: 'hidden',
    paddingHorizontal: 8,
    marginBottom: 10,
  },
  word: {
    lineHeight: 19,
    color: colors.primary,
    marginLeft: 8,
  },
  containerNumber: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    marginTop: 10,
  },
  suggest: {
    color: colors.primary,
    lineHeight: 18,
    fontFamily: fonts.heavy,
    marginTop: formatPixel(25, 'wHeight'),
    marginBottom: formatPixel(18, 'wHeight'),
  },
});
