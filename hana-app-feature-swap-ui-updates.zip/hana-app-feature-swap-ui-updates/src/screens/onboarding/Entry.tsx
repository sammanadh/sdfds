import { Button } from '@/components/Button';
import { ColorSchemeSwitch } from '@/components/ColorSchemeSwitch';
import { OnboardingStackParams, RootStackParams } from '@/components/Navigation';
import { useSafeAreaHeading } from '@/components/Navigation/utils';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { TextButton } from '@/components/TextButton';
import { Heading } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { JOURNEY } from '@/utils/constants';
import { fonts } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import { common } from '@/utils/styles';
import { CompositeNavigationProp, useFocusEffect, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as NavigationBar from 'expo-navigation-bar';
import { useCallback, useEffect } from 'react';
import { Dimensions, Image, Platform, StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<OnboardingStackParams, 'Entry'>,
  StackNavigationProp<RootStackParams>
>;

const dimensions = Dimensions.get('window');

const image = require('@/assets/illustrations/frame.png');

export function EntryScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const { isDarkMode, colors } = useTheme();

  function handleCreate() {
    navigate('CreatePasscode', { journey: JOURNEY.CREATE_SEED_PHRASE });
  }

  function handleImport() {
    navigate('ImportSeedPhrase');
  }

  useEffect(() => {
    if (Platform.OS !== 'android') return;
    NavigationBar.setBackgroundColorAsync(isDarkMode ? colors.background : colors.offPurple);
    NavigationBar.setButtonStyleAsync(isDarkMode ? 'light' : 'dark');
  }, [isDarkMode]);

  useFocusEffect(
    useCallback(() => {
      if (Platform.OS !== 'android') return;
      NavigationBar.setBackgroundColorAsync(isDarkMode ? colors.background : colors.offPurple);
    }, [isDarkMode])
  );

  return (
    <SafeAreaScreen top padTop={false}>
      <View style={[styles.toggle, { top: useSafeAreaHeading() + 20 }]}>
        <ColorSchemeSwitch />
      </View>
      <View style={common.fill}>
        <Image source={image} style={styles.imageStyle} resizeMode="contain" />
        <Heading large style={styles.title}>
          Multi-chain crypto made simple...
        </Heading>
      </View>

      <Button onPress={handleCreate}>Create account</Button>
      <TextButton
        center
        onPress={handleImport}
        style={{ marginTop: 15 }}
        textStyle={[styles.textButton, { color: colors.foreground }]}
      >
        Import seed phrase
      </TextButton>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  title: {
    fontSize: dimensions.height > 700 ? formatPixel(34) : formatPixel(26),
    lineHeight: dimensions.height > 700 ? formatPixel(42) : formatPixel(34),
    bottom: dimensions.height > 700 ? 40 : 55,
  },
  textButton: {
    fontFamily: fonts.heavy,
    lineHeight: 22,
  },
  imageStyle: {
    maxWidth: dimensions.width,
    maxHeight: formatPixel(500, 'wWidth'),
    bottom: 60,
    left: -20,
    flexShrink: 1,
  },
  toggle: {
    position: 'absolute',
    zIndex: 1,
  },
});
