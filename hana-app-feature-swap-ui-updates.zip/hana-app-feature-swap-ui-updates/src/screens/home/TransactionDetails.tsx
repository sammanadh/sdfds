import { IconCloneGray, IconExternalLink } from '@/assets/icons';
import DownArrowIcon from '@/assets/icons/down-arrow-black.svg';
import DownArrowGrayIcon from '@/assets/icons/down-arrow-gray.svg';
import UpArrowIcon from '@/assets/icons/up-arrow-black.svg';
import UpArrowGrayIcon from '@/assets/icons/up-arrow-gray.svg';
import { Button } from '@/components/Button';
import { CollectableImage } from '@/components/Collectables/CollectableImage';
import { Footer } from '@/components/Footer';
import { SelectGasPriceModal } from '@/components/Modals/SelectGasPriceModal';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { SelectGasPrice } from '@/components/SelectGasPrice';
import { TextInput } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { TokenLogo } from '@/components/TokenLogo';
import { AltHeading, Heading, Text } from '@/components/Typography';
import { GasPriceOption } from '@/models/GasPriceOption';
import { TransactionType } from '@/models/Transaction';
import { WalletType } from '@/models/Vault';
import { EthereumService } from '@/services/chainServices/EthereumService';
import { serviceForChainWallet } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { usePrices } from '@/stores/Price';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { BigNumber } from '@/utils/bignumber';
import { chainForChainWallet, getTransactionUrlPath } from '@/utils/chains';
import { ICX_GOVERNANCE_ADDRESS } from '@/utils/constants';
import { HIT_SLOP_XLARGE, ZERO } from '@/utils/constants';
import { findContactOrWallet } from '@/utils/contacts';
import { convertAndFormatCurrency, formatAmount } from '@/utils/format';
import { dismissModal, presentModal } from '@/utils/modal';
import Clipboard from '@react-native-clipboard/clipboard';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { format, formatDistanceToNowStrict } from 'date-fns';
import * as WebBrowser from 'expo-web-browser';
import { isNil, isUndefined } from 'lodash-es';
import React, { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import { Animated, LayoutChangeEvent, StyleSheet, TouchableOpacity, View } from 'react-native';
import Web3 from 'web3';

const COLLAPSE_DURATION = 300;
const MAX_COLLAPSED_HEIGHT = 90;

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'TransactionDetails'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'TransactionDetails'>;

export function TransactionDetails() {
  const {
    params: { transaction },
  } = useRoute<RouteProps>();

  const { goBack } = useNavigation<NavigationProps>();

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();
  const { getNativePrice, getTokenPrice } = usePrices();
  const { chainWallet, token } = transaction;

  const service = chainWallet ? serviceForChainWallet(chainWallet) : undefined;
  const network = service?.getNetworkDetails();

  const [gettingGasPrices, setGettingGasPrices] = useState(false);
  const [gasPriceOptions, setGasPriceOptions] = useState<GasPriceOption[]>([
    { label: 'Recommended', price: null, estimatedWait: null },
  ]);
  const [selectedGasPrice, setSelectedGasPrice] = useState<GasPriceOption>(gasPriceOptions[0]);
  const [gasPrice, setGasPrice] = useState(selectedGasPrice.price?.toString() ?? '');
  const [isSending, setIsSending] = React.useState(false);

  const [txDataCollapsed, setTxDataCollapsed] = useState(true);
  const [txDataMaxHeight, setTxDataMaxHeight] = useState<number | null>(null);

  const [collapseAnim] = useState(new Animated.Value(MAX_COLLAPSED_HEIGHT));

  const chain = useMemo(() => {
    return chainWallet ? chainForChainWallet(chainWallet) : undefined;
  }, [chainWallet]);

  const canSetGasPrice = useMemo(
    () =>
      transaction.isPending &&
      !isNil(transaction.rawTx) &&
      chain?.canSetGasPrice === true &&
      transaction.from === chainWallet?.address,
    [chain]
  );

  const usdPrice = useMemo(() => {
    if (
      chain &&
      (transaction.type === TransactionType.SendNativeToken ||
        transaction.type === TransactionType.IScoreClaim)
    ) {
      return getNativePrice(chain);
    }

    if (token?.contract && transaction.type === TransactionType.SendToken) {
      return getTokenPrice(token.contract);
    }

    return null;
  }, [transaction, chain, token]);

  const fromContact = useMemo(() => {
    if (transaction && transaction.from && chain) {
      return findContactOrWallet(transaction.from, chain.id);
    }

    return null;
  }, [transaction]);

  const fromName = useMemo(() => {
    if (transaction.type === TransactionType.IScoreClaim) {
      return 'ICON Governance';
    }

    if (fromContact) {
      return fromContact.name;
    }

    return undefined;
  }, [fromContact, transaction]);

  const fromAddress = useMemo(() => {
    if (transaction.type === TransactionType.IScoreClaim) {
      return ICX_GOVERNANCE_ADDRESS;
    }

    if (fromContact) {
      return fromContact.address;
    }

    return undefined;
  }, [fromContact, transaction]);

  const toContact = useMemo(() => {
    if (transaction && transaction.to && chain) {
      return findContactOrWallet(transaction.to, chain.id);
    }

    return null;
  }, [transaction]);

  const toName = useMemo(() => {
    if (
      transaction.type === TransactionType.IScoreClaim &&
      !isNil(transaction.chainWallet) &&
      !isNil(chain)
    ) {
      return findContactOrWallet(transaction.chainWallet?.address, chain.id).name;
    }

    if (toContact) {
      return toContact.name;
    }

    return undefined;
  }, [toContact, transaction, chain]);

  const toAddress = useMemo(() => {
    if (
      transaction.type === TransactionType.IScoreClaim &&
      !isNil(transaction.chainWallet) &&
      !isNil(chain)
    ) {
      return findContactOrWallet(transaction.chainWallet?.address, chain.id).address;
    }

    if (toContact) {
      return toContact.address;
    }

    return undefined;
  }, [toContact, transaction, chain]);

  const navigation = useNavigation<NavigationProps>();

  const { isDarkMode, colors, styles: themeStyles } = useTheme();

  const { setToastMessage } = useNavigationStore();

  function openBrowser() {
    if (!isNil(service?.getNetworkDetails().blockExplorerUrl) && network?.chainType) {
      const url =
        transaction.transactionUrl ||
        `${service?.getNetworkDetails().blockExplorerUrl}${getTransactionUrlPath(
          network.chainType
        )}/${transaction.hash}`;

      WebBrowser.openBrowserAsync(url);
    }
  }

  function handleChangeGasPrice(value: string) {
    const stepPrice = new BigNumber(value);
    if (!stepPrice.isPositive()) return ZERO;
    setGasPrice(stepPrice.integerValue().toString());
  }

  function handleSelectGasPrice(option: GasPriceOption) {
    setSelectedGasPrice(option);
    if (!isNil(option.price)) {
      setGasPrice(option.price.toFixed(0).toString());
    }
  }

  useEffect(() => {
    if (!canSetGasPrice) return;
    if (!transaction.gasPrice) return;

    setGettingGasPrices(true);
    (service as EthereumService)
      .getGasPrices()
      .then((gasPriceOptions) => {
        console.debug('gasPriceOptions', gasPriceOptions);

        let options: Array<GasPriceOption> = [
          {
            label: 'Current',
            price: new BigNumber(Web3.utils.fromWei(transaction.gasPrice!.toString(), 'gwei')),
            estimatedWait: null,
          },
          {
            label: 'Minimum',
            price: new BigNumber(Web3.utils.fromWei(gasPriceOptions.low.toString(), 'gwei')),
            estimatedWait: gasPriceOptions.lowWait,
          },
          {
            label: 'Recommended',
            price: new BigNumber(Web3.utils.fromWei(gasPriceOptions.standard.toString(), 'gwei')),
            estimatedWait: gasPriceOptions.standardWait,
          },
          {
            label: 'Priority',
            price: new BigNumber(Web3.utils.fromWei(gasPriceOptions.high.toString(), 'gwei')),
            estimatedWait: gasPriceOptions.highWait,
          },
          { label: 'Advanced', price: null, estimatedWait: null },
        ];
        setGasPriceOptions(options);
        handleSelectGasPrice(options[1]);
      })
      .catch((error) => console.warn('Failed getting gas prices.', error.message))
      .finally(() => setGettingGasPrices(false));
  }, [service, chain, transaction]);

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          hitSlop={HIT_SLOP_XLARGE}
          style={{
            marginRight: 24,
          }}
          onPress={openBrowser}
        >
          <IconExternalLink width={24} height={24} color={isDarkMode ? 'white' : 'black'} />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  useLayoutEffect(() => {
    if (!txDataMaxHeight) return;

    const config = {
      toValue: txDataCollapsed ? MAX_COLLAPSED_HEIGHT : txDataMaxHeight,
      duration: COLLAPSE_DURATION,
      useNativeDriver: false,
    };

    Animated.timing(collapseAnim, config).stop();
    Animated.timing(collapseAnim, config).start();
  }, [txDataCollapsed]);

  function getTxDataLayout(event: LayoutChangeEvent) {
    if (txDataMaxHeight == null) {
      setTxDataMaxHeight(event.nativeEvent.layout.height);
    }
  }

  function handleCopyTransactionHashToClipboard() {
    Clipboard.setString(transaction.hash);
    setToastMessage('Transaction hash copied', ToastType.info);
  }

  function handleCopyToAddressToClipboard() {
    if (toContact) {
      Clipboard.setString(toContact.address);
      setToastMessage('To address copied', ToastType.info);
    }
  }

  async function handleReSend() {
    if (!activeWallet || !service || !chainWallet) return;
    if (isSending) return;

    if (activeWallet.type === WalletType.Ledger) {
      // TODO: add Ledger support
      setToastMessage(`Can't update gas price for Ledger`, ToastType.error);
      return;
    }

    let parsedGasPrice = new BigNumber(gasPrice);
    if (!parsedGasPrice.isPositive()) {
      setToastMessage(`Please enter a valid gas price`, ToastType.error);
      return;
    }

    setIsSending(true);
    try {
      const transactionToSend = {
        method: 'eth_sendTransaction',
        params: [
          {
            ...transaction.rawTx,
            maxFeePerGas: Web3.utils.toHex(Web3.utils.toWei(parsedGasPrice.toString(), 'gwei')),
            maxPriorityFeePerGas: '',
          },
        ],
      };

      await service.rpcTransaction(chainWallet, transactionToSend);
      setToastMessage('Transaction has been sent', ToastType.info);
      goBack();
    } catch (error: any) {
      const errorMessage = 'Failed re-sending: ' + error.message;
      console.warn(errorMessage + '.', error.message);
      setToastMessage(errorMessage, ToastType.error);
      setIsSending(false);
    }
  }

  const amountSymbol = useMemo(
    () => transaction.tokenSymbol ?? network?.token?.symbol ?? chain?.token.symbol,
    [transaction]
  );

  return (
    <>
      <ScrollViewScreen
        style={{ backgroundColor: isDarkMode ? colors.purple.darkBlacker : colors.white }}
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps={'always'}
        showsVerticalScrollIndicator={false}
      >
        <Heading>Transaction</Heading>
        <View style={styles.addressContainer}>
          <Text muted style={{ flex: 1 }}>
            {transaction.hash}
          </Text>
          <TouchableOpacity
            hitSlop={HIT_SLOP_XLARGE}
            onPress={handleCopyTransactionHashToClipboard}
            style={{ marginLeft: 8 }}
          >
            <IconCloneGray width={16} height={16} color={isDarkMode ? 'white' : 'black'} />
          </TouchableOpacity>
        </View>

        {transaction.type === TransactionType.CollectableTransfer && (
          <>
            <View style={styles.item}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <View>
                  <AltHeading>NFT</AltHeading>
                  <Text large bold style={{ marginTop: 10 }}>
                    {transaction.title}
                  </Text>
                </View>

                <CollectableImage url={transaction.imageUrl} size={46} forceImage showChainLogo />
              </View>
            </View>

            <View style={[styles.separator, { backgroundColor: colors.divider }]} />
          </>
        )}

        <View style={[styles.item, { marginTop: 24 }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <View>
              <AltHeading>Chain</AltHeading>
              <Text large bold style={{ marginTop: 10 }}>
                {chain?.name}
              </Text>
            </View>
            <TokenLogo chain={chain} token={token || transaction.token} />
          </View>
        </View>

        <View style={[styles.separator, { backgroundColor: colors.divider }]} />

        {!isUndefined(fromAddress) && (
          <View style={styles.item}>
            <AltHeading style={{ marginBottom: 10 }}>From</AltHeading>
            {fromName && (
              <Text large bold style={{ marginBottom: 6 }}>
                {fromName}
              </Text>
            )}
            <Text small muted>
              {fromAddress}
            </Text>
          </View>
        )}

        <View style={[styles.separator, { backgroundColor: colors.divider }]} />

        {!isUndefined(toAddress) && (
          <>
            <View style={styles.item}>
              <AltHeading style={{ marginBottom: 10 }}>To</AltHeading>
              {/* Show contact name if available */}
              {toName && (
                <Text large bold style={{ marginBottom: 6 }}>
                  {toName}
                </Text>
              )}
              <View style={{ flexDirection: 'row' }}>
                <Text small muted style={{ flex: 1 }}>
                  {toAddress}
                </Text>
                <TouchableOpacity
                  hitSlop={HIT_SLOP_XLARGE}
                  onPress={handleCopyToAddressToClipboard}
                  style={{ marginLeft: 8 }}
                >
                  <IconCloneGray width={16} height={16} />
                </TouchableOpacity>
              </View>
            </View>

            <View style={[styles.separator, { backgroundColor: colors.divider }]} />
          </>
        )}

        {transaction.amount.gt(ZERO) && (
          <View style={styles.item}>
            <AltHeading>Amount</AltHeading>

            <Text large bold style={{ marginTop: 10 }}>
              {formatAmount(transaction.amount)}{' '}
              {transaction.type !== TransactionType.CollectableTransfer ? amountSymbol : ''}
            </Text>

            {!isNil(usdPrice) && (
              <Text small muted style={{ marginTop: 6 }}>
                {convertAndFormatCurrency(transaction.amount, usdPrice)}
              </Text>
            )}
          </View>
        )}

        <View style={[styles.separator, { backgroundColor: colors.divider }]} />

        {canSetGasPrice && (
          <>
            <View style={styles.item}>
              <AltHeading style={{ marginBottom: 10 }}>Gas Price</AltHeading>

              <SelectGasPrice
                value={selectedGasPrice}
                onPress={() => {
                  presentModal({
                    title: 'Choose gas price',
                    content: (
                      <SelectGasPriceModal
                        options={gasPriceOptions}
                        selectedOption={selectedGasPrice}
                        onSelectedOption={(option) => {
                          setSelectedGasPrice(option);
                          dismissModal();
                        }}
                      />
                    ),
                  });
                }}
                disabled={gettingGasPrices}
              />

              {selectedGasPrice.label === 'Advanced' && (
                <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 14 }}>
                  <TextInput
                    value={gasPrice}
                    onChangeText={handleChangeGasPrice}
                    key={'step-price'}
                    isDarkMode={isDarkMode}
                    styleInputContainer={{
                      width: 100,
                      height: 44,
                    }}
                    inputStyle={{
                      height: '100%',
                    }}
                    editable={true}
                  />

                  <Text small muted style={{ marginLeft: 8 }}>
                    GWEI
                  </Text>
                </View>
              )}
            </View>

            <View style={[styles.separator, { backgroundColor: colors.divider }]} />
          </>
        )}

        {!isNil(transaction.fee) && (
          <>
            <View style={styles.item}>
              <AltHeading>Transaction Fee</AltHeading>

              <Text large bold style={{ marginTop: 10 }}>
                {formatAmount(transaction.fee)} {chain?.token.symbol}
              </Text>

              {!isNil(usdPrice) && (
                <Text small muted style={{ marginTop: 6 }}>
                  {convertAndFormatCurrency(transaction.fee, usdPrice)}
                </Text>
              )}
            </View>

            <View style={[styles.separator, { backgroundColor: colors.divider }]} />
          </>
        )}

        {!isNil(transaction.rawTx?.data) && (
          <>
            <View style={styles.item}>
              <AltHeading style={{ marginBottom: 10 }}>Tx Data</AltHeading>
              <TouchableOpacity
                onPress={() => setTxDataCollapsed((collapsed) => !collapsed)}
                style={{ flexDirection: 'row', alignItems: 'center' }}
              >
                <Text
                  style={[{ marginRight: 10 }, isDarkMode && { color: colors.gray.altHeading }]}
                >
                  {txDataCollapsed ? 'Expand' : 'Collapse'}
                </Text>
                {txDataCollapsed ? (
                  isDarkMode ? (
                    <DownArrowGrayIcon style={{ marginTop: 3 }} />
                  ) : (
                    <DownArrowIcon style={{ marginTop: 3 }} />
                  )
                ) : isDarkMode ? (
                  <UpArrowGrayIcon style={{ marginTop: 3 }} />
                ) : (
                  <UpArrowIcon style={{ marginTop: 3 }} />
                )}
              </TouchableOpacity>
            </View>
            <View style={[styles.dataContainer, styles.headingGap, themeStyles.cards]}>
              <Animated.View
                style={[!isNil(txDataMaxHeight) && { height: collapseAnim, overflow: 'hidden' }]}
              >
                <Text onLayout={getTxDataLayout}>
                  {JSON.stringify(transaction.rawTx.data, null, 4)}
                </Text>
              </Animated.View>
            </View>

            <View
              style={[
                styles.separator,
                isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
              ]}
            />
          </>
        )}

        <View style={styles.item}>
          <AltHeading>Status</AltHeading>
          <Text large bold style={{ marginTop: 10 }}>
            {transaction.isPending ? 'Pending' : transaction.isFailed ? 'Failed' : 'Success'}
          </Text>
        </View>

        <View
          style={[
            styles.separator,
            isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
          ]}
        />

        <View style={styles.item}>
          <AltHeading>Date</AltHeading>
          <Text large bold style={{ marginTop: 10 }}>
            {format(transaction.date, 'PPpp')}
          </Text>
          <Text small muted style={{ marginTop: 6 }}>
            {formatDistanceToNowStrict(transaction.date, { addSuffix: true })}
          </Text>
        </View>
      </ScrollViewScreen>

      {canSetGasPrice && (
        <Footer>
          <Button
            working={isSending}
            style={{ marginTop: 30 }}
            onPress={handleReSend}
            disabled={selectedGasPrice.label === 'Current' || isSending}
          >
            Re-send
          </Button>
        </Footer>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    paddingTop: 30,
  },
  addressContainer: {
    flexDirection: 'row',
    marginTop: 10,
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    marginHorizontal: 0,
  },
  item: {
    paddingVertical: 16,
  },
  dataContainer: {
    padding: 16,
  },
  headingGap: {
    marginTop: 10,
  },
});
