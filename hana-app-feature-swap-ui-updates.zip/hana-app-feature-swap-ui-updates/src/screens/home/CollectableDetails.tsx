import { Button, ButtonVariant } from '@/components/Button';
import { CollectableImage } from '@/components/Collectables/CollectableImage';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { TokenLogo } from '@/components/TokenLogo';
import { Text } from '@/components/Typography';
import { getCollectable, useCollectables } from '@/stores/Collectables';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainID, ChainID } from '@/utils/chains';
import { colors, fonts } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import { common } from '@/utils/styles';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty } from 'lodash-es';
import React, { useEffect, useMemo } from 'react';
import { Dimensions, StyleSheet, View } from 'react-native';

const { width } = Dimensions.get('window');

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'CollectableDetails'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'CollectableDetails'>;

export function CollectableDetailsScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const route = useRoute<RouteProps>();
  const { isDarkMode } = useTheme();

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  const { collectable: _collectable, collection } = route.params;
  const type = collection.chain.type;
  const chain = chainForChainID(type as ChainID);

  const chainWallet = activeWallet?.chainWallets.find((cw) => cw.type === collection.chain.type);

  const { loadCollectable, collectables } = useCollectables();

  const collectable = useMemo(
    () => getCollectable(collection, _collectable.tokenId),
    [collectables]
  );

  const hasDescription = useMemo(
    () => collectable && !isEmpty(collectable.description),
    [collectable]
  );
  const hasAttributes = useMemo(
    () => collectable && !isEmpty(collectable.attributes),
    [collectable]
  );

  //effect
  useEffect(() => {
    activeWallet &&
      loadCollectable(
        collection.chain.type,
        activeWallet,
        collection.contract,
        _collectable.tokenId
      );
  }, [activeWallet, _collectable]);

  //render
  return (
    <View style={[common.fill]}>
      <ScrollViewScreen
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollViewContainer}
      >
        {collectable && (
          <>
            <View style={styles.imgContainer}>
              <CollectableImage
                route={route?.name}
                url={collectable?.imageUrl ?? ''}
                size={width - 32}
                style={styles.img}
              />
              <Text
                style={{
                  fontFamily: fonts.heavy,
                  fontSize: formatPixel(26),
                  lineHeight: formatPixel(35),
                  color: colors.whiteSecond,
                  position: 'absolute',
                  bottom: formatPixel(13),
                  left: formatPixel(13),
                }}
              >
                {collectable?.name ?? ''}
              </Text>
            </View>
            <Button
              onPress={() => {
                chainWallet &&
                  navigate('Send', {
                    wallet: chainWallet,
                    collection,
                    collectable,
                  });
              }}
              variant={ButtonVariant.Purple}
            >
              Send
            </Button>
            {hasDescription && (
              <>
                <View style={styles.descriptionContainer}>
                  <Text
                    style={[
                      styles.description,
                      { color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlacker },
                    ]}
                  >
                    {collectable?.description ?? ''}
                  </Text>
                </View>
              </>
            )}
            <View>
              <Text style={styles.header}>Chain</Text>
              <View style={{ marginTop: 10 }}>
                <TokenLogo chain={chain} size={40} />
              </View>
            </View>
            {hasAttributes && (
              <>
                <Text style={styles.header}>Attributes</Text>
                <View style={{ height: formatPixel(20) }} />
                {collectable?.attributes!.map((item, index: number) => (
                  <>
                    <View key={item.trait_type} style={styles.propertyContainer}>
                      <Text
                        bold
                        muted
                        style={{
                          fontSize: formatPixel(13),

                          textTransform: 'uppercase',
                        }}
                      >
                        {item?.trait_type ?? ''}
                      </Text>
                      <Text bold style={{ fontSize: formatPixel(18) }}>
                        {item?.value ?? ''}
                      </Text>
                    </View>
                    {index !== collectable?.attributes!?.length - 1 && (
                      <View
                        style={[
                          styles.line,
                          {
                            marginBottom: undefined,
                            borderColor: isDarkMode
                              ? colors.gray.breakLineDarkMode
                              : colors.gray.cards,
                          },
                        ]}
                      />
                    )}
                  </>
                ))}
              </>
            )}
          </>
        )}
      </ScrollViewScreen>
    </View>
  );
}

const styles = StyleSheet.create({
  scrollViewContainer: {
    paddingTop: 0,
  },
  imgContainer: {
    width: '100%',
    height: width - 40,
    overflow: 'hidden',
    marginBottom: formatPixel(20),
    marginTop: formatPixel(20),
  },
  img: {
    backgroundColor: colors.gray.meta,
  },
  descriptionContainer: {
    width: '100%',
    marginTop: formatPixel(30),
    marginBottom: formatPixel(20),
  },
  description: {
    fontSize: formatPixel(16),
  },
  line: {
    width: '100%',
    borderWidth: 1,
  },
  header: {
    fontFamily: fonts.heavy,
    fontSize: formatPixel(16),
    marginTop: formatPixel(30),
  },
  propertyContainer: {
    width: '100%',
    height: formatPixel(80),
    justifyContent: 'space-evenly',
  },
});
