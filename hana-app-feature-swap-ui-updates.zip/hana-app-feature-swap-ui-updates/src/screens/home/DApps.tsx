import DAppsList from '@/components/DAppsList';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React from 'react';
import { FlatList, StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'Home'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'DApps'>;

const DApps = () => {
  const {
    params: { dAppsData },
  } = useRoute<RouteProps>();
  const { navigate } = useNavigation<NavigationProps>();
  const { isDarkMode } = useTheme();

  function handleOpenBrowser(url: string) {
    navigate('Browser', { url });
  }

  return (
    <SafeAreaScreen bottom={false}>
      <FlatList
        data={dAppsData}
        keyExtractor={(item) => item.url}
        renderItem={({ item }) => <DAppsList item={item} onPress={handleOpenBrowser} />}
        ItemSeparatorComponent={() => (
          <View
            style={[
              styles.separator,
              isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
            ]}
          />
        )}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaScreen>
  );
};

export default DApps;

const styles = StyleSheet.create({
  separator: {
    width: '100%',
    height: 1,
    backgroundColor: colors.gray.cards,
  },
});
