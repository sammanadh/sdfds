import { Button } from '@/components/Button';
import Loading from '@/components/Loading';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { IconStakingDetails } from '@/components/TokenDetails/IconStakingDetails';
import { TokenLogo } from '@/components/TokenLogo';
import { TransactionItem } from '@/components/TransactionItem';
import { Heading, Text } from '@/components/Typography';
import { TransactionType } from '@/models/Transaction';
import { useTokens } from '@/hooks/useTokens';
import { Token } from '@/models/Vault';
import { serviceForChainWallet, useChainServices } from '@/stores/ChainServices';
import { usePendingTransactions } from '@/stores/PendingTransactions';
import { usePrices } from '@/stores/Price';
import { useTheme } from '@/stores/Theme';
import { useTransactions } from '@/stores/Transactions';
import { chains } from '@/utils/chains';
import { CoinType } from '@/utils/coinTypes';
import { ZERO } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { formatNumber, formatPrice } from '@/utils/format';
import { common } from '@/utils/styles';
import { wait } from '@/utils/wait';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isNil } from 'lodash-es';
import React, { useEffect, useMemo, useState } from 'react';
import { Dimensions, FlatList, StyleSheet, View } from 'react-native';

const { height } = Dimensions.get('window');

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'TokenDetails'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'TokenDetails'>;

export function TokenDetails() {
  const {
    params: { wallet, token },
  } = useRoute<RouteProps>();
  const { navigate } = useNavigation<NavigationProps>();

  const { isDarkMode } = useTheme();

  const allTokens = useTokens({ filterByValue: 'contractTokens' });

  const [loading, setLoading] = useState(true);
  const chain = chains?.find((chain) => chain.id === wallet?.type);
  const service = serviceForChainWallet(wallet);
  const network = service?.getNetworkDetails();

  const tokenFromAllTokens = useMemo(() => {
    return allTokens.find((t) => t.contract === token?.contract && t.chainId === token?.chainId);
  }, [allTokens, token]);

  const tokenAsToken = useMemo(() => token as unknown as Token, [token]);
  const balance = useMemo(() => tokenFromAllTokens?.balance || ZERO, [tokenFromAllTokens]);

  const symbol = useMemo(() => {
    return !token.native ? token.symbol : network?.token?.symbol || chain?.token.symbol || '';
  }, [wallet, token, chain]);

  const { servicesUpdatedAt, otherNetwork } = useChainServices();
  const { getNativePrice, getTokenPrice } = usePrices();
  const { refreshTransactions, getTransactions, transactions: _transactions } = useTransactions();

  const { pendingTransactions } = usePendingTransactions();

  const transactions = !isNil(chain) ? getTransactions(chain.id, wallet.address, token) ?? [] : [];

  useEffect(() => {
    if (chain && wallet) {
      refreshTransactions(chain.id, wallet.address);
    }
  }, [wallet, chain, servicesUpdatedAt, otherNetwork, pendingTransactions]);

  useEffect(() => {
    wait(10000).then(() => setLoading(false));
  }, []);

  const price = useMemo(() => {
    if (token.native && chain && chain.coinType) {
      return getNativePrice(chain);
    }

    if (!token.native && token.contract) {
      return getTokenPrice(token.contract);
    }

    return ZERO;
  }, [wallet, token, chain]);

  const usdValue = price.multipliedBy(balance);

  const onSend = () => {
    navigate('Send', { wallet, token });
  };

  const onReceive = () => {
    navigate('Receive', { wallet, token });
  };

  return (
    <SafeAreaScreen>
      <FlatList
        showsVerticalScrollIndicator={false}
        data={transactions}
        renderItem={({ item }) => (
          <TransactionItem
            isDarkMode={isDarkMode}
            key={item.hash}
            transaction={item}
            chainWallet={wallet}
            network={network}
            token={!token.native ? tokenAsToken : undefined}
            onPress={() => {
              if (item.type === TransactionType.TokenSwap) {
                navigate('SwapTransactionDetails', {
                  transaction: item,
                });
              } else {
                navigate('TransactionDetails', {
                  transaction: item,
                });
              }
            }}
          />
        )}
        keyExtractor={(item) => item.hash}
        ListHeaderComponent={
          chain && (
            <>
              <View style={[common.centerContent, { marginBottom: 25 }]}>
                <TokenLogo chain={chain} token={!token.native ? tokenAsToken : undefined} />
                <Heading style={styles.heading}>
                  {formatNumber(balance, 4)} {symbol}
                </Heading>
                {+usdValue ? (
                  <Text muted style={styles.subHeading}>
                    {formatPrice(usdValue, false)}
                  </Text>
                ) : null}
              </View>

              {token.native && chain.coinType === CoinType.ICX && <IconStakingDetails />}

              <View style={styles.buttonsContainer}>
                <Button style={styles.button} onPress={onSend}>{`Send`}</Button>
                <Button style={styles.button} onPress={onReceive}>{`Receive`}</Button>
              </View>

              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />

              <Heading style={styles.transactionsHeading}>Transactions</Heading>
            </>
          )
        }
        ListEmptyComponent={
          loading ? (
            <View style={[{ width: '100%' }]}>
              <Loading height={90} width={'100%'} />
              <View style={{ marginBottom: 15 }} />
              <Loading height={90} width={'100%'} />
              <View style={{ marginBottom: 15 }} />
              <Loading height={90} width={'100%'} />
              <View style={{ marginBottom: 15 }} />
              <Loading height={90} width={'100%'} />
              <View style={{ marginBottom: 15 }} />
              <Loading height={90} width={'100%'} />
              <View style={{ marginBottom: 15 }} />
              <Loading height={90} width={'100%'} />
            </View>
          ) : (
            <View style={{ height: height * 0.3, justifyContent: 'center', alignItems: 'center' }}>
              <Text large style={{ color: 'rgb(115, 107, 136)' }}>
                No transactions found.
              </Text>
            </View>
          )
        }
      />
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    textAlign: 'center',
    marginTop: 20,
  },
  subHeading: {
    textAlign: 'center',
    marginTop: 10,
  },
  container: {
    flexDirection: 'column',
    alignItems: 'center',
  },
  buttonsContainer: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    marginBottom: 30,
  },
  button: {
    width: '48%',
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.gray.border,
    marginHorizontal: 20,
    width: '100%',
  },
  transactionsHeading: {
    fontSize: 16,
    width: '100%',
    marginVertical: 20,
  },
});
