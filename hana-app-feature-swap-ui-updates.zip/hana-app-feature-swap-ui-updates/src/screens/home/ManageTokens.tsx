import { ChainSelect } from '@/components/ChainSelect';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ToastType } from '@/components/Toast.types';
import { Heading } from '@/components/Typography';
import { TokenLogo } from '@/components/TokenLogo';
import { Text } from '@/components/Typography';
import { Switch } from '@/components/Switch';
import { Token } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useVault } from '@/stores/Vault';
import { ChainDetails, ChainID, chainFilter, chains } from '@/utils/chains';
import { isCustomNetwork, isTestnetConfig } from '@/utils/types';
import { tokensForChainWallet } from '@/utils/wallet';
import { HIT_SLOP_LARGE } from '@/utils/constants';
import { CompositeNavigationProp, useIsFocused } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  DefaultSectionT,
  SectionList,
  SectionListData,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import { useTheme } from '@/stores/Theme';
import { card } from '@/utils/styles';
import { colors, fonts } from '@/utils/designTokens';
import CloseBlackIcon from '@/assets/icons/close-black.svg';
import CloseWhiteIcon from '@/assets/icons/close-white.svg';
import { SearchInput } from '@/components/SearchInput';
import { tokenFilter } from '@/utils/token';
import { isEmpty, isNull, isUndefined } from 'lodash-es';

const tokenChains = [
  ChainID.ICON,
  ChainID.Ethereum,
  ChainID.Moonbeam,
  ChainID.Moonriver,
  ChainID.Binance,
  ChainID.Arctic,
  ChainID.HAVAH,
  ChainID.Arbitrum,
  ChainID.Optimism,
  ChainID.Polygon,
  ChainID.Avalanche,
];

const TokenSwitchSeperator = () => {
  return <View style={tokenSwitchStyles.seperator}></View>;
};

export function ManageTokens() {
  const { getActiveWallet } = useVault();
  const { otherNetwork, connectedChains } = useChainServices();
  const { realm } = useVault();
  const { setToastMessage, setHideTabBar } = useNavigationStore();
  const { isDarkMode, styles: themeStyles } = useTheme();

  const [_, setRefresh] = useState(false);

  const isFocused = useIsFocused();

  const activeWallet = getActiveWallet();

  const [selectedChain, setSelectedChain] = useState<ChainID | null>(null);

  const [allContractTokens, setAllContractTokens] = useState<Token[]>([]);

  const [query, setQuery] = useState('');

  const connectedChainIds = useMemo(() => {
    if (isTestnetConfig(otherNetwork)) {
      return [otherNetwork.chainType];
    }

    if (isCustomNetwork(otherNetwork)) {
      return [otherNetwork.chain];
    }

    return connectedChains.map((c) => c.id);
  }, [otherNetwork, connectedChains]);

  useEffect(() => {
    let contractTokens: Token[] = [];
    tokenChains.forEach((chainID) => {
      const isActive = connectedChainIds.includes(chainID);
      const chainWallet = activeWallet?.chainWallets.find((w) => w.type === chainID);

      if (chainWallet && isActive) {
        const tokens = tokensForChainWallet(chainWallet);
        contractTokens.push(...tokens);
      }
    });
    setAllContractTokens(contractTokens);
  }, [tokenChains, connectedChainIds, activeWallet]);

  useEffect(() => {
    if (isFocused) {
      setHideTabBar(false);
    }
  }, [isFocused]);

  const onRemoveToken = (token: Token) => {
    setAllContractTokens(
      allContractTokens.filter((t) => t.contract !== token.contract || t.chainId !== token.chainId)
    );

    setToastMessage(`Removed ${token.name}`, ToastType.info);

    setTimeout(() => {
      realm?.write(() => {
        realm?.delete(token);
      });
    }, 500);
  };

  const tokenSwitchForTokens = useCallback(
    ({ item: token }: { item: Token; index: number }) => {
      const chain = chains.find((chain) => chain.id === token.chainId);
      return (
        <>
          <View
            style={[
              card.base,
              tokenSwitchStyles.container,
              styles.token,
              {
                backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards,
                borderColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards,
              },
            ]}
          >
            {token && (
              <>
                <TokenLogo token={token} chain={chain} />

                <View style={tokenSwitchStyles.details}>
                  <Text
                    style={[
                      tokenSwitchStyles.tokenName,
                      { color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack },
                    ]}
                  >
                    {token.name}
                  </Text>
                  <Text small muted style={tokenSwitchStyles.tokenSymbol}>
                    {token.symbol}
                  </Text>
                </View>
                {token.isCustom ? (
                  <TouchableOpacity
                    style={tokenSwitchStyles.removeButton}
                    hitSlop={HIT_SLOP_LARGE}
                    onPress={() => {
                      onRemoveToken(token);
                    }}
                  >
                    {isDarkMode ? <CloseWhiteIcon /> : <CloseBlackIcon />}
                  </TouchableOpacity>
                ) : (
                  <Switch
                    value={token.isActive}
                    onChange={(enabled) => {
                      realm?.write(() => {
                        token.isActive = enabled;
                        if (typeof setRefresh === 'function') {
                          setRefresh((prev) => !prev);
                        }
                      });
                    }}
                  />
                )}
              </>
            )}
          </View>
          <TokenSwitchSeperator />
        </>
      );
    },
    [
      chains,
      card,
      tokenSwitchStyles,
      styles,
      colors,
      isDarkMode,
      realm,
      setRefresh,
      HIT_SLOP_LARGE,
      onRemoveToken,
    ]
  );

  const tokenSwitchForChains = useCallback(
    ({ item: chainDetails }: { item: ChainDetails; index: number }) => {
      const chainId = chainDetails.id;
      const isActive = connectedChainIds.includes(chainId);
      const chainWallet = activeWallet?.chainWallets.find((w) => w.type === chainId);

      if (chainWallet && isActive) {
        return (
          <>
            <View
              style={[
                card.base,
                tokenSwitchStyles.container,
                styles.token,
                {
                  backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards,
                  borderColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards,
                },
              ]}
            >
              {chainDetails && (
                <>
                  <TokenLogo chain={chainDetails} />
                  <View style={tokenSwitchStyles.details}>
                    <Text
                      style={[
                        tokenSwitchStyles.tokenName,
                        { color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack },
                      ]}
                    >
                      {chainDetails.name}
                    </Text>
                    <Text small muted style={tokenSwitchStyles.tokenSymbol}>
                      {chainDetails.token.symbol}
                    </Text>
                  </View>
                  <Switch value={chainWallet.isActive} onChange={() => {}} disabled={true} />
                </>
              )}
            </View>
            <TokenSwitchSeperator />
          </>
        );
      } else {
        return <></>;
      }
    },
    [chains, card, tokenSwitchStyles, styles, colors, isDarkMode, realm]
  );

  const filteredTokens: Token[] = useMemo(() => {
    if (isEmpty(query)) {
      if (isNull(selectedChain)) {
        return allContractTokens;
      } else {
        return allContractTokens.filter((t) => t.chainId === selectedChain);
      }
    } else {
      if (isNull(selectedChain)) {
        return allContractTokens.filter((token) => tokenFilter(token, query));
      } else {
        return allContractTokens.filter(
          (token) => token.chainId === selectedChain && tokenFilter(token, query)
        );
      }
    }
  }, [allContractTokens, query, selectedChain]);

  const filteredChainDetails: ChainDetails[] = useMemo(() => {
    const chainIds: ChainID[] = !isNull(selectedChain) ? [selectedChain] : tokenChains;

    let chainDetails: ChainDetails[] = [];
    for (let chainId of chainIds) {
      const newChainDetail = chains.find((c) => c.id === chainId);
      if (!isUndefined(newChainDetail)) chainDetails.push(newChainDetail);
    }

    return !isEmpty(query)
      ? chainDetails.filter((chain) => !!chain && chainFilter(chain, query))
      : chainDetails;
  }, [tokenChains, query, selectedChain]);

  const sectionsData: SectionListData<any, DefaultSectionT>[] = useMemo(() => {
    return [
      {
        data: filteredChainDetails,
        renderItem: tokenSwitchForChains,
      },
      {
        data: filteredTokens,
        renderItem: tokenSwitchForTokens,
      },
    ];
  }, [filteredChainDetails, filteredTokens, tokenSwitchForChains, tokenSwitchForTokens]);

  const tokenListHeader = useMemo(
    () => (
      <View style={styles.headerContainer}>
        <View style={styles.headerRow}>
          <Heading style={styles.header}>Tokens</Heading>

          <ChainSelect
            chain={selectedChain}
            onSelectChain={setSelectedChain}
            filterByTokenSupport
          />
        </View>
        <SearchInput
          value={query}
          onChangeText={setQuery}
          placeholder="Search"
          style={{ marginTop: 20 }}
        />
      </View>
    ),
    [query, setQuery, styles, selectedChain, setSelectedChain]
  );

  return (
    <SafeAreaScreen>
      <SectionList
        sections={sectionsData}
        keyExtractor={(item, index) => `${index}`}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[{ paddingBottom: 30, minHeight: '100%' }, themeStyles.screen]}
        ListHeaderComponent={tokenListHeader}
      />
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'column',
    justifyContent: 'center',
    marginBottom: 20
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  header: {
    marginBottom: 20,
    flex: 1,
  },
  token: {
    borderRadius: 0,
    borderWidth: 1,
  },
});

const tokenSwitchStyles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 90,
  },
  details: {
    flex: 1,
    marginLeft: 10,
  },
  value: {
    fontFamily: fonts.regular,
    fontSize: 15,
  },
  removeButton: {
    width: 15,
    height: 15,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 5,
  },
  tokenName: {
    lineHeight: 22,
  },
  tokenSymbol: {
    marginTop: 1,
    fontSize: 12,
    lineHeight: 13,
  },
  seperator: { height: 15 },
});
