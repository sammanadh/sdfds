import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { ModalTextItem } from '@/components/ModalTextItem';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Select } from '@/components/Select';
import { TextInput } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { Token } from '@/models/Vault';
import { EvmChainService, NearChainService } from '@/models/ChainService';
import { ICONService } from '@/services/chainServices/IconService';
import { PolkadotService } from '@/services/chainServices/PolkadotService';
import { serviceForChainID, useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainID, ChainID, TokenType } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { dismissModal, presentModal } from '@/utils/modal';
import { evmChains } from '@/utils/networks';
import { isCustomNetwork, isTestnetConfig } from '@/utils/types';
import { CompositeNavigationProp, useIsFocused, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty, isNil, isNumber } from 'lodash-es';
import React, { useEffect, useLayoutEffect, useMemo } from 'react';
import { StyleSheet, View } from 'react-native';
import Web3 from 'web3';
import { chains } from '@/utils/chains';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'AddCustomToken'>,
  StackNavigationProp<RootStackParams>
>;

export function AddCustomToken() {
  const { navigate } = useNavigation<NavigationProps>();
  const { realm, getActiveWallet, getActiveChainWallets } = useVault();
  const activeWallet = getActiveWallet();
  const { setToastMessage, setHideTabBar } = useNavigationStore();
  const { otherNetwork } = useChainServices();
  const { isDarkMode } = useTheme();

  const isFocused = useIsFocused();

  const [contractAddress, setContractAddress] = React.useState('');
  const [assetId, setAssetId] = React.useState('');
  const [tokenName, setTokenName] = React.useState('');
  const [tokenSymbol, setTokenSymbol] = React.useState('');
  const [decimals, setDecimals] = React.useState('');

  const [addingToken, setAddingToken] = React.useState(false);

  const [chainID, setChainID] = React.useState<ChainID | null>(ChainID.ICON);

  const chain = useMemo(() => {
    if (isNil(chainID)) {
      return null;
    }
    return chainForChainID(chainID);
  }, [chainID]);

  const [chainError, setChainError] = React.useState<string | null>(null);
  const [contractAddressError, setContractAddressError] = React.useState<string | null>(null);
  const [assetIdError, setAssetIdError] = React.useState<string | null>(null);
  const [tokenNameError, setTokenNameError] = React.useState<string | null>(null);
  const [tokenSymbolError, setTokenSymbolError] = React.useState<string | null>(null);
  const [decimalsError, setDecimalsError] = React.useState<string | null>(null);

  const service = React.useMemo(() => {
    if (chainID) {
      return serviceForChainID(chainID);
    }

    return null;
  }, [chainID]);

  useLayoutEffect(() => {
    if (isFocused) {
      setHideTabBar(true);
    }
  }, []);

  React.useEffect(() => {
    setChainError(null);
  }, [chainID]);

  React.useEffect(() => {
    setContractAddressError(null);

    async function fetchTokenDetails() {
      if (service && !service.isValidAddress(contractAddress)) {
        return;
      }

      if (chainID === ChainID.ICON || chainID === ChainID.HAVAH) {
        const { name, symbol, decimals } = await (service as ICONService).getTokenDetails(
          contractAddress
        );
        setTokenName(name);
        setTokenSymbol(symbol);
        setDecimals(String(decimals));
      }

      if (chainID && (chainID === ChainID.Ethereum || evmChains.includes(chainID))) {
        const { name, symbol, decimals } = await (service as EvmChainService).getTokenDetails(
          contractAddress
        );
        setTokenName(name);
        setTokenSymbol(symbol);
        setDecimals(String(decimals));
      }

      if (chainID === ChainID.NEAR) {
        const { name, symbol, decimals } = await (service as NearChainService).getTokenDetails(
          contractAddress
        );
        setTokenName(name);
        setTokenSymbol(symbol);
        setDecimals(String(decimals));
      }
    }

    fetchTokenDetails();
  }, [contractAddress]);

  useEffect(() => {
    setAssetIdError(null);

    async function fetchAssetDetails() {
      if (!isNumber(+assetId)) {
        return;
      }

      if (chainID === ChainID.Arctic) {
        const { name, symbol, decimals } = await (service as PolkadotService).getAssetDetails(
          assetId
        );
        setTokenName(name);
        setTokenSymbol(symbol);
        setDecimals(String(decimals));
      }
    }

    fetchAssetDetails();
  }, [assetId]);

  React.useEffect(() => {
    setTokenNameError(null);
  }, [tokenName]);

  React.useEffect(() => {
    setTokenSymbolError(null);
  }, [tokenSymbol]);

  React.useEffect(() => {
    setDecimalsError(null);
  }, [decimals]);

  function verifyFields() {
    let errors = false;

    if (isNil(chainID)) {
      setChainError('Please select a Chain');
      errors = true;
    }

    if (chain?.tokenType === TokenType.Contract && isEmpty(contractAddress)) {
      setContractAddressError('Please enter the contract address');
      errors = true;
    }

    if (chain?.tokenType === TokenType.Asset && isEmpty(assetId)) {
      setAssetIdError('Please enter the asset id');
      errors = true;
    }

    if (isEmpty(tokenName)) {
      setTokenNameError('Please enter the token name');
      errors = true;
    }

    if (isEmpty(tokenSymbol)) {
      setTokenSymbolError('Please enter the token symbol');
      errors = true;
    }

    if (isEmpty(decimals)) {
      setDecimalsError('Please enter the decimals');
      errors = true;
    }

    if (
      chainID === ChainID.Ethereum &&
      !isEmpty(contractAddress) &&
      !Web3.utils.isAddress(contractAddress)
    ) {
      setContractAddress('Please enter a valid contract address');
      errors = true;
    }

    return !errors;
  }

  function resetErrors() {
    setChainError(null);
    setContractAddressError(null);
    setTokenNameError(null);
    setTokenSymbolError(null);
    setDecimalsError(null);
  }

  const onAddToken = () => {
    resetErrors();

    if (!verifyFields()) {
      return;
    }

    setAddingToken(true);

    const wallet = activeWallet?.chainWallets.find((cw) => cw.type === chainID);

    if (wallet && realm && chainID) {
      realm.write(() => {
        const token = realm.create<Token>(
          Token.schema.name,
          new Token(chainID, tokenName, tokenSymbol, +decimals)
        );

        if (chain?.tokenType === TokenType.Contract) {
          token.contract = contractAddress;
        }

        if (chain?.tokenType === TokenType.Asset) {
          token.assetId = assetId;
        }

        token.isCustom = true;

        if (isTestnetConfig(otherNetwork)) {
          token.networkRef = otherNetwork.ref;
        } else if (isCustomNetwork(otherNetwork)) {
          token.customNetworkId = otherNetwork.id;
        }
      });

      setToastMessage('Added custom token', ToastType.success);

      navigate('ManageTokens');
    }

    setAddingToken(false);
  };

  const activeChainWallets = getActiveChainWallets();
  const activeChainIDs = useMemo(
    () => activeChainWallets.filter((cw) => cw.isActive).map((cw) => cw.type),
    [activeChainWallets]
  );

  const chainsSupportingTokens = chains
    .filter((chain) => !isNil(chain.tokenType))
    .map((chain) => chain.id);

  const selectableChainIDs = useMemo(() => {
    return activeChainIDs.filter((chainID) => chainsSupportingTokens.includes(chainID));
  }, [activeChainIDs, chainsSupportingTokens]);

  useEffect(() => {
    if (isTestnetConfig(otherNetwork)) {
      setChainID(otherNetwork.chainType);
    } else if (isCustomNetwork(otherNetwork)) {
      setChainID(otherNetwork.chain);
    }
  }, [otherNetwork]);

  const modalContent = React.useMemo(() => {
    return (
      <View style={{ marginTop: 20 }}>
        {selectableChainIDs.map((_chainID) => {
          const chain = chainForChainID(_chainID);
          return (
            <ModalTextItem
              title={chain?.name}
              onPress={() => {
                setChainID(_chainID);
                dismissModal();
              }}
              chain={chain}
              isActive={chainID === _chainID}
              key={_chainID}
            />
          );
        })}
      </View>
    );
  }, [selectableChainIDs, isDarkMode, chainID]);

  return (
    <SafeAreaScreen bottom={false}>
      <ScrollViewScreen>
        <Heading style={styles.heading}>Add a token</Heading>

        <Select
          placeholder="Chain"
          value={chainID ? chainForChainID(chainID)?.name : null}
          onPress={() => {
            presentModal({
              title: 'Select a Chain',
              content: modalContent,
            });
          }}
          chain={chainForChainID(chainID!)}
        />

        {chainError && <Text style={styles.errorMessage}>{chainError}</Text>}

        {chain?.tokenType === TokenType.Contract && (
          <TextInput
            label="Contract address (e.g. cx429731644462ebcfd22185df38727273f16f9b87)"
            labelTitle="Address"
            error={!!contractAddressError}
            msgError={contractAddressError}
            value={contractAddress}
            isDarkMode={isDarkMode}
            onChangeText={(text) => setContractAddress(text)}
            style={{ marginTop: 14 }}
            autoFocus
          />
        )}

        {chain?.tokenType === TokenType.Asset && (
          <TextInput
            label="Asset ID"
            value={assetId}
            error={!!assetIdError}
            msgError={assetIdError}
            onChangeText={(text) => setAssetId(text)}
            style={{ marginTop: 14 }}
            autoFocus
          />
        )}

        <TextInput
          label="Token name"
          labelTitle="Name"
          value={tokenName}
          isDarkMode={isDarkMode}
          error={!!tokenNameError}
          msgError={tokenNameError}
          onChangeText={(text) => setTokenName(text)}
          style={{ marginTop: 14 }}
        />

        <TextInput
          label="Token symbol"
          labelTitle="Symbol"
          value={tokenSymbol}
          isDarkMode={isDarkMode}
          error={!!tokenSymbolError}
          msgError={tokenSymbolError}
          onChangeText={(text) => setTokenSymbol(text)}
          style={{ marginTop: 14 }}
        />

        <TextInput
          label="Decimals"
          value={decimals}
          isDarkMode={isDarkMode}
          error={!!decimalsError}
          msgError={decimalsError}
          onChangeText={(text) => setDecimals(text)}
          style={{ marginTop: 14 }}
        />
      </ScrollViewScreen>
      <Footer>
        <Button working={addingToken} style={{ marginTop: 30 }} onPress={onAddToken}>
          Add token
        </Button>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  errorMessage: {
    color: colors.red,
    marginTop: 8,
  },
  heading: {
    marginBottom: 20,
  },
});
