import { CollectableItem } from '@/components/Collectables/CollectableItem';
import Loading from '@/components/Loading';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { Heading, Text } from '@/components/Typography';
import { Collectable, CollectionDetails } from '@/models/Collectable';
import { itemsForCollection, useCollectables } from '@/stores/Collectables';
import { useNavigationStore } from '@/stores/Navigation';
import { useVault } from '@/stores/Vault';
import { formatPixel } from '@/utils/format';
import {
  CompositeNavigationProp,
  RouteProp,
  useIsFocused,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useLayoutEffect, useMemo, useRef, useState } from 'react';
import { Animated, Dimensions, FlatList, ListRenderItemInfo, StyleSheet, View } from 'react-native';

const { width } = Dimensions.get('window');

export interface CollectionDetailsScreenParams {
  details: CollectionDetails;
  sending?: boolean;
}

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'CollectionDetails'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'CollectionDetails'>;

export function CollectionDetailsScreen() {
  //state
  const { navigate } = useNavigation<NavigationProps>();
  const route = useRoute<RouteProps>();

  const offset = useRef(new Animated.Value(0)).current;
  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();
  const screenWidth = Dimensions.get('window').width;
  const { details, sending } = route.params;
  const [items, setItems] = useState<Collectable[]>([]);

  const { refreshCollectablesForCollection, collectables } = useCollectables();
  const { setHideTabBar } = useNavigationStore();
  const isFocused = useIsFocused();

  //func
  const itemWidth = useMemo(() => {
    return (width - 34 - formatPixel(14)) / 2;
  }, [screenWidth]);

  const chainWallet = activeWallet?.chainWallets.find(
    (cw) => cw.type === details.collection.chain.type
  );

  const onScroll = Animated.event([{ nativeEvent: { contentOffset: { y: offset } } }], {
    useNativeDriver: false,
  });

  useLayoutEffect(() => {
    refreshCollectablesForCollection(details.collection);
  }, [details]);

  useLayoutEffect(() => {
    setItems(itemsForCollection(details.collection));
  }, [collectables]);
  const keyExtractor = (item: Collectable) => {
    return item?.tokenId?.toString() ?? '';
  };

  React.useEffect(() => {
    if (isFocused && !sending) {
      setHideTabBar(false);
    }
  }, [isFocused, sending]);

  const ListEmptyComponent = () => {
    return (
      <View style={{ width: '100%' }}>
        <Loading height={itemWidth} width={itemWidth} />
      </View>
    );
  };

  const renderItem = ({ item, index }: ListRenderItemInfo<Collectable>) => {
    return (
      <CollectableItem
        detail={details}
        index={index}
        item={item}
        onPress={() => {
          if (sending === true) {
            chainWallet &&
              navigate('Send', {
                wallet: chainWallet,
                collection: details.collection,
                collectable: item,
              });
          } else {
            setHideTabBar(true);
            navigate('CollectableDetails', {
              collection: details.collection,
              collectable: item,
            });
          }
        }}
        size={itemWidth}
      />
    );
  };

  //render
  return (
    <SafeAreaScreen bottom={false}>
      <FlatList
        style={{ width: '100%' }}
        numColumns={2}
        contentContainerStyle={[styles.content]}
        ItemSeparatorComponent={() => <View style={styles.spacer} />}
        data={items}
        showsVerticalScrollIndicator={false}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        scrollEventThrottle={16}
        onScroll={onScroll}
        ListEmptyComponent={ListEmptyComponent}
        ListHeaderComponent={() => {
          return (
            <View style={{ marginBottom: 20 }}>
              <Heading>{details.collection.name}</Heading>
              <Text muted style={styles.subTitle}>
                {details.tokensCount} collected
              </Text>
            </View>
          );
        }}
      />
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  subTitle: {
    marginTop: 10,
  },
  content: {
    paddingBottom: 20,
    width: '100%',
  },
  spacer: {
    height: 15,
  },
});
