import { ActivityIndicator } from '@/components/ActivityIndicator';
import { ChainSelect } from '@/components/ChainSelect';
import { CollectionItem } from '@/components/Collectables/CollectionItem';
import { CollectiblesPlaceholder } from '@/components/CollectiblesPlaceholder';
import { HomeButton } from '@/components/HomeButton';
import Loading from '@/components/Loading';
import { WalletAddressesModal } from '@/components/Modals/Home/WalletAddressesModal';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import SegmentedControl from '@/components/SegmentedControl';
import { TokenButton } from '@/components/TokenButton';
import { AltHeading, Heading } from '@/components/Typography';
import { MAINNET, useCurrentNetworkName } from '@/hooks/useCurrentNetworkName';
import { TokenWithBalance, useTokens } from '@/hooks/useTokens';
import { CollectionDetails } from '@/models/Collectable';
import { Token } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { collectablesForActiveWallet, useCollectables } from '@/stores/Collectables';
import { useCuratedTokens } from '@/stores/CuratedTokens';
import { useIconNetwork } from '@/stores/IconNetwork';
import { useNavigationStore } from '@/stores/Navigation';
import { usePendingTransactions } from '@/stores/PendingTransactions';
import { usePrices } from '@/stores/Price';
import { useTheme } from '@/stores/Theme';
import { useTransactions } from '@/stores/Transactions';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import { HIT_SLOP_LARGE, ZERO } from '@/utils/constants';
import { colors, palette, paletteDark } from '@/utils/designTokens';
import { dismissModal, presentModal } from '@/utils/modal';
import { getTotalValueForActiveWallet } from '@/utils/price';
import { common } from '@/utils/styles';
import { useHeaderHeight } from '@react-navigation/elements';
import { CompositeNavigationProp, useIsFocused, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty } from 'lodash-es';
import debounce from 'lodash/debounce';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Dimensions,
  FlatList,
  LayoutAnimation,
  Platform,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'Home'>,
  StackNavigationProp<RootStackParams>
>;

enum Segment {
  Tokens = 'Tokens',
  NFTs = 'NFTs',
}

const segments = [Segment.Tokens, Segment.NFTs];

const { height: deviceHeight } = Dimensions.get('screen');

export function HomeScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const headerHeight = useHeaderHeight();
  const { isDarkMode, styles: themeStyles } = useTheme();
  const {
    getActiveWallet,
    refreshWalletBalances,
    wallets,
    createWallet,
    lastCreatedWalletAt,
    realm,
    isCreatingWallet,
  } = useVault();
  const activeWallet = getActiveWallet();
  const allTokens = useTokens({ filterByValue: 'contractTokens', filterByActiveChains: true });
  const {
    refreshCollectablesForActiveWallet,
    collectables,
    refreshingCollectablesForActiveWallet,
  } = useCollectables();
  const { servicesUpdatedAt } = useChainServices();
  const { refreshCuratedTokens } = useCuratedTokens();
  const isFocused = useIsFocused();
  const { setHideTabBar, setHeaderHeight } = useNavigationStore();
  const { refreshPrices, nativePrices } = usePrices();
  const [portfolioValue, setPortfolioValue] = useState(ZERO);
  const { refreshICXAssets } = useIconNetwork();
  const [selectedSegment, setSelectedSegment] = useState(segments[0]);
  const [refreshing, setRefreshing] = useState(false);
  const { pendingTransactions } = usePendingTransactions();
  const [selectedChain, setSelectedChain] = useState<ChainID | null>(null);

  const tokens = realm?.objects<Token>('Token');
  const [tokensLastUpdated, setTokensLastUpdated] = useState<Date | null>(null);
  // This helps with refreshing token balances by force a re-rendering as Realm object writes don't trigger state changes automatically
  useEffect(() => {
    function onTokensChanged() {
      setTokensLastUpdated(new Date());
    }

    tokens?.addListener(onTokensChanged);

    return () => {
      tokens?.removeListener(onTokensChanged);
    };
  }, []);

  const service = useCurrentNetworkName();

  // NOTE: Have to debounce this so it doesn't refresh too often (lastCreatedWalletAt can update very often due to new chain wallets being created)
  const debouncedRefresh = useCallback(
    debounce(() => {
      refreshWalletBalances();
      refreshCollectablesForActiveWallet();
    }, 500),
    []
  );
  useEffect(() => {
    debouncedRefresh();
  }, [activeWallet?.id, lastCreatedWalletAt, service, tokens?.length, pendingTransactions]);

  useEffect(() => {
    setHeaderHeight(headerHeight);
  }, [headerHeight]);

  const [lastRefreshDate, setLastRefreshDate] = useState<Date | null>(null);
  const minutesSinceLastRefresh = useMemo(() => {
    if (lastRefreshDate) {
      const diff = new Date().getTime() - lastRefreshDate.getTime();
      return Math.floor(diff / 1000 / 60);
    }
    return null;
  }, [isFocused, lastRefreshDate]);

  useEffect(() => {
    setPortfolioValue(getTotalValueForActiveWallet());
  }, [activeWallet, nativePrices, allTokens.length, service]);

  async function refreshData(force: boolean = false) {
    if (refreshing && !force) return;
    try {
      setRefreshing(true);
      setLastRefreshDate(new Date());
      // NOTE: Errors need to be caught or pull to refresh can get stuck
      await refreshWalletBalances();
      await refreshPrices();

      setPortfolioValue(getTotalValueForActiveWallet());
      await refreshICXAssets();
      refreshCollectablesForActiveWallet();
    } catch (e) {
      setRefreshing(false);
    } finally {
      setRefreshing(false);
      refreshCuratedTokens();
    }
  }

  useEffect(() => {
    refreshData();
  }, []);

  useEffect(() => {
    if (isFocused) {
      setHideTabBar(false);

      // Create first wallet if needed
      if (isEmpty(wallets)) {
        createWallet();
      }
    }

    if (isFocused && minutesSinceLastRefresh && minutesSinceLastRefresh > 1) {
      refreshData();
    }
  }, [isFocused]);

  useEffect(() => {
    refreshCuratedTokens();
  }, [servicesUpdatedAt?.getTime()]);

  function onWalletNamePress() {
    if (!activeWallet) return;

    presentModal({
      title: `${activeWallet?.name}`,
      content: (
        <WalletAddressesModal
          wallet={activeWallet}
          onConnectLedger={(chainId) => {
            dismissModal();

            navigate('ConnectWithLedger', {
              initialChainId: chainId,
            });
          }}
        />
      ),
    });
  }

  const screenWidth = Dimensions.get('window').width;
  const screenHeight = Dimensions.get('window').height;

  const collectionItemWidth = useMemo(() => screenWidth / 2 - 30, [screenWidth]);

  function renderItem({
    item,
    index,
  }: {
    item: TokenWithBalance | CollectionDetails;
    index: number;
  }) {
    if (!activeWallet) {
      return <></>;
    }

    if (selectedSegment === Segment.Tokens) {
      const token = item as TokenWithBalance;

      const wallet = activeWallet.chainWallets.find((wallet) => wallet.type === token.chainId)!;

      return (
        <TokenButton
          key={`${token.chainId}-${token.contract ?? token.symbol}`}
          token={token}
          onPress={async () => {
            Platform.OS === 'ios' &&
              LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
            setHideTabBar(true);

            navigate('TokenDetails', { wallet, token });
          }}
          style={{ marginHorizontal: 14 }}
        />
      );
    }

    if (selectedSegment === Segment.NFTs) {
      const collection = item as CollectionDetails;

      return (
        <CollectionItem
          key={collection.collection.contract}
          details={collection}
          onPress={() => {
            Platform.OS === 'ios' &&
              LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
            navigate('CollectionDetails', {
              details: collection,
            });
          }}
          index={index}
          size={collectionItemWidth}
        />
      );
    }

    return <></>;
  }

  const walletCollectables = useMemo(() => {
    return collectablesForActiveWallet();
  }, [activeWallet?.id, collectables]);

  const data = useMemo(() => {
    if (selectedSegment === Segment.Tokens) {
      if (selectedChain) {
        return allTokens.filter((tokens) => tokens.chainId === selectedChain);
      } else {
        return allTokens;
      }
    } else {
      if (service === MAINNET) {
        if (selectedChain) {
          return walletCollectables.filter(
            (collectable) => collectable.collection.chain.type === selectedChain
          );
        } else {
          return walletCollectables;
        }
      } else {
        return [];
      }
    }
  }, [selectedSegment, activeWallet, allTokens, walletCollectables, service, selectedChain]);

  const ListEmptyComponent = useMemo(() => {
    if (selectedSegment === Segment.NFTs && service !== MAINNET) {
      return (
        <View style={{ flex: 1, justifyContent: 'center' }}>
          <CollectiblesPlaceholder />
        </View>
      );
    }

    if (selectedSegment === Segment.NFTs && (refreshing || refreshingCollectablesForActiveWallet)) {
      return (
        <View style={{ paddingHorizontal: 16 }}>
          <Loading height={collectionItemWidth} width={collectionItemWidth} />
        </View>
      );
    }

    if (isEmpty(walletCollectables)) {
      return <CollectiblesPlaceholder empty />;
    }

    return <></>;
  }, [selectedSegment, refreshingCollectablesForActiveWallet, refreshing, service]);

  return (
    <SafeAreaScreen top padTop={false} bottom={false}>
      <View style={common.negateScreen}>
        {/* Workaround so that background beyond scroll remains the same -- issue only exists in iOS */}
        {Platform.OS === 'ios' && (
          <View
            style={[
              themeStyles.screen,
              {
                width: '100%',
                height: screenHeight / 2,
                bottom: 0,
                left: 0,
                right: 0,
                position: 'absolute',
                zIndex: -999,
              },
            ]}
          />
        )}

        <FlatList
          style={{ height: '100%' }}
          key={selectedSegment}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[{ paddingBottom: 30, minHeight: '100%' }, themeStyles.screen]}
          data={data as (TokenWithBalance | CollectionDetails)[]}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          numColumns={selectedSegment === Segment.NFTs ? 2 : 1}
          onRefresh={() => refreshData(true)}
          refreshing={refreshing}
          columnWrapperStyle={
            selectedSegment === Segment.NFTs
              ? {
                  flex: 1,
                  justifyContent: 'space-between',
                  paddingHorizontal: 16,
                }
              : undefined
          }
          ItemSeparatorComponent={() =>
            selectedSegment === Segment.Tokens ? <View style={{ height: 14 }} /> : <></>
          }
          ListEmptyComponent={ListEmptyComponent}
          ListHeaderComponent={
            <View>
              <View
                style={[
                  { backgroundColor: isDarkMode ? paletteDark.offPurple : palette.offPurple },
                  { paddingBottom: 30 },
                ]}
              >
                <HomeButton isHomeScreen refreshing={() => refreshData(true)} />
                <View style={common.screen}>
                  <TouchableOpacity
                    hitSlop={HIT_SLOP_LARGE}
                    style={{ marginBottom: 10, marginTop: Math.min(deviceHeight / 9, 100) }}
                    onPress={onWalletNamePress}
                  >
                    <View style={styles.walletNameContent}>
                      <AltHeading style={styles.walletName}>{activeWallet?.name}</AltHeading>
                      {(refreshing || isCreatingWallet) && (
                        <ActivityIndicator
                          size={12}
                          color={palette.black}
                          style={{ marginLeft: 10, paddingBottom: 2 }}
                        />
                      )}
                    </View>
                  </TouchableOpacity>
                  <Heading style={styles.jumbo}>
                    $
                    {Number(portfolioValue) != 0
                      ? portfolioValue?.toFixed(2)
                      : Number(getTotalValueForActiveWallet()).toFixed(2)}
                  </Heading>
                </View>
              </View>
              <View style={[common.screen, themeStyles.screen, styles.segmentControlContainer]}>
                <SegmentedControl
                  segments={segments}
                  selectedSegment={selectedSegment}
                  onSelectedSegment={setSelectedSegment}
                />
                <ChainSelect
                  chain={selectedChain}
                  onSelectChain={setSelectedChain}
                  filterByTokenSupport={selectedSegment === segments[0]}
                />
              </View>
            </View>
          }
        />
      </View>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  jumbo: {
    fontSize: 42,
    lineHeight: 56,
    marginTop: 8,
    color: palette.black,
  },
  walletNameContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  manageTokenButtonText: {
    lineHeight: 19.5,
    paddingVertical: 16,
    paddingHorizontal: 8,
  },
  manageTokenButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    borderWidth: 1,
  },
  manageTokenButtonContainer: {
    alignItems: 'center',
    marginVertical: 15,
  },
  walletName: {
    color: colors.black,
    fontSize: 12,
  },
  scrollViewContainer: {
    flexGrow: 1,
    paddingBottom: 0,
    margin: 0,
  },
  segmentControlContainer: {
    marginBottom: 14,
    flexDirection: 'row',
    alignItems: 'center',
  },
});
