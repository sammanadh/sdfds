import { IconCloneGray, IconExternalLink } from '@/assets/icons';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { ToastType } from '@/components/Toast.types';
import { SwapAmountHeader } from '@/components/Trade/SwapAmountHeader';
import { AltHeading, Heading, Text } from '@/components/Typography';
import { TokenWithBalance, useTokens } from '@/hooks/useTokens';
import { SwapServiceProvider } from '@/models/SwapService';
import { serviceForChainWallet, useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { usePrices } from '@/stores/Price';
import { useSwapServices } from '@/stores/SwapServices';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainWallet, getTransactionUrlPath } from '@/utils/chains';
import { HIT_SLOP_XLARGE, ZERO } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { formatNumber, formatPrice } from '@/utils/format';
import Clipboard from '@react-native-clipboard/clipboard';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import BigNumber from 'bignumber.js';
import { format, formatDistanceToNowStrict } from 'date-fns';
import * as WebBrowser from 'expo-web-browser';
import { isEmpty, isNil } from 'lodash-es';
import React, { useEffect, useMemo } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'SwapTransactionDetails'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'SwapTransactionDetails'>;

interface DetailsRowProps {
  type: string;
  title?: string | number | React.ReactElement;
  subtitle?: string | null;
  isDarkMode: Boolean;
}

function DetailsRow({ type, title, subtitle, isDarkMode }: DetailsRowProps) {
  return (
    <View style={styles.detailsRow}>
      <AltHeading>{type}</AltHeading>

      {title && (
        <Text
          large
          bold
          style={[{ marginTop: 8, color: '#16073a' }, isDarkMode && { color: colors.whiteSecond }]}
        >
          {title}
        </Text>
      )}

      {subtitle && <Text style={[styles.subtitle, { marginTop: 6 }]}>{subtitle}</Text>}
    </View>
  );
}

export function SwapTransactionDetails() {
  const {
    params: { transaction },
  } = useRoute<RouteProps>();

  const { amount, toAmount } = transaction;

  const { goBack } = useNavigation<NavigationProps>();

  const navigation = useNavigation<NavigationProps>();

  const { setToastMessage } = useNavigationStore();

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();
  const { getNativePriceForNetwork, getTokenPrice } = usePrices();
  const { chainWallet, token } = transaction;

  const service = chainWallet ? serviceForChainWallet(chainWallet) : undefined;
  const network = service?.getNetworkDetails();

  const chain = chainWallet ? chainForChainWallet(chainWallet) : undefined;

  const { isDarkMode, colors, styles: themeStyles } = useTheme();

  const allTokens = useTokens({
    filterBySwappable: true,
  });

  const { swappableTokensForProvider, refreshSwappableTokensForProvider } = useSwapServices();

  const { connectedChains } = useChainServices();

  useEffect(() => {
    (async () => {
      if (isEmpty(swappableTokensForProvider(SwapServiceProvider.ChangeNow))) {
        await refreshSwappableTokensForProvider(SwapServiceProvider.ChangeNow, connectedChains);
      }
    })();
  }, [service]);

  const fromToken = useMemo(() => {
    return (
      transaction.fromToken ||
      allTokens.find(
        (t) => t.chainId === transaction.fromChainId && t.contract === transaction.fromTokenContract
      )
    );
  }, [allTokens, transaction]);

  const toToken = useMemo(() => {
    return (
      transaction.toToken ||
      allTokens.find(
        (t) => t.chainId === transaction.toChainId && t.contract === transaction.toTokenContract
      )
    );
  }, [allTokens, transaction]);

  const totalFee = useMemo(() => {
    return transaction.fee ? new BigNumber(transaction.fee) : undefined;
  }, [transaction]);

  const totalFeeValue = useMemo(() => {
    if (!isNil(totalFee) && !isNil(network)) {
      return totalFee.times(getNativePriceForNetwork(network));
    }

    return ZERO;
  }, [totalFee, transaction, network]);

  const feeSymbol = useMemo(() => {
    return network?.token?.symbol || chain?.token.symbol;
  }, [network, chain]);

  function openBrowser() {
    if (!isNil(service?.getNetworkDetails().blockExplorerUrl) && network?.chainType) {
      const url =
        transaction.transactionUrl ||
        `${service?.getNetworkDetails().blockExplorerUrl}${getTransactionUrlPath(
          network.chainType
        )}/${transaction.hash}`;

      WebBrowser.openBrowserAsync(url);
    }
  }

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          hitSlop={HIT_SLOP_XLARGE}
          style={{
            marginRight: 24,
          }}
          onPress={openBrowser}
        >
          <IconExternalLink width={24} height={24} color={isDarkMode ? 'white' : 'black'} />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  function handleCopyTransactionHashToClipboard() {
    Clipboard.setString(transaction.hash);
    setToastMessage('Transaction hash copied', ToastType.info);
  }

  return (
    <ScrollViewScreen
      style={{ backgroundColor: isDarkMode ? colors.purple.darkBlacker : colors.white }}
      contentContainerStyle={styles.container}
      keyboardShouldPersistTaps={'always'}
      showsVerticalScrollIndicator={false}
    >
      <Heading>Swap</Heading>

      <View style={styles.addressContainer}>
        <Text muted>{transaction.hash}</Text>
        <TouchableOpacity
          hitSlop={HIT_SLOP_XLARGE}
          onPress={handleCopyTransactionHashToClipboard}
          style={{ marginLeft: 8 }}
        >
          <IconCloneGray width={16} height={16} color={isDarkMode ? 'white' : 'black'} />
        </TouchableOpacity>
      </View>

      {!isNil(fromToken) && !isNil(toToken) && !isNil(toAmount) && (
        <View
          style={{
            marginVertical: 16,
          }}
        >
          <SwapAmountHeader
            fromToken={fromToken as TokenWithBalance}
            toToken={toToken as TokenWithBalance}
            fromAmount={amount}
            toAmount={toAmount}
          />
        </View>
      )}

      <View
        style={[styles.separator, isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode }]}
      />

      <DetailsRow type="estimate time to swap" title="10 - 60 minutes" isDarkMode={isDarkMode} />

      <View
        style={[styles.separator, isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode }]}
      />

      {!isNil(totalFee) && (
        <DetailsRow
          type="transaction fee"
          title={`${totalFee ? formatNumber(totalFee, 5) : '-'} ${feeSymbol}`}
          subtitle={!totalFeeValue ? null : formatPrice(totalFeeValue, false)}
          isDarkMode={isDarkMode}
        />
      )}

      <View
        style={[styles.separator, isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode }]}
      />

      <DetailsRow type="status" title={transaction.statusLabel} isDarkMode={isDarkMode} />

      <View
        style={[styles.separator, isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode }]}
      />

      <DetailsRow
        type="date"
        title={format(transaction.date, 'PPpp')}
        subtitle={formatDistanceToNowStrict(transaction.date, { addSuffix: true })}
        isDarkMode={isDarkMode}
      />
    </ScrollViewScreen>
  );
}

const styles = StyleSheet.create({
  detailsRow: {
    paddingVertical: 20,
  },
  subtitle: {
    fontSize: 13,
    color: '#736b88',
    textTransform: 'uppercase',
  },
  separator: {
    height: 1,
    backgroundColor: colors.gray.border,
    marginHorizontal: 0,
  },
  container: {
    flexDirection: 'column',
    paddingTop: 30,
  },
  addressContainer: {
    flexDirection: 'row',
    marginTop: 10,
  },
});
