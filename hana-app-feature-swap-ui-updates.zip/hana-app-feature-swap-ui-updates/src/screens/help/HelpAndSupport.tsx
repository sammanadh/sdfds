import { IconExternalLink, IconNextBlack, IconNextWhite } from '@/assets/icons';
import { CardButton } from '@/components/CardButton';
import { HelpStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { SupportFooter } from '@/components/SupportFooter';
import { Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as WebBrowser from 'expo-web-browser';
import { StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HelpStackParams, 'Disclaimer'>,
  StackNavigationProp<RootStackParams>
>;

export function HelpAndSupportScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const { isDarkMode, colors } = useTheme();

  return (
    <SafeAreaScreen>
      <ScrollViewScreen>
        <Heading style={styles.heading}>Help & Support</Heading>

        <CardButton onPress={() => WebBrowser.openBrowserAsync('https://docs.hanawallet.io/')}>
          <View style={styles.itemDetails}>
            <Text large bold>
              Documentation
            </Text>
          </View>
          <IconExternalLink width={24} height={24} color={colors.foreground} />
        </CardButton>

        <CardButton onPress={() => WebBrowser.openBrowserAsync('https://discord.gg/b5QvCXJjJM')}>
          <View style={styles.itemDetails}>
            <Text large bold>
              Get help
            </Text>
          </View>
          <IconExternalLink width={24} height={24} color={colors.foreground} />
        </CardButton>
        <CardButton
          onPress={() => WebBrowser.openBrowserAsync('https://hanawallet.io/privacy.html')}
        >
          <View style={styles.itemDetails}>
            <Text large bold>
              Privacy policy
            </Text>
          </View>
          <IconExternalLink width={24} height={24} color={colors.foreground} />
        </CardButton>
        <CardButton onPress={() => navigate('Disclaimer')}>
          <View style={styles.itemDetails}>
            <Text large bold>
              Disclaimer
            </Text>
          </View>
          {isDarkMode ? <IconNextWhite /> : <IconNextBlack />}
        </CardButton>
      </ScrollViewScreen>

      <SupportFooter isDarkMode={isDarkMode} />
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginBottom: 20,
  },
  itemDetails: {
    flex: 1,
    marginRight: 15,
  },
});
