import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { StyleSheet, View } from 'react-native';

export function DisclaimerScreen() {
  const { isDarkMode } = useTheme();

  return (
    <>
      <SafeAreaScreen top={false} bottom={false}>
        <ScrollViewScreen>
          <Heading style={styles.heading}>Disclaimer</Heading>

          <View style={styles.container}>
            <Text muted style={[isDarkMode && { color: colors.whiteSecond }]}>
              As the user of Hana you are solely responsible for managing and keeping your private
              keys safe. Private keys for Hana are stored on your device. The developer does not
              store and/or manage private keys.
            </Text>
            <Text muted style={[isDarkMode && { color: colors.whiteSecond }]} space>
              The developer is not responsible for any loss of private keys.
            </Text>
            <Text muted style={[isDarkMode && { color: colors.whiteSecond }]} space>
              The developer provides Hana "as is", with no guarantee of security, integrity,
              completeness, accuracy, timeliness or of the results obtained from the use of the app,
              and without warranty of any kind, express or implied, including, but not limited to
              warranties of performance, security and fitness for a particular purpose.
            </Text>
            <Text muted style={[isDarkMode && { color: colors.whiteSecond }]} space>
              The developer is not responsible for any direct or indirect bugs, issues,
              malfunctions, hacks, third-party transactions, viruses, malware or any loss from the
              use of Hana.
            </Text>
          </View>
        </ScrollViewScreen>
      </SafeAreaScreen>
    </>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginBottom: 0,
  },
  container: {
    marginTop: 20,
  },
});
