import { ChainSelect } from '@/components/ChainSelect';
import { HomeButton } from '@/components/HomeButton';
import Loading from '@/components/Loading';
import { RootStackParams, TransactionsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { TransactionItem } from '@/components/TransactionItem';
import { Heading, Text } from '@/components/Typography';
import { sortByDate, TransactionType } from '@/models/Transaction';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { usePendingTransactions } from '@/stores/PendingTransactions';
import { useTheme } from '@/stores/Theme';
import { useTransactions } from '@/stores/Transactions';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import {
  CompositeNavigationProp,
  RouteProp,
  useIsFocused,
  useNavigation,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty } from 'lodash-es';
import debounce from 'lodash/debounce';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Dimensions,
  FlatList,
  LayoutAnimation,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TransactionsStackParams, 'Transactions'>,
  StackNavigationProp<RootStackParams>
>;
type RouteProps = RouteProp<TransactionsStackParams, 'Transactions'>;

const LOADING_PLACEHOLDER_COUNT = 6;

export function TransactionsScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const { isDarkMode } = useTheme();
  const { getActiveChainWallets, getActiveWallet, lastCreatedWalletAt } = useVault();
  const { setHideTabBar } = useNavigationStore();
  const isFocused = useIsFocused();

  const { otherNetwork, servicesUpdatedAt } = useChainServices();

  const activeWallet = getActiveWallet();

  const scrollViewRef = useRef<ScrollView>(null);

  const activeChainWallets = getActiveChainWallets();
  const {
    refreshTransactionsForActiveChainWallets,
    refreshingTransactionsForActiveChainWallets,
    getAllTransactionsForChainWallets,
    transactions,
  } = useTransactions();

  const { pendingTransactions } = usePendingTransactions();

  const screenHeight = Dimensions.get('window').height;

  const [selectedChain, setSelectedChain] = useState<ChainID | null>(null);

  const [loading, setLoading] = useState(true);

  const allTransactions = useMemo(() => {
    return activeChainWallets
      ? getAllTransactionsForChainWallets(activeChainWallets).sort(sortByDate)
      : [];
  }, [activeChainWallets, transactions]);

  const transactionsForSelectedChain = useMemo(
    () =>
      selectedChain
        ? allTransactions.filter((t) => t.chainWallet?.type === selectedChain)
        : allTransactions,
    [selectedChain, allTransactions]
  );

  const [lastRefreshDate, setLastRefreshDate] = useState<Date | null>(null);
  const minutesSinceLastRefresh = useMemo(() => {
    if (lastRefreshDate) {
      const diff = new Date().getTime() - lastRefreshDate.getTime();
      return Math.floor(diff / 1000 / 60);
    }
    return null;
  }, [isFocused, lastRefreshDate]);

  useEffect(() => {
    setLoading(refreshingTransactionsForActiveChainWallets);
  }, [transactionsForSelectedChain, refreshingTransactionsForActiveChainWallets]);

  // NOTE: Have to debounce this so it doesn't refresh too often (lastCreatedWalletAt can update very often due to new chain wallets being created)
  const debouncedRefresh = useCallback(
    debounce(() => {
      setLastRefreshDate(new Date());
      refreshTransactionsForActiveChainWallets();
    }, 500),
    []
  );

  useEffect(() => {
    debouncedRefresh();
  }, []);

  useEffect(() => {
    useTransactions.setState({
      refreshingTransactionsForActiveChainWallets: true,
    });

    debouncedRefresh();
  }, [activeWallet?.id, lastCreatedWalletAt, pendingTransactions]);

  useEffect(() => {
    if (isFocused) {
      if (minutesSinceLastRefresh && minutesSinceLastRefresh > 1) {
        setLastRefreshDate(new Date());
        refreshTransactionsForActiveChainWallets();
      }
      setHideTabBar(false);
    } else {
      scrollViewToTop();
    }
  }, [isFocused, servicesUpdatedAt]);

  // Reset selection when switching networks
  useEffect(() => {
    setSelectedChain(null);
  }, [otherNetwork]);

  const scrollViewToTop = () => {
    debounce(() => {
      scrollViewRef.current?.scrollTo({ x: 0, y: 0, animated: false });
    }, 600)();
  };

  return (
    <SafeAreaScreen top padTop={false} bottom={false}>
      <FlatList
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 30 }}
        data={transactionsForSelectedChain}
        renderItem={({ item, index }) => {
          const { chainWallet } = item;
          if (chainWallet) {
            return (
              <TransactionItem
                isDarkMode={isDarkMode}
                chainWallet={chainWallet}
                transaction={item}
                token={item.token}
                onPress={() => {
                  Platform.OS === 'ios' &&
                    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
                  setHideTabBar(true);

                  if (item.type === TransactionType.TokenSwap) {
                    navigate('SwapTransactionDetails', {
                      transaction: item,
                    });
                  } else {
                    navigate('TransactionDetails', {
                      transaction: item,
                    });
                  }
                }}
                style={{ marginHorizontal: 16 }}
              />
            );
          }
          return <></>;
        }}
        ListHeaderComponent={
          <View>
            <HomeButton />
            <View style={styles.headerContainer}>
              <Heading large style={styles.heading}>
                History
              </Heading>

              <ChainSelect chain={selectedChain} onSelectChain={setSelectedChain} />
            </View>
          </View>
        }
        ListEmptyComponent={() =>
          !loading ? (
            <View
              style={{
                height: screenHeight * 0.6,
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Text muted>{'No transactions Found'}</Text>
            </View>
          ) : (
            <View
              style={{
                marginHorizontal: 16,
              }}
            >
              {Array(LOADING_PLACEHOLDER_COUNT)
                .fill(0)
                .map((_, index) => (
                  <View key={index} style={{ marginBottom: 15 }}>
                    <Loading height={90} width={'100%'} />
                  </View>
                ))}
            </View>
          )
        }
        keyExtractor={(item, index) => index.toString()}
      />
    </SafeAreaScreen>
  );
}
const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 16,
  },
  heading: {
    marginVertical: 25,
    flex: 1,
    textAlign: 'left',
  },
});
