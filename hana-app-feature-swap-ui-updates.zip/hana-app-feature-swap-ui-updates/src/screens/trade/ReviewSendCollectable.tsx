import { Button } from '@/components/Button';
import { CollectableImage } from '@/components/Collectables/CollectableImage';
import { Footer } from '@/components/Footer';
import { ConfirmLedgerTransactionModal } from '@/components/Modals/Ledger/ConfirmLedgerTransactionModal';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { Collectable, Collection } from '@/models/Collectable';
import { Transaction } from '@/models/Transaction';
import { ChainWallet, RealmChainWallet, Wallet, WalletType } from '@/models/Vault';
import { EvmChainService, RawTxResponse } from '@/models/ChainService';
import { EthereumService } from '@/services/chainServices/EthereumService';
import { ICONService } from '@/services/chainServices/IconService';
import { serviceForChainWallet } from '@/stores/ChainServices';
import { useLedgerStore } from '@/stores/Ledger';
import { useNavigationStore } from '@/stores/Navigation';
import { usePrices } from '@/stores/Price';
import { useTheme } from '@/stores/Theme';
import { useTransactions } from '@/stores/Transactions';
import { useVault } from '@/stores/Vault';
import { ChainID, chains } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { formatAddress, formatPrice } from '@/utils/format';
import { appTypeForChainID, getLedgerApp, LedgerAddress, signTransaction } from '@/utils/ledger';
import { dismissModal, presentModal } from '@/utils/modal';
import { isEvmChain } from '@/utils/networks';
import Transport from '@ledgerhq/hw-transport';
import TransportHID from '@ledgerhq/react-native-hid';
import TransportBLE from '@ledgerhq/react-native-hw-transport-ble';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isNil } from 'lodash-es';
import React, { useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { usePendingTransactions } from '@/stores/PendingTransactions';

// NOTE: BLE module is imported lazily so that the Bluetooth permissions don't prompt when app first loads
// let TransportBLE: typeof TransportBLEType.default | undefined = undefined;

export interface ReviewSendCollectableScreenParams {
  wallet: ChainWallet | RealmChainWallet;
  collectable: Collectable;
  collection: Collection;
  toAddress: string;
  toWallet?: Wallet | null;
}

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'ReviewSendCollectable'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<HomeStackParams, 'ReviewSendCollectable'>;

interface DetailsRowProps {
  type: string;
  title: string;
  subtitle?: string;
  isDarkMode: boolean;
  imageUrl?: string;
}

function DetailsRow({ type, title, subtitle, isDarkMode, imageUrl }: DetailsRowProps) {
  return (
    <View style={styles.detailRowContainer}>
      <View style={styles.detailsRow}>
        <Text bold style={[styles.type, { color: isDarkMode ? '#b9b5c3' : '#736b88' }]}>
          {type}
        </Text>
        <Text large bold style={[{ marginTop: 8 }, isDarkMode && { color: colors.whiteSecond }]}>
          {title}
        </Text>
        {subtitle && (
          <Text
            bold
            style={[
              styles.subtitle,
              { marginTop: 6 },
              { color: isDarkMode ? '#b9b5c3' : '#736b88' },
            ]}
          >
            {subtitle}
          </Text>
        )}
      </View>
      {imageUrl && <CollectableImage url={imageUrl ?? ''} size={64} style={styles.img} />}
    </View>
  );
}

export function ReviewSendCollectableScreen() {
  const navigation = useNavigation<NavigationProps>();

  const {
    params: { wallet, collection, collectable, toAddress, toWallet },
  } = useRoute<RouteProps>();

  const { setToastMessage } = useNavigationStore();
  const { addPendingTransaction } = usePendingTransactions();

  const { setConnectingToLedger, transport, setTransport, setLedgerBleId } = useLedgerStore();

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  const service = serviceForChainWallet(wallet);
  const network = service?.getNetworkDetails();

  const chain = chains.find((chain) => chain.id === wallet.type);

  const feeSymbol = network?.token?.symbol || chain?.token.symbol;

  const [estimatedFee, setEstimatedFee] = useState(ZERO);
  const [estimatingFee, setEstimatingFee] = useState(false);

  const { getNativePrice, getTokenPrice } = usePrices();

  const [sending, setSending] = useState(false);

  const price = React.useMemo(() => {
    return chain ? getNativePrice(chain) : ZERO;
  }, [wallet]);

  const totalFee = React.useMemo(() => {
    return estimatedFee;
  }, [estimatedFee]);

  const totalFeeValue = React.useMemo(() => {
    return price.multipliedBy(estimatedFee);
  }, [price, estimatedFee]);

  const isEthOrEVM = (chain && isEvmChain(chain)) || chain?.id === ChainID.Ethereum;
  const { isDarkMode } = useTheme();

  useEffect(() => {
    setEstimatingFee(true);

    const evmService = service as EvmChainService;

    evmService
      ?.sendCollectable(
        wallet,
        {
          toAddress,
          collectable,
          collection,
        },
        {
          getRawTx: true,
          estimatingFee: true,
        }
      )
      .then((response) => {
        if ((response as RawTxResponse).rawTx) {
          const { rawTx } = response as RawTxResponse;

          if (isEthOrEVM) {
            (service as EthereumService).estimateWeb3Transaction(rawTx).then((estimate) => {
              console.debug('estimate', estimate);
              setEstimatedFee(estimate.amount.times(estimate.tokenPrice));
            });
          }

          if (chain?.id === ChainID.ICON) {
            (service as ICONService).estimateRawTransaction(rawTx).then((estimate) => {
              console.debug('estimate', estimate);
              setEstimatedFee(estimate.amount.times(estimate.tokenPrice));
            });
          }
        }
      });
  }, []);

  function onSend() {
    setSending(true);

    if (activeWallet?.type === WalletType.Ledger) {
      presentModal({
        title: 'Connect to Ledger',
        content: (
          <ConfirmLedgerTransactionModal
            chainWallet={wallet}
            onConnectToLedger={async () => {
              try {
                await connectToLedger();
                handleCloseLedger();
              } catch (error: any) {
                console.debug('Failed connecting to Ledger.', error.message);
                handleCloseLedger(error.message);
              }
            }}
          />
        ),
        options: {
          onClose: () => handleCloseLedger(),
        },
      });
    } else {
      service &&
        (service as EvmChainService)
          ?.sendCollectable(wallet, {
            toAddress,
            collectable,
            collection,
          })
          .then((response) => {
            if ((response as Transaction).type) {
              addPendingTransaction(response as Transaction);
            }

            setSending(false);
            navigation.popToTop();
          });
    }
  }

  async function connectToLedger() {
    if (transport) {
      await transport.close();
    }

    setConnectingToLedger(true);

    let thisTransport: any;

    if (activeWallet?.ledgerBleId) {
      // if (!TransportBLE) {
      //   TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
      // }

      thisTransport = await TransportBLE.open(activeWallet.ledgerBleId);
      thisTransport.on('disconnect', () => {
        console.debug('BLE disconnected');
      });

      setTransport(thisTransport);
      setLedgerBleId(activeWallet.ledgerBleId);

      console.debug('connected to BLE');
    } else {
      thisTransport = await TransportHID.create();
      thisTransport.on('disconnect', () => {
        console.debug('HID disconnected');
      });

      setTransport(thisTransport);
    }

    service &&
      (service as EvmChainService)
        ?.sendCollectable(
          wallet,
          {
            toAddress,
            collectable,
            collection,
          },
          {
            getRawTx: true,
          }
        )
        .then(async (rawTxResponse) => {
          if ((rawTxResponse as RawTxResponse).rawTx) {
            const myRawTxResponse = rawTxResponse as RawTxResponse;
            const { rawTx, serializedTx } = myRawTxResponse;

            const appType = appTypeForChainID(wallet.type)!;

            const ledgerApp = await getLedgerApp(thisTransport, appType);
            const ledgerAddress = {
              index: wallet.hdIndex,
              hdPath: wallet.hdPath,
              address: wallet.address,
            } as LedgerAddress;

            const signature = await signTransaction(
              ledgerApp,
              appType,
              ledgerAddress,
              serializedTx,
              toAddress
            );

            setConnectingToLedger(false);

            service &&
              (service as EvmChainService)
                ?.sendCollectable(
                  wallet,
                  {
                    toAddress,
                    collectable,
                    collection,
                  },
                  {
                    rawTx,
                    signature,
                  }
                )
                .then((transaction) => {
                  if ((transaction as Transaction).type) {
                    addPendingTransaction(transaction as Transaction);
                  }

                  setSending(false);

                  navigation.popToTop();

                  setToastMessage('Your transaction has been sent!', ToastType.success);
                });
          }
        })
        .catch((error) => {
          setSending(false);
        });
  }

  function handleCloseLedger(errorMessage?: string) {
    if (!isNil(errorMessage)) {
      const toastMessage =
        errorMessage === 'NoAddress' ? `Failed connecting to Ledger` : `Failed or rejected signing`;
      setToastMessage(toastMessage, ToastType.error);
    } else {
      dismissModal();
    }

    transport?.close();
    setTransport(null);
    setConnectingToLedger(false);
  }

  return (
    <SafeAreaScreen top={false}>
      <ScrollViewScreen contentContainerStyle={styles.container}>
        <Heading style={styles.heading}>Review & send</Heading>
        <Text
          muted
          style={[{ marginTop: 10, width: '100%' }, isDarkMode && { color: colors.gray.watermark }]}
        >
          Your NFT may be lost permanently if the transaction details are incorrect.
        </Text>
        {activeWallet && (
          <>
            <View style={styles.detailsContainer}>
              <DetailsRow
                type="sending"
                title={collectable.name}
                subtitle={collection.name}
                isDarkMode={isDarkMode}
                imageUrl={collectable.imageUrl}
              />
              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />

              <DetailsRow
                type="from"
                title={activeWallet.name}
                subtitle={formatAddress(wallet.address)}
                isDarkMode={isDarkMode}
              />
              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />
              {toWallet ? (
                <DetailsRow type="to" title={toWallet.name} isDarkMode={isDarkMode} />
              ) : (
                toAddress && (
                  <DetailsRow type="to" title={formatAddress(toAddress)} isDarkMode={isDarkMode} />
                )
              )}
              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />

              <DetailsRow
                type="transaction fee"
                title={`${totalFee} ${feeSymbol}`}
                subtitle={formatPrice(totalFeeValue)}
                isDarkMode={isDarkMode}
              />
            </View>
          </>
        )}
      </ScrollViewScreen>

      <View style={styles.footerContainer}>
        <Footer>
          <Button working={sending} onPress={onSend}>
            Send
          </Button>
        </Footer>
      </View>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    paddingTop: 30,
    width: '100%',
  },
  container: {
    flexDirection: 'column',
    alignItems: 'center',
    paddingBottom: 200,
  },
  detailsContainer: {
    marginTop: 20,
    width: '100%',
  },
  subtitle: {
    fontSize: 13,
    textTransform: 'uppercase',
  },
  separator: {
    height: 1,
    backgroundColor: colors.gray.border,
  },
  type: {
    fontSize: 12,
    textTransform: 'uppercase',
  },
  detailRowContainer: {
    flexGrow: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailsRow: {
    paddingTop: 20,
    paddingBottom: 20,
  },
  footerContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
  },
  img: {
    backgroundColor: colors.gray.meta,
  },
});
