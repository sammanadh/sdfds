import { IconInfoCircle, IconNextBlack } from '@/assets/icons';
import { ActivityIndicator } from '@/components/ActivityIndicator';
import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { RootStackParams, TradeStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { ToastType } from '@/components/Toast.types';
import { SwapAmountHeader } from '@/components/Trade/SwapAmountHeader';
import { AltHeading, Heading, Text } from '@/components/Typography';
import { ChainService, EvmChainService, TransactionEstimate } from '@/models/ChainService';
import {
  CreateSwapParams,
  CreatedSwapBalanced,
  CreatedSwapOneInch,
  ProviderWithInstantSettlement,
  SLIPPAGE,
  SwapServiceProvider,
} from '@/models/SwapService';
import { Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet, Token } from '@/models/Vault';
import { EthereumService } from '@/services/chainServices/EthereumService';
import { ICONChainService } from '@/services/chainServices/IconService';
import { serviceForChainID, useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { usePendingTransactions } from '@/stores/PendingTransactions';
import { usePrices } from '@/stores/Price';
import { useSwapServices } from '@/stores/SwapServices';
import { useTheme } from '@/stores/Theme';
import { useTransactions } from '@/stores/Transactions';
import { useVault } from '@/stores/Vault';
import { ChainID, chains, getSubstrateFeeRoundingDecimals, isSubstrateChain } from '@/utils/chains';
import {
  DEFAULT_DOT_ESTIMATED_FEE,
  DEFAULT_ICZ_ESTIMATED_FEE,
  HIT_SLOP_XLARGE,
  ZERO,
} from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { formatAddress, formatNumber, formatPrice } from '@/utils/format';
import { dismissModal, presentModal } from '@/utils/modal';
import Checkbox from '@react-native-community/checkbox';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import BigNumber from 'bignumber.js';
import { isNil } from 'lodash-es';
import React, { useEffect, useMemo, useState } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { useIntervalWhen } from 'rooks';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'SwapReview'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<TradeStackParams, 'SwapReview'>;

const ESTIMATE_REFRESH_INTERVAL = 10000; // 10 seconds

interface DetailsRowProps {
  type: string;
  title?: string | number | React.ReactElement;
  subtitle?: string | null;
  isDarkMode: Boolean;
}

function DetailsRow({ type, title, subtitle, isDarkMode }: DetailsRowProps) {
  return (
    <View style={styles.detailsRow}>
      <AltHeading>{type}</AltHeading>

      {title && (
        <Text
          large
          bold
          style={[{ marginTop: 8, color: '#16073a' }, isDarkMode && { color: colors.whiteSecond }]}
        >
          {title}
        </Text>
      )}

      {subtitle && <Text style={[styles.subtitle, { marginTop: 6 }]}>{subtitle}</Text>}
    </View>
  );
}

export function SwapReview() {
  const {
    params: {
      fromToken,
      fromSwappable,
      toToken,
      toSwappable,
      fromAmount,
      toAmount: initialToAmount,
      useMaxAmount,
      provider,
      slippage,
    },
  } = useRoute<RouteProps>();
  const { navigate } = useNavigation<NavigationProps>();
  const { getActiveWallet } = useVault();
  const { isDarkMode, styles: themeStyles } = useTheme();
  const { serviceForProvider, refreshSwappableTokensForProvider, swappableTokensForProvider } =
    useSwapServices();

  const activeWallet = getActiveWallet();

  const [readTerms, setReadTerms] = React.useState(false);
  const [isSwapping, setIsSwapping] = React.useState(false);
  const [toAmount, setToAmount] = React.useState(initialToAmount);
  const [gettingEstimate, setGettingEstimate] = React.useState(false);
  const [speedEstimate, setSpeedEstimate] = useState({ min: -1, max: -1 });

  const chainService = serviceForChainID(fromSwappable.chainId);
  const isNativeToken = fromSwappable.isNative;

  const navigation = useNavigation<NavigationProps>();

  const { addPendingTransaction } = usePendingTransactions();

  const swapService = useMemo(() => {
    return serviceForProvider(provider);
  }, [provider]);

  const fromChainWallet = useMemo(() => {
    return activeWallet?.chainWallets.find(
      (chainWallet) => chainWallet.type === fromSwappable.chainId
    );
  }, [activeWallet, fromSwappable.chainId]);

  const toChainWallet = useMemo(() => {
    return activeWallet?.chainWallets.find(
      (chainWallet) => chainWallet.type === toSwappable.chainId
    );
  }, [activeWallet, toSwappable.chainId]);

  const isSubstrate = isSubstrateChain(fromSwappable.chainId);

  const chain = useMemo(() => {
    return chains.find((chain) => chain.id === fromSwappable.chainId);
  }, [fromSwappable.chainId]);

  const fromTokenAsToken = useMemo(() => fromToken as unknown as Token, [fromToken]);
  const toTokenAsToken = useMemo(() => toToken as unknown as Token, [toToken]);

  const [transactionEstimate, setTransactionEstimate] = useState<TransactionEstimate | null>(null);
  const [estimatedError, setEstimatedError] = useState<string | null>(null);
  const [estimatedDotFee, setEstimatedDotFee] = useState<BigNumber>(
    chain?.id === ChainID.Arctic ? DEFAULT_ICZ_ESTIMATED_FEE : DEFAULT_DOT_ESTIMATED_FEE
  ); // Used to calculate if amount exceeds Existential Deposit threshold
  const [feeHasBeenEstimated, setFeeHasBeenEstimated] = useState(false);
  const [estimatedFee, setEstimatedFee] = useState(ZERO);

  const { getNativePrice, getTokenPrice } = usePrices();

  const { setToastMessage } = useNavigationStore();

  const price = React.useMemo(() => {
    if (!isNativeToken && chain && chain.coinType) {
      return getNativePrice(chain);
    }

    if (isNativeToken && fromToken.contract) {
      return getTokenPrice(fromToken.contract);
    }

    if (isNativeToken && chain) {
      return getNativePrice(chain);
    }

    return ZERO;
  }, [chain, fromToken, isNativeToken]);

  const totalFee = React.useMemo(() => {
    return isSubstrate ? estimatedDotFee : estimatedFee;
  }, [isSubstrate, estimatedDotFee, estimatedFee]);

  const totalFeeValue = React.useMemo(() => {
    if (isSubstrate) {
      return price.multipliedBy(estimatedDotFee);
    }

    return price.multipliedBy(estimatedFee);
  }, [isSubstrate, price, estimatedDotFee, estimatedFee]);

  const network = chainService?.getNetworkDetails();
  const feeSymbol = network?.token?.symbol || chain?.token.symbol;

  const { selectChain, connectedChains } = useChainServices();

  useEffect(() => {
    // Check for and enable to chain if necessary
    if (!connectedChains.find((chain) => chain.id === toSwappable.chainId)) {
      selectChain(toSwappable.chainId);
    }
  }, []);

  useEffect(() => {
    if (chainService) {
      let params;

      if (!fromChainWallet) {
        return;
      }

      // Handle gas estimate for Balanced swaps separately
      if (provider === SwapServiceProvider.BalancedNetwork) {
        params = {
          type: TransactionType.TokenSwap,
          toAddress: fromChainWallet?.address,
          amount: fromAmount,
          token: fromTokenAsToken,
        };

        const swapParams = createSwapParams();
        swapService?.createSwap(...swapParams).then((createdSwap) => {
          const { txObj } = createdSwap as CreatedSwapBalanced;
          (chainService as ICONChainService)
            .estimateRawTransaction(txObj)
            .then((estimate) => {
              setTransactionEstimate(estimate);
            })
            .catch((error) => {
              console.warn('Failed estimating transaction fee.', error.message);
              setEstimatedError(error.message ?? 'Unknown error');
            });
        });

        return;
      } else if (provider === SwapServiceProvider.OneInch) {
        const swapParams = createSwapParams();

        swapService?.createSwap(...swapParams).then((createdSwap) => {
          const { txn } = createdSwap as CreatedSwapOneInch;
          (chainService as EthereumService)
            .estimateWeb3Transaction(txn)
            .then((estimate) => {
              setTransactionEstimate({ ...estimate });
            })
            .catch((error) => {
              console.warn('Failed estimating transaction fee.', error.message);
              setEstimatedError(error.message ?? 'Unknown error');
            });
        });

        return;
      }

      if (!isNativeToken) {
        params = {
          type: TransactionType.SendToken,
          toAddress: fromChainWallet?.address,
          amount: fromAmount,
          token: fromTokenAsToken,
        };
      } else {
        // NOTE: Amount is not required for ICX/EVM chains and can cause issues if trying to specify max amount
        const amountToEstimate = isSubstrate ? fromAmount : ZERO;
        params = {
          type: TransactionType.SendNativeToken,
          toAddress: fromChainWallet?.address,
          amount: amountToEstimate,
        };
      }

      chainService
        ?.estimateTransaction(fromChainWallet, params)
        .then((estimate) => {
          setTransactionEstimate(estimate);
        })
        .catch((error) => {
          console.warn('ReviewSend Failed estimating transaction fee.', error.message);
          setEstimatedError(error.message);
        });
    }
  }, [chainService, fromAmount, fromChainWallet, fromTokenAsToken, isNativeToken, isSubstrate]);

  useEffect(() => {
    if (!transactionEstimate) return;

    if (isSubstrate) {
      if (chain) {
        const feeRoundingDecimals = getSubstrateFeeRoundingDecimals(chain.id);

        setEstimatedDotFee(
          new BigNumber(transactionEstimate.price)
            .div(new BigNumber(10).pow(chain.token.decimals))
            .decimalPlaces(feeRoundingDecimals, BigNumber.ROUND_UP)
        );
        setFeeHasBeenEstimated(true);
      }
      // } else if (chain?.coinType === CoinType.ETH && chain?.canSetGasPrice === true) {
      //   const priceInWei = Web3.utils.toWei(new BigNumber(stepPrice).toFixed(), 'gwei');
      //   const estimatedFee = Web3.utils.fromWei(
      //     transactionEstimate.amount.times(priceInWei).toFixed(),
      //     'ether'
      //   );
      //   setEstimatedFee(new BigNumber(estimatedFee));
      //   setFeeHasBeenEstimated(true);
    } else {
      setEstimatedFee(transactionEstimate.amount.times(transactionEstimate.tokenPrice));
      setFeeHasBeenEstimated(true);
    }
  }, [transactionEstimate, chain, isSubstrate]);

  async function handleGetEstimate() {
    if (!swapService || !toChainWallet || !fromChainWallet) {
      return;
    }

    try {
      setGettingEstimate(true);
      const { amount, speed } = await swapService.getEstimate(
        fromSwappable,
        toSwappable,
        fromAmount,
        toChainWallet.address,
        fromChainWallet
      );
      setToAmount(amount);
      setSpeedEstimate(speed);
    } catch (error: any) {
      console.warn(`Failed getting swap estimate.`, error.message);
    }
    setGettingEstimate(false);
  }

  useIntervalWhen(
    () => {
      handleGetEstimate();
    },
    ESTIMATE_REFRESH_INTERVAL,
    !isSwapping,
    true
  );

  const createSwapParams = (): [
    ChainWallet,
    ChainService,
    CreateSwapParams,
    string,
    string,
    BigNumber?
  ] => {
    const amount = useMaxAmount
      ? isNativeToken
        ? fromToken.balance.minus(estimatedFee!)
        : fromToken.balance
      : fromAmount;

    return [
      fromChainWallet as ChainWallet,
      chainService as ChainService,
      {
        fromSwappable,
        fromToken: fromTokenAsToken,
        toSwappable,
        toToken: toTokenAsToken,
        amount,
        estimate: {
          amount: toAmount,
          speed: speedEstimate,
        },
      },
      fromChainWallet?.address as string,
      toChainWallet?.address as string,
      slippage?.div(100), // 0.01 = 1 / 100 = 0.01
    ];
  };

  function handleSwapComplete() {
    const swapState = Object.values(ProviderWithInstantSettlement).includes(provider)
      ? 'completed'
      : 'initiated';
    setIsSwapping(false);
    setToastMessage(`Swap has been ${swapState}.`);

    navigation.popToTop();

    // @ts-expect-error not worth mapping navigation props to here
    navigate('HomeStack');
  }

  const onSwap = async () => {
    if (isSwapping) return;

    setIsSwapping(true);

    if (!swapService || !fromChainWallet || !toChainWallet || !chainService) {
      console.debug(
        "Can't swap without swapService, fromChainWallet, toChainWallet, or chainService",
        {
          swapService,
          fromChainWallet,
          toChainWallet,
          chainService,
        }
      );
      return;
    }

    const amount = useMaxAmount
      ? isNativeToken
        ? fromToken.balance.minus(estimatedFee!)
        : fromToken.balance
      : fromAmount;

    try {
      const createSwapParamArr = createSwapParams();

      const createdSwap = await swapService.createSwap(...createSwapParamArr);

      const transaction = await swapService.completeSwap(
        fromChainWallet,
        chainService,
        {
          fromSwappable,
          fromToken: fromTokenAsToken,
          toSwappable,
          toToken: toTokenAsToken,
          amount,
          estimate: {
            amount: toAmount,
            speed: speedEstimate,
          },
        },
        fromChainWallet.address,
        toChainWallet.address,
        createdSwap,
        {},
        slippage?.div(100)
      );

      if ((transaction as Transaction).type) {
        addPendingTransaction(transaction as Transaction);
      }

      handleSwapComplete();
    } catch (error) {
      setIsSwapping(false);
      console.warn('Failed creating swap.', error);

      setToastMessage('Failed creating swap: ' + error, ToastType.error);
    }

    setIsSwapping(false);
  };

  function onReadTerms(provider: SwapServiceProvider) {
    let content = <></>;
    let title = '';
    switch (provider) {
      case SwapServiceProvider.ChangeNow:
        title = 'ChangeNOW terms';
        content = (
          <>
            <Text>
              By accessing or using the ChangeNOW API, you agree to these API Terms and Conditions
              (also called the “API Terms”). API terms is a form of agreement that you or any
              company you represent (“Partner“, “you”, “your”) and ChN Group Limited (“ChangeNOW“,
              “we”, “us”) for the publicly available application programming interfaces by ChangeNOW
              ( “ChangeNOW API”, “our API”). By using the ChangeNOW API, you agree to the terms
              below. ChangeNOW does not grant you the right to use the ChangeNOW API if you disagree
              with any of these terms. We reserve the right to update and change these terms from
              time to time without notice.
            </Text>
          </>
        );
        break;
      case SwapServiceProvider.BalancedNetwork:
        title = 'BalancedNetwork terms';
        content = (
          <>
            <Text>
              By using this service, you agree to pay service fee to Hana Wallet for performing this
              swap on your behalf
            </Text>
          </>
        );
        break;
    }

    presentModal({
      title,
      content,
      options: {
        withCloseButton: true,
        confirmButton: {
          title: 'Accept',
          onPress: () => {
            dismissModal();

            setReadTerms(true);
          },
        },
      },
    });
  }

  return (
    <SafeAreaScreen bottom={false}>
      <ScrollViewScreen>
        <Heading>Review & swap</Heading>

        <Text muted style={{ marginTop: 8, marginBottom: 14 }}>
          Double check the information is correct
        </Text>

        <View
          style={{
            marginVertical: 16,
          }}
        >
          <SwapAmountHeader
            fromToken={fromToken}
            toToken={toToken}
            fromAmount={fromAmount}
            toAmount={toAmount}
            loading={gettingEstimate}
            showTokenNameAndSymbol
          />
        </View>

        <View
          style={{
            marginVertical: 16,
          }}
        >
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <Text bold>{provider}</Text>

            <TouchableOpacity hitSlop={HIT_SLOP_XLARGE} onPress={() => onReadTerms(provider)}>
              <IconInfoCircle
                width={20}
                height={20}
                color={isDarkMode ? '#ffffff' : 'rgba(16, 15, 16, 0.8)'}
              />
            </TouchableOpacity>
          </View>
          <View
            style={{
              flexDirection: 'row',
              marginTop: 8,
            }}
          >
            <Checkbox
              boxType="square"
              value={readTerms}
              onFillColor="rgba(16, 15, 16, 0.8)"
              onCheckColor="#ffffff"
              onTintColor={isDarkMode ? '#ffffff' : 'rgba(16, 15, 16, 0.8)'}
              tintColor={isDarkMode ? '#ffffff' : 'rgba(16, 15, 16, 0.8)'}
              onValueChange={(checked) => setReadTerms(checked)}
              style={{
                marginRight: 16,
              }}
            />

            <Text
              small
              style={{
                flex: 1,
              }}
            >
              I have{' '}
              <Text
                bold
                small
                style={{
                  color: isDarkMode ? '#CDBEF2' : '#4300AF',
                }}
                onPress={() => onReadTerms(provider)}
              >
                read the terms
              </Text>{' '}
              and accept that there is risk associated with using a swap service
            </Text>
          </View>
        </View>

        <View
          style={[
            styles.separator,
            isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
          ]}
        />

        {!isNil(slippage) && (
          <DetailsRow type="slippage" title={slippage.toString() + ' %'} isDarkMode={isDarkMode} />
        )}

        <View
          style={[
            styles.separator,
            isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
          ]}
        />

        <DetailsRow
          type="estimate time to swap"
          title={`${speedEstimate.min} - ${speedEstimate.max} minutes`}
          isDarkMode={isDarkMode}
        />

        <View
          style={[
            styles.separator,
            isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
          ]}
        />

        {estimatedError && totalFee.eq(0) && (
          <DetailsRow
            type="transaction fee"
            subtitle={'Failed estimating fee'}
            isDarkMode={isDarkMode}
          />
        )}

        <DetailsRow
          type="transaction fee"
          title={
            !estimatedError && totalFee.eq(0) ? (
              <ActivityIndicator size={20} color={colors.black} />
            ) : (
              `${formatNumber(totalFee, 5)} ${feeSymbol}`
            )
          }
          subtitle={!totalFeeValue ? null : formatPrice(totalFeeValue, false)}
          isDarkMode={isDarkMode}
        />

        <View
          style={[
            styles.separator,
            isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
          ]}
        />

        <View style={styles.detailsRow}>
          <AltHeading>Wallet</AltHeading>

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <View
              style={{
                flexDirection: 'column',
              }}
            >
              <Text bold style={{ marginTop: 8 }}>
                {activeWallet?.name} ({fromTokenAsToken.symbol})
              </Text>
              <AltHeading style={{ marginTop: 6 }}>
                {fromChainWallet?.address && formatAddress(fromChainWallet.address)}
              </AltHeading>
            </View>
            <IconNextBlack width={15} height={15} />
            <View
              style={{
                flexDirection: 'column',
              }}
            >
              <Text bold style={{ textAlign: 'right', marginTop: 8 }}>
                {toTokenAsToken.symbol}
              </Text>
              <AltHeading style={{ textAlign: 'right', marginTop: 6 }}>
                {toChainWallet?.address && formatAddress(toChainWallet.address)}
              </AltHeading>
            </View>
          </View>
        </View>
      </ScrollViewScreen>

      <Footer>
        <Button working={isSwapping} onPress={onSwap} disabled={!readTerms}>
          Swap
        </Button>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  detailsRow: {
    paddingVertical: 20,
  },
  subtitle: {
    fontSize: 13,
    color: '#736b88',
    textTransform: 'uppercase',
  },
  separator: {
    height: 1,
    backgroundColor: colors.gray.border,
    marginHorizontal: 0,
  },
});
