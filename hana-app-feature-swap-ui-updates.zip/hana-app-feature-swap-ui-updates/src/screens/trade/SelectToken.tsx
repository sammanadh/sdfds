import { ChainSelect } from '@/components/ChainSelect';
import { CollectionItem } from '@/components/Collectables/CollectionItem';
import { RootStackParams, SelectTokenType, TradeStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { SearchInput } from '@/components/SearchInput';
import SegmentedControl from '@/components/SegmentedControl';
import { TokenButton } from '@/components/TokenButton';
import { Heading } from '@/components/Typography';
import { MAINNET, useCurrentNetworkName } from '@/hooks/useCurrentNetworkName';
import { TokenWithBalance, useTokens } from '@/hooks/useTokens';
import { CollectionDetails } from '@/models/Collectable';
import { collectablesForActiveWallet, useCollectables } from '@/stores/Collectables';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isNil } from 'lodash-es';
import React, { useMemo, useState } from 'react';
import {
  Dimensions,
  FlatList,
  LayoutAnimation,
  Platform,
  StyleSheet,
  Text,
  View,
} from 'react-native';

enum Segment {
  Tokens = 'Tokens',
  NFTs = 'NFTs',
}

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'SelectToken'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<TradeStackParams, 'SelectToken'>;

export function SelectToken() {
  const {
    params: { type },
  } = useRoute<RouteProps>();
  const { navigate } = useNavigation<NavigationProps>();
  const { getActiveWallet } = useVault();
  const [query, setQuery] = React.useState('');
  const activeWallet = getActiveWallet();
  const allTokens = useTokens({
    filterByValue: type === SelectTokenType.send,
    filterByActiveChains: true,
  });
  const { isDarkMode, styles: themeStyles } = useTheme();
  const [selectedChain, setSelectedChain] = useState<ChainID | null>(null);

  const segments = useMemo(() => {
    if (type === SelectTokenType.receive) {
      return [Segment.Tokens];
    }

    return [Segment.Tokens, Segment.NFTs];
  }, [type]);

  const [selectedSegment, setSelectedSegment] = React.useState<string>(segments[0]);

  const { collectables } = useCollectables();

  const walletCollectables = useMemo(() => {
    return collectablesForActiveWallet();
  }, [activeWallet?.id, collectables]);

  const service = useCurrentNetworkName();

  const data = useMemo(() => {
    if (selectedSegment === Segment.Tokens) {
      return allTokens.filter((token) => {
        return (
          (!isNil(selectedChain) ? token.chainId === selectedChain : true) &&
          (token.name.toLowerCase().includes(query.toLowerCase()) ||
            token.symbol.toLowerCase().includes(query.toLowerCase()))
        );
      });
    }

    if (selectedSegment === Segment.NFTs) {
      return service === MAINNET
        ? walletCollectables.filter((c) => {
            return (
              c.collection.name.toLowerCase().includes(query.toLowerCase()) &&
              (!isNil(selectedChain) ? c.collection.chain.type === selectedChain : true)
            );
          })
        : [];
    }

    return [];
  }, [selectedSegment, allTokens, walletCollectables, service, selectedChain]);

  const screenWidth = Dimensions.get('window').width;
  const collectionItemWidth = useMemo(() => screenWidth / 2 - 30, [screenWidth]);

  function renderItem({
    item,
    index,
  }: {
    item: TokenWithBalance | CollectionDetails;
    index: number;
  }) {
    if (selectedSegment === Segment.Tokens) {
      const token = item as TokenWithBalance;
      const wallet = activeWallet?.chainWallets.find(
        (chainWallet) => chainWallet.type === token.chainId
      )!;
      return (
        <TokenButton
          key={`${token.chainId}-${token.contract ?? token.symbol}`}
          token={token}
          isTrade
          onPress={() => {
            if (type === SelectTokenType.send) {
              navigate('Send', { wallet, token });
            } else if (type === SelectTokenType.receive) {
              navigate('Receive', { wallet, token });
            }
          }}
        />
      );
    }

    if (selectedSegment === Segment.NFTs) {
      const collection = item as CollectionDetails;

      return (
        <CollectionItem
          key={collection.collection.contract}
          details={collection}
          onPress={() => {
            Platform.OS === 'ios' &&
              LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
            navigate('CollectionDetails', {
              details: collection,
              sending: true,
            });
          }}
          index={index}
          size={collectionItemWidth}
        />
      );
    }

    return <></>;
  }

  return (
    <SafeAreaScreen>
      <FlatList
        key={selectedSegment}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[{ paddingBottom: 30 }, themeStyles.screen]}
        data={data as (TokenWithBalance | CollectionDetails)[]}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
        numColumns={selectedSegment === Segment.NFTs ? 2 : 1}
        ItemSeparatorComponent={() =>
          selectedSegment === Segment.Tokens ? <View style={{ height: 14 }} /> : <></>
        }
        ListHeaderComponent={
          <View style={{ paddingBottom: 14 }}>
            <View style={styles.header}>
              <Heading style={styles.heading}>
                {type === SelectTokenType.send ? 'Send' : 'Receive'}
              </Heading>
              <ChainSelect
                chain={selectedChain}
                onSelectChain={setSelectedChain}
                filterByTokenSupport={selectedSegment === segments[0]}
              />
            </View>

            {type === SelectTokenType.send && (
              <SegmentedControl
                segments={segments}
                selectedSegment={selectedSegment}
                onSelectedSegment={setSelectedSegment}
              />
            )}

            <SearchInput
              value={query}
              onChangeText={(txt) => {
                setQuery(txt);
              }}
              placeholder="Search"
              style={{ marginTop: 10 }}
            />
          </View>
        }
      />
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    flex: 1,
    marginTop: 11,
  },
  header: {
    paddingTop: 2,
    flexDirection: 'row',
    alignItems: 'center',
  },
});
