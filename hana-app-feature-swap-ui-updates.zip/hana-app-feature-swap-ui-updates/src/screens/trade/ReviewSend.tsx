import { ActivityIndicator } from '@/components/ActivityIndicator';
import { Button } from '@/components/Button';
import { ConfirmLedgerTransactionModal } from '@/components/Modals/Ledger/ConfirmLedgerTransactionModal';
import { SelectGasPriceModal } from '@/components/Modals/SelectGasPriceModal';
import { RootStackParams, TradeStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { SelectGasPrice } from '@/components/SelectGasPrice';
import { TextInput } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { AltHeading, Heading, Text } from '@/components/Typography';
import { GasPriceOption } from '@/models/GasPriceOption';
import { Transaction, TransactionType } from '@/models/Transaction';
import { Token, WalletType } from '@/models/Vault';
import { RawTxResponse, TransactionEstimate } from '@/models/ChainService';
import { EthereumService } from '@/services/chainServices/EthereumService';
import { ICONService } from '@/services/chainServices/IconService';
import { NearService } from '@/services/chainServices/NearService';
import { PolkadotService } from '@/services/chainServices/PolkadotService';
import { serviceForChainWallet } from '@/stores/ChainServices';
import { useLedgerStore } from '@/stores/Ledger';
import { useNavigationStore } from '@/stores/Navigation';
import { usePrices } from '@/stores/Price';
import { useTheme } from '@/stores/Theme';
import { useTransactions } from '@/stores/Transactions';
import { useVault } from '@/stores/Vault';
import { BigNumber } from '@/utils/bignumber';
import {
  ChainID,
  TokenType,
  chains,
  getSubstrateFeeRoundingDecimals,
  isIconChain,
  isSubstrateChain,
} from '@/utils/chains';
import { CoinType } from '@/utils/coinTypes';
import {
  DEFAULT_DOT_ESTIMATED_FEE,
  DEFAULT_ICZ_ESTIMATED_FEE,
  NEAR_FT_MINIMUM_STORAGE_BALANCE_LARGE,
  ZERO,
} from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { formatAddress, formatAmount, formatPrice } from '@/utils/format';
import { appTypeForChainID, getLedgerApp, LedgerAddress, signTransaction } from '@/utils/ledger';
import { dismissModal, presentModal } from '@/utils/modal';
import { isEvmChain } from '@/utils/networks';
import Transport from '@ledgerhq/hw-transport';
import TransportHID from '@ledgerhq/react-native-hid';
import TransportBLE from '@ledgerhq/react-native-hw-transport-ble';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isNil } from 'lodash-es';
import React, { useEffect, useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import Web3 from 'web3';
import { usePendingTransactions } from '@/stores/PendingTransactions';

// NOTE: BLE module is imported lazily so that the Bluetooth permissions don't prompt when app first loads
// let TransportBLE: typeof TransportBLEType.default | undefined = undefined;

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'ReviewSend'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<TradeStackParams, 'ReviewSend'>;

interface DetailsRowProps {
  type: string;
  title?: string | number | React.ReactElement;
  subtitle?: string | null;
  isDarkMode: Boolean;
}

function DetailsRow({ type, title, subtitle, isDarkMode }: DetailsRowProps) {
  return (
    <View style={styles.detailsRow}>
      <AltHeading>{type}</AltHeading>

      {title && (
        <Text
          large
          bold
          style={[{ marginTop: 8, color: '#16073a' }, isDarkMode && { color: colors.whiteSecond }]}
        >
          {title}
        </Text>
      )}

      {subtitle && <Text style={[styles.subtitle, { marginTop: 6 }]}>{subtitle}</Text>}
    </View>
  );
}

export function ReviewSend() {
  const {
    params: { wallet, toAddress, amount, token, dotTransferKeepAlive, toWallet, useMaxAmount },
  } = useRoute<RouteProps>();

  const { setToastMessage } = useNavigationStore();
  const { addPendingTransaction } = usePendingTransactions();

  const { setConnectingToLedger, transport, setTransport, setLedgerBleId } = useLedgerStore();

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();
  const navigation = useNavigation<NavigationProps>();

  const chain = chains.find((chain) => chain.id === wallet.type);
  const service = serviceForChainWallet(wallet);
  const network = service?.getNetworkDetails();

  const isSubstrate = chain ? isSubstrateChain(chain.id) : false;

  const { getNativePrice, getTokenPrice } = usePrices();

  const feeSymbol = network?.token?.symbol || chain?.token.symbol;
  const { isDarkMode } = useTheme();

  const isNativeToken = useMemo(() => token.native, [token]);
  const tokenAsToken = useMemo(() => token as unknown as Token, [token]);
  const balance = useMemo(() => token.balance, [token]);

  const symbol = React.useMemo(() => {
    if (isNativeToken) {
      return feeSymbol;
    } else {
      return token.symbol;
    }
  }, [token, chain, network]);

  const [sending, setSending] = useState(false);
  const [estimatedFee, setEstimatedFee] = useState(ZERO);
  const [estimatingFeeError, setEstimatingFeeError] = useState<string | null>(null);
  const [estimatedDotFee, setEstimatedDotFee] = useState<BigNumber>(
    chain?.id === ChainID.Arctic ? DEFAULT_ICZ_ESTIMATED_FEE : DEFAULT_DOT_ESTIMATED_FEE
  ); // Used to calculate if amount exceeds Existential Deposit threshold
  const [feeHasBeenEstimated, setFeeHasBeenEstimated] = useState(false);

  const [gettingGasPrices, setGettingGasPrices] = useState(false);
  const [gasPriceOptions, setGasPriceOptions] = useState<GasPriceOption[]>([
    { label: 'Recommended', price: null, estimatedWait: null },
  ]);
  const [selectedGasPrice, setSelectedGasPrice] = useState<GasPriceOption>(gasPriceOptions[0]);

  const [stepPrice, setStepPrice] = useState('');

  const [transactionEstimate, setTransactionEstimate] = useState<TransactionEstimate | null>(null);

  function handleChangeStepPrice(value: string) {
    const stepPrice = new BigNumber(value);

    if (!stepPrice.isPositive()) return ZERO;
    setStepPrice(stepPrice.integerValue().toString());
  }

  function handleSelectGasPrice(option: GasPriceOption) {
    setSelectedGasPrice(option);
    if (!isNil(option.price)) {
      setStepPrice(option.price.toFixed(0).toString());
    }
  }

  useEffect(() => {
    if (!chain?.canSetGasPrice) return;

    setGettingGasPrices(true);
    (service as EthereumService)
      .getGasPrices()
      .then((gasPriceOptions) => {
        console.debug('gasPriceOptions', gasPriceOptions);

        let options: Array<GasPriceOption> = [
          {
            label: 'Minimum',
            price: new BigNumber(Web3.utils.fromWei(gasPriceOptions.low.toString(), 'gwei')),
            estimatedWait: gasPriceOptions.lowWait,
          },
          {
            label: 'Recommended',
            price: new BigNumber(Web3.utils.fromWei(gasPriceOptions.standard.toString(), 'gwei')),
            estimatedWait: gasPriceOptions.standardWait,
          },
          {
            label: 'Priority',
            price: new BigNumber(Web3.utils.fromWei(gasPriceOptions.high.toString(), 'gwei')),
            estimatedWait: gasPriceOptions.highWait,
          },
          { label: 'Advanced', price: null, estimatedWait: null },
        ];
        setGasPriceOptions(options);
        handleSelectGasPrice(options[1]);
      })
      .catch((error) => console.warn('Failed getting gas prices.', error.message))
      .finally(() => setGettingGasPrices(false));
  }, [service]);

  const sendAmount = useMemo(() => {
    if (useMaxAmount) {
      if (!isNativeToken) {
        return new BigNumber(balance);
      } else {
        return new BigNumber(balance).minus(estimatedFee);
      }
    }

    return amount;
  }, [amount, balance, estimatedFee, useMaxAmount, token]);

  React.useEffect(() => {
    if (service) {
      let params;

      if (!isNativeToken) {
        params = {
          type: TransactionType.SendToken,
          toAddress,
          amount: sendAmount,
          token: tokenAsToken,
        };
      } else {
        // NOTE: Amount is not required for ICX/EVM chains and can cause issues if trying to specify max amount
        const amountToEstimate = isSubstrate ? sendAmount : ZERO;
        params = {
          type: TransactionType.SendNativeToken,
          toAddress,
          amount: amountToEstimate,
        };
      }

      service
        ?.estimateTransaction(wallet, params)
        .then((estimate) => {
          setTransactionEstimate(estimate);
        })
        .catch((error) => {
          console.warn('ReviewSend Failed estimating transaction fee.', error.message);
          setEstimatingFeeError(error.message);
        });
    }
  }, [service, sendAmount]);

  useEffect(() => {
    if (!transactionEstimate) return;

    setEstimatingFeeError(null);

    if (isSubstrate) {
      if (chain) {
        const feeRoundingDecimals = getSubstrateFeeRoundingDecimals(chain.id);

        setEstimatedDotFee(
          new BigNumber(transactionEstimate.price)
            .div(new BigNumber(10).pow(chain.token.decimals))
            .decimalPlaces(feeRoundingDecimals, BigNumber.ROUND_UP)
        );
        setFeeHasBeenEstimated(true);
      }
    } else if (chain?.coinType === CoinType.ETH && chain.canSetGasPrice) {
      const priceInWei = Web3.utils.toWei(new BigNumber(stepPrice).toFixed(), 'gwei');
      const estimatedFee = Web3.utils.fromWei(
        transactionEstimate.amount.times(priceInWei).toFixed(),
        'ether'
      );
      setEstimatedFee(new BigNumber(estimatedFee));
      setFeeHasBeenEstimated(true);
    } else {
      setEstimatedFee(transactionEstimate.amount.times(transactionEstimate.tokenPrice));
      setFeeHasBeenEstimated(true);
    }
  }, [transactionEstimate, chain, isSubstrate, stepPrice]);

  const onSend = () => {
    setSending(true);

    if (!isNativeToken) {
      // Ledger support
      if (activeWallet?.type === WalletType.Ledger) {
        presentModal({
          title: 'Connect to Ledger',
          content: (
            <ConfirmLedgerTransactionModal
              chainWallet={wallet}
              onConnectToLedger={async () => {
                try {
                  await connectToLedger();
                  handleCloseLedger();
                } catch (error: any) {
                  console.debug('Failed connecting to Ledger.', error.message);
                  handleCloseLedger(error.message);
                }
              }}
            />
          ),
          options: {
            onClose: () => handleCloseLedger(),
          },
        });

        return;
      }

      if (chain && isEvmChain(chain)) {
        const parsedStepPrice = new BigNumber(stepPrice);

        (service as EthereumService)
          .sendToken(wallet, tokenAsToken, toAddress, sendAmount, {
            stepPrice: parsedStepPrice.isPositive() ? parsedStepPrice : undefined,
          })
          .then((transaction) => {
            if ((transaction as Transaction).type) {
              addPendingTransaction(transaction as Transaction);
            }

            setSending(false);

            navigation.popToTop();

            setToastMessage('Your transaction has been sent!', ToastType.success);
          })
          .catch((error) => {
            setToastMessage(error.message, ToastType.error);
            setSending(false);
          });
      } else if (chain && isIconChain(chain.id)) {
        (service as ICONService)
          .sendToken(wallet, tokenAsToken, toAddress, sendAmount)
          .then((transaction) => {
            if ((transaction as Transaction).type) {
              addPendingTransaction(transaction as Transaction);
            }

            setSending(false);

            navigation.popToTop();

            setToastMessage('Your transaction has been sent!', ToastType.success);
          })
          .catch((error) => {
            console.debug('error: ', error);
            setToastMessage(error.message, ToastType.error);
            setSending(false);
          });
      } else if (chain?.tokenType === TokenType.Asset) {
        (service as PolkadotService)
          .sendAsset(wallet, tokenAsToken, toAddress, sendAmount, {
            dotTransferKeepAlive,
          })
          .then((transaction) => {
            addPendingTransaction(transaction);
            setSending(false);

            navigation.popToTop();

            setToastMessage('Your transaction has been sent!', ToastType.success);
          })
          .catch((error) => {
            setToastMessage(error.message, ToastType.error);
            setSending(false);
          });
      } else if (chain?.id === ChainID.NEAR) {
        (service as NearService)
          .sendToken(wallet, tokenAsToken, toAddress, sendAmount)
          .then((transaction) => {
            if ((transaction as Transaction).type) {
              addPendingTransaction(transaction as Transaction);
            }

            setSending(false);

            navigation.popToTop();

            setToastMessage('Your transaction has been sent!', ToastType.success);
          })
          .catch((error) => {
            setToastMessage(error.message, ToastType.error);
            setSending(false);
          });
      }
    } else {
      if (activeWallet?.type === WalletType.Ledger) {
        presentModal({
          title: 'Connect to Ledger',
          content: (
            <ConfirmLedgerTransactionModal
              chainWallet={wallet}
              onConnectToLedger={async () => {
                try {
                  await connectToLedger();
                  handleCloseLedger();
                } catch (error: any) {
                  console.debug('Failed connecting to Ledger.', error.message);
                  handleCloseLedger(error.message);
                }
              }}
            />
          ),
          options: {
            onClose: () => handleCloseLedger(),
          },
        });
      } else {
        // Send native token using soft wallet
        const parsedStepPrice = new BigNumber(stepPrice);

        service
          ?.sendNativeToken(wallet, toAddress, sendAmount, {
            dotTransferKeepAlive,
            stepPrice: parsedStepPrice.isPositive() ? parsedStepPrice : undefined,
          })
          .then((transaction) => {
            if ((transaction as Transaction).type) {
              addPendingTransaction(transaction as Transaction);
            }

            setSending(false);

            navigation.popToTop();

            setToastMessage('Your transaction has been sent!', ToastType.success);
          })
          .catch((error) => {
            setToastMessage(error.message, ToastType.error);
            console.debug('error', error);

            setSending(false);
          });
      }
    }
  };

  function handleCloseLedger(errorMessage?: string) {
    if (!isNil(errorMessage)) {
      const toastMessage =
        errorMessage === 'NoAddress' ? `Failed connecting to Ledger` : `Failed or rejected signing`;
      setToastMessage(toastMessage, ToastType.error);
    } else {
      dismissModal();
    }

    transport?.close();
    setTransport(null);
    setConnectingToLedger(false);
    setSending(false);
  }

  const price = React.useMemo(() => {
    if (!isNativeToken && chain && chain.coinType) {
      return getNativePrice(chain);
    }

    if (isNativeToken && token.contract) {
      return getTokenPrice(token.contract);
    }

    return ZERO;
  }, [wallet, token, chain]);

  const totalSendValue = price.multipliedBy(sendAmount);

  const totalFee = React.useMemo(() => {
    return isSubstrate ? estimatedDotFee : estimatedFee;
  }, [isSubstrate, estimatedDotFee, estimatedFee]);

  const totalFeeValue = React.useMemo(() => {
    if (isSubstrate) {
      return price.multipliedBy(estimatedDotFee);
    }

    return price.multipliedBy(estimatedFee);
  }, [isSubstrate, price, estimatedDotFee, estimatedFee]);

  async function connectToLedger() {
    if (transport) {
      await transport.close();
      setTransport(null);
    }

    setConnectingToLedger(true);

    let thisTransport: any;

    if (activeWallet?.ledgerBleId) {
      // if (!TransportBLE) {
      //   TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
      // }

      thisTransport = await TransportBLE.open(activeWallet.ledgerBleId);
      thisTransport.on('disconnect', () => {
        console.debug('BLE disconnected');
      });

      setTransport(thisTransport);
      setLedgerBleId(activeWallet.ledgerBleId);
    } else {
      thisTransport = await TransportHID.create();
      thisTransport.on('disconnect', () => {
        console.debug('HID disconnected');
      });

      setTransport(thisTransport);
    }

    const parsedStepPrice = new BigNumber(stepPrice);

    console.debug('isnativetoken: ', isNativeToken);

    if (!isNativeToken) {
      if (chain?.id === ChainID.NEAR) {
        const thisService = service as NearService;

        const storageAvailable = await thisService.storageAvailable(token.contract!, toAddress);

        // TODO: Try the smaller balance first. Doing a large one just to make it work for now
        if (!storageAvailable) {
          const rawTxResponse = await thisService.transferStorageDeposit(
            wallet.address,
            token.contract!,
            toAddress,
            NEAR_FT_MINIMUM_STORAGE_BALANCE_LARGE,
            { getRawTx: true }
          );

          if ((rawTxResponse as RawTxResponse).rawTx) {
            const myRawTxResponse = rawTxResponse as RawTxResponse;
            const { rawTx, serializedTx } = myRawTxResponse;

            const appType = appTypeForChainID(wallet.type)!;

            const ledgerApp = await getLedgerApp(thisTransport, appType);
            const ledgerAddress = {
              index: wallet.hdIndex,
              hdPath: wallet.hdPath,
              address: wallet.address,
            } as LedgerAddress;

            const signature = await signTransaction(
              ledgerApp,
              appType,
              ledgerAddress,
              serializedTx,
              toAddress
            );

            const hash = await thisService.transferStorageDeposit(
              wallet.address,
              token.contract!,
              toAddress,
              NEAR_FT_MINIMUM_STORAGE_BALANCE_LARGE,
              { rawTx, signature }
            );
          }
        }

        const rawTxResponse = await thisService.sendToken(
          wallet,
          tokenAsToken,
          toAddress,
          sendAmount,
          {
            getRawTx: true,
          }
        );

        if ((rawTxResponse as RawTxResponse).rawTx) {
          const myRawTxResponse = rawTxResponse as RawTxResponse;
          const { rawTx, serializedTx } = myRawTxResponse;

          const appType = appTypeForChainID(wallet.type)!;

          const ledgerApp = await getLedgerApp(thisTransport, appType);
          const ledgerAddress = {
            index: wallet.hdIndex,
            hdPath: wallet.hdPath,
            address: wallet.address,
          } as LedgerAddress;

          const signature = await signTransaction(
            ledgerApp,
            appType,
            ledgerAddress,
            serializedTx,
            toAddress
          );

          setConnectingToLedger(false);

          const transaction = await thisService.sendToken(
            wallet,
            tokenAsToken,
            toAddress,
            sendAmount,
            {
              rawTx,
              signature,
              stepPrice: parsedStepPrice.isPositive() ? parsedStepPrice : undefined,
            }
          );

          if ((transaction as Transaction).type) {
            addPendingTransaction(transaction as Transaction);
          }

          setSending(false);

          navigation.popToTop();

          setToastMessage('Your transaction has been sent!', ToastType.success);
        }
      }

      if (chain && isEvmChain(chain)) {
        const rawTxResponse = await (service as EthereumService).sendToken(
          wallet,
          tokenAsToken,
          toAddress,
          sendAmount,
          {
            getRawTx: true,
            stepPrice: parsedStepPrice.isPositive() ? parsedStepPrice : undefined,
          }
        );

        if ((rawTxResponse as RawTxResponse).rawTx) {
          const myRawTxResponse = rawTxResponse as RawTxResponse;
          const { rawTx, serializedTx } = myRawTxResponse;

          const appType = appTypeForChainID(wallet.type)!;

          const ledgerApp = await getLedgerApp(thisTransport, appType);
          const ledgerAddress = {
            index: wallet.hdIndex,
            hdPath: wallet.hdPath,
            address: wallet.address,
          } as LedgerAddress;

          const signature = await signTransaction(
            ledgerApp,
            appType,
            ledgerAddress,
            serializedTx,
            toAddress
          );

          setConnectingToLedger(false);

          signature &&
            (service as EthereumService)
              .sendToken(wallet, tokenAsToken, toAddress, sendAmount, {
                rawTx,
                signature,
                stepPrice: parsedStepPrice.isPositive() ? parsedStepPrice : undefined,
              })
              .then((transaction) => {
                if ((transaction as Transaction).type) {
                  addPendingTransaction(transaction as Transaction);
                }

                setSending(false);

                navigation.popToTop();

                setToastMessage('Your transaction has been sent!', ToastType.success);
              });
        }
      }

      if (chain && isIconChain(chain.id)) {
        const rawTxResponse = await (service as ICONService).sendToken(
          wallet,
          tokenAsToken,
          toAddress,
          sendAmount,
          {
            getRawTx: true,
            stepPrice: parsedStepPrice.isPositive() ? parsedStepPrice : undefined,
          }
        );

        if ((rawTxResponse as RawTxResponse).rawTx) {
          const myRawTxResponse = rawTxResponse as RawTxResponse;
          const { rawTx, serializedTx } = myRawTxResponse;

          const appType = appTypeForChainID(wallet.type)!;

          const ledgerApp = await getLedgerApp(thisTransport, appType);
          const ledgerAddress = {
            index: wallet.hdIndex,
            hdPath: wallet.hdPath,
            address: wallet.address,
          } as LedgerAddress;

          const signature = await signTransaction(
            ledgerApp,
            appType,
            ledgerAddress,
            serializedTx,
            toAddress
          );

          setConnectingToLedger(false);

          signature &&
            (service as ICONService)
              .sendToken(wallet, tokenAsToken, toAddress, sendAmount, {
                rawTx,
                signature,
                stepPrice: parsedStepPrice.isPositive() ? parsedStepPrice : undefined,
              })
              .then((transaction) => {
                if ((transaction as Transaction).type) {
                  addPendingTransaction(transaction as Transaction);
                }

                setSending(false);

                navigation.popToTop();

                setToastMessage('Your transaction has been sent!', ToastType.success);
              });
        }
      }
    } else {
      const rawTxResponse = await service?.sendNativeToken(wallet, toAddress, sendAmount, {
        dotTransferKeepAlive,
        getRawTx: true,
        stepPrice: parsedStepPrice.isPositive() ? parsedStepPrice : undefined,
      });

      if ((rawTxResponse as RawTxResponse).rawTx) {
        const myRawTxResponse = rawTxResponse as RawTxResponse;
        const { rawTx, serializedTx } = myRawTxResponse;

        const appType = appTypeForChainID(wallet.type)!;

        const ledgerApp = await getLedgerApp(thisTransport, appType);
        const ledgerAddress = {
          index: wallet.hdIndex,
          hdPath: wallet.hdPath,
          address: wallet.address,
        } as LedgerAddress;

        const signature = await signTransaction(
          ledgerApp,
          appType,
          ledgerAddress,
          serializedTx,
          toAddress
        );

        setConnectingToLedger(false);

        signature &&
          service
            ?.sendNativeToken(wallet, toAddress, sendAmount, {
              dotTransferKeepAlive,
              rawTx,
              signature,
              stepPrice: parsedStepPrice.isPositive() ? parsedStepPrice : undefined,
            })
            .then((transaction) => {
              if ((transaction as Transaction).type) {
                addPendingTransaction(transaction as Transaction);
              }

              setSending(false);

              navigation.popToTop();

              setToastMessage('Your transaction has been sent!', ToastType.success);
            });
      }
    }
  }

  return (
    <SafeAreaScreen>
      <ScrollViewScreen>
        <Heading>Review & send</Heading>
        <Text muted style={[styles.altHeading, isDarkMode && { color: colors.gray.watermark }]}>
          Your funds may be lost permanently if the transaction details are incorrect
        </Text>

        {estimatingFeeError && (
          <View
            style={[
              styles.error,
              isDarkMode && { backgroundColor: colors.purple.darkBlack, borderWidth: 0 },
            ]}
          >
            <Text large style={[isDarkMode && { color: colors.white }]} bold>
              Failed estimating fee
            </Text>
            <Text style={[{ marginTop: 5 }, isDarkMode && { color: colors.white }]}>
              This transaction is likely to fail because fee estimating returned an error.
            </Text>
            <View style={[{ flexDirection: 'row', marginTop: 5 }]}>
              <Text style={[{ color: colors.primary }, isDarkMode && { color: colors.white }]} bold>
                Error:{' '}
              </Text>
              <Text style={[{ width: '90%' }, isDarkMode && { color: colors.white }]}>
                {estimatingFeeError}
              </Text>
            </View>
          </View>
        )}
        {activeWallet && (
          <>
            <View>
              <DetailsRow
                type="from"
                title={activeWallet.name}
                subtitle={formatAddress(wallet.address)}
                isDarkMode={isDarkMode}
              />
              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />
              {toWallet ? (
                <>
                  <DetailsRow
                    type="to"
                    title={toWallet.name}
                    subtitle={formatAddress(toAddress)}
                    isDarkMode={isDarkMode}
                  />
                </>
              ) : (
                toAddress && (
                  <DetailsRow type="to" title={formatAddress(toAddress)} isDarkMode={isDarkMode} />
                )
              )}
              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />
              <DetailsRow
                type="sending"
                title={`${formatAmount(sendAmount ?? 0)} ${symbol}`}
                subtitle={formatPrice(totalSendValue, false)}
                isDarkMode={isDarkMode}
              />
              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />

              {chain?.canSetGasPrice === true && (
                <>
                  <View style={styles.detailsRow}>
                    <AltHeading>gas price</AltHeading>

                    <SelectGasPrice
                      value={selectedGasPrice}
                      style={{ marginTop: 10 }}
                      onPress={() => {
                        presentModal({
                          title: 'Choose gas price',
                          content: (
                            <View
                              style={{
                                marginTop: 20,
                              }}
                            >
                              <SelectGasPriceModal
                                options={gasPriceOptions}
                                selectedOption={selectedGasPrice}
                                onSelectedOption={(option) => {
                                  handleSelectGasPrice(option);
                                  dismissModal();
                                }}
                              />
                            </View>
                          ),
                          options: {
                            withCloseButton: false,
                          },
                        });
                      }}
                      disabled={gettingGasPrices}
                    />
                  </View>

                  {selectedGasPrice.label === 'Advanced' && (
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        marginBottom: 14,
                      }}
                    >
                      <TextInput
                        value={stepPrice}
                        onChangeText={handleChangeStepPrice}
                        key={'step-price'}
                        isDarkMode={isDarkMode}
                        styleInputContainer={{
                          width: 100,
                          height: 44,
                        }}
                        inputStyle={{
                          height: '100%',
                        }}
                        editable={true}
                      />

                      <Text
                        muted
                        style={{
                          marginLeft: 8,
                        }}
                      >
                        GWEI
                      </Text>
                    </View>
                  )}
                  <View
                    style={[
                      styles.separator,
                      isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                    ]}
                  />
                </>
              )}

              {estimatingFeeError ? (
                <DetailsRow
                  type="transaction fee"
                  subtitle={'Failed estimating fee'}
                  isDarkMode={isDarkMode}
                />
              ) : (
                <DetailsRow
                  type="transaction fee"
                  title={
                    !estimatingFeeError && totalFee.eq(0) ? (
                      <ActivityIndicator size={20} color={colors.black} />
                    ) : (
                      `${formatAmount(totalFee)} ${feeSymbol}`
                    )
                  }
                  subtitle={!totalFeeValue ? null : formatPrice(totalFeeValue, false)}
                  isDarkMode={isDarkMode}
                />
              )}
            </View>
          </>
        )}
      </ScrollViewScreen>

      <Button
        working={sending}
        onPress={onSend}
        disabled={!feeHasBeenEstimated && !isNil(estimatingFeeError)}
      >
        Send
      </Button>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  altHeading: {
    marginTop: 8,
    marginBottom: 25,
  },
  subtitle: {
    fontSize: 13,
    color: '#736b88',
    textTransform: 'uppercase',
  },
  separator: {
    height: 1,
    backgroundColor: colors.gray.border,
    marginHorizontal: 0,
  },
  detailsRow: {
    paddingVertical: 20,
  },
  error: {
    backgroundColor: colors.gray.cards,
    borderTopColor: colors.gray.border,
    borderBottomColor: colors.gray.border,
    borderRightColor: colors.gray.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 5,
    borderRadius: 4,
    padding: 15,
    borderLeftColor: colors.negative,
  },
});
