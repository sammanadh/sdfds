import QrScanWhite from '@/assets/icons/qr-scan-white.svg';
import QrScan from '@/assets/icons/qr-scan.svg';
import { AddressBookItem } from '@/components/AddressBook/AddressBookItem';
import { Button, ButtonVariant } from '@/components/Button';
import { CollectableImage } from '@/components/Collectables/CollectableImage';
import { HomeStackParams, RootStackParams, TradeStackParams } from '@/components/Navigation';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { TextInput } from '@/components/TextInput';
import { TokenLogo } from '@/components/TokenLogo';
import { Heading, Text } from '@/components/Typography';
import { TokenWithBalance, useTokens } from '@/hooks/useTokens';
import { Collectable, Collection } from '@/models/Collectable';
import { ChainWallet, RealmChainWallet, Token, Wallet } from '@/models/Vault';
import { serviceForChainWallet } from '@/stores/ChainServices';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chains } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import { getContactsForChain } from '@/utils/contacts';
import { colors } from '@/utils/designTokens';
import { formatNumber, formatPixel } from '@/utils/format';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty, isNil } from 'lodash-es';
import React, { useMemo } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

export interface SendScreenParams {
  wallet: ChainWallet | RealmChainWallet;
  token?: TokenWithBalance;
  collection?: Collection;
  collectable?: Collectable;
  index?: number;
}

type TradeNavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'Send'>,
  StackNavigationProp<RootStackParams>
>;

type HomeNavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'Send'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<TradeStackParams | HomeStackParams, 'Send'>;

export function Send() {
  const {
    params: { wallet, token, collectable, collection },
  } = useRoute<RouteProps>();

  const { isDarkMode } = useTheme();

  const tradeNavigation = useNavigation<TradeNavigationProps>();
  const homeNavigation = useNavigation<HomeNavigationProps>();

  const allTokens = useTokens({ filterByValue: 'contractTokens' });

  const { getActiveWallet, wallets } = useVault();
  const activeWallet = getActiveWallet();

  const chain = chains.find((chain) => chain.id === wallet.type);
  const service = serviceForChainWallet(wallet);
  const network = service?.getNetworkDetails();

  const contacts = React.useMemo(() => {
    return chain && getContactsForChain(chain.id);
  }, [chain]);

  const tokenFromAllTokens = useMemo(() => {
    return allTokens.find((t) => t.contract === token?.contract && t.chainId === token?.chainId);
  }, [allTokens, token]);

  const tokenAsToken = useMemo(() => token as unknown as Token, [token]);
  const balance = useMemo(() => tokenFromAllTokens?.balance || ZERO, [tokenFromAllTokens]);

  const [errorMessage, setErrorMessage] = React.useState<string | null>(null);
  const [toAddress, setToAddress] = React.useState<string>('');

  const isCollectable = collectable && collection;
  const tokenSymbol = token?.symbol || network?.token?.symbol || chain?.token.symbol;

  const assetName = useMemo(() => {
    if (isCollectable) {
      return collectable.name;
    }
    return tokenSymbol;
  }, [collectable, collection, token]);

  const onNext = (address: string, toWallet?: Wallet) => {
    if (service?.isValidAddress(address) === false) {
      setErrorMessage(`Please enter a valid ${chain?.name} address`);
      return;
    }

    if (wallet && service?.isValidAddress(address) === true) {
      if (isCollectable) {
        homeNavigation.navigate('ReviewSendCollectable', {
          wallet,
          collectable,
          collection,
          toAddress: address,
          toWallet,
        });
      } else {
        tradeNavigation.navigate('AmountToSend', {
          wallet,
          toAddress: address,
          token: token!,
          toWallet,
        });
      }
    }
  };

  return (
    <ScrollViewScreen contentContainerStyle={styles.container} keyboardShouldPersistTaps={'always'}>
      {chain && (
        <>
          {isCollectable ? (
            <CollectableImage url={collectable.imageUrl} size={80} forceImage />
          ) : (
            <TokenLogo chain={chain} token={!token?.native ? tokenAsToken : undefined} />
          )}
          <Heading style={styles.heading}>Send {assetName}</Heading>
          {!isCollectable && (
            <Text
              bold
              muted
              style={[styles.quantity, isDarkMode && { color: colors.gray.watermark }]}
            >
              {formatNumber(balance, 4)} {tokenSymbol} available
            </Text>
          )}

          <TextInput
            autoCapitalize="none"
            autoCompleteType="off"
            autoCorrect={false}
            style={{ width: '100%', marginTop: 20 }}
            clearButtonMode="never"
            isDarkMode={isDarkMode}
            labelTitle="Address"
            label={`Recipient's ${tokenSymbol} address`}
            accessory={
              <TouchableOpacity
                onPress={() => {
                  tradeNavigation.navigate('QRCodeScanner', {
                    onScan: (code) => {
                      tradeNavigation.goBack();
                      setToAddress(code);
                    },
                  });
                }}
              >
                {isDarkMode ? <QrScanWhite /> : <QrScan />}
              </TouchableOpacity>
            }
            error={!isEmpty(errorMessage)}
            msgError={errorMessage}
            value={toAddress}
            onChangeText={(text) => setToAddress(text)}
          />
          <Button
            variant={ButtonVariant.Primary}
            style={{ marginTop: formatPixel(20) }}
            onPress={() => onNext(toAddress)}
            hasNextIcon={isCollectable ? false : true}
          >
            Next
          </Button>

          <View style={styles.separator} />

          <Heading style={styles.addressBookHeading}>Address book</Heading>

          {wallets
            .filter((w) => w.id !== activeWallet?.id)
            .filter((w) => !isNil(w.chainWallets.find((cw) => cw.type === chain.id)))
            .map((w) => {
              const chainWallet = w.chainWallets.find((cw) => cw.type === chain.id);
              const toAddress = chainWallet?.address;

              return (
                <AddressBookItem
                  style={styles.addressBookItem}
                  wallet={w}
                  key={chain.id}
                  chainID={chain.id}
                  hasNextIcon
                  showAvatar={false}
                  onPress={() => {
                    toAddress && onNext(toAddress, w);
                  }}
                />
              );
            })}

          {contacts?.map((contact) => (
            <AddressBookItem
              showAvatar={false}
              style={styles.addressBookItem}
              hasNextIcon
              contact={contact}
              onPress={() => {
                const toAddress = contact.address;
                toAddress && onNext(toAddress);
              }}
            />
          ))}
        </>
      )}
    </ScrollViewScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    textAlign: 'center',
    marginTop: 20,
  },
  container: {
    flexDirection: 'column',
    alignItems: 'center',
    paddingTop: 0,
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.gray.border,
    marginTop: 35,
    marginBottom: 35,
    width: '100%',
  },
  addressBookHeading: {
    fontSize: 16,
    width: '100%',
    marginBottom: 13,
  },
  addressBookItem: {
    marginVertical: 7,
    marginHorizontal: 12,
  },
  quantity: {
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 20,
  },
});
