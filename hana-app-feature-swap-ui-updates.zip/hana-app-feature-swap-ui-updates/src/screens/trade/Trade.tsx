import { HomeButton } from '@/components/HomeButton';
import { RootStackParams, SelectTokenType, TradeStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import Button, { ButtonType } from '@/components/Trade/Button';
import { Heading } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { CompositeNavigationProp, useIsFocused, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React from 'react';
import { LayoutAnimation, Platform, StyleSheet } from 'react-native';
import { useVault } from '@/stores/Vault';
import { WalletType } from '@/models/Vault';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'Trade'>,
  StackNavigationProp<RootStackParams>
>;

export function TradeScreen() {
  const navigation = useNavigation<NavigationProps>();

  const isFocused = useIsFocused();
  const { setHideTabBar } = useNavigationStore();

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  React.useEffect(() => {
    if (isFocused) {
      setHideTabBar(false);
    }
  }, [isFocused]);

  return (
    <SafeAreaScreen top padTop={false} bottom={false}>
      <HomeButton />
      <Heading large style={styles.heading}>
        Trade
      </Heading>

      <Button
        type={ButtonType.send}
        onPress={() => {
          Platform.OS === 'ios' &&
            LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          setHideTabBar(true);
          navigation.navigate('SelectToken', {
            type: SelectTokenType.send,
            isTrade: true,
          });
        }}
      />
      <Button
        type={ButtonType.receive}
        onPress={() => {
          Platform.OS === 'ios' &&
            LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          setHideTabBar(true);
          navigation.navigate('SelectToken', {
            type: SelectTokenType.receive,
            isTrade: true,
          });
        }}
      />
      {/* {activeWallet?.type !== WalletType.Ledger && (
        <Button
          type={ButtonType.swap}
          onPress={() => {
            Platform.OS === 'ios' &&
              LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
            setHideTabBar(true);
            navigation.navigate('SwapFrom');
          }}
        />
      )} */}
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginVertical: 25,
    marginHorizontal: 20,
  },
});
