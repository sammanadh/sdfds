import { Button, ButtonVariant } from '@/components/Button';
import { RootStackParams, TradeStackParams } from '@/components/Navigation';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { TextButton } from '@/components/TextButton';
import { TokenLogo } from '@/components/TokenLogo';
import { SendAmountInput } from '@/components/Trade/SendAmountInput';
import { Heading, Text } from '@/components/Typography';
import { useTokens } from '@/hooks/useTokens';
import { TransactionType } from '@/models/Transaction';
import { Token } from '@/models/Vault';
import { SubstrateChainService } from '@/models/ChainService';
import { serviceForChainWallet } from '@/stores/ChainServices';
import { usePrices } from '@/stores/Price';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { BigNumber } from '@/utils/bignumber';
import { ChainID, chains, getSubstrateFeeRoundingDecimals, isSubstrateChain } from '@/utils/chains';
import {
  DEFAULT_DOT_ED,
  DEFAULT_DOT_ESTIMATED_FEE,
  DEFAULT_ICZ_ESTIMATED_FEE,
  MIN_ICX_FOR_TRANSACTION_FEE,
  ZERO,
} from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { formatNumber } from '@/utils/format';
import { tokensForChainWallet } from '@/utils/wallet';
import Checkbox from '@react-native-community/checkbox';
import {
  CompositeNavigationProp,
  RouteProp,
  useIsFocused,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as WebBrowser from 'expo-web-browser';
import { isEmpty } from 'lodash-es';
import React, { useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'AmountToSend'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<TradeStackParams, 'AmountToSend'>;

export function AmountToSend() {
  const {
    params: { wallet, toAddress, token, toWallet },
  } = useRoute<RouteProps>();
  const { navigate } = useNavigation<NavigationProps>();
  const isFocused = useIsFocused();
  const { refreshWalletBalances, getActiveChainWallets } = useVault();
  const { isDarkMode } = useTheme();

  const allTokens = useTokens({ filterByValue: 'contractTokens' });

  const chain = chains.find((chain) => chain.id === wallet.type);
  const service = serviceForChainWallet(wallet);
  const network = service?.getNetworkDetails();

  const isSubstrate = chain ? isSubstrateChain(chain.id) : false;

  const isNativeToken = useMemo(() => token.native, [token]);
  const tokenAsToken = useMemo(() => token as unknown as Token, [token]);

  const tokenFromAllTokens = useMemo(() => {
    return allTokens.find((t) => t.contract === token.contract && t.chainId === token.chainId);
  }, [allTokens, token]);

  const balance = useMemo(() => tokenFromAllTokens?.balance || ZERO, [tokenFromAllTokens]);

  const nativeToken = React.useMemo(
    () =>
      allTokens.find((token) => {
        return token.chainId === wallet.type && token.native;
      }),
    [allTokens]
  );
  const nativeTokenBalance = React.useMemo(() => nativeToken?.balance || ZERO, [nativeToken]);

  const nativeTokenSymbol = React.useMemo(
    () => network?.token?.symbol || chain?.token.symbol,
    [network, chain]
  );

  const symbol = React.useMemo(() => {
    return !token.native ? token.symbol : network?.token?.symbol || chain?.token.symbol || '';
  }, [wallet, token, chain, network]);

  const [inputAmount, setInputAmount] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [estimatedFee, setEstimatedFee] = useState<BigNumber>(MIN_ICX_FOR_TRANSACTION_FEE);
  const [hasEstimatedFee, setHasEstimatedFee] = useState(false);
  const [dotEd, setDotEd] = useState<BigNumber>(DEFAULT_DOT_ED);
  const [estimatedDotFee, setEstimatedDotFee] = useState<BigNumber>(
    chain?.id === ChainID.Arctic ? DEFAULT_ICZ_ESTIMATED_FEE : DEFAULT_DOT_ESTIMATED_FEE
  ); // Used to calculate if amount exceeds Existential Deposit threshold

  const [useMaxAmount, setUseMaxAmount] = useState(false);

  const amountNumber = parseFloat(inputAmount);

  const { getNativePrice, getTokenPrice } = usePrices();

  const price = React.useMemo(() => {
    if (isNativeToken && chain && chain.coinType) {
      return getNativePrice(chain);
    }

    if (!isNativeToken && token.contract) {
      return getTokenPrice(token.contract);
    }

    return ZERO;
  }, [wallet, token, chain]);

  const totalSendValue = amountNumber > 0 ? price.multipliedBy(amountNumber) : ZERO;

  React.useEffect(() => {
    async function getEd() {
      if ((service as SubstrateChainService).getExistentialDepositAmount) {
        const ed = await (service as SubstrateChainService).getExistentialDepositAmount();
        setDotEd(ed);
      }
    }

    if (isSubstrate) {
      getEd();
    }
  }, [service]);

  React.useEffect(() => {
    if (service && chain) {
      const balanceBN = new BigNumber(balance);
      const amount =
        chain.id === ChainID.ICON || chain.id === ChainID.HAVAH
          ? BigNumber.maximum(balanceBN.minus(MIN_ICX_FOR_TRANSACTION_FEE), ZERO)
          : balanceBN;

      let params;

      if (!isNativeToken) {
        params = {
          type: TransactionType.SendToken,
          toAddress,
          amount,
          token: tokenAsToken,
        };
      } else {
        params = {
          type: TransactionType.SendNativeToken,
          toAddress,
          amount,
        };
      }

      service
        ?.estimateTransaction(wallet, params)
        .then((estimate) => {
          if (isSubstrate) {
            if (chain) {
              const feeRoundingDecimals = getSubstrateFeeRoundingDecimals(chain.id);

              setEstimatedDotFee(
                new BigNumber(estimate.price)
                  .div(new BigNumber(10).pow(chain.token.decimals))
                  .decimalPlaces(feeRoundingDecimals, BigNumber.ROUND_UP)
              );
              setHasEstimatedFee(true);
            }

            return;
          }

          setEstimatedFee(estimate.amount.times(estimate.tokenPrice));
          setHasEstimatedFee(true);
        })
        .catch((error) => {
          // Set to true as estimate could fail due to low balance
          setHasEstimatedFee(true);

          console.warn('AmountToSend Failed estimating transaction fee.', error.message);
        });
    }
  }, [service, balance]);

  React.useEffect(() => {
    if (isFocused) {
      refreshWalletBalances();
    }
  }, [isFocused]);

  const isInDangerBelowDotEd = useMemo(() => {
    const tokenBalance = new BigNumber(balance);
    const balanceAfterTransfer = tokenBalance.minus(estimatedDotFee.plus(amountNumber));

    return balanceAfterTransfer.lte(dotEd);
  }, [balance, amountNumber, estimatedDotFee, dotEd]);

  const canProceedWithAmount = useMemo(() => {
    if (isSubstrate && isNativeToken) {
      if (useMaxAmount) {
        return true;
      }

      const tokenBalance = new BigNumber(balance);

      if (new BigNumber(amountNumber).lte(tokenBalance)) {
        return !isInDangerBelowDotEd;
      }
    }

    return true;
  }, [isSubstrate, useMaxAmount, balance, amountNumber, isInDangerBelowDotEd]);

  const showDotEDCheckbox = useMemo(() => {
    if (isSubstrate && isNativeToken) {
      if (useMaxAmount) {
        return true;
      }

      if (new BigNumber(amountNumber).gte(balance) || isInDangerBelowDotEd) {
        return true;
      }
    }

    return false;
  }, [isSubstrate, useMaxAmount, amountNumber, balance, isInDangerBelowDotEd]);

  const maxSendableAmount = useMemo(() => {
    if (isSubstrate && isNativeToken) {
      return new BigNumber(balance).minus(estimatedDotFee);
    } else {
      if (!isNativeToken) {
        return new BigNumber(balance);
      } else {
        return new BigNumber(balance).minus(estimatedFee);
      }
    }
  }, [isSubstrate, balance, token, estimatedFee, useMaxAmount, estimatedDotFee]);

  const hasEnoughNativeTokenForFee = useMemo(() => {
    if (!hasEstimatedFee) return false;

    if (isSubstrate) {
      return new BigNumber(nativeTokenBalance).gt(estimatedDotFee);
    }

    return new BigNumber(nativeTokenBalance).gt(estimatedFee);
  }, [nativeTokenBalance, isSubstrate, estimatedDotFee, estimatedFee, hasEstimatedFee, balance]);

  const onNext = async () => {
    if (amountNumber <= 0) {
      setErrorMessage('Please enter a valid amount');
      return;
    }

    if (!hasEnoughNativeTokenForFee) {
      setErrorMessage(`You don't have enough ${nativeTokenSymbol} for transaction fee`);
      return;
    }

    if (isSubstrate) {
      const minBalanceForTransfer = dotEd.plus(estimatedDotFee);

      if (new BigNumber(balance).lte(minBalanceForTransfer)) {
        setErrorMessage(
          `Your balance is too low. It has to be greater than ${minBalanceForTransfer} ${symbol} before you can make any transfers`
        );
        return;
      }
    }

    // If use Max
    if (useMaxAmount) {
      navigate('ReviewSend', {
        wallet,
        toAddress,
        amount: maxSendableAmount,
        token,
        dotTransferKeepAlive: isSubstrate ? false : undefined,
        toWallet,
        useMaxAmount,
      });
    } else {
      if (new BigNumber(inputAmount).gt(maxSendableAmount)) {
        setErrorMessage(`You don't have enough ${symbol}`);
        return;
      }

      navigate('ReviewSend', {
        wallet,
        toAddress,
        amount: new BigNumber(amountNumber),
        token,
        dotTransferKeepAlive: isSubstrate ? true : undefined,
        toWallet,
      });
    }
  };

  const onMax = () => {
    setUseMaxAmount(true);
    setInputAmount(Number(balance).toFixed(4));
    if (hasEstimatedFee) return;
  };

  const onWhatIsEd = async () => {
    WebBrowser.openBrowserAsync(
      'https://support.polkadot.network/support/solutions/articles/65000168651'
    );
  };

  return (
    <ScrollViewScreen contentContainerStyle={styles.container} keyboardShouldPersistTaps={'always'}>
      {chain && (
        <>
          <TokenLogo chain={chain} token={!isNativeToken ? tokenAsToken : undefined} />

          <Heading style={styles.heading}>Send amount</Heading>
          <Text muted style={styles.quantity}>
            {formatNumber(balance, 4)} {symbol} available
          </Text>

          <SendAmountInput
            symbol={symbol}
            value={inputAmount}
            isDarkMode={isDarkMode}
            onValueChanged={(value) => {
              setInputAmount(value);
              setUseMaxAmount(false);
              setErrorMessage('');
            }}
            maxEnabled={hasEstimatedFee}
            onMax={onMax}
            totalUSD={totalSendValue}
          />

          {!isEmpty(errorMessage) && (
            <Text center small error>
              {errorMessage}
            </Text>
          )}

          {showDotEDCheckbox && (
            <View style={styles.edWarningContainer}>
              <Checkbox
                boxType="square"
                value={useMaxAmount}
                onFillColor="#ffffff"
                onValueChange={(checked) => {
                  if (checked) {
                    onMax();
                  } else {
                    setUseMaxAmount(false);
                  }
                }}
              />

              <View>
                <Text style={[styles.edWarningLabel, isDarkMode && { color: colors.whiteSecond }]}>
                  This transaction will leave less than {dotEd.toString()} {symbol} in your wallet,
                  which will be lost due to it being removed by the network. In this situation, you
                  should send the full balance of your wallet. Learn more about why this is
                  happening, here:
                </Text>

                <TextButton
                  textStyle={isDarkMode ? { color: colors.whiteSecond } : undefined}
                  style={{ marginLeft: 15 }}
                  onPress={onWhatIsEd}
                >
                  What is the "Existential Deposit"?
                </TextButton>
              </View>
            </View>
          )}

          <Button
            variant={ButtonVariant.Primary}
            style={{ marginTop: 30 }}
            onPress={onNext}
            disabled={!inputAmount || !canProceedWithAmount || !hasEstimatedFee}
            hasNextIcon
          >
            Next
          </Button>
        </>
      )}
    </ScrollViewScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 8,
  },
  container: {
    flexDirection: 'column',
    alignItems: 'center',
  },
  edWarningContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 24,
    paddingHorizontal: 15,
  },
  edWarningLabel: {
    marginLeft: 15,
    marginBottom: 15,
  },
  quantity: {
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 40,
  },
});
