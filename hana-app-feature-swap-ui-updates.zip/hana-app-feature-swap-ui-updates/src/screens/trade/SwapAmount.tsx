import { IconInfoCircle } from '@/assets/icons';
import { ActivityIndicator } from '@/components/ActivityIndicator';
import { Button, ButtonVariant } from '@/components/Button';
import { ChangeSlippageModal } from '@/components/ChangeSlippageModal';
import { ChangeSwapProviderModal } from '@/components/ChangeSwapProviderModal';
import { RootStackParams, TradeStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Select } from '@/components/Select';
import { SendAmountInput } from '@/components/Trade/SendAmountInput';
import { SwapAmountHeader } from '@/components/Trade/SwapAmountHeader';
import { AltHeading, Heading, Text } from '@/components/Typography';
import {
  SwapServiceProvider,
  ProviderWithSlippage,
  ProviderWithPriceImpact,
} from '@/models/SwapService';
import { useNavigationStore } from '@/stores/Navigation';
import { useSwapServices } from '@/stores/SwapServices';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chains } from '@/utils/chains';
import { HIT_SLOP_XLARGE, ONE, ZERO } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { formatAmount, formatNumber } from '@/utils/format';
import { dismissModal, presentModal } from '@/utils/modal';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import BigNumber from 'bignumber.js';
import * as WebBrowser from 'expo-web-browser';
import { isEmpty, isNil, isUndefined, intersection } from 'lodash-es';
import debounce from 'lodash/debounce';
import React, { useEffect, useMemo } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';
import { TextInput, TextInputRef } from '@/components/TextInput';
import { isValidPositiveNum } from '@/utils/validation';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'SwapAmount'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<TradeStackParams, 'SwapAmount'>;

const PRICE_IMPACT_THRESHOLD = 0.05;

const slippageOptions = [
  {
    label: '1%',
    slippage: ONE,
  },
  {
    label: '0.5%',
    slippage: new BigNumber(0.5),
  },
  {
    label: '0.25%',
    slippage: new BigNumber(0.25),
  },
  {
    label: 'Advanced',
    slippage: new BigNumber(1),
  },
];

export function SwapAmount() {
  const {
    params: { fromToken, fromSwappable, toToken, toSwappable },
  } = useRoute<RouteProps>();

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  const fromChainWallet = useMemo(() => {
    return activeWallet?.chainWallets.find(
      (chainWallet) => chainWallet.type === fromSwappable.chainId
    );
  }, [activeWallet, fromSwappable]);

  const toChainWallet = useMemo(() => {
    return activeWallet?.chainWallets.find(
      (chainWallet) => chainWallet.type === toSwappable.chainId
    );
  }, [activeWallet, toSwappable]);

  const { navigate } = useNavigation<NavigationProps>();
  const { isDarkMode, styles: themeStyles } = useTheme();
  const { serviceForProvider, refreshSwappableTokensForProvider, swappableTokensForProvider } =
    useSwapServices();
  const chain = useMemo(() => chains.find((chain) => chain.id === fromToken.chainId)!, [fromToken]);

  const [inputAmount, setInputAmount] = React.useState('');
  const [useMaxAmount, setUseMaxAmount] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState<string>('');
  const [hasEstimatedFee, setHasEstimatedFee] = React.useState(false);
  const [fromAmount, setFromAmount] = React.useState(ZERO);
  const [toAmount, setToAmount] = React.useState(ZERO);
  const [priceImpact, setPriceImpact] = React.useState(ZERO);
  const [gettingEstimate, setGettingEstimate] = React.useState(false);
  const [gettingMinAmount, setGettingMinAmount] = React.useState(false);
  const [minAmount, setMinAmount] = React.useState(new BigNumber(Infinity));
  const isLoading = useMemo(
    () => gettingMinAmount || gettingEstimate,
    [gettingMinAmount, gettingEstimate]
  );

  const [slippage, setSlippage] = React.useState(slippageOptions[0].slippage);
  const [selectedSlippageOption, setSelectedSlippageOption] = React.useState(slippageOptions[0]);
  const [showSlippageInputField, setShowSlippageInputField] = React.useState(false);
  const [slippageInputValue, setSlippageInputValue] = React.useState('');

  const [commonProvider, setCommonProvider] = React.useState<SwapServiceProvider>(
    SwapServiceProvider.BalancedNetwork
  );

  const { setToastMessage } = useNavigationStore();

  useEffect(() => {
    setSlippage(selectedSlippageOption.slippage);
    setShowSlippageInputField(selectedSlippageOption.label.toLowerCase() === 'advanced');
  }, [selectedSlippageOption]);

  useEffect(() => {
    const provider = fromSwappable.providers.find((p) => {
      let shouldUseThisProvider = true;
      // If both are on the same chain, do not use Squid
      if (fromToken.chainId === toToken.chainId) {
        shouldUseThisProvider = shouldUseThisProvider && p !== SwapServiceProvider.Squid;
      }

      // If both are on different chain, do not use OneInch
      if (fromToken.chainId !== toToken.chainId) {
        shouldUseThisProvider = shouldUseThisProvider && p !== SwapServiceProvider.OneInch;
      }

      // Prioritize OneInch over ChangeNow
      if (
        p === SwapServiceProvider.ChangeNow &&
        fromSwappable.providers.includes(SwapServiceProvider.OneInch) &&
        toSwappable.providers.includes(SwapServiceProvider.OneInch)
      ) {
        shouldUseThisProvider = false;
      }
      return shouldUseThisProvider && toSwappable.providers.includes(p);
    });

    setCommonProvider(provider!);
  }, [fromSwappable, toSwappable]);

  const availableProviders = useMemo(() => {
    return intersection(fromSwappable.providers, toSwappable.providers);
  }, [fromSwappable.providers]);

  const onMax = () => {
    setUseMaxAmount(true);
    setInputAmount(Number(fromToken.balance).toFixed(4));
    if (hasEstimatedFee) return;
  };

  async function handleGetEstimate(fromAmount: BigNumber) {
    if (!commonProvider) {
      setErrorMessage(`Can't swap ${fromToken.symbol} to ${toToken.symbol}`);
      return;
    }

    if (!toChainWallet || !fromChainWallet) {
      setErrorMessage(`Can't swap ${fromToken.symbol} to ${toToken.symbol}`);
      return;
    }

    setToAmount(ZERO);
    setPriceImpact(ZERO);
    if (fromAmount.lt(minAmount)) return;
    if (fromAmount.lte(ZERO)) return;

    try {
      setGettingEstimate(true);

      const swapService = serviceForProvider(commonProvider);

      if (swapService) {
        const { amount, priceImpactPercent } = await swapService.getEstimate(
          fromSwappable,
          toSwappable,
          fromAmount,
          toChainWallet.address,
          fromChainWallet
        );
        if (!isNil(priceImpactPercent)) {
          setPriceImpact(priceImpactPercent);
        }
        setToAmount(amount);
        setHasEstimatedFee(true);
      }
    } catch (error: any) {
      console.warn(`Failed getting swap estimate.`, error.message);
    }
    setGettingEstimate(false);
  }

  const getEstimateDebounced = useMemo(() => debounce(handleGetEstimate, 300), [minAmount]);

  useEffect(() => {
    if (!commonProvider) {
      setErrorMessage(`Can't swap ${fromToken.symbol} to ${toToken.symbol}`);
      return;
    }

    setGettingMinAmount(true);

    const swapService = serviceForProvider(commonProvider);
    swapService
      ?.getMinAmount(fromSwappable, toSwappable)
      .then((amount) => {
        setMinAmount(amount);
      })
      .catch((error) => {
        console.warn(`Failed getting min amount.`, error.message);
      });
  }, [commonProvider]);

  useEffect(() => {
    if (useMaxAmount) {
      const amount = fromToken.balance;
      setFromAmount(amount);
      getEstimateDebounced(amount);
    } else if (inputAmount) {
      const amount = new BigNumber(inputAmount);
      setFromAmount(amount);
      getEstimateDebounced(amount);
    } else {
      setFromAmount(ZERO);
      getEstimateDebounced(ZERO);
    }
  }, [inputAmount, useMaxAmount, minAmount]);

  function onNext() {
    let slippageToPass = new BigNumber(slippage);

    if (!fromAmount.isPositive()) {
      setErrorMessage('Please enter a valid amount');
      return;
    }

    if (fromAmount.gt(fromToken.balance)) {
      setErrorMessage(`You don't have enough ${fromToken.symbol}`);
      return;
    }

    if (fromAmount.lt(minAmount)) {
      setErrorMessage(`The minimum amount is ${formatNumber(minAmount, 4)} ${fromToken.symbol}`);
      return;
    }

    if (!commonProvider) {
      setErrorMessage(`Can't swap ${fromToken.symbol} to ${toToken.symbol}`);
      return;
    }

    if (showSlippageInputField) {
      if (!isValidPositiveNum(slippageInputValue)) {
        setErrorMessage(`Enter a valid slippage %`);
        return;
      }
      slippageToPass = new BigNumber(slippageInputValue);
    }

    if (fromAmount.gt(ZERO)) {
      navigate('SwapReview', {
        fromToken,
        fromSwappable,
        fromAmount,
        toToken,
        toSwappable,
        toAmount,
        useMaxAmount,
        provider: commonProvider,
        slippage: Object.values(ProviderWithSlippage).includes(commonProvider)
          ? slippageToPass
          : undefined,
      });
    }
  }

  function onReadInfo(commonProvider: SwapServiceProvider) {
    let content = <></>;
    let title = '';
    switch (commonProvider) {
      case SwapServiceProvider.ChangeNow:
        title = 'ChangeNOW';
        content = (
          <>
            <Text>
              ChangeNOW is a simple and fast instant cryptocurrency exchange service. You do not
              need to register, and your exchange will have no limits. We'll quickly convert more
              than 170 coins for you without charging any additional or hidden fees.
            </Text>
            <Text
              style={{
                marginTop: 12,
              }}
            >
              ChangeNOW is integrated into multiple cryptocurrency trading platforms, including
              Binance, Bitfinex, Huobi, OKEx, and Kucoin. At the moment of the trade, we'll choose
              the best exchange rate on the market at any given moment and offer it to you.
            </Text>

            <Text
              bold
              style={{
                color: isDarkMode ? '#CDBEF2' : '#4300AF',
                marginTop: 12,
                marginBottom: 55,
              }}
              onPress={() => {
                WebBrowser.openBrowserAsync('https://changenow.io');
              }}
            >
              changenow.io
            </Text>
          </>
        );
        break;
      case SwapServiceProvider.BalancedNetwork:
        title = 'BalancedNetwork';
        content = (
          <>
            <Text>
              Balanced is DeFi designed for adoption: it’s fast, affordable, and easy to use. 99% of
              crypto investors struggled to use decentralised finance in 20201, so Balanced was
              built from first principles to redefine the experience.
            </Text>
            <Text
              style={{
                marginTop: 12,
              }}
            >
              The Balanced experience revolves around the bnUSD stablecoin and a decentralised
              exchange. Borrow bnUSD or supply liquidity to earn Balance Tokens (BALN), which you
              can lock to increase your earning potential, vote on governance proposals, and
              incentivise liquidity pools.
            </Text>

            <Text
              bold
              style={{
                color: isDarkMode ? '#CDBEF2' : '#4300AF',
                marginTop: 12,
                marginBottom: 55,
              }}
              onPress={() => {
                WebBrowser.openBrowserAsync('https://balanced.network/');
              }}
            >
              balanced.network
            </Text>
          </>
        );
        break;
    }

    presentModal({
      title,
      content,
      options: {
        withCloseButton: true,
      },
    });
  }

  function onSelectProvider() {
    presentModal({
      title: 'Swap Provider',
      content: (
        <ChangeSwapProviderModal
          selectedItem={commonProvider}
          items={availableProviders}
          onChange={(item: SwapServiceProvider) => {
            setCommonProvider(item);
            dismissModal();
          }}
        />
      ),
    });
  }

  function onSelectSlippage() {
    presentModal({
      title: 'Slippage',
      content: (
        <ChangeSlippageModal
          selectedItem={selectedSlippageOption}
          items={slippageOptions}
          onChange={(item) => {
            console.log(item);
            setSelectedSlippageOption(item);
            dismissModal();
          }}
        />
      ),
    });
  }

  function handleSlippageInputChange(text: string) {
    setSlippageInputValue(text);
    setErrorMessage('');
  }

  return (
    <SafeAreaScreen>
      <ScrollViewScreen>
        <View style={styles.container}>
          <SwapAmountHeader
            fromToken={fromToken}
            fromAmount={fromAmount}
            toToken={toToken}
            toAmount={toAmount}
            loading={gettingEstimate}
          />

          <View
            style={{
              alignItems: 'center',
              marginTop: 30,
            }}
          >
            <Heading>Swap amount</Heading>

            <AltHeading style={{ marginTop: 8, marginBottom: 14 }}>
              {formatAmount(fromToken.balance)} {fromToken.symbol} available
            </AltHeading>

            <SendAmountInput
              symbol={fromToken.symbol}
              value={inputAmount}
              isDarkMode={isDarkMode}
              onValueChanged={(value) => {
                setInputAmount(value);
                setUseMaxAmount(false);
                setErrorMessage('');
              }}
              maxEnabled={hasEstimatedFee}
              onMax={onMax}
              totalUSD={ZERO}
            />

            {!isEmpty(errorMessage) && <Text style={styles.errorMessage}>{errorMessage}</Text>}

            <View style={{ flexDirection: 'column', width: '100%', marginTop: 24 }}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  height: 44,
                }}
              >
                <AltHeading>SWAP SERVICE</AltHeading>

                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}
                >
                  {availableProviders.length > 1 ? (
                    <Select
                      placeholder={'Choose Provider'}
                      value={commonProvider ?? ''}
                      onPress={onSelectProvider}
                      style={{ width: '65%', marginLeft: 'auto' }}
                      innerStyle={{ height: 37, paddingLeft: 20 }}
                    />
                  ) : (
                    <Text small bold>
                      {commonProvider}
                    </Text>
                  )}
                  <TouchableOpacity
                    hitSlop={HIT_SLOP_XLARGE}
                    onPress={() => !isUndefined(commonProvider) && onReadInfo(commonProvider)}
                    style={{
                      marginLeft: 8,
                    }}
                  >
                    <IconInfoCircle
                      width={20}
                      height={20}
                      color={isDarkMode ? '#ffffff' : 'rgba(16, 15, 16, 0.8)'}
                    />
                  </TouchableOpacity>
                </View>
              </View>

              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  height: 44,
                }}
              >
                <AltHeading>MINIMUM AMOUNT</AltHeading>
                <Text small bold>
                  {minAmount.toString()}&nbsp;{fromToken.symbol}
                </Text>
              </View>

              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />

              <View
                style={[
                  styles.separator,
                  isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                ]}
              />

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <AltHeading>SLIPPAGE</AltHeading>

                <View
                  style={{
                    flexDirection: 'column',
                    alignItems: 'flex-end',
                    maxWidth: '70%',
                    paddingVertical: 10,
                  }}
                >
                  <Select
                    placeholder={'Choose Slippage'}
                    value={selectedSlippageOption.label}
                    onPress={onSelectSlippage}
                    style={{ width: '65%', marginLeft: 'auto' }}
                    innerStyle={{ height: 37, paddingLeft: 20 }}
                  />
                  {showSlippageInputField && (
                    <View
                      style={{
                        display: 'flex',
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <TextInput
                        styleInputContainer={{ height: 38 }}
                        inputStyle={{ height: 27 }}
                        style={{ padding: 5, height: 38 }}
                        placeholder="Slippage"
                        onChangeText={handleSlippageInputChange}
                      />
                      <Text style={{ marginTop: 10 }} bold>
                        %
                      </Text>
                    </View>
                  )}
                </View>
              </View>

              {!isUndefined(commonProvider) &&
                Object.values(ProviderWithPriceImpact).includes(commonProvider) && (
                  <>
                    <View
                      style={[
                        styles.separator,
                        isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                      ]}
                    />
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        height: 44,
                      }}
                    >
                      <AltHeading>PRICE IMPACT</AltHeading>
                      {!gettingEstimate && priceImpact.isFinite() ? (
                        <Text small bold danger={priceImpact.gte(PRICE_IMPACT_THRESHOLD)}>
                          {formatNumber(priceImpact.times(100), 2)}%
                        </Text>
                      ) : (
                        <ActivityIndicator size={12} />
                      )}
                    </View>
                  </>
                )}
            </View>

            <Button
              variant={ButtonVariant.Primary}
              style={{ marginTop: 30 }}
              onPress={onNext}
              disabled={!inputAmount || !hasEstimatedFee}
              hasNextIcon
            >
              Next
            </Button>
          </View>
        </View>
      </ScrollViewScreen>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  errorMessage: {
    color: colors.red,
    marginTop: 8,
  },
  separator: {
    height: 1,
    backgroundColor: colors.gray.border,
    marginHorizontal: 0,
  },
});
