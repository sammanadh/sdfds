import { RootStackParams, TradeStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { TokenButton } from '@/components/TokenButton';
import { Heading, Text } from '@/components/Typography';
import { TokenWithBalance, useTokens } from '@/hooks/useTokens';
import { SwapServiceProvider } from '@/models/SwapService';
import { useChainServices } from '@/stores/ChainServices';
import { useSwapServices } from '@/stores/SwapServices';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty, isNil } from 'lodash-es';
import React, { useEffect } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'SwapFrom'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<TradeStackParams, 'SwapFrom'>;

export function SwapFrom() {
  const { params } = useRoute<RouteProps>();
  const { navigate } = useNavigation<NavigationProps>();
  const { getActiveWallet } = useVault();
  const { isDarkMode, styles: themeStyles } = useTheme();
  const {
    serviceForProvider,
    refreshSwappableTokensForProvider,
    swappableTokensForProvider,
    services,
    getAllSwappableTokens,
  } = useSwapServices();

  const { connectedChains } = useChainServices();

  const activeWallet = getActiveWallet();

  const allTokens = useTokens({
    filterBySwappable: true,
    filterByValue: true,
    filterByActiveChains: true,
  });

  // console.log("THESE ARE ALLO TOKENS::: ", allTokens)

  const changeNowService = serviceForProvider(SwapServiceProvider.ChangeNow);
  const oneInchService = serviceForProvider(SwapServiceProvider.OneInch);
  const squidService = serviceForProvider(SwapServiceProvider.Squid);
  const balancedService = serviceForProvider(SwapServiceProvider.BalancedNetwork);

  useEffect(() => {
    (async () => {
      if (isEmpty(swappableTokensForProvider(SwapServiceProvider.ChangeNow))) {
        await refreshSwappableTokensForProvider(SwapServiceProvider.ChangeNow, connectedChains);
      }
    })();
  }, [changeNowService]);

  useEffect(() => {
    (async () => {
      if (isEmpty(swappableTokensForProvider(SwapServiceProvider.Squid))) {
        await refreshSwappableTokensForProvider(SwapServiceProvider.Squid, connectedChains);
      }
    })();
  }, [squidService]);

  useEffect(() => {
    (async () => {
      if (isEmpty(swappableTokensForProvider(SwapServiceProvider.OneInch))) {
        await refreshSwappableTokensForProvider(SwapServiceProvider.OneInch, connectedChains);
      }
    })();
  }, [oneInchService]);
  useEffect(() => {
    (async () => {
      if (isEmpty(swappableTokensForProvider(SwapServiceProvider.BalancedNetwork))) {
        await refreshSwappableTokensForProvider(
          SwapServiceProvider.BalancedNetwork,
          connectedChains
        );
      }
    })();
  }, [balancedService]);

  function renderItem({ item, index }: { item: TokenWithBalance; index: number }) {
    const token = item;
    const wallet = activeWallet?.chainWallets.find(
      (chainWallet) => chainWallet.type === token.chainId
    )!;
    return (
      <TokenButton
        key={`${token.chainId}-${token.contract ?? token.symbol}`}
        token={token}
        isTrade
        onPress={() => {
          const swappableTokens = getAllSwappableTokens();

          const fromSwappable = swappableTokens.find(
            (swappable) =>
              swappable.chainId === token.chainId &&
              (swappable.isNative
                ? isNil(token.contract) && isNil(token.assetId)
                : swappable.contract?.toLowerCase() === token.contract?.toLowerCase() ||
                  swappable.contract === token.assetId)
          );

          if (fromSwappable) {
            navigate('SwapTo', {
              fromToken: token,
              fromSwappable,
            });
          }
        }}
      />
    );
  }

  return (
    <SafeAreaScreen>
      <FlatList
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[{ paddingBottom: 30 }, themeStyles.screen]}
        data={allTokens}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
        ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
        ListHeaderComponent={
          <View style={{ paddingBottom: 14 }}>
            <View style={styles.header}>
              <Heading style={styles.heading}>Swap</Heading>
              <Text style={styles.subheading}>Select the token you would like to swap</Text>
            </View>
          </View>
        }
      />
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    width: 336,
    marginTop: 11,
  },
  subheading: {
    color: '#736b88',
  },
  header: {
    paddingTop: 2,
  },
});
