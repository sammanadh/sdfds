import { Button, ButtonSize } from '@/components/Button';
import { RootStackParams, TradeStackParams } from '@/components/Navigation';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { TokenLogo } from '@/components/TokenLogo';
import { Heading, Text } from '@/components/Typography';
import { Token } from '@/models/Vault';
import { serviceForChainWallet } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chains } from '@/utils/chains';
import { formatAddress, formatPixel } from '@/utils/format';
import Clipboard from '@react-native-clipboard/clipboard';
import { CompositeNavigationProp, RouteProp, useRoute } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React from 'react';
import { StyleSheet, View } from 'react-native';
import QRCode from 'react-native-qrcode-svg';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'Receive'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<TradeStackParams, 'Receive'>;

export function Receive() {
  const {
    params: { wallet, token },
  } = useRoute<RouteProps>();
  const { setToastMessage } = useNavigationStore();
  const chain = chains.find((chain) => chain.id === wallet.type);
  const service = serviceForChainWallet(wallet);
  const network = service?.getNetworkDetails();
  const { colors } = useTheme();

  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  const tokenSymbol = token?.symbol || network?.token?.symbol || chain?.token.symbol;

  const address = wallet.address;

  return (
    <>
      <ScrollViewScreen contentContainerStyle={styles.container}>
        {chain && (
          <TokenLogo
            chain={chain}
            token={!token.native ? (token as unknown as Token) : undefined}
            size={68}
          />
        )}

        <Heading style={styles.heading}>Receive {tokenSymbol}</Heading>
        <Text bold muted style={styles.networkName}>
          {activeWallet?.name || ''}
        </Text>

        <View style={[styles.codeContainer, { backgroundColor: colors.gray.cards }]}>
          <QRCode value={address} size={formatPixel(250)} />
        </View>
      </ScrollViewScreen>

      <View
        style={[
          styles.addressContainer,
          { backgroundColor: colors.background, borderColor: colors.gray.meta },
        ]}
      >
        <Text muted style={styles.address}>
          {formatAddress(address)}
        </Text>
        <Button
          size={ButtonSize.Tiny}
          style={[styles.buttonCopy, { backgroundColor: colors.offPurple }]}
          textStyle={{ color: colors.black }}
          onPress={() => {
            Clipboard.setString(address);
            setToastMessage('Address copied');
          }}
        >
          Copy
        </Button>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    alignItems: 'center',
  },
  codeContainer: {
    width: formatPixel(280),
    height: formatPixel(280),
    alignItems: 'center',
    justifyContent: 'center',
  },
  addressContainer: {
    paddingLeft: 20,
    paddingRight: 14,
    flexDirection: 'row',
    width: '100%',
    height: 50,
    borderRadius: 30,
    borderWidth: 2,
    marginBottom: 36,
    alignItems: 'center',
  },
  networkName: {
    marginTop: 8,
    marginBottom: 40,
  },
  heading: {
    marginTop: formatPixel(20),
  },
  address: {
    flex: 1,
    fontSize: formatPixel(16),
  },
  buttonCopy: {
    width: 56,
  },
});
