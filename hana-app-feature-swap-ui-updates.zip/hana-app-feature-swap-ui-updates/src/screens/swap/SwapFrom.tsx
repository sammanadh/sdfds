import { ChainSelect } from '@/components/ChainSelect';
import { TokenButton } from '@/components/TokenButton';
import { Heading, Text } from '@/components/Typography';
import { TokenWithBalance, useTokens } from '@/hooks/useTokens';
import { SwapServiceProvider } from '@/models/SwapService';
import { useChainServices } from '@/stores/ChainServices';
import { useSwapStore } from '@/stores/Swap';
import { useSwapServices } from '@/stores/SwapServices';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import { isEmpty, isNil } from 'lodash-es';
import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';

type Props = {
  onTokenSelect: (token: TokenWithBalance) => void;
  selectedChain: ChainID | null;
  onSelectChain: any;
  onSelectChainClick: any;
};

export function SwapFrom({
  onTokenSelect,
  selectedChain,
  onSelectChain,
  onSelectChainClick,
}: Props) {
  const { styles: themeStyles } = useTheme();
  const { serviceForProvider, refreshSwappableTokensForProvider, swappableTokensForProvider } =
    useSwapServices();
  const { setFromToken } = useSwapStore();

  const { connectedChains } = useChainServices();

  const allTokens = useTokens({
    filterBySwappable: true,
    filterByValue: true,
    filterByActiveChains: true,
  });

  const filteredTokens = useMemo(() => {
    if (isNil(selectedChain)) return allTokens;
    return allTokens.filter((token) => token.chainId === selectedChain);
  }, [selectedChain]);

  const changeNowService = serviceForProvider(SwapServiceProvider.ChangeNow);
  const oneInchService = serviceForProvider(SwapServiceProvider.OneInch);
  const squidService = serviceForProvider(SwapServiceProvider.Squid);
  const balancedService = serviceForProvider(SwapServiceProvider.BalancedNetwork);

  useEffect(() => {
    (async () => {
      if (isEmpty(swappableTokensForProvider(SwapServiceProvider.ChangeNow))) {
        await refreshSwappableTokensForProvider(SwapServiceProvider.ChangeNow, connectedChains);
      }
    })();
  }, [changeNowService]);

  useEffect(() => {
    (async () => {
      if (isEmpty(swappableTokensForProvider(SwapServiceProvider.Squid))) {
        await refreshSwappableTokensForProvider(SwapServiceProvider.Squid, connectedChains);
      }
    })();
  }, [squidService]);

  useEffect(() => {
    (async () => {
      if (isEmpty(swappableTokensForProvider(SwapServiceProvider.OneInch))) {
        await refreshSwappableTokensForProvider(SwapServiceProvider.OneInch, connectedChains);
      }
    })();
  }, [oneInchService]);
  useEffect(() => {
    (async () => {
      if (isEmpty(swappableTokensForProvider(SwapServiceProvider.BalancedNetwork))) {
        await refreshSwappableTokensForProvider(
          SwapServiceProvider.BalancedNetwork,
          connectedChains
        );
      }
    })();
  }, [balancedService]);

  function renderItem({ item, index }: { item: TokenWithBalance; index: number }) {
    const token = item;
    return (
      <TokenButton
        key={`${token.chainId}-${token.contract ?? token.symbol}`}
        token={token}
        isTrade
        onPress={() => {
          onTokenSelect(token);
        }}
      />
    );
  }

  return (
    <FlatList
      showsVerticalScrollIndicator={false}
      contentContainerStyle={[{ paddingBottom: 30 }, themeStyles.screen]}
      data={filteredTokens}
      renderItem={renderItem}
      keyExtractor={(item, index) => index.toString()}
      ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
      ListHeaderComponent={
        <View style={{ paddingBottom: 24 }}>
          <View style={styles.header}>
            <View style={styles.headingRow}>
              <Heading style={styles.heading}>Swap</Heading>

              <ChainSelect
                onClick={onSelectChainClick}
                chain={selectedChain}
                onSelectChain={onSelectChain}
                filterByTokenSupport
              />
            </View>
            <Text style={styles.subheading}>Select the token you would like to swap</Text>
          </View>
        </View>
      }
    />
  );
}

const styles = StyleSheet.create({
  heading: {
    flex: 1,
    marginVertical: 11,
  },
  subheading: {
    color: '#736b88',
  },
  headingRow: {
    display: 'flex',
    flexDirection: 'row',
  },
  header: {
    paddingTop: 2,
  },
});
