import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  IconInfoCircle,
  IconArrowBidirectionalBlack,
  IconArrowBidirectionalLight,
  IconBackWhite,
  IconBack,
  IconClose,
  IconExternalLink,
} from '@/assets/icons';
import { ActivityIndicator } from '@/components/ActivityIndicator';
import { Button, ButtonVariant } from '@/components/Button';
import { ChangeSlippageModal } from '@/components/ChangeSlippageModal';
import { ChangeSwapProviderModal } from '@/components/ChangeSwapProviderModal';
import { RootStackParams, SwapStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Select } from '@/components/Select';
// import { SwapFormHeader } from '@/components/Trade/SwapFormHeader';
import { AltHeading, Heading, Text } from '@/components/Typography';
import {
  SwapServiceProvider,
  ProviderWithSlippage,
  ProviderWithPriceImpact,
  SwappableToken,
  ProviderWithFixedSlippage,
} from '@/models/SwapService';
import { useNavigationStore } from '@/stores/Navigation';
import { useSwapServices } from '@/stores/SwapServices';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import { HIT_SLOP_XLARGE, ONE, ZERO } from '@/utils/constants';
import { colors, paletteDark } from '@/utils/designTokens';
import { formatNumber, formatPixel } from '@/utils/format';
import { dismissModal, presentModal } from '@/utils/modal';
import {
  CompositeNavigationProp,
  RouteProp,
  useIsFocused,
  useNavigation,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import BigNumber from 'bignumber.js';
import * as WebBrowser from 'expo-web-browser';
import { isEmpty, isNil, isUndefined, isEqual } from 'lodash-es';
import debounce from 'lodash/debounce';
import { Dimensions, Linking, Modal, StyleSheet, TouchableOpacity, View } from 'react-native';
import { TextInput } from '@/components/TextInput';
import { isValidPositiveNum } from '@/utils/validation';
import { Footer } from '@/components/Footer';
import { useSwapStore } from '@/stores/Swap';
import { TokenWithBalance, useTokens } from '@/hooks/useTokens';
import { useChainServices } from '@/stores/ChainServices';
import { SwapInput } from '@/components/Swap/SwapInput';
import { ToastType } from '@/components/Toast.types';
import { navigationStyles } from '@/components/Navigation/utils';
import { SwapFrom } from './SwapFrom';
import { SwapTo } from './SwapTo';
import { CloseButton } from '@/components/CloseButton';
import { HamburgerButton } from '@/components/HamburgerButton';
import { common } from '@/utils/styles';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SwapStackParams, 'SwapForm'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SwapStackParams, 'SwapForm'>;

const PRICE_IMPACT_THRESHOLD = 0.05;

const slippageOptions = [
  {
    label: '1%',
    slippage: ONE,
  },
  {
    label: '0.5%',
    slippage: new BigNumber(0.5),
  },
  {
    label: '0.25%',
    slippage: new BigNumber(0.25),
  },
  {
    label: 'Advanced',
    slippage: new BigNumber(1),
  },
];

export function SwapForm({ navigation }: any) {
  const { getActiveWallet } = useVault();
  const activeWallet = getActiveWallet();

  const { fromToken, setFromToken, toToken, setToToken } = useSwapStore();
  const [fromSwappable, setFromSwappable] = useState<SwappableToken>();
  const [toSwappable, setToSwappable] = useState<SwappableToken>();
  const [selectedChain, setSelectedChain] = useState<ChainID | null>(null);

  const fromChainWallet = useMemo(() => {
    if (!fromSwappable) return;
    return activeWallet?.chainWallets.find(
      (chainWallet) => chainWallet.type === fromSwappable.chainId
    );
  }, [activeWallet, fromSwappable]);

  const toChainWallet = useMemo(() => {
    if (!toSwappable) return;
    return activeWallet?.chainWallets.find(
      (chainWallet) => chainWallet.type === toSwappable.chainId
    );
  }, [activeWallet, toSwappable]);

  const isFocused = useIsFocused();
  const { setHideTabBar } = useNavigationStore();

  const { navigate } = useNavigation<NavigationProps>();
  const { isDarkMode, styles: themeStyles } = useTheme();
  const {
    serviceForProvider,
    refreshSwappableTokensForProvider,
    swappableTokensForProvider,
    getAllSwappableTokens,
    getPossibleSwapsForToken,
  } = useSwapServices();

  const [inputAmount, setInputAmount] = React.useState<string>('');
  const [useMaxAmount, setUseMaxAmount] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState<string>('');
  const [hasEstimatedFee, setHasEstimatedFee] = React.useState(false);
  const [fromAmount, setFromAmount] = useState(ZERO);
  const [toAmount, setToAmount] = useState(ZERO);
  const [priceImpact, setPriceImpact] = React.useState(ZERO);
  const [gettingEstimate, setGettingEstimate] = React.useState(false);
  const [gettingMinAmount, setGettingMinAmount] = React.useState(false);
  const [minAmount, setMinAmount] = React.useState(new BigNumber(Infinity));

  const [slippage, setSlippage] = React.useState(slippageOptions[0].slippage);
  const [selectedSlippageOption, setSelectedSlippageOption] = React.useState(slippageOptions[0]);
  const [showSlippageInputField, setShowSlippageInputField] = React.useState(false);
  const [slippageInputValue, setSlippageInputValue] = React.useState('');
  const [allSwappableTokensLoaded, setAllSwappableTokensLoaded] = useState<boolean>(false);
  const [showDefaultTokenPair, setShouldHowDefaultTokenPair] = useState<boolean>(false);
  const [showFromTokenSelectionModal, setShowFromTokenSelectionModal] = useState<boolean>(false);
  const [showToTokenSelectionModal, setShowToTokenSelectionModal] = useState<boolean>(false);

  const [commonProvider, setCommonProvider] = React.useState<SwapServiceProvider>(
    SwapServiceProvider.BalancedNetwork
  );

  const { setToastMessage } = useNavigationStore();

  // -------- FROM HERE
  const { connectedChains } = useChainServices();

  const allSwappableTokens = useTokens({
    filterBySwappable: true,
    filterByValue: true,
    filterByActiveChains: true,
  });

  const changeNowService = serviceForProvider(SwapServiceProvider.ChangeNow);
  const oneInchService = serviceForProvider(SwapServiceProvider.OneInch);
  const squidService = serviceForProvider(SwapServiceProvider.Squid);
  const balancedService = serviceForProvider(SwapServiceProvider.BalancedNetwork);

  React.useEffect(() => {
    if (isFocused) {
      setHideTabBar(true);
      resetAmounts();
    }
  }, [isFocused]);

  useEffect(() => {
    (async () => {
      const refreshSwappableTokensPromises = [];
      if (
        !!changeNowService &&
        isEmpty(swappableTokensForProvider(SwapServiceProvider.ChangeNow))
      ) {
        refreshSwappableTokensPromises.push(
          await refreshSwappableTokensForProvider(
            SwapServiceProvider.ChangeNow,
            connectedChains
          ).catch((err) => {})
        );
      }
      if (!!squidService && isEmpty(swappableTokensForProvider(SwapServiceProvider.Squid))) {
        refreshSwappableTokensPromises.push(
          await refreshSwappableTokensForProvider(SwapServiceProvider.Squid, connectedChains).catch(
            (err) => {}
          )
        );
      }
      if (!!oneInchService || isEmpty(swappableTokensForProvider(SwapServiceProvider.OneInch))) {
        refreshSwappableTokensPromises.push(
          await refreshSwappableTokensForProvider(
            SwapServiceProvider.OneInch,
            connectedChains
          ).catch((err) => {})
        );
      }
      if (
        !!balancedService ||
        isEmpty(swappableTokensForProvider(SwapServiceProvider.BalancedNetwork))
      ) {
        refreshSwappableTokensPromises.push(
          await refreshSwappableTokensForProvider(
            SwapServiceProvider.BalancedNetwork,
            connectedChains
          ).catch((err) => {})
        );
      }

      await Promise.all(refreshSwappableTokensPromises).finally(() => {
        setAllSwappableTokensLoaded(true);
      });
    })();
  }, [changeNowService, oneInchService, squidService, balancedService]);

  useEffect(() => {
    if (!fromToken && allSwappableTokensLoaded && !isEmpty(allSwappableTokens)) {
      setShouldHowDefaultTokenPair(true);
      const icxToken = allSwappableTokens.find(
        (t) => t.symbol === 'ICX' && t.chainId === ChainID.ICON
      );
      if (icxToken) setFromToken(icxToken);
      else setFromToken(allSwappableTokens[0]);
    }
  }, [allSwappableTokens, fromToken, allSwappableTokensLoaded]);

  useEffect(() => {
    if (!fromToken) return;
    const swappableTokens = getAllSwappableTokens();

    const fromSwappable = swappableTokens.find(
      (swappable) =>
        swappable.chainId === fromToken.chainId &&
        (swappable.isNative
          ? isNil(fromToken.contract) && isNil(fromToken.assetId)
          : swappable.contract?.toLowerCase() === fromToken.contract?.toLowerCase() ||
            swappable.contract === fromToken.assetId)
    );

    setFromSwappable(fromSwappable);
  }, [fromToken]);

  const resetAmounts = () => {
    setInputAmount('');
    setFromAmount(ZERO);
    setToAmount(ZERO);
  };

  const toSwappables = useMemo(() => {
    if (!fromSwappable) return;
    const toTokens = getPossibleSwapsForToken(fromSwappable);
    return toTokens;
  }, [fromSwappable]);

  const swappableTokens = useMemo(() => {
    return allSwappableTokens.filter((token) => {
      return toSwappables?.some(
        (swappable) =>
          swappable.chainId === token.chainId &&
          (swappable.isNative
            ? isNil(token.contract)
            : swappable.contract?.toLowerCase() === token.contract?.toLowerCase())
      );
    });
  }, [toSwappables, allSwappableTokens]);

  const swappableTokenRef = useRef<TokenWithBalance[]>();

  useEffect(() => {
    if (isEqual(swappableTokens, swappableTokenRef.current)) return;
    swappableTokenRef.current = swappableTokens;
    if (!isEmpty(swappableTokens)) {
      if (showDefaultTokenPair) {
        setShouldHowDefaultTokenPair(false);
        const bnUSDToken = swappableTokens.find(
          (t) => t.symbol === 'bnUSD' && t.chainId === ChainID.ICON
        );
        if (bnUSDToken) return setToToken(bnUSDToken);
      }
      setToToken(swappableTokens[0]);
    }
  }, [swappableTokens]);

  useEffect(() => {
    if (!toToken) return;
    const toSwappable = toSwappables?.find(
      (swappable) =>
        swappable.chainId === toToken.chainId &&
        (swappable.isNative
          ? isNil(toToken.contract)
          : swappable.contract?.toLocaleLowerCase() === toToken.contract?.toLowerCase())
    );

    setToSwappable(toSwappable);
  }, [toToken]);

  useEffect(() => {
    setSlippage(selectedSlippageOption.slippage);
    setShowSlippageInputField(selectedSlippageOption.label.toLowerCase() === 'advanced');
  }, [selectedSlippageOption]);

  const availableProviders: Array<SwapServiceProvider> = useMemo(() => {
    if (!fromSwappable || !toSwappable || !fromToken || !toToken) return [];
    return fromSwappable.providers.filter((p) => {
      let shouldUseThisProvider = true;
      // If both are on the same chain, do not use Squid
      if (fromToken.chainId === toToken.chainId) {
        shouldUseThisProvider = shouldUseThisProvider && p !== SwapServiceProvider.Squid;
      }

      // If both are on different chain, do not use OneInch
      if (fromToken.chainId !== toToken.chainId) {
        shouldUseThisProvider = shouldUseThisProvider && p !== SwapServiceProvider.OneInch;
      }

      return shouldUseThisProvider && toSwappable.providers.includes(p);
    });
  }, [fromSwappable, toSwappable, fromToken, toToken]);

  useEffect(() => {
    const provider = availableProviders[0];

    // Prioritize OneInch over ChangeNow
    if (
      provider === SwapServiceProvider.ChangeNow &&
      availableProviders.includes(SwapServiceProvider.OneInch)
    ) {
      return setCommonProvider(SwapServiceProvider.OneInch);
    }

    setCommonProvider(provider!);
  }, [availableProviders]);

  const onMax = () => {
    setUseMaxAmount(true);
    setInputAmount(Number(fromToken?.balance).toFixed(4));
    if (hasEstimatedFee) return;
  };

  async function handleGetEstimate(fromAmount: BigNumber) {
    if (!fromToken || !toToken) return;
    if (!commonProvider) {
      setErrorMessage(`Can't swap ${fromToken?.symbol} to ${toToken?.symbol}`);
      return;
    }

    if (!toChainWallet || !fromChainWallet) {
      setErrorMessage(`Can't swap ${fromToken?.symbol} to ${toToken?.symbol}`);
      return;
    }

    setToAmount(ZERO);
    setPriceImpact(ZERO);
    // if (fromAmount.lt(minAmount)) return;
    if (fromAmount.lte(ZERO)) return;

    try {
      setGettingEstimate(true);

      const swapService = serviceForProvider(commonProvider);

      if (swapService && fromSwappable && toSwappable) {
        const { amount, priceImpactPercent } = await swapService.getEstimate(
          fromSwappable,
          toSwappable,
          fromAmount,
          toChainWallet.address,
          fromChainWallet
        );
        if (!isNil(priceImpactPercent)) {
          setPriceImpact(priceImpactPercent);
        }
        setToAmount(amount);
        setHasEstimatedFee(true);
      }
    } catch (error: any) {
      console.warn(`Failed getting swap estimate.`, error.message);
    } finally {
      setGettingEstimate(false);
    }
  }

  const getEstimateDebounced = useMemo(() => debounce(handleGetEstimate, 300), [minAmount]);

  useEffect(() => {
    if (!fromSwappable || !toSwappable) return;

    if (!commonProvider) {
      return;
    }

    setGettingMinAmount(true);

    const swapService = serviceForProvider(commonProvider);
    swapService
      ?.getMinAmount(fromSwappable, toSwappable)
      .then((amount) => {
        setMinAmount(amount);
      })
      .catch((error) => {
        console.warn(`Failed getting min amount.`, error.message);
      });
  }, [commonProvider, fromSwappable, toSwappable]);

  useEffect(() => {
    if (!errorMessage) return;
    setToastMessage(errorMessage, ToastType.error);
    setErrorMessage('');
  }, [errorMessage]);

  useEffect(() => {
    if (useMaxAmount && fromToken) {
      const amount = fromToken.balance;
      setFromAmount(amount);
      getEstimateDebounced(amount);
    } else if (inputAmount) {
      const amount = new BigNumber(inputAmount);
      setFromAmount(amount);
      getEstimateDebounced(amount);
    } else {
      setFromAmount(ZERO);
      getEstimateDebounced(ZERO);
    }
  }, [inputAmount, useMaxAmount, minAmount, fromToken]);

  function onNext() {
    if (!fromToken || !toToken || !fromSwappable || !toSwappable) return;
    let slippageToPass = new BigNumber(slippage);

    if (!fromAmount.isPositive()) {
      setErrorMessage('Please enter a valid amount');
      return;
    }

    if (fromAmount.gt(fromToken.balance)) {
      setErrorMessage(`You don't have enough ${fromToken.symbol}`);
      return;
    }

    if (fromAmount.lt(minAmount)) {
      setErrorMessage(`The minimum amount is ${formatNumber(minAmount, 4)} ${fromToken.symbol}`);
      return;
    }

    if (!commonProvider) {
      setErrorMessage(`Can't swap ${fromToken.symbol} to ${toToken.symbol}`);
      return;
    }

    if (showSlippageInputField) {
      if (!isValidPositiveNum(slippageInputValue)) {
        setErrorMessage(`Enter a valid slippage %`);
        return;
      }
      slippageToPass = new BigNumber(slippageInputValue);
    }

    if (fromAmount.gt(ZERO)) {
      navigate('SwapReview', {
        fromToken,
        fromSwappable,
        fromAmount,
        toToken,
        toSwappable,
        toAmount,
        useMaxAmount,
        provider: commonProvider,
        slippage: Object.values(ProviderWithSlippage).includes(commonProvider)
          ? slippageToPass
          : undefined,
      });
    }
  }

  function onReadInfo(commonProvider: SwapServiceProvider) {
    let content = <></>;
    let title = '';
    switch (commonProvider) {
      case SwapServiceProvider.ChangeNow:
        title = 'ChangeNOW';
        content = (
          <>
            <Text>
              ChangeNOW is a simple and fast instant cryptocurrency exchange service. You do not
              need to register, and your exchange will have no limits. We'll quickly convert more
              than 170 coins for you without charging any additional or hidden fees.
            </Text>
            <Text
              style={{
                marginTop: 12,
              }}
            >
              ChangeNOW is integrated into multiple cryptocurrency trading platforms, including
              Binance, Bitfinex, Huobi, OKEx, and Kucoin. At the moment of the trade, we'll choose
              the best exchange rate on the market at any given moment and offer it to you.
            </Text>

            <Text
              bold
              style={{
                color: isDarkMode ? '#CDBEF2' : '#4300AF',
                marginTop: 12,
                marginBottom: 55,
              }}
              onPress={() => {
                WebBrowser.openBrowserAsync('https://changenow.io');
              }}
            >
              changenow.io
            </Text>
          </>
        );
        break;
      case SwapServiceProvider.BalancedNetwork:
        title = 'BalancedNetwork';
        content = (
          <>
            <Text>
              Balanced is DeFi designed for adoption: it’s fast, affordable, and easy to use. 99% of
              crypto investors struggled to use decentralised finance in 20201, so Balanced was
              built from first principles to redefine the experience.
            </Text>
            <Text
              style={{
                marginTop: 12,
              }}
            >
              The Balanced experience revolves around the bnUSD stablecoin and a decentralised
              exchange. Borrow bnUSD or supply liquidity to earn Balance Tokens (BALN), which you
              can lock to increase your earning potential, vote on governance proposals, and
              incentivise liquidity pools.
            </Text>

            <Text
              bold
              style={{
                color: isDarkMode ? '#CDBEF2' : '#4300AF',
                marginTop: 12,
                marginBottom: 55,
              }}
              onPress={() => {
                WebBrowser.openBrowserAsync('https://balanced.network/');
              }}
            >
              balanced.network
            </Text>
          </>
        );
        break;
      case SwapServiceProvider.OneInch:
        title = 'OneInch';
        content = (
          <>
            <Text>
              The 1inch exchange aggregator is a cutting-edge discovery and routing algorithm, which
              offers asset exchanges at the best rates on the market. Its pathfinder algorithm finds
              the most efficient paths for a token swap, able to split between different protocols
              and even different market depths in within one protocol in the shortest possible time.
            </Text>
            <Text
              bold
              style={{
                color: isDarkMode ? '#CDBEF2' : '#4300AF',
                marginTop: 12,
                marginBottom: 55,
              }}
              onPress={() => {
                WebBrowser.openBrowserAsync('https://1inch.io/');
              }}
            >
              1inch.io
            </Text>
          </>
        );
        break;
    }

    presentModal({
      title,
      content,
      options: {
        withCloseButton: true,
      },
    });
  }

  function onSelectProvider() {
    presentModal({
      title: 'Swap Provider',
      content: (
        <ChangeSwapProviderModal
          selectedItem={commonProvider}
          items={availableProviders}
          onChange={(item: SwapServiceProvider) => {
            setCommonProvider(item);
            dismissModal();
          }}
        />
      ),
    });
  }

  function onSelectSlippage() {
    presentModal({
      title: 'Slippage',
      content: (
        <ChangeSlippageModal
          selectedItem={selectedSlippageOption}
          items={slippageOptions}
          onChange={(item) => {
            console.log(item);
            setSelectedSlippageOption(item);
            dismissModal();
          }}
        />
      ),
    });
  }

  function handleSlippageInputChange(text: string) {
    setSlippageInputValue(text);
    setErrorMessage('');
  }

  function interchangeTokens() {
    if (!fromToken || !toToken || !fromSwappable || !toSwappable) return;
    const tempToken = { ...fromToken };
    const tempSwappable = { ...fromSwappable };

    setFromToken(toToken);
    setToToken(tempToken);

    setFromSwappable(toSwappable);
    setToSwappable(tempSwappable);
  }

  const onSelectChain = (selectedChain: ChainID) => {
    setShowFromTokenSelectionModal(true);
    setSelectedChain(selectedChain);
  };

  const onChainSelected = () => {
    setShowFromTokenSelectionModal(false);
    setSelectedChain(null);
  };

  return (
    <SafeAreaScreen top padTop={false} bottom={false}>
      <ScrollViewScreen>
        <View style={styles.scrollViewContainer}>
          <View style={[navigationStyles.headerRight, styles.headerBar]}>
            <View>
              <TouchableOpacity onPress={() => navigation.goBack()}>
                {isDarkMode ? <IconBackWhite /> : <IconBack />}
              </TouchableOpacity>
            </View>

            <View style={common.negateScreen}>
              <HamburgerButton isDarkMode={isDarkMode} />
            </View>
          </View>
          <View style={styles.header}>
            <Heading style={styles.heading}>Swap</Heading>
            <View style={styles.subheader}>
              <Text style={styles.subheading}>The quickest swaps directly in your wallet</Text>
              <TouchableOpacity
                onPress={() => {
                  Linking.openURL('https://docs.hanawallet.io/using-hana/swaps');
                }}
              >
                <IconExternalLink
                  width={20}
                  height={20}
                  color={isDarkMode ? 'white' : 'black'}
                  style={styles.externalLinkImg}
                />
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.swapInputcontiner}>
            {fromToken && (
              <SwapInput
                token={fromToken}
                value={inputAmount}
                onValueChanged={(val) => {
                  setInputAmount(val);
                }}
                onSelectToken={() => {
                  setShowFromTokenSelectionModal(true);
                }}
                isDarkMode={isDarkMode}
                title={'You pay'}
                editable={true}
                onBalanceClick={() => {
                  setInputAmount(formatNumber(fromToken.balance, 4));
                }}
              />
            )}
            <View style={styles.swapInputSeperator}>
              <View
                style={[
                  !isDarkMode
                    ? { borderColor: colors.white }
                    : { borderColor: paletteDark.blacker },
                ]}
              >
                <TouchableOpacity onPress={interchangeTokens}>
                  {isDarkMode ? (
                    <IconArrowBidirectionalLight style={styles.bidirectionalArrow} />
                  ) : (
                    <IconArrowBidirectionalBlack style={styles.bidirectionalArrow} />
                  )}
                </TouchableOpacity>
              </View>
            </View>
            {toToken && fromToken && fromSwappable && (
              <SwapInput
                token={toToken}
                value={
                  !!inputAmount
                    ? (toAmount.isGreaterThan(new BigNumber(1))
                        ? toAmount.dp(2, BigNumber.ROUND_FLOOR)
                        : toAmount.dp(4, BigNumber.ROUND_FLOOR)
                      ).toString()
                    : ''
                }
                onValueChanged={() => {}}
                onSelectToken={() => {
                  setShowToTokenSelectionModal(true);
                }}
                isDarkMode={isDarkMode}
                title={'You receive'}
                editable={false}
                amountLoading={gettingEstimate}
              />
            )}
          </View>
          <View style={{ flexDirection: 'column', width: '100%', marginTop: 24 }}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                height: 44,
              }}
            >
              <AltHeading>SWAP SERVICE</AltHeading>

              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                }}
              >
                {availableProviders.length > 1 ? (
                  <Select
                    placeholder={'Choose Provider'}
                    value={commonProvider ?? ''}
                    onPress={onSelectProvider}
                    style={{ width: '65%', marginLeft: 'auto' }}
                    innerStyle={{ height: 37, paddingLeft: 20 }}
                  />
                ) : (
                  <Text small bold>
                    {commonProvider}
                  </Text>
                )}
                <TouchableOpacity
                  hitSlop={HIT_SLOP_XLARGE}
                  onPress={() => !isUndefined(commonProvider) && onReadInfo(commonProvider)}
                  style={{
                    marginLeft: 8,
                  }}
                >
                  <IconInfoCircle
                    width={20}
                    height={20}
                    color={isDarkMode ? '#ffffff' : 'rgba(16, 15, 16, 0.8)'}
                  />
                </TouchableOpacity>
              </View>
            </View>

            <View
              style={[
                styles.separator,
                isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
              ]}
            />

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                height: 44,
              }}
            >
              <AltHeading>MINIMUM AMOUNT</AltHeading>
              <Text small bold>
                {minAmount.toString()}&nbsp;{fromToken?.symbol}
              </Text>
            </View>

            <View
              style={[
                styles.separator,
                isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
              ]}
            />

            <View
              style={[
                styles.separator,
                isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
              ]}
            />

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <AltHeading>SLIPPAGE</AltHeading>

              <View
                style={{
                  flexDirection: 'column',
                  alignItems: 'flex-end',
                  maxWidth: '70%',
                  paddingVertical: 10,
                }}
              >
                {!isUndefined(commonProvider) &&
                  (Object.values(ProviderWithFixedSlippage || {}).includes(commonProvider) ? (
                    <Text>{selectedSlippageOption.label}</Text>
                  ) : (
                    <>
                      <Select
                        placeholder={'Choose Slippage'}
                        value={selectedSlippageOption.label}
                        onPress={onSelectSlippage}
                        style={{ width: '65%', marginLeft: 'auto' }}
                        innerStyle={{ height: 37, paddingLeft: 20 }}
                      />
                      {showSlippageInputField && (
                        <View
                          style={{
                            display: 'flex',
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <TextInput
                            styleInputContainer={{ height: 38 }}
                            inputStyle={{ height: 27 }}
                            style={{ padding: 5, height: 38 }}
                            placeholder="Slippage"
                            onChangeText={handleSlippageInputChange}
                          />
                          <Text style={{ marginTop: 10 }} bold>
                            %
                          </Text>
                        </View>
                      )}
                    </>
                  ))}
              </View>
            </View>

            {!isUndefined(commonProvider) &&
              Object.values(ProviderWithPriceImpact).includes(commonProvider) && (
                <>
                  <View
                    style={[
                      styles.separator,
                      isDarkMode && { backgroundColor: colors.gray.breakLineDarkMode },
                    ]}
                  />
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      height: 44,
                    }}
                  >
                    <AltHeading>PRICE IMPACT</AltHeading>
                    {!gettingEstimate && priceImpact.isFinite() ? (
                      <Text small bold danger={priceImpact.gte(PRICE_IMPACT_THRESHOLD)}>
                        {formatNumber(priceImpact.times(100), 2)}%
                      </Text>
                    ) : (
                      <ActivityIndicator size={12} />
                    )}
                  </View>
                </>
              )}
          </View>
        </View>
      </ScrollViewScreen>
      <View style={styles.scrollViewContainer}>
        <Footer>
          <Button
            variant={ButtonVariant.Primary}
            onPress={onNext}
            disabled={!inputAmount || !hasEstimatedFee}
            hasNextIcon
          >
            Review
          </Button>
        </Footer>
      </View>

      {/* From Token Modal */}
      <Modal
        animationType="slide"
        visible={showFromTokenSelectionModal}
        onRequestClose={onChainSelected}
      >
        <View
          style={{
            ...styles.modalContent,
            backgroundColor: !isDarkMode ? colors.white : paletteDark.blacker,
          }}
        >
          <View style={styles.modalHeader}>
            <CloseButton onPress={onChainSelected} />
          </View>
          <SwapFrom
            onTokenSelect={(token) => {
              setFromToken(token);
              onChainSelected();
            }}
            selectedChain={selectedChain}
            onSelectChain={onSelectChain}
            onSelectChainClick={onChainSelected}
          />
        </View>
      </Modal>

      {/* To Token Modal */}
      {!!fromToken && !!fromSwappable && (
        <Modal
          animationType="slide"
          visible={showToTokenSelectionModal}
          onRequestClose={() => {
            setShowToTokenSelectionModal(false);
          }}
        >
          <View
            style={{
              ...styles.modalContent,
              backgroundColor: !isDarkMode ? colors.white : paletteDark.blacker,
            }}
          >
            <View style={styles.modalHeader}>
              <CloseButton onPress={() => setShowToTokenSelectionModal(false)} />
            </View>
            <SwapTo
              fromToken={fromToken}
              fromSwappable={fromSwappable}
              onTokenSelect={(token) => {
                setToToken(token);
                setShowToTokenSelectionModal(false);
              }}
            />
          </View>
        </Modal>
      )}
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  scrollViewContainer: {
    flexGrow: 1,
    paddingHorizontal: 20,
  },
  subheading: {
    color: '#736b88',
  },
  externalLinkImg: {
    color: '#736b88',
  },
  subheader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
    marginBottom: 14,
  },
  header: {
    marginBottom: 10,
    marginTop: -10,
  },
  heading: {
    width: 336,
    marginTop: 9,
  },
  swapInputcontiner: {
    flexDirection: 'column',
  },
  swapInputSeperator: {
    width: '100%',
    maxHeight: formatPixel(10),
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'visible',
    zIndex: 1,
  },
  bidirectionalArrow: {
    height: 18,
  },
  container: {
    flex: 1,
  },
  errorMessage: {
    color: colors.red,
    marginTop: 8,
  },
  separator: {
    height: 1,
    backgroundColor: colors.gray.border,
    marginHorizontal: 0,
  },
  headerBar: {
    marginBottom: 35,
  },
  modalHeader: {
    display: 'flex',
    alignItems: 'flex-end',
    marginTop: 22,
  },
  modalContent: {
    paddingHorizontal: 20,
    height: '100%',
    width: '100%',
  },
});
