import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { TokenButton } from '@/components/TokenButton';
import { TokenLogo } from '@/components/TokenLogo';
import { Heading, Text } from '@/components/Typography';
import { TokenWithBalance, useTokens } from '@/hooks/useTokens';
import { SwappableToken } from '@/models/SwapService';
import { Token } from '@/models/Vault';
import { useSwapStore } from '@/stores/Swap';
import { useSwapServices } from '@/stores/SwapServices';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chains } from '@/utils/chains';
import { isNil } from 'lodash-es';
import React, { useMemo } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';

type Props = {
  fromToken: TokenWithBalance;
  fromSwappable: SwappableToken;
  onTokenSelect: (token: TokenWithBalance) => void;
};

export function SwapTo({ fromToken, fromSwappable, onTokenSelect }: Props) {
  const { getActiveWallet } = useVault();
  const { styles: themeStyles } = useTheme();
  const { getPossibleSwapsForToken } = useSwapServices();
  const { setToToken } = useSwapStore();
  const chain = useMemo(() => chains.find((chain) => chain.id === fromToken.chainId)!, [fromToken]);

  const activeWallet = getActiveWallet();

  const toSwappables = useMemo(() => {
    const toTokens = getPossibleSwapsForToken(fromSwappable);
    return toTokens;
  }, []);

  const allSwappableTokens = useTokens({
    filterBySwappable: true,
    filterByActiveChains: false,
  });

  const swappableTokens = useMemo(
    () =>
      allSwappableTokens.filter((token) =>
        toSwappables.some(
          (swappable) =>
            swappable.chainId === token.chainId &&
            (swappable.isNative
              ? isNil(token.contract)
              : swappable.contract?.toLowerCase() === token.contract?.toLowerCase())
        )
      ),
    [fromSwappable, toSwappables, allSwappableTokens]
  );

  function renderItem({ item, index }: { item: TokenWithBalance; index: number }) {
    const token = item;
    const wallet = activeWallet?.chainWallets.find(
      (chainWallet) => chainWallet.type === token.chainId
    )!;
    return (
      <TokenButton
        key={`${token.chainId}-${token.contract ?? token.symbol}`}
        token={token}
        isTrade
        showBalance={false}
        onPress={() => {
          onTokenSelect(token);
        }}
      />
    );
  }

  return (
    <SafeAreaScreen>
      <FlatList
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[{ paddingBottom: 30 }, themeStyles.screen]}
        data={swappableTokens}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
        ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
        ListHeaderComponent={
          <View style={{ paddingBottom: 30 }}>
            <View style={styles.header}>
              <TokenLogo
                chain={chain}
                token={!fromToken.native ? (fromToken as unknown as Token) : undefined}
              />
              <Heading style={styles.heading}>Swap {fromToken.symbol}</Heading>
              <Text style={styles.subheading}>What do you want to swap {fromToken.symbol} to?</Text>
            </View>
          </View>
        }
      />
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginTop: 11,
  },
  subheading: {
    color: '#736b88',
  },
  header: {
    paddingTop: 2,
    alignItems: 'center',
  },
});
