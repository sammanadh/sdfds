import { IconBack, IconBackWhite } from '@/assets/icons';
import { RootStackParams, TradeStackParams } from '@/components/Navigation';
import { Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { BarCodeScanner } from 'expo-barcode-scanner';
import * as StatusBar from 'expo-status-bar';
import React, { useEffect, useLayoutEffect, useState } from 'react';
import { Button, StyleSheet, TouchableOpacity, View } from 'react-native';

type RouteProps = RouteProp<TradeStackParams, 'QRCodeScanner'>;

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<TradeStackParams, 'QRCodeScanner'>,
  StackNavigationProp<RootStackParams>
>;

export function QRCodeScanner() {
  const {
    params: { onScan },
  } = useRoute<RouteProps>();

  const [hasPermission, setHasPermission] = useState(false);
  const [scanned, setScanned] = useState(false);
  const { goBack, navigate, setOptions } = useNavigation<NavigationProps>();
  const { setHideTabBar } = useNavigationStore();
  const { isDarkMode } = useTheme();

  useLayoutEffect(() => {
    setOptions({
      headerLeft: () => (
        <TouchableOpacity
          style={{ width: 55, height: 45, alignItems: 'center', justifyContent: 'center' }}
          onPress={() => {
            setHideTabBar(true);
            goBack();
          }}
        >
          {isDarkMode ? <IconBackWhite /> : <IconBack />}
        </TouchableOpacity>
      ),
    });
  }, [isDarkMode]);

  useEffect(() => {
    StatusBar.setStatusBarStyle('light');
    return () => {
      StatusBar.setStatusBarStyle(isDarkMode ? 'light' : 'dark');
    };
  }, []);

  useEffect(() => {
    (async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  const handleBarCodeScanned = (result: any) => {
    const { type, data } = result;
    setScanned(true);
    onScan(data);
  };

  if (hasPermission === null) {
    return <Text>Requesting for camera permission</Text>;
  }
  if (hasPermission === false) {
    return (
      <Text
        style={{
          alignSelf: 'center',
          marginTop: 40,
        }}
      >
        No access to camera
      </Text>
    );
  }

  return (
    <View style={styles.container}>
      <BarCodeScanner
        onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
        style={StyleSheet.absoluteFillObject}
      />
      {scanned && <Button title={'Tap to Scan Again'} onPress={() => setScanned(false)} />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
  },
});
