import { CrossIcon } from '@/assets/icons';
import LeftIconLight from '@/assets/icons/arrow-left-solid-light.svg';
import LeftIconDark from '@/assets/icons/arrow-left-solid.svg';
import RightIconLight from '@/assets/icons/arrow-right-solid-light.svg';
import RightIconDark from '@/assets/icons/arrow-right-solid.svg';
import PadlockLockedIcon from '@/assets/icons/padlock-lock.svg';
import PadlockUnlockedIcon from '@/assets/icons/padlock-unlock.svg';
import PortfolioIconLight from '@/assets/icons/portfolio-active-light.svg';
import PortfolioIconDark from '@/assets/icons/portfolio-active.svg';
import RefreshIcon from '@/assets/icons/rotate-right-solid.svg';
import { CloseButton } from '@/components/CloseButton';
import { ModalProps } from '@/components/Modal';
import { AuthorizeDAppModal } from '@/components/Modals/Browser/AuthorizeDAppModal';
import { ChangeWalletModal } from '@/components/Modals/Browser/ChangeWalletModal';
import { ConfirmSignatureModal } from '@/components/Modals/Browser/ConfirmSignatureModal';
import { ConfirmSwitchNetworkModal } from '@/components/Modals/Browser/ConfirmSwitchNetworkModal';
import { ConfirmTransactionModal as ETHConfirmTransactionModal } from '@/components/Modals/ETHBrowser/ConfirmTransactionModal';
import { ConfirmTransactionModal as ICXConfirmTransactionModal } from '@/components/Modals/ICXBrowser/ConfirmTransactionModal';
import { InsufficientFundsTransactionModal } from '@/components/Modals/ICXBrowser/InsufficientFundsTransactionModal';
import { WrongNetworkTransactionModal } from '@/components/Modals/ICXBrowser/WrongNetworkTransactionModal';
import { ConfirmLedgerTransactionModal } from '@/components/Modals/Ledger/ConfirmLedgerTransactionModal';
import { HomeStackParams, RootStackParams } from '@/components/Navigation';
import { BrowserStackParams } from '@/components/Navigation/Browser';
import RefreshableWebView from '@/components/RefreshableWebView';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ToastType } from '@/components/Toast.types';
import {
  EthereumRequest,
  EthereumRequestAddAsset,
  EthereumRequestAddEthereumChain,
  EthereumRequestSign,
  EthereumRequestSignTransaction,
  EthereumRequestSubscribe,
  EthereumRequestSwitchEthereumChain,
} from '@/models/EthereumRequest';
import {
  PolkadotAccountData,
  PolkadotAccountsGetRequest,
  PolkadotAccountsSubscribeRequest,
  PolkadotRequest,
  PolkadotSignerSignPayloadRequest,
  PolkadotSignerSignRawRequest,
} from '@/models/PolkadotRequest';
import { ChainWallet, CustomNetwork, Token, Wallet, WalletType } from '@/models/Vault';
import { RawTxResponse, RpcTransactionResponse } from '@/models/ChainService';
import { EthereumService } from '@/services/chainServices/EthereumService';
import { ICONService } from '@/services/chainServices/IconService';
import { PolkadotService } from '@/services/chainServices/PolkadotService';
import { serviceForChainID, serviceForChainWallet, useChainServices } from '@/stores/ChainServices';
import { useLedgerStore } from '@/stores/Ledger';
import { useModal } from '@/stores/Modal';
import { useNavigationStore } from '@/stores/Navigation';
import { useSettings } from '@/stores/Settings';
import { useTheme } from '@/stores/Theme';
import { useTransactions } from '@/stores/Transactions';
import { useVault } from '@/stores/Vault';
import {
  addAuthorizedDApp,
  getChainIDForAuthorizedDApp,
  hasAuthorizedDApp,
  updateChainIDForAuthorizedDApp,
} from '@/utils/browser';
import { ChainID, getGenesisHashForChain, isSubstrateChain } from '@/utils/chains';
import { SubstrateKeyDerivationMethod } from '@/utils/constants';
import { convertLoopToToken } from '@/utils/conversion';
import { colors } from '@/utils/designTokens';
import { fetchLogo } from '@/utils/fetchLogo';
import {
  AppType,
  LedgerAddress,
  appTypeForChainID,
  getLedgerApp,
  signMessage,
  signTransaction,
} from '@/utils/ledger';
import { dismissModal, presentModal } from '@/utils/modal';
import {
  EthereumNetworkDetails,
  IconNetworkDetails,
  TestnetConfig,
  evmChains,
  evmMainnets,
  evmNetworks,
  getCustomNetworksForChain,
  isEthOrEvmChainID,
  isEvmChainID,
  networkDetailsForChainID,
  networkDetailsForTestnet,
} from '@/utils/networks';
import { getChainWalletForPolkadotSignerWallet } from '@/utils/polkadot';
import { common } from '@/utils/styles';
import { isCustomNetwork, isTestnetConfig } from '@/utils/types';
import { isValidHttpUrl, isValidHttpsUrl, isValidUrlWithoutProtocol } from '@/utils/url';
import { wait } from '@/utils/wait';
import Transport from '@ledgerhq/hw-transport';
import TransportHID from '@ledgerhq/react-native-hid';
import TransportBLE from '@ledgerhq/react-native-hw-transport-ble';
import {
  addMetadata as polkadotAddMetadata,
  knownMetadata as polkadotKnownMetadata,
} from '@polkadot/extension-chains';
import type { Keyring } from '@polkadot/keyring';
import { cryptoWaitReady } from '@polkadot/util-crypto';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { ethErrors } from 'eth-rpc-errors';
import * as Application from 'expo-application';
import IconSDK from 'icon-sdk-js';
import produce from 'immer';
import { gt, isArray, isEmpty, isNil, isObject, uniq } from 'lodash-es';
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { Animated, Platform, StyleSheet, TextInput, TouchableOpacity, View } from 'react-native';
import RNFS from 'react-native-fs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { WebViewNavigation } from 'react-native-webview';
import { v4 as uuid } from 'uuid';
import Web3 from 'web3';
import { usePendingTransactions } from '@/stores/PendingTransactions';

// NOTE: BLE module is imported lazily so that the Bluetooth permissions don't prompt when app first loads
// let TransportBLE: typeof TransportBLEType.default | undefined = undefined;

let _Keyring: typeof Keyring | undefined = undefined;

cryptoWaitReady().then(() => {
  import('@polkadot/keyring').then((keyring) => {
    _Keyring = keyring.Keyring;
  });
});

const atob = require('base-64').decode;

const DEFAULT_URL = 'https://dapp-tester.herokuapp.com/';
// const DEFAULT_URL = 'https://duckduckgo.com/';
// const DEFAULT_URL = 'https://myetherwallet.github.io/web3-extension-tester/';
// const DEFAULT_URL = 'https://metamask.github.io/test-dapp/';
// const DEFAULT_URL = 'https://app.uniswap.org';
// const DEFAULT_URL = 'https://web3-react-mu.vercel.app/';
// const DEFAULT_URL = 'http://localhost:3000';
// const DEFAULT_URL = 'https://pancake.kiemtienonline360.com/#/swap';
// const DEFAULT_URL = 'https://pancakeswap.com';
// const DEFAULT_URL = 'https://test.polkaswap.io/';

export const ETHEREUM_RELAY_RESPONSE = 'HANA_ETHEREUM_RESPONSE';
export const POLKADOT_RELAY_RESPONSE = 'HANA_POLKADOT_RESPONSE';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<BrowserStackParams, 'Browser'>,
  StackNavigationProp<RootStackParams>
>;

type _NavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'Home'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<BrowserStackParams, 'Browser'>;

const { IconConverter } = IconSDK;

interface URL_DATA {
  title: string;
  url: string;
}

export function Browser(props: any) {
  const { navigate } = useNavigation<_NavigationProps>();
  const { setHideTabBar } = useNavigationStore();

  const { addPendingTransaction } = usePendingTransactions();

  const { params } = useRoute<RouteProps>();
  const { isDarkMode } = useTheme();
  const [uri, setUri] = useState(params?.url || DEFAULT_URL);
  const [urlInput, setUrlInput] = useState(uri);
  const [urlData, setUrlData] = useState<URL_DATA>();
  const [httpsUrl, setHttpsUrl] = useState(isValidHttpsUrl(uri));
  const [canGoBack, setCanGoBack] = useState(false);
  const [canGoForward, setCanGoForward] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [inputWidth, setInputWidth] = useState(0);
  const [progressAnim] = useState(new Animated.Value(loadingProgress));
  const [footerAnim] = useState(new Animated.Value(60));
  const [isKeyboardOpen, setIsKeyboardOpen] = useState<boolean>(false);
  const urlInputRef = useRef<any>(null);
  const webviewEl = useRef<any>(null);

  const [confirmTransactionEstimatedFee, setConfirmTransactionEstimatedFee] =
    useState<boolean>(false);
  const [confirmTransactionCorrectWallet, setConfirmTransactionCorrectWallet] =
    useState<boolean>(false);

  const { modalOptions, setModalOptions } = useModal();

  useEffect(() => {
    // Enable or disable confirm button in modal
    setModalOptions(
      produce(modalOptions, (draft) => {
        if (draft.confirmButton) {
          draft.confirmButton.disabled =
            !confirmTransactionEstimatedFee || !confirmTransactionCorrectWallet;
        }
      })
    );
  }, [confirmTransactionEstimatedFee, modalOptions, confirmTransactionCorrectWallet]);

  const [injectionScript, setInjectionScript] = useState<string>('');

  const { setConnectingToLedger, transport, setTransport, setLedgerBleId } = useLedgerStore();
  const { setToastMessage } = useNavigationStore();

  const { wallets, getActiveWallet, getActiveChainWallets } = useVault();
  const activeWallet = getActiveWallet();
  const activeChainWallets = getActiveChainWallets();
  const activeChains = useMemo(() => {
    const chains = activeChainWallets.map((wallet) => wallet.type);
    return uniq(chains);
  }, [activeChainWallets]);

  const { otherNetwork, selectOtherNetwork, connectedChains } = useChainServices();
  const { realm } = useVault();

  const sourceHost = vanityUrl(uri);

  const isMainnet = useMemo(() => isNil(otherNetwork), [otherNetwork]);

  const otherNetworkChainID = useMemo(() => {
    if (isTestnetConfig(otherNetwork)) return (otherNetwork as TestnetConfig).chainType;
    if (isCustomNetwork(otherNetwork)) return (otherNetwork as CustomNetwork).chain;

    return undefined;
  }, [otherNetwork]);

  const evmNetwork = useMemo(() => {
    const chainId = getChainIDForAuthorizedDApp(activeWallet!, sourceHost);

    if (!isNil(chainId) && isEthOrEvmChainID(chainId)) {
      return networkDetailsForChainID(chainId) as EthereumNetworkDetails;
    }

    // Return Ethereum as default, if connected
    if (activeChains.includes(ChainID.Ethereum)) {
      return networkDetailsForChainID(ChainID.Ethereum) as EthereumNetworkDetails;
    }

    // If Ethereum is not connected, return first active EVM chain
    const firstActiveEvmChainId = activeChains.find((c) => evmChains.includes(c));

    if (firstActiveEvmChainId && networkDetailsForChainID(firstActiveEvmChainId)) {
      return networkDetailsForChainID(firstActiveEvmChainId) as EthereumNetworkDetails;
    }

    return networkDetailsForChainID(ChainID.Ethereum) as EthereumNetworkDetails;
  }, [sourceHost, activeChains]);

  const evmChainId = useMemo(() => {
    if (isMainnet) return evmNetwork?.chainId;

    if (isTestnetConfig(otherNetwork))
      return (networkDetailsForTestnet(otherNetwork) as EthereumNetworkDetails).chainId;

    if (isCustomNetwork(otherNetwork)) return otherNetwork.networkId;
  }, [isMainnet, evmNetwork, otherNetwork]);

  const activeETHWallet = useMemo(() => {
    if (evmNetwork && evmChains.includes(evmNetwork.chainType)) {
      return activeWallet?.chainWallets.find((w) => w.type === evmNetwork.chainType);
    }

    return activeWallet?.chainWallets.find((w) => w.type === ChainID.Ethereum);
  }, [activeWallet, evmNetwork]);

  const activeICXWallet = useMemo(() => {
    return activeWallet?.chainWallets.find((w) => w.type === ChainID.ICON);
  }, [activeWallet]);

  const ethService = useMemo(() => {
    if (evmNetwork && evmChains.includes(evmNetwork.chainType)) {
      return serviceForChainID(evmNetwork.chainType) as EthereumService;
    }

    return activeETHWallet && (serviceForChainWallet(activeETHWallet) as EthereumService);
  }, [activeETHWallet, evmNetwork]);

  const icxService = activeICXWallet && (serviceForChainWallet(activeICXWallet) as ICONService);

  const icxNetwork = icxService
    ? (icxService?.getNetworkDetails() as IconNetworkDetails)
    : undefined;

  const insets = useSafeAreaInsets();

  useEffect(() => {
    async function read() {
      console.debug('read');

      const hanaGlobal = `;
        Object.defineProperty(window, 'hanaWallet', {
          value: Object.create(null, {
            available: { value: true, writable: false },
            version: { value: 'v${Application.nativeApplicationVersion} (${Application.nativeBuildVersion})', writable: false },
          }),
        });
      `;

      if (Platform.OS === 'ios') {
        const ethProvider = await RNFS.readFile(RNFS.MainBundlePath + '/EthereumProvider.js');
        const icxProvider = await RNFS.readFile(RNFS.MainBundlePath + '/IconProvider.js');
        const dotProvider = await RNFS.readFile(RNFS.MainBundlePath + '/PolkadotProvider.js');

        setInjectionScript(`${hanaGlobal}${ethProvider}${icxProvider}${dotProvider}`);
      }

      if (Platform.OS === 'android') {
        const ethProvider = await RNFS.readFileAssets('EthereumProvider.js');
        const icxProvider = await RNFS.readFileAssets('IconProvider.js');
        const dotProvider = await RNFS.readFileAssets('PolkadotProvider.js');

        setInjectionScript(`${hanaGlobal}${ethProvider}${icxProvider}${dotProvider}`);
      }
    }

    read();
  }, []);

  useLayoutEffect(() => {
    if (inputWidth === 0) return;
    Animated.timing(progressAnim, {
      toValue: loadingProgress * inputWidth,
      duration: loadingProgress ? 300 : 0,
      useNativeDriver: false,
    }).start();
  }, [inputWidth, loadingProgress]);

  useLayoutEffect(() => {
    wait(300).then(() => {
      Animated.timing(footerAnim, {
        toValue: 0,
        duration: 400,
        useNativeDriver: true,
      }).start();
    });
  }, []);

  function vanityUrl(url: string) {
    return url.replace(/https?\:\/\//, '').split('/')[0];
  }

  function handleClose() {
    setHideTabBar(false);
    navigate('Home');
  }

  function handleNavigationStateChange(newNavState: WebViewNavigation) {
    if (newNavState.url) {
      setUri(newNavState.url);
      setUrlInput(vanityUrl(newNavState.url));
      setHttpsUrl(isValidHttpsUrl(newNavState.url));
    }

    setCanGoBack(newNavState.canGoBack);
    setCanGoForward(newNavState.canGoForward);
    setIsRefreshing(false);
  }

  function handleLoadEnd() {
    setLoadingProgress(1);
    wait(1000).then(() => setLoadingProgress(0));
  }

  function handleRefresh() {
    setIsRefreshing(true);
    webviewEl.current?.reload();
  }

  function handleChangeUrl() {
    setIsKeyboardOpen(false);

    let uri;

    if (isValidHttpsUrl(urlInput)) {
      uri = urlInput;
    } else if (isValidHttpUrl(urlInput)) {
      // replace http with https
      uri = urlInput.replace(/^http\:\/\//, 'https://');
    } else if (isValidUrlWithoutProtocol(urlInput)) {
      // add https
      uri = `https://${urlInput}`;
    } else {
      uri = `https://duckduckgo.com/?q=${urlInput}`;
    }

    setUri(uri);
    setUrlInput(vanityUrl(uri));
    setHttpsUrl(isValidHttpsUrl(uri));
  }

  function emitEvent(event: string, data: string | Array<string> | Object) {
    const dataToSend = isArray(data)
      ? `[${data.map((d) => `'${d}'`).join(',')}]`
      : isObject(data)
      ? JSON.stringify(data)
      : `'${data}'`;

    console.debug('data to send: ', dataToSend);

    const script = `
    window.ethereum.emit('${event}', ${dataToSend});
    true;
  `;

    console.debug('script: ', script);

    return void webviewEl.current.injectJavaScript(script);
  }

  function onChangeWallet() {
    presentModal({
      title: 'Change wallet',
      content: (
        <View style={{ marginTop: 20 }}>
          <ChangeWalletModal
            onChangedWallet={(wallet) => {
              dismissModal();

              const ethWallet = wallet.chainWallets.find((w) => w.type === ChainID.Ethereum);

              if (ethWallet?.address) {
                emitEvent('accountsChanged', [ethWallet.address]);
              }
            }}
          />
        </View>
      ),
    });
  }

  const [faviconUrl, setFaviconUrl] = useState<string | undefined>(undefined);

  function handleAuthorizeDApp(sourceHost: string, originalData: string) {
    if (!activeWallet) return;
    if (!urlData) return;

    const [message] = originalData.split(':');
    const isEvm = message === 'ethereum';

    presentModal({
      title: 'Authorize dApp',
      content: (
        <AuthorizeDAppModal
          urlData={urlData}
          faviconUrl={faviconUrl}
          sourceHost={sourceHost}
          wallet={activeWallet}
          onCancel={() => dismissModal()}
          onAuthorize={(selectedChainID) => {
            dismissModal();

            addAuthorizedDApp(
              activeWallet,
              sourceHost,
              urlData.title,
              faviconUrl,
              selectedChainID || undefined
            );

            handleRelayRequest(originalData);
          }}
          isEvm={isEvm}
        />
      ),
      options: {
        withCloseButton: false,
      },
    });
  }

  function handleConfirmSigning(
    chain: ChainID,
    payload: any,
    signFrom: string,
    data: string | null,
    sourceHost: string
  ) {
    presentModal({
      title: 'Signing request',
      content: (
        <View style={{ marginTop: 20 }}>
          <ConfirmSignatureModal
            chain={chain}
            data={data}
            signFrom={signFrom}
            sourceHost={sourceHost}
            onConfirm={() => {
              handleFinalizeSigning(chain, payload, data);
            }}
            onCancel={() => dismissModal()}
          />
        </View>
      ),
      options: {
        withCloseButton: false,
      },
    });
  }

  async function handleFinalizeSigning(chain: ChainID, payload: any, data: string | null) {
    // Handle if Ledger
    if (activeWallet?.type === WalletType.Ledger) {
      dismissModal();

      if (chain === ChainID.Ethereum && data) {
        handleLedgerSignMessage(activeWallet, payload, data);
      }

      if (chain === ChainID.ICON) {
        setToastMessage('Cannot sign with Ledger wallet', ToastType.error);
      }

      if (chain === ChainID.Polkadot) {
        const { method } = payload as PolkadotRequest;
        if (method === 'polkadot_signer_sign_raw') {
          setToastMessage('Cannot sign with Ledger wallet', ToastType.error);
        } else if (method === 'polkadot_signer_sign_payload') {
          try {
            await dotConnectToLedgerAndSignTransaction(payload);
            handleCloseLedger();
          } catch (error: any) {
            console.debug('Failed connecting to Ledger.', error.message);
            handleCloseLedger(error.message);
          }
        }
      }
    } else {
      // TODO: Check if confirm every transaction -- passcode modal

      handleSigning(chain, payload, data);
    }
  }

  async function handleSigning(chain: ChainID, payload: any, data: any) {
    if (chain === ChainID.Ethereum) {
      const { id, method, params } = payload as EthereumRequest;
      const result = await ethService?.sign(data);

      console.debug('sign result: ', result);

      const script = `
      window.dispatchEvent(
        new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
          detail: {
            id: '${id}',
            method: '${method}',
            params: '${result}',
          }
        })
      );
      true;
    `;

      console.debug('script: ', script);

      dismissModal();

      return void webviewEl.current.injectJavaScript(script);
    }

    if (chain === ChainID.ICON) {
      console.debug('handleSigning data: ', data);

      const signature = await icxService?.sign(data);

      console.debug('signature: ', signature);

      webviewEl.current.injectJavaScript(`
        window.dispatchEvent(
          new CustomEvent('ICONEX_RELAY_RESPONSE', {
            detail: {
              type: 'RESPONSE_SIGNING',
              payload: '${signature}',
            }
          })
        );
        true;
      `);

      dismissModal();
    }

    if (chain === ChainID.Polkadot) {
      const {
        payload: internalPayload,
        method,
        id,
      } = payload as PolkadotSignerSignPayloadRequest | PolkadotSignerSignRawRequest;
      const chainWallet = getChainWalletForPolkadotSignerWallet(internalPayload.address);
      const chainID = chainWallet!.type;

      const chainService = serviceForChainID(chainID) as PolkadotService;

      let signature;

      if (method === 'polkadot_signer_sign_payload') {
        signature = await chainService.signPayload(internalPayload);
      } else if (method === 'polkadot_signer_sign_raw') {
        signature = await chainService.sign(internalPayload.data);
      }

      if (!isEmpty(signature)) {
        const script = `
        window.dispatchEvent(
          new CustomEvent('${POLKADOT_RELAY_RESPONSE}', {
            detail: {
              id: '${id}',
              method: '${method}',
              signature: '${signature}',
            }
          })
        );
        true;
      `;

        console.debug('script: ', script);

        dismissModal();

        return void webviewEl.current.injectJavaScript(script);
      }
    }
  }

  async function ethConnectToLedgerAndSignMessage(payload: EthereumRequest, message: string) {
    const { id, method, params } = payload;

    if (!activeWallet) return;
    if (!activeETHWallet) return;

    if (transport) {
      await transport.close();
      setTransport(null);
    }

    setConnectingToLedger(true);

    let thisTransport: any;

    if (activeWallet.ledgerBleId) {
      // if (!TransportBLE) {
      //   TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
      // }

      thisTransport = await TransportBLE.open(activeWallet.ledgerBleId);
      thisTransport.on('disconnect', () => {
        console.debug('BLE disconnected');
      });

      setTransport(thisTransport);
      setLedgerBleId(activeWallet.ledgerBleId);
    } else {
      thisTransport = await TransportHID.create();
      thisTransport.on('disconnect', () => {
        console.debug('HID disconnected');
      });

      setTransport(thisTransport);
    }

    const ledgerApp = await getLedgerApp(thisTransport, AppType.ETH);
    const ledgerAddress = {
      index: activeETHWallet.hdIndex,
      hdPath: activeETHWallet.hdPath,
      address: activeETHWallet.address,
    } as LedgerAddress;

    console.debug('message: ', message);

    const response = await signMessage(ledgerApp, AppType.ETH, ledgerAddress, message);

    console.debug('response: ', response);

    const script = `
    window.dispatchEvent(
      new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
        detail: {
          id: '${id}',
          method: '${method}',
          params: '${response}',
        }
      })
    );
    true;
  `;

    console.debug('script: ', script);
    webviewEl.current.injectJavaScript(script);

    dismissModal();
  }

  async function ethConnectToLedgerAndSignTransaction(transaction: EthereumRequest) {
    const { id, method, params } = transaction;

    if (!activeWallet) return;
    if (!activeETHWallet) return;

    if (transport) {
      await transport.close();
      setTransport(null);
    }

    setConnectingToLedger(true);

    let thisTransport: any;

    if (activeWallet.ledgerBleId) {
      // if (!TransportBLE) {
      //   TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
      // }

      thisTransport = await TransportBLE.open(activeWallet.ledgerBleId);
      thisTransport.on('disconnect', () => {
        console.debug('BLE disconnected');
      });

      setTransport(thisTransport);
      setLedgerBleId(activeWallet.ledgerBleId);
    } else {
      thisTransport = await TransportHID.create();
      thisTransport.on('disconnect', () => {
        console.debug('HID disconnected');
      });

      setTransport(thisTransport);
    }

    try {
      const rawTxResponse = await ethService?.rpcTransaction(activeETHWallet, transaction, {
        getRawTx: true,
      });

      console.debug('rawTxResponse: ', rawTxResponse);

      if ((rawTxResponse as RawTxResponse).rawTx) {
        const myRawTxResponse = rawTxResponse as RawTxResponse;
        const { rawTx, serializedTx } = myRawTxResponse;

        const ledgerApp = await getLedgerApp(thisTransport, AppType.ETH);
        const ledgerAddress = {
          index: activeETHWallet.hdIndex,
          hdPath: activeETHWallet.hdPath,
          address: activeETHWallet.address,
        } as LedgerAddress;

        console.debug('before sign transaction: ', serializedTx);
        const signature = await signTransaction(
          ledgerApp,
          AppType.ETH,
          ledgerAddress,
          serializedTx
        );

        console.debug('signature: ', signature);

        // rpcTransaction with signature
        const response = await ethService?.rpcTransaction(activeETHWallet, transaction, {
          rawTx,
          signature,
        });

        console.debug('response: ', response);

        const script = `
      window.dispatchEvent(
        new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
          detail: {
            id: '${id}',
            method: '${method}',
            params: '${response}',
          }
        })
      );
      true;
    `;

        console.debug('script: ', script);
        webviewEl.current.injectJavaScript(script);

        dismissModal();
      }
    } catch (error) {
      setToastMessage((error as any)?.message, ToastType.error);
    }
  }

  async function dotConnectToLedgerAndSignTransaction(
    transaction: PolkadotSignerSignPayloadRequest
  ) {
    const { id, method, payload } = transaction;

    if (!activeWallet) return;

    if (transport) {
      await transport.close();
      setTransport(null);
    }

    setConnectingToLedger(true);

    let thisTransport: any;

    if (activeWallet.ledgerBleId) {
      // if (!TransportBLE) {
      //   TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
      // }

      thisTransport = await TransportBLE.open(activeWallet.ledgerBleId);
      thisTransport.on('disconnect', () => {
        console.debug('BLE disconnected');
      });

      setTransport(thisTransport);
      setLedgerBleId(activeWallet.ledgerBleId);
    } else {
      thisTransport = await TransportHID.create();
      thisTransport.on('disconnect', () => {
        console.debug('HID disconnected');
      });

      setTransport(thisTransport);
    }

    const chainWallet = getChainWalletForPolkadotSignerWallet(payload.address);

    if (chainWallet) {
      const chainID = chainWallet.type;
      const appType = appTypeForChainID(chainID)!;

      const chainService = serviceForChainID(chainID) as PolkadotService;

      const serializedTx = await chainService.signPayload(payload, true);

      const ledgerApp = await getLedgerApp(thisTransport, appType);
      const ledgerAddress = {
        index: chainWallet.hdIndex,
        hdPath: chainWallet.hdPath,
        address: chainWallet.address,
      } as LedgerAddress;

      const signature = await signTransaction(ledgerApp, appType, ledgerAddress, serializedTx);

      if (!isEmpty(signature)) {
        const script = `
        window.dispatchEvent(
          new CustomEvent('${POLKADOT_RELAY_RESPONSE}', {
            detail: {
              id: '${id}',
              method: '${method}',
              signature: '0x${signature}',
            }
          })
        );
        true;
      `;

        console.debug('script: ', script);

        dismissModal();

        return void webviewEl.current.injectJavaScript(script);
      }
    }
  }

  async function handleLedgerSignMessage(
    fromWallet: Wallet,
    payload: EthereumRequest,
    message: string
  ) {
    if (!activeETHWallet) return;

    dismissModal();

    // Induce a short delay, there's a UI bug with modal content changing
    setTimeout(() => {
      presentModal({
        title: 'Connect to Ledger',
        content: (
          <ConfirmLedgerTransactionModal
            chainWallet={activeETHWallet}
            onConnectToLedger={async () => {
              try {
                await ethConnectToLedgerAndSignMessage(payload, message);
                handleCloseLedger();
              } catch (error: any) {
                console.debug('Failed connecting to Ledger.', error.message);
                handleCloseLedger(error.message);
              }
            }}
          />
        ),
        options: {
          onClose: () => handleCloseLedger(),
        },
      });
    }, 500);
  }

  async function ethHandleLedgerTransaction(fromWallet: Wallet, payload: EthereumRequest) {
    if (!activeETHWallet) return;

    dismissModal();

    // Induce a short delay, there's a UI bug with modal content changing
    setTimeout(() => {
      presentModal({
        title: 'Connect to Ledger',
        content: (
          <ConfirmLedgerTransactionModal
            chainWallet={activeETHWallet}
            onConnectToLedger={async () => {
              try {
                await ethConnectToLedgerAndSignTransaction(payload);
                handleCloseLedger();
              } catch (error: any) {
                console.debug('Failed connecting to Ledger.', error.message);
                handleCloseLedger(error.message);
              }
            }}
          />
        ),
        options: {
          onClose: () => handleCloseLedger(),
        },
      });
    }, 500);
  }

  function handleCloseLedger(errorMessage?: string) {
    if (!isNil(errorMessage)) {
      const toastMessage =
        errorMessage === 'NoAddress' ? `Failed connecting to Ledger` : `Failed or rejected signing`;
      setToastMessage(toastMessage, ToastType.error);
    } else {
      dismissModal();
    }

    transport?.close();
    setTransport(null);
    setConnectingToLedger(false);
  }

  function handleIcxRpcTransactionResponseError(response: any) {
    if (response?.error) {
      setToastMessage(response.error.message, ToastType.error);
    }
  }

  async function icxHandleTransaction(
    fromWallet: Wallet,
    transaction: any,
    completedResponse = null
  ) {
    let response = completedResponse;
    if (!completedResponse) {
      try {
        const icxWallet = fromWallet.chainWallets.find((w) => w.type === ChainID.ICON);

        if (icxWallet) {
          response = await icxService?.rpcTransaction(icxWallet, transaction);

          handleIcxRpcTransactionResponseError(response);
        }
      } catch (error) {
        console.debug('handleTransaction error: ', error);
      }
    }

    // wait(5000).then(() => refreshWallet(fromWallet));

    webviewEl.current.injectJavaScript(`
      window.dispatchEvent(
        new CustomEvent('ICONEX_RELAY_RESPONSE', {
          detail: {
            type: 'RESPONSE_JSON-RPC',
            payload: ${JSON.stringify(response)},
          }
        })
      );
      true;
    `);
  }
  async function ethHandleTransaction(fromWallet: Wallet, payload: EthereumRequest) {
    console.debug('ethHandleTransaction');

    if (!ethService) return;
    if (!activeWallet) return;
    if (!activeETHWallet) return;

    const { id, method, params } = payload;

    const request = payload as EthereumRequestSignTransaction;

    if (activeETHWallet.address !== Web3.utils.toChecksumAddress(request.params[0].from)) {
      // TODO: Show error
      return;
    }

    console.debug('before transaction: ');

    try {
      const transaction = await ethService.rpcTransaction(activeETHWallet, request);

      console.debug('transaction: ', transaction);

      let result;

      if ((transaction as RpcTransactionResponse).rpcResponse) {
        const txResponse = transaction as RpcTransactionResponse;

        result = txResponse.rpcResponse;

        txResponse.pendingTransaction && addPendingTransaction(txResponse.pendingTransaction);
      } else {
        result = transaction;
      }

      console.debug('>>>result: ', result);

      const script = `
    window.dispatchEvent(
      new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
        detail: {
          id: '${id}',
          method: '${method}',
          params: '${result}',
        }
      })
    );
    true;
  `;

      console.debug('script: ', script);
      webviewEl.current.injectJavaScript(script);
    } catch (error) {
      setToastMessage((error as any)?.message, ToastType.error);
    }
  }

  async function icxConnectToLedger(transaction: any) {
    // Handle confirm transaction

    if (!activeWallet) return;
    if (!activeICXWallet) return;

    if (transport) {
      await transport.close();
      setTransport(null);
    }

    setConnectingToLedger(true);

    let thisTransport: any;

    if (activeWallet.ledgerBleId) {
      // if (!TransportBLE) {
      //   TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
      // }

      thisTransport = await TransportBLE.open(activeWallet.ledgerBleId);
      thisTransport.on('disconnect', () => {
        console.debug('BLE disconnected');
      });

      setTransport(thisTransport);
      setLedgerBleId(activeWallet.ledgerBleId);
    } else {
      thisTransport = await TransportHID.create();
      thisTransport.on('disconnect', () => {
        console.debug('HID disconnected');
      });

      setTransport(thisTransport);
    }

    const rawTxResponse = await icxService?.rpcTransaction(activeICXWallet, transaction, {
      getRawTx: true,
    });

    if ((rawTxResponse as RawTxResponse).rawTx) {
      const myRawTxResponse = rawTxResponse as RawTxResponse;
      const { rawTx, serializedTx } = myRawTxResponse;

      const ledgerApp = await getLedgerApp(thisTransport, AppType.ICX);
      const ledgerAddress = {
        index: activeICXWallet.hdIndex,
        hdPath: activeICXWallet.hdPath,
        address: activeICXWallet.address,
      } as LedgerAddress;

      console.debug('before sign transaction: ', serializedTx);
      const signature = await signTransaction(ledgerApp, AppType.ICX, ledgerAddress, serializedTx);

      // rpcTransaction with signature
      const response = await icxService?.rpcTransaction(activeICXWallet, transaction, {
        signature,
      });

      handleIcxRpcTransactionResponseError(response);

      console.debug('response: ', response);

      webviewEl.current.injectJavaScript(`
          window.dispatchEvent(
            new CustomEvent('ICONEX_RELAY_RESPONSE', {
              detail: {
                type: 'RESPONSE_JSON-RPC',
                payload: ${JSON.stringify(response)},
              }
            })
          );
          true;
        `);

      dismissModal();
    }
  }

  async function icxHandleFinalizeTransaction(fromWallet: Wallet, transaction: any) {
    if (fromWallet.type === WalletType.Ledger) {
      // Handle Ledger
      if (activeICXWallet) {
        dismissModal();

        // Induce a short delay, there's a UI bug with modal content changing
        setTimeout(() => {
          presentModal({
            title: 'Connect to Ledger',
            content: (
              <ConfirmLedgerTransactionModal
                chainWallet={activeICXWallet}
                onConnectToLedger={async () => {
                  try {
                    await icxConnectToLedger(transaction);
                    handleCloseLedger();
                  } catch (error: any) {
                    console.debug('Failed connecting to Ledger.', error.message);
                    handleCloseLedger(error.message);
                  }
                }}
              />
            ),
            options: {
              onClose: () => handleCloseLedger(),
            },
          });
        }, 500);
      }
    } else {
      icxHandleTransaction(fromWallet, transaction);
    }
  }

  function icxHandleConfirmTransaction(payload: any, sourceHost: string) {
    if (!activeWallet) return;

    // Confirm transaction
    console.debug('payload: ', payload);

    const {
      params: { from },
    } = payload;

    const activeICXWallet = activeWallet?.chainWallets.find((w) => w.type === ChainID.ICON);

    const isCorrectWallet = activeICXWallet?.address.toLowerCase() === from.toLowerCase();

    setConfirmTransactionCorrectWallet(isCorrectWallet);

    setConfirmTransactionEstimatedFee(false);

    const title = 'Transaction';
    const content = (
      <ICXConfirmTransactionModal
        urlData={urlData}
        payload={payload}
        fromWallet={activeWallet}
        sourceHost={sourceHost}
        onEstimatedFee={(success) => {
          setConfirmTransactionEstimatedFee(success);
        }}
      />
    );

    const options: ModalProps = {
      withCloseButton: false,
      confirmButton: {
        title: 'Authorize',
        onPress: () => {
          dismissModal();
          icxHandleFinalizeTransaction(activeWallet, payload);
        },
        disabled: !isCorrectWallet || !confirmTransactionEstimatedFee,
      },
      cancelButton: {
        title: 'Cancel',
        onPress: () => {
          dismissModal();
          icxHandleCancelTransaction();
        },
      },
    };

    presentModal({
      title,
      content,
      options,
    });
  }

  function ethHandleConfirmTransaction(payload: EthereumRequest, sourceHost: string) {
    if (!ethService) return;
    if (!activeWallet) return;
    if (!activeETHWallet) return;

    const { id, method, params } = payload;

    const request = payload as EthereumRequestSignTransaction;

    const isCorrectWallet = activeETHWallet.address.toLowerCase() === params[0].from.toLowerCase();

    setConfirmTransactionCorrectWallet(isCorrectWallet);

    // Show confirm transaction modal
    console.debug('payload: ', payload);

    setConfirmTransactionEstimatedFee(false);

    const title = 'Transaction';
    const content = (
      <ETHConfirmTransactionModal
        urlData={urlData}
        network={evmNetwork}
        payload={request}
        fromWallet={activeWallet}
        sourceHost={sourceHost}
        onEstimatedFee={(success) => {
          console.debug('ETH onEstimatedFee: ', success);
          setConfirmTransactionEstimatedFee(success);
        }}
      />
    );

    const options: ModalProps = {
      withCloseButton: false,
      confirmButton: {
        title: 'Authorize',
        onPress: () => {
          dismissModal();

          if (activeWallet.type === WalletType.Ledger) {
            ethHandleLedgerTransaction(activeWallet, payload);
          } else {
            ethHandleTransaction(activeWallet, payload);
          }
        },
        disabled: !confirmTransactionEstimatedFee || !isCorrectWallet,
      },
      cancelButton: {
        title: 'Cancel',
        onPress: () => {
          dismissModal();

          // Emit error event (user rejected request)
          const script = `
            window.dispatchEvent(
              new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
                detail: {
                  id: '${id}',
                  error: ${JSON.stringify(ethErrors.provider.userRejectedRequest().serialize())}
                }
              })
            );
            true;
            `;

          console.debug('script: ', script);

          webviewEl.current.injectJavaScript(script);
        },
      },
    };

    presentModal({
      title,
      content,
      options,
    });
  }

  function showConfirmSwitchNetworkModal(networkName: string, onConfirm: () => unknown) {
    presentModal({
      title: 'Switch network',
      content: (
        <ConfirmSwitchNetworkModal
          sourceHost={vanityUrl(uri)}
          networkName={networkName}
          onConfirm={() => {
            onConfirm();
            dismissModal();
          }}
          onCancel={() => {
            dismissModal();
          }}
        />
      ),
    });
  }

  async function dotHandleAccountsListRequest(
    payload: PolkadotAccountsGetRequest | PolkadotAccountsSubscribeRequest
  ) {
    if (!activeWallet) return;

    const { id, method } = payload;

    const dotConnected =
      isNil(otherNetwork) && !isNil(connectedChains.find((c) => c.id === ChainID.Polkadot));
    const ksmConnected =
      isNil(otherNetwork) && !isNil(connectedChains.find((c) => c.id === ChainID.Kusama));
    const wndConnected = (otherNetwork as TestnetConfig)?.chainType === ChainID.Westend;
    const arcticConnected = (otherNetwork as TestnetConfig)?.chainType === ChainID.Arctic;
    const snowConnected =
      isNil(otherNetwork) && !isNil(connectedChains.find((c) => c.id === ChainID.SNOW));
    const astarConnected =
      isNil(otherNetwork) && !isNil(connectedChains.find((c) => c.id === ChainID.Astar));
    const shidenConnected =
      isNil(otherNetwork) && !isNil(connectedChains.find((c) => c.id === ChainID.Shiden));
    const shibuyaConnected =
      isNil(otherNetwork) && !isNil(connectedChains.find((c) => c.id === ChainID.Shibuya));

    const dotGenesisHash = getGenesisHashForChain(ChainID.Polkadot)!;
    const ksmGenesisHash = getGenesisHashForChain(ChainID.Kusama)!;
    const wndGenesisHash = getGenesisHashForChain(ChainID.Westend)!;
    const arcticGenesisHash = getGenesisHashForChain(ChainID.Arctic)!;
    const snowGenesisHash = getGenesisHashForChain(ChainID.SNOW)!;
    const astarGenesisHash = getGenesisHashForChain(ChainID.Astar)!;
    const shidenGenesisHash = getGenesisHashForChain(ChainID.Shiden)!;
    const shibuyaGenesisHash = getGenesisHashForChain(ChainID.Shibuya)!;

    if (!_Keyring) {
      throw new Error('Keyring unavailable');
    }

    const dotWallet = activeWallet.chainWallets.find((w) => w.type === ChainID.Polkadot);
    const ksmWallet = activeWallet.chainWallets.find((w) => w.type === ChainID.Kusama);
    const wndWallet = activeWallet.chainWallets.find((w) => w.type === ChainID.Westend);
    const arcticWallet = activeWallet.chainWallets.find((w) => w.type === ChainID.Arctic);
    const snowWallet = activeWallet.chainWallets.find((w) => w.type === ChainID.SNOW);
    const astarWallet = activeWallet.chainWallets.find((w) => w.type === ChainID.Astar);
    const shidenWallet = activeWallet.chainWallets.find((w) => w.type === ChainID.Shiden);
    const shibuyaWallet = activeWallet.chainWallets.find((w) => w.type === ChainID.Shibuya);

    // NOTE: Only show 1 wallet as they're actually all the same, but we traverse top down (Polkadot, then Kusama etc) due to difference in genesis hash
    let wallets: PolkadotAccountData[] = [];

    // Return based on signature type

    const { substrateKeyDerivationMethod } = useSettings.getState();

    // Default - sr25519
    if (substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.MnemonicSr25519) {
      const keyring: Keyring = new _Keyring({ type: 'sr25519' });

      if (dotConnected && !isNil(dotWallet)) {
        wallets.push({
          address: keyring.encodeAddress(dotWallet.address, 42),
          genesisHash: dotGenesisHash,
          name: `${activeWallet.name}`,
          type: 'sr25519', // Default keyring pair type
        });
      } else if (ksmConnected && !isNil(ksmWallet) && isEmpty(wallets)) {
        wallets.push({
          address: keyring.encodeAddress(ksmWallet.address, 42),
          genesisHash: ksmGenesisHash,
          name: `${activeWallet.name}`,
          type: 'sr25519', // Default keyring pair type
        });
      } else if (wndConnected && !isNil(wndWallet) && isEmpty(wallets)) {
        wallets.push({
          address: keyring.encodeAddress(wndWallet.address, 42),
          genesisHash: wndGenesisHash,
          name: `${activeWallet.name}`,
          type: 'sr25519', // Default keyring pair type
        });
      } else if (arcticConnected && !isNil(arcticWallet) && isEmpty(wallets)) {
        wallets.push({
          address: keyring.encodeAddress(arcticWallet.address, 42),
          genesisHash: arcticGenesisHash,
          name: `${activeWallet.name}`,
          type: 'sr25519', // Default keyring pair type
        });
      } else if (snowConnected && !isNil(snowWallet) && isEmpty(wallets)) {
        wallets.push({
          address: keyring.encodeAddress(snowWallet.address, 42),
          genesisHash: snowGenesisHash,
          name: `${activeWallet.name}`,
          type: 'sr25519', // Default keyring pair type
        });
      } else if (astarConnected && !isNil(astarWallet) && isEmpty(wallets)) {
        wallets.push({
          address: keyring.encodeAddress(astarWallet.address, 42),
          genesisHash: astarGenesisHash,
          name: `${activeWallet.name}`,
          type: 'sr25519', // Default keyring pair type
        });
      } else if (shidenConnected && !isNil(shidenWallet) && isEmpty(wallets)) {
        wallets.push({
          address: keyring.encodeAddress(shidenWallet.address, 42),
          genesisHash: shidenGenesisHash,
          name: `${activeWallet.name}`,
          type: 'sr25519', // Default keyring pair type
        });
      } else if (shibuyaConnected && !isNil(shibuyaWallet) && isEmpty(wallets)) {
        wallets.push({
          address: keyring.encodeAddress(shibuyaWallet.address, 42),
          genesisHash: shibuyaGenesisHash,
          name: `${activeWallet.name}`,
          type: 'sr25519', // Default keyring pair type
        });
      }
    }

    // Legacy - ed25519
    if (substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.Bip44Ed25519) {
      const keyring: Keyring = new _Keyring({ type: 'ed25519' });

      if (dotConnected && !isNil(dotWallet)) {
        wallets.push({
          address: keyring.encodeAddress(dotWallet.address, 42),
          genesisHash: dotGenesisHash,
          name: `${activeWallet.name} (Polkadot)`,
          type: 'ed25519',
        });
      }

      if (ksmConnected && !isNil(ksmWallet)) {
        wallets.push({
          address: keyring.encodeAddress(ksmWallet.address, 42),
          genesisHash: ksmGenesisHash,
          name: `${activeWallet.name} (Kusama)`,
          type: 'ed25519',
        });
      }

      if (wndConnected && !isNil(wndWallet)) {
        wallets.push({
          address: keyring.encodeAddress(wndWallet.address, 42),
          genesisHash: wndGenesisHash,
          name: `${activeWallet.name} (Westend)`,
          type: 'ed25519',
        });
      }

      if (arcticConnected && !isNil(arcticWallet)) {
        wallets.push({
          address: keyring.encodeAddress(arcticWallet.address, 42),
          genesisHash: arcticGenesisHash,
          name: `${activeWallet.name} (Arctic)`,
          type: 'ed25519',
        });
      }

      if (snowConnected && !isNil(snowWallet)) {
        wallets.push({
          address: keyring.encodeAddress(snowWallet.address, 42),
          genesisHash: snowGenesisHash,
          name: `${activeWallet.name} (SNOW)`,
          type: 'ed25519',
        });
      }

      if (astarConnected && !isNil(astarWallet)) {
        wallets.push({
          address: keyring.encodeAddress(astarWallet.address, 42),
          genesisHash: astarGenesisHash,
          name: `${activeWallet.name} (Astar)`,
          type: 'ed25519',
        });
      }

      if (shidenConnected && !isNil(shidenWallet)) {
        wallets.push({
          address: keyring.encodeAddress(shidenWallet.address, 42),
          genesisHash: shidenGenesisHash,
          name: `${activeWallet.name} (Shiden)`,
          type: 'ed25519',
        });
      }

      if (shibuyaConnected && !isNil(shibuyaWallet)) {
        wallets.push({
          address: keyring.encodeAddress(shibuyaWallet.address, 42),
          genesisHash: shibuyaGenesisHash,
          name: `${activeWallet.name} (Shibuya)`,
          type: 'ed25519',
        });
      }
    }

    const data = wallets.filter((w) => !isNil(w)) as PolkadotAccountData[];

    const script = `
    window.dispatchEvent(
      new CustomEvent('${POLKADOT_RELAY_RESPONSE}', {
        detail: {
          id: '${id}',
          method: '${method}',
          params: ${JSON.stringify(data)},
        }
      })
    );
    true;
  `;

    console.debug('script: ', script);

    return void webviewEl.current.injectJavaScript(script);
  }

  async function handlePolkadotRelayRequest(payload: PolkadotRequest) {
    console.debug('handlePolkadotRelayRequest: ', payload);

    const { id, method } = payload;

    if (method === 'polkadot_accounts_subscribe' || method === 'polkadot_accounts_get') {
      return void dotHandleAccountsListRequest(payload);
    }

    if (method === 'polkadot_signer_sign_payload' || method === 'polkadot_signer_sign_raw') {
      let data = null;

      if (method === 'polkadot_signer_sign_payload') {
        data = JSON.stringify(payload.payload, null, 4);
      }

      if (method === 'polkadot_signer_sign_raw') {
        data = Web3.utils.isHex(payload.payload.data)
          ? Web3.utils.hexToString(payload.payload.data)
          : payload.payload.data;
      }

      const fromAddress = payload.payload.address;

      return void handleConfirmSigning(ChainID.Polkadot, payload, fromAddress, data, sourceHost);
    }

    if (method === 'polkadot_metadata_get') {
      const definitions = polkadotKnownMetadata();
      const metadata = definitions.map(({ genesisHash, specVersion }) => ({
        genesisHash,
        specVersion,
      }));

      const script = `
      window.dispatchEvent(
        new CustomEvent('${POLKADOT_RELAY_RESPONSE}', {
          detail: {
            id: '${id}',
            method: '${method}',
            metadata: ${JSON.stringify(metadata)},
          }
        })
      );
      true;
    `;

      console.debug('script: ', script);

      dismissModal();

      return void webviewEl.current.injectJavaScript(script);
    }

    if (method === 'polkadot_metadata_provide') {
      const { definition } = payload;
      polkadotAddMetadata(definition);

      const script = `
      window.dispatchEvent(
        new CustomEvent('${POLKADOT_RELAY_RESPONSE}', {
          detail: {
            id: '${id}',
            method: '${method}',
          }
        })
      );
      true;
    `;

      console.debug('script: ', script);

      dismissModal();

      return void webviewEl.current.injectJavaScript(script);
    }
  }

  async function handleEthereumRelayRequest(payload: EthereumRequest) {
    if (!activeWallet) return;
    if (!activeETHWallet) return;
    if (!ethService) return;

    const sourceHost = vanityUrl(uri);

    const { id, method, params } = payload;

    console.debug('***sourceHost:', sourceHost);
    console.debug('method: ', method);

    if (method === 'eth_chainId' || method === 'net_version') {
      if (!evmChainId) return;

      const params = method === 'eth_chainId' ? Web3.utils.toHex(evmChainId) : String(evmChainId);

      const script = `
      window.dispatchEvent(
        new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
          detail: {
            id: '${id}',
            method: '${method}',
            params: '${params}',
          }
        })
      );
      true;
    `;

      console.debug('script: ', script);

      return void webviewEl.current.injectJavaScript(script);
    }

    if (
      method === 'eth_requestAccounts' ||
      method === 'eth_accounts' ||
      method === 'eth_coinbase'
    ) {
      const script = `
      window.dispatchEvent(
        new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
          detail: {
            id: '${id}',
            method: '${method}',
            params: ['${activeETHWallet.address}'],
          }
        })
      );
      true;
    `;

      console.debug('script: ', script);

      return void webviewEl.current.injectJavaScript(script);
    }

    if (method === 'eth_sendTransaction' || method === 'eth_signTransaction') {
      return void ethHandleConfirmTransaction(payload, sourceHost);
    }

    if (method === 'eth_sign' || method === 'personal_sign') {
      const request = payload as EthereumRequestSign;
      const dataToSign = method === 'eth_sign' ? request.params[1] : request.params[0];
      const signFrom = Web3.utils.toChecksumAddress(
        method === 'eth_sign' ? request.params[0] : request.params[1]
      );

      return void handleConfirmSigning(ChainID.Ethereum, payload, signFrom, dataToSign, sourceHost);
    }

    if (method === 'eth_subscribe') {
      const request = payload as EthereumRequestSubscribe;

      const subscription = await ethService.subscribe(request);

      // TODO
    }

    if (method === 'wallet_watchAsset') {
      if ((payload as EthereumRequestAddAsset)?.params.type === 'ERC20') {
        const request = payload as EthereumRequestAddAsset;
        const { address, decimals, symbol } = request.params.options;

        realm?.write(() => {
          const tokens = realm?.objects<Token>('Token');

          if (!tokens.find((t) => t.contract === address)) {
            let newToken = new Token(
              ethService.getNetworkDetails().chainType,
              symbol,
              symbol,
              decimals
            );

            newToken.isCustom = true;
            newToken.contract = address;

            if (isTestnetConfig(otherNetwork)) {
              newToken.networkRef = otherNetwork.ref;
            } else if (isCustomNetwork(otherNetwork)) {
              newToken.customNetworkId = otherNetwork.id;
            }

            realm?.create<Token>('Token', newToken);
          }
        });

        setToastMessage(`Added custom token ${symbol}`, ToastType.success);

        return;
      }
    }

    if (method === 'wallet_switchEthereumChain') {
      if (!isMainnet) {
        // TEMP: disable wallet_switchEthereumChain when already on a testnet
        // Need to re-add this with user prompts
        const script = `
          window.dispatchEvent(
            new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
              detail: {
                id: '${id}',
                error: ${JSON.stringify(ethErrors.provider.unsupportedMethod().serialize())}
              }
            })
          );
          true;
        `;
        return void webviewEl.current.injectJavaScript(script);
      }

      const request = payload as EthereumRequestSwitchEthereumChain;
      const { chainId: hexChainId } = request.params[0];

      console.debug('request: ', request);
      console.debug('hexChainId: ', hexChainId);

      const chainId = Web3.utils.toDecimal(hexChainId);

      console.debug('chainId: ', chainId);

      const allEVMChainIds = evmNetworks.map((n) => n.chainId);
      const allEVMCustomNetworkChainIds =
        getCustomNetworksForChain(ChainID.Ethereum)?.map((n) => n.networkId) || [];

      if (!allEVMChainIds.includes(chainId) && !allEVMCustomNetworkChainIds.includes(chainId)) {
        setToastMessage(
          `Unrecognized chain ID ${chainId}. Try adding the chain first`,
          ToastType.error
        );

        return;
      }

      const evmMainnetChainIds = evmMainnets.map((n) => (n as EthereumNetworkDetails).chainId);

      // Is mainnet
      if (evmMainnetChainIds.includes(chainId)) {
        const network = evmMainnets.find(
          (n) => (n as EthereumNetworkDetails).chainId === chainId
        ) as EthereumNetworkDetails;

        selectOtherNetwork(null);

        updateChainIDForAuthorizedDApp(activeWallet, sourceHost, network.chainType);

        emitEvent('chainChanged', Web3.utils.toHex(chainId));

        const script = `
          window.dispatchEvent(
            new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
              detail: {
                id: '${id}',
                method: '${method}',
                params: '${params}',
              }
            })
          );
          true;
        `;

        console.debug('script: ', script);

        return void webviewEl.current.injectJavaScript(script);
      } else {
        // TEMP: disable wallet_switchEthereumChain for testnets
        // Need to re-add this with user prompts
        const script = `
          window.dispatchEvent(
            new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
              detail: {
                id: '${id}',
                error: ${JSON.stringify(ethErrors.provider.unsupportedMethod().serialize())}
              }
            })
          );
          true;
        `;
        return void webviewEl.current.injectJavaScript(script);

        /*
        // Other networks
        const ethTestnets = testnets[ChainID.Ethereum] as EthereumNetworkDetails[];
        const customNetworks = getCustomNetworksForChain(ChainID.Ethereum);
        const testnet = ethTestnets.find((t) => t.chainId === chainId);
        // Testnet
        if (testnet) {
          selectOtherNetwork(testnet);

          setToastMessage(`Switched to ${testnet.name} network`, ToastType.success);

          emitEvent('chainChanged', Web3.utils.toHex(testnet.chainId));

          const script = `
            window.dispatchEvent(
              new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
                detail: {
                  id: '${id}',
                  method: '${method}',
                  params: '${params}',
                }
              })
            );
            true;
          `;

          console.debug('script: ', script);

          return void webviewEl.current.injectJavaScript(script);
        } else {
          // Custom network
          const customNetwork = customNetworks?.find((n) => n.networkId === chainId);

          if (customNetwork) {
            selectOtherNetwork(customNetwork);

            setToastMessage(`Switched to ${customNetwork.name} network`, ToastType.success);

            emitEvent('chainChanged', Web3.utils.toHex(customNetwork.networkId));

            const script = `
              window.dispatchEvent(
                new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
                  detail: {
                    id: '${id}',
                    method: '${method}',
                    params: '${params}',
                  }
                })
              );
              true;
            `;

            console.debug('script: ', script);

            return void webviewEl.current.injectJavaScript(script);
          }
          // else {
          //   // EVM Network Mainnets
          //   const network = evmMainnets.find(
          //     (n) => (n as EthereumNetworkDetails).chainId === chainId
          //   ) as EthereumNetworkDetails;

          //   console.debug('is mainnet!');
          //   console.debug('network: ', network);

          //   if (!isNil(network)) {
          //     showConfirmSwitchNetworkModal(network.name, () => {
          //       selectOtherNetwork(null);
          //       setEvmChain(network.chainType);

          //       setToastMessage(`Switched to ${network.name}`);

          //       webviewEl.current?.reload();

          //       emitEvent('chainChanged', Web3.utils.toHex(network.chainId));
          //     });
          //   }

          //   return;
          // }
        }
        */
      }
    }

    if (method === 'wallet_addEthereumChain') {
      console.debug('requestPayload: ', payload);

      const request = payload as EthereumRequestAddEthereumChain;

      if (isEmpty(request.params)) return;

      const { chainId, chainName, nativeCurrency, rpcUrls, blockExplorerUrls } = request.params[0];

      console.debug('request: ', JSON.stringify(request));

      realm?.write(() => {
        realm?.create('CustomNetwork', {
          id: uuid(),
          chain: ChainID.Ethereum,
          name: chainName,
          providerRpcUrl: rpcUrls[0],
          networkId: Web3.utils.hexToNumber(chainId),
          symbol: nativeCurrency.symbol,
          blockExplorerUrl: !isEmpty(blockExplorerUrls) ? blockExplorerUrls![0] : undefined,
        });
      });

      setToastMessage(`Added ${chainName} network`, ToastType.success);

      return;
    }

    // All other requests
    try {
      const request = payload as EthereumRequest;
      const result = await ethService.rpcTransaction(activeETHWallet, request);

      const script = `
      window.dispatchEvent(
        new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
          detail: {
            id: '${id}',
            method: '${method}',
            params: ${JSON.stringify(result)},
          }
        })
      );
      true;
    `;

      console.debug('script: ', script);

      return void webviewEl.current.injectJavaScript(script);
    } catch (error) {
      setToastMessage((error as any)?.message, ToastType.error);

      console.debug('unsupported method? error: ', error);

      const script = `
      window.dispatchEvent(
        new CustomEvent('${ETHEREUM_RELAY_RESPONSE}', {
          detail: {
            id: '${id}',
            error: ${JSON.stringify(ethErrors.provider.unsupportedMethod().serialize())}
          }
        })
      );
      true;
    `;

      console.debug('script: ', script);

      return void webviewEl.current.injectJavaScript(script);
    }
  }

  async function handleIconRelayRequest(type: string, payload: any) {
    console.debug('handleIconRelayRequest: ', type);
    console.debug('payload: ', payload);

    const sourceHost = vanityUrl(uri);

    switch (type) {
      case 'REQUEST_HAS_ACCOUNT':
        return void webviewEl.current.injectJavaScript(`
        window.dispatchEvent(
          new CustomEvent('ICONEX_RELAY_RESPONSE', {
            detail: {
              type: 'RESPONSE_HAS_ACCOUNT',
              payload: { hasAccount: true },
            }
          })
        );
        true;
      `);
      case 'REQUEST_HAS_ADDRESS':
        const allWalletAddresses = wallets
          .flatMap((w) => w.chainWallets)
          .filter((w) => w.type === ChainID.ICON)
          .map((w) => w.address);

        return void webviewEl.current.injectJavaScript(`
        window.dispatchEvent(
          new CustomEvent('ICONEX_RELAY_RESPONSE', {
            detail: {
              type: 'RESPONSE_HAS_ADDRESS',
              payload: { hasAddress: ${allWalletAddresses.includes(payload)} },
            }
          })
        );
        true;
      `);
      case 'REQUEST_ADDRESS':
        return void webviewEl.current.injectJavaScript(`
        window.dispatchEvent(
          new CustomEvent('ICONEX_RELAY_RESPONSE', {
            detail: {
              type: 'RESPONSE_ADDRESS',
              payload: '${activeICXWallet?.address}',
            }
          })
        );
        true;
      `);

      case 'REQUEST_SIGNING':
        const { from, hash } = payload;

        console.debug('request signing payload: ', payload);

        return handleConfirmSigning(ChainID.ICON, null, from, hash, sourceHost);

      case 'REQUEST_JSON-RPC':
        if (
          !isNil(payload.params.nid) &&
          IconConverter.toNumber(payload.params.nid) !== icxNetwork?.networkId
        ) {
          console.debug('wrong network');
          return icxHandleWrongNetworkTransaction(payload);
        } else if (
          !isNil(payload.params.value) &&
          convertLoopToToken(payload.params.value).isGreaterThan(activeICXWallet?.balance || 0)
        ) {
          console.debug('insufficient funds');
          return activeICXWallet && icxHandleInsufficientFundsTransaction(payload, activeICXWallet);
        }
        console.debug('confirm transaction');
        return icxHandleConfirmTransaction(payload, sourceHost);

      default:
        throw new Error(`Unknown ICONex relay event: ${type}`);
    }
  }

  function icxHandleWrongNetworkTransaction(payload: any) {
    if (!icxNetwork) return;

    const title = 'Transaction';
    const content = (
      <View style={{ marginTop: 20 }}>
        <WrongNetworkTransactionModal
          payload={payload}
          network={icxNetwork}
          onCancel={() => {
            dismissModal();
            icxHandleCancelTransaction();
          }}
        />
      </View>
    );
    const options = {
      withCloseButton: false,
      confirmButton: {
        title: 'Cancel transaction',
        onPress: () => {
          dismissModal();
          icxHandleCancelTransaction();
        },
      },
    };

    presentModal({
      title,
      content,
      options,
    });
  }

  function icxHandleInsufficientFundsTransaction(payload: any, wallet: ChainWallet) {
    presentModal({
      title: 'Transaction',
      content: (
        <InsufficientFundsTransactionModal
          payload={payload}
          wallet={wallet}
          onCancel={() => {
            dismissModal();
            icxHandleCancelTransaction();
          }}
        />
      ),
      options: {
        withCloseButton: false,
      },
    });
  }

  function icxHandleCancelTransaction() {
    webviewEl.current.injectJavaScript(`
      window.dispatchEvent(
        new CustomEvent('ICONEX_RELAY_RESPONSE', {
          detail: {
            type: 'CANCEL_JSON-RPC',
          }
        })
      );
      true;
    `);
  }

  async function handleRelayRequest(data: string) {
    if (!activeWallet) return;

    const [message] = data.split(':');

    if (!hasAuthorizedDApp(activeWallet, sourceHost)) {
      if (message === 'ethereum') {
        const isEvmConnected = !isNil(activeChainWallets.find((cw) => isEthOrEvmChainID(cw.type)));

        if (isEvmConnected) {
          handleAuthorizeDApp(sourceHost, data);
        }
      }

      if (message === 'icon') {
        const isIconConnected = !isNil(activeChainWallets.find((cw) => cw.type === ChainID.ICON));

        if (isIconConnected) {
          handleAuthorizeDApp(sourceHost, data);
        }
      }

      if (message === 'polkadot') {
        const isSubstrateConnected = !isNil(
          activeChainWallets.find((cw) => isSubstrateChain(cw.type))
        );

        if (isSubstrateConnected) {
          handleAuthorizeDApp(sourceHost, data);
        }
      }

      return;
    }

    console.debug('message: ', message);

    if (
      message === 'ethereum' &&
      (isMainnet ||
        otherNetworkChainID === ChainID.Ethereum ||
        (otherNetworkChainID && isEvmChainID(otherNetworkChainID)))
    ) {
      const [message, encodedPayload] = data.split(':');
      const decodedPayload = atob(encodedPayload);
      handleEthereumRelayRequest(JSON.parse(decodedPayload));
    }

    if (message === 'icon' && (isMainnet || otherNetworkChainID === ChainID.ICON)) {
      const [message, type, encodedPayload] = data.split(':');

      console.debug('type: ', type);
      console.debug('encoded pay: ', encodedPayload);

      const decodedPayload = encodedPayload ? atob(encodedPayload) : null;
      handleIconRelayRequest(type, JSON.parse(decodedPayload));
    }

    if (
      message === 'polkadot' &&
      (isMainnet || (otherNetworkChainID && isSubstrateChain(otherNetworkChainID)))
    ) {
      const [message, encodedPayload] = data.split(':');
      const decodedPayload = atob(encodedPayload);

      console.debug('decodedPayload: ', decodedPayload);
      handlePolkadotRelayRequest(JSON.parse(decodedPayload));
    }
  }

  return (
    <SafeAreaScreen
      top={Platform.OS === 'android'}
      padTop={false}
      bottom={false}
      style={{ backgroundColor: isDarkMode ? colors.purple.darkBlacker : colors.gray.cards }}
    >
      <View style={styles.header}>
        <TouchableOpacity style={styles.closeButton}>
          <CloseButton style={styles.closeButton} onPress={handleClose} />
        </TouchableOpacity>
        <View
          style={[common.fill, { marginHorizontal: 10 }]}
          onLayout={({ nativeEvent: { layout } }) => setInputWidth(layout.width)}
        >
          <TextInput
            ref={urlInputRef}
            value={urlInput}
            onChangeText={(text) => {
              setUrlInput(text);
            }}
            onTouchStart={() => setIsKeyboardOpen(true)}
            onEndEditing={() => setIsKeyboardOpen(false)}
            onSubmitEditing={handleChangeUrl}
            onBlur={() => setUrlInput((urlInput) => vanityUrl(urlInput))}
            placeholder="Enter an address or search term"
            placeholderTextColor={colors.gray.placeholder}
            returnKeyType="go"
            autoCorrect={false}
            autoCapitalize="none"
            selectTextOnFocus={true}
            style={styles.input}
            keyboardType="url"
          />
          {httpsUrl ? (
            <PadlockLockedIcon style={styles.padlockIcon} />
          ) : (
            <PadlockUnlockedIcon style={styles.padlockIcon} />
          )}
          {isKeyboardOpen === false && urlInput.length > 0 && (
            <TouchableOpacity
              onPress={() => webviewEl.current?.reload()}
              style={styles.refreshButton}
            >
              <RefreshIcon style={{ backgroundColor: 'white' }} height={20} width={20} />
            </TouchableOpacity>
          )}
          {isKeyboardOpen === true && urlInput.length != 0 && (
            <TouchableOpacity
              onPress={() => {
                urlInputRef?.current?.focus();
                setUrlInput('');
              }}
              style={styles.refreshButton}
            >
              <CrossIcon width={20} height={20} />
            </TouchableOpacity>
          )}

          <Animated.View
            style={[
              styles.loadingBar,
              { width: progressAnim },
              gt(loadingProgress, 0.98) && { borderBottomRightRadius: 4 },
            ]}
          />
        </View>
      </View>
      {/* NOTE: injectedJavaScriptBeforeContentLoaded is important for chain switching to work for EVM chains */}
      <RefreshableWebView
        ref={webviewEl}
        source={{ uri }}
        onLoad={({ nativeEvent }) => {
          const url = vanityUrl(nativeEvent.url);
          setUrlData({ url, title: nativeEvent.title });
          fetchLogo(url)
            .then(setFaviconUrl)
            .catch(() => null);
        }}
        onNavigationStateChange={handleNavigationStateChange}
        onLoadProgress={({ nativeEvent: { progress }, nativeEvent }) => {
          setLoadingProgress(progress);
          const url = vanityUrl(nativeEvent.url);
          setUrlData({ url, title: nativeEvent.title });
          fetchLogo(url)
            .then(setFaviconUrl)
            .catch(() => null);
        }}
        onLoadStart={() => setLoadingProgress(0.1)}
        onLoadEnd={handleLoadEnd}
        injectedJavaScriptBeforeContentLoaded={injectionScript}
        onMessage={(event) => handleRelayRequest(event.nativeEvent.data)}
        isRefreshing={isRefreshing}
        onRefresh={handleRefresh}
        geolocationEnabled
        thirdPartyCookiesEnabled
        style={common.fill}
        containerStyle={Platform.OS === 'ios' && { paddingBottom: 116 + insets.bottom }}
        forceDarkOn={isDarkMode}
      />

      <Animated.View
        style={[
          styles.footerButtons,
          { paddingBottom: Math.max(insets.bottom, 15) },
          { transform: [{ translateY: footerAnim }] },
        ]}
      >
        <TouchableOpacity
          onPress={() => webviewEl.current.goBack()}
          style={styles.footerButton}
          disabled={!canGoBack}
        >
          {isDarkMode ? (
            <LeftIconLight
              style={
                (!canGoBack && styles.footerButtonDisabled,
                { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards })
              }
              width={22}
              height={22}
            />
          ) : (
            <LeftIconDark
              style={
                (!canGoBack && styles.footerButtonDisabled,
                { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards })
              }
              width={22}
              height={22}
            />
          )}
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => webviewEl.current.goForward()}
          style={styles.footerButton}
          disabled={!canGoForward}
        >
          {isDarkMode ? (
            <RightIconLight
              style={
                (!canGoForward && styles.footerButtonDisabled,
                { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards })
              }
              width={22}
              height={22}
            />
          ) : (
            <RightIconDark
              style={
                (!canGoForward && styles.footerButtonDisabled,
                { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards })
              }
              width={22}
              height={22}
            />
          )}
        </TouchableOpacity>
        <CloseButton style={styles.footerButton} onPress={handleClose} />
        <TouchableOpacity onPress={onChangeWallet} style={styles.footerButton}>
          {isDarkMode ? (
            <PortfolioIconLight width={22} height={22} />
          ) : (
            <PortfolioIconDark width={22} height={22} />
          )}
        </TouchableOpacity>
      </Animated.View>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 15,
    paddingHorizontal: 10,
  },
  padlockIcon: {
    position: 'absolute',
    left: 15,
    top: 10,
    opacity: 0.8,
  },
  input: {
    flex: 1,
    fontSize: 14,
    color: colors.black,
    backgroundColor: colors.white,
    borderColor: colors.gray.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: 4,
    paddingLeft: 38,
    paddingRight: 40,
    marginTop: 2,
  },
  closeButton: {
    padding: 3,
  },
  refreshButton: {
    position: 'absolute',
    right: 10,
    top: 5,
    padding: 5,
  },
  loadingBar: {
    position: 'absolute',
    left: 0,
    bottom: 0,
    height: 3,
    backgroundColor: colors.brand.primary,
    borderBottomLeftRadius: 4,
  },
  footerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 15,
    paddingHorizontal: 20,
  },
  footerButton: {
    padding: 10,
  },
  footerButtonDisabled: {
    opacity: 0.6,
  },
  footer: {
    flexDirection: 'row',
    paddingBottom: 50,
    paddingHorizontal: 20,
  },
});
