import CaretLeftBlackIcon from '@/assets/icons/caret-left-black.svg';
import CaretLeftWhiteIcon from '@/assets/icons/caret-left-white.svg';
import CaretRightBlackIcon from '@/assets/icons/caret-right-black.svg';
import CaretRightWhiteIcon from '@/assets/icons/caret-right-white.svg';
import { Button } from '@/components/Button';
import { AddressItem } from '@/components/ConnectWithLedger/AddressItem';
import Loading from '@/components/Loading';
import { ConnectToLedgerModal } from '@/components/Modals/ConnectToLedger/ConnectToLedgerModal';
import { HomeStackParams, RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { TextButton } from '@/components/TextButton';
import { ToastType } from '@/components/Toast.types';
import { TokenLogo } from '@/components/TokenLogo';
import { AltHeading, Heading, Text } from '@/components/Typography';
import { LedgerDevice, LedgerDeviceConnection } from '@/models/Ledger';
import { serviceForChainID, useChainServices } from '@/stores/ChainServices';
import { useLedgerStore } from '@/stores/Ledger';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainID } from '@/utils/chains';
import {
  appTypeForChainID,
  getLedgerAddresses,
  getLedgerAppName,
  initialIndexForChainID,
  LedgerAddress,
  LedgerAddresses,
} from '@/utils/ledger';
import { dismissModal, presentModal, PresentModalProps } from '@/utils/modal';
import { common } from '@/utils/styles';
import TransportHID from '@ledgerhq/react-native-hid';
import TransportBLE from '@ledgerhq/react-native-hw-transport-ble';
import {
  CompositeNavigationProp,
  RouteProp,
  useIsFocused,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import produce from 'immer';
import { get, isNil, last, without } from 'lodash-es';
import React, { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import { FlatList, Platform, StyleSheet, View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { check, checkMultiple, PERMISSIONS, requestMultiple } from 'react-native-permissions';
import { Observable, Subscription } from 'rxjs';

// NOTE: BLE module is imported lazily so that the Bluetooth permissions don't prompt when app first loads
// let TransportBLE: typeof TransportBLEType.default | undefined = undefined;

const ADDRESSES_PER_PAGE = 3;
const NUMBER_OF_PAGES = 3;

enum State {
  Initial,
  Connecting,
  FetchingAddresses,
  FetchedAddresses,
}

type SettingsNavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'ConnectWithLedger'>,
  StackNavigationProp<RootStackParams>
>;

type HomeNavigationProps = CompositeNavigationProp<
  StackNavigationProp<HomeStackParams, 'ConnectWithLedger'>,
  StackNavigationProp<RootStackParams>
>;

type SettingsRouteProps = RouteProp<SettingsStackParams, 'ConnectWithLedger'>;
type HomeRouteProps = RouteProp<HomeStackParams, 'ConnectWithLedger'>;

export function ConnectWithLedger() {
  const { navigate, popToTop, setOptions } = useNavigation<
    SettingsNavigationProps | HomeNavigationProps
  >();
  const { params } = useRoute<SettingsRouteProps | HomeRouteProps>();
  const initialChainId = useMemo(() => params?.initialChainId ?? null, []);

  const { isDarkMode, colors, styles: themeStyles } = useTheme();
  const isFocused = useIsFocused();
  const { connectedChains } = useChainServices();
  const { getActiveChainWallets } = useVault();

  const allChainIds = useMemo(
    () =>
      connectedChains.filter((chain) => chain.supportsLedger !== false).map((chain) => chain.id),
    []
  );
  const connectedChainIds = useMemo(
    () => getActiveChainWallets().map((chainWallet) => chainWallet.type),
    []
  );
  const chains = useMemo(() => {
    if (!isNil(initialChainId)) {
      const otherChainIds = without(allChainIds, initialChainId, ...connectedChainIds);
      return [initialChainId, ...otherChainIds];
    }

    return allChainIds;
  }, [initialChainId, allChainIds, connectedChainIds]);

  const bleScanSub = React.useRef<Subscription | null>(null);
  const hidScanSub = React.useRef<Subscription | null>(null);

  const [state, setState] = useState(State.Initial);
  const [addresses, setAddresses] = useState<LedgerAddress[]>([]);
  const [chain, setChain] = useState(chains[0]);

  const [ledgerAddresses, setLedgerAddresses] = useState<LedgerAddresses>({});
  const [selectedAddresses, setSelectedAddresses] = useState(false);

  const [permissionsGranted, setPermissionsGranted] = useState(false);

  const [page, setPage] = useState(1);
  const pages = useMemo(
    () => Array.from(new Array(NUMBER_OF_PAGES), (_, index) => Math.max(page, 2) + (index - 1)),
    [page]
  );

  const isLastChain = useMemo(() => {
    return chain === last(chains);
  }, [chain]);

  const nextChain = useMemo(() => {
    const currentChainIndex = chains.indexOf(chain);

    if (currentChainIndex < chains.length - 1) {
      return chains[currentChainIndex + 1];
    }

    return undefined;
  }, [chain]);

  const chainService = useMemo(() => chain && serviceForChainID(chain), [chain]);

  const {
    availableDevices: devices,
    setAvailableDevices: setDevices,
    transport,
    setTransport,
    ledgerBleId,
    setLedgerBleId,
  } = useLedgerStore();

  const { importLedger, importLedgerExistingWallet } = useVault();

  const { setToastMessage, setHideTabBar } = useNavigationStore();

  async function startScanning() {
    console.debug('Start scanning');
    // if (!TransportBLE) {
    //   TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
    // }

    bleScanSub.current = new Observable(TransportBLE.listen).subscribe({
      complete: () => {
        console.debug('bleScanSub: complete');
      },
      next: (event) => {
        const type = get(event, 'type');

        if (type === 'add') {
          const device = get(event, 'descriptor') as LedgerDevice;
          device.connection = LedgerDeviceConnection.ble;

          if (!devices.find((d) => d.id === device.id)) {
            setDevices([device, ...devices]);
          }
        }
      },
      error: (error) => {
        console.debug('scanSub: error', error);
      },
    });

    const hidSupported = await TransportHID.isSupported();

    console.debug('hidSupported: ', hidSupported);

    if (hidSupported) {
      console.debug('STARTING HID SCAN');
      hidScanSub.current = new Observable(TransportHID.listen).subscribe({
        complete: () => {
          console.debug('hidScanSub: complete');
        },
        next: (event) => {
          const type = get(event, 'type');

          if (type === 'add') {
            const device = get(event, 'descriptor') as LedgerDevice;
            device.connection = LedgerDeviceConnection.hid;

            console.debug('hid device: ', device);

            console.debug('hid device id: ', device.id);
            console.debug('hid device name: ', device.name);

            if (!devices.find((d) => d.id === device.id)) {
              setDevices([device, ...devices]);
            }
          }
        },
        error: (error) => {
          console.debug('hidScanSub: error', error);
        },
      });
    } else {
      console.debug('HID NOT SUPPORTED');
    }
  }

  function stopScanning() {
    console.debug('stopScanning');

    if (bleScanSub.current) {
      bleScanSub.current.unsubscribe();
    }

    if (hidScanSub.current) {
      hidScanSub.current.unsubscribe();
    }
  }

  useEffect(() => {
    if (Platform.OS === 'android') {
      checkMultiple([
        PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
        PERMISSIONS.ANDROID.BLUETOOTH_SCAN,
        PERMISSIONS.ANDROID.BLUETOOTH_CONNECT,
      ]).then((statuses) => {
        if (
          statuses[PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION] === 'denied' ||
          statuses[PERMISSIONS.ANDROID.BLUETOOTH_SCAN] === 'denied' ||
          statuses[PERMISSIONS.ANDROID.BLUETOOTH_CONNECT] === 'denied'
        ) {
          requestMultiple([
            PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
            PERMISSIONS.ANDROID.BLUETOOTH_SCAN,
            PERMISSIONS.ANDROID.BLUETOOTH_CONNECT,
          ]).then((statuses) => {
            if (
              statuses[PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION] === 'denied' ||
              statuses[PERMISSIONS.ANDROID.BLUETOOTH_SCAN] === 'denied' ||
              statuses[PERMISSIONS.ANDROID.BLUETOOTH_CONNECT] === 'denied'
            ) {
              // Denied
              // Show error
              setToastMessage(
                'Please enable location and bluetooth permissions to use with Ledger',
                ToastType.error
              );
            } else {
              setPermissionsGranted(true);
            }
          });
        } else {
          setPermissionsGranted(true);
        }
      });
    }

    if (Platform.OS === 'ios') {
      check(PERMISSIONS.IOS.BLUETOOTH_PERIPHERAL).then((status) => {
        if (status === 'blocked') {
          setToastMessage(
            'Please enable bluetooth permissions to use with Ledger',
            ToastType.error
          );
        } else {
          setPermissionsGranted(true);
        }
      });
    }
  }, []);

  useEffect(() => {
    setLedgerBleId(null);

    if (transport) {
      transport.close();

      setTransport(null);
    }

    // startScanning();

    return () => {
      stopScanning();
    };
  }, []);

  useEffect(() => {
    if (permissionsGranted) {
      startScanning();
    } else {
      stopScanning();
    }
  }, [permissionsGranted]);

  useEffect(() => {
    if (selectedAddresses) {
      if (!isNil(initialChainId)) {
        // Came from wallet addresses modal on Home screen
        importLedgerExistingWallet(ledgerAddresses, ledgerBleId);
      } else {
        importLedger(ledgerAddresses, ledgerBleId);
      }

      popToTop();

      // @ts-expect-error not worth mapping navigation props to here
      navigate('HomeStack');
    }
  }, [selectedAddresses, ledgerAddresses, initialChainId]);

  useEffect(() => {
    setOptions({
      headerRight: () => (
        <AltHeading style={{ marginRight: 20 }}>
          Step {chains.indexOf(chain) + 1} of {chains.length}
        </AltHeading>
      ),
    });
  }, [chains, chain]);

  useLayoutEffect(() => {
    if (isFocused) {
      setHideTabBar(true);
    }
  }, []);

  async function fetchAddresses() {
    const { transport } = useLedgerStore.getState();

    if (isNil(chain) || isNil(transport) || state !== State.FetchingAddresses) {
      return;
    }

    try {
      // Fetch addresses
      const appType = appTypeForChainID(chain);
      const initialIndex = initialIndexForChainID(chain);

      const addresses = await getLedgerAddresses(
        transport,
        appType!,
        ADDRESSES_PER_PAGE,
        initialIndex + (page - 1) * ADDRESSES_PER_PAGE
      );
      setAddresses(addresses);

      setState(State.FetchedAddresses);
    } catch (error) {
      console.debug('error: ', error);
      setToastMessage(
        `Failed getting addresses from ${getLedgerAppName(chain)} app`,
        ToastType.error
      );
      transport.close();
      setTransport(null);
      setState(State.Initial);
    }
  }

  useEffect(() => {
    fetchAddresses();
  }, [transport, chain, state, page]);

  async function onConnect() {
    if (!isNil(transport)) {
      setState(State.FetchingAddresses);
    } else if (ledgerBleId) {
      setState(State.Connecting);

      // Reconnect
      // if (!TransportBLE) {
      //   TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
      // }

      const device = devices.find((d) => d.id === ledgerBleId);

      // Pause for 2 seconds -- sometimes the device is not ready to connect
      // Seems to be only an issue for Android
      if (Platform.OS === 'android') {
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }

      console.debug('onConnect device: ', device);

      if (device) {
        try {
          console.debug('before opening transport');
          const newTransport = await TransportBLE.open(device);

          setTransport(newTransport);

          console.debug('setTransport with: ', newTransport);

          setState(State.FetchingAddresses);
        } catch (error) {
          console.debug('error: ', error);
        }
      }
    } else {
      // Not connected yet - Show modal
      setState(State.Connecting);
      const title = 'Connect to Ledger';
      const content = (
        <ConnectToLedgerModal
          onSelectedDevice={async (device) => {
            dismissModal();

            setState(State.FetchingAddresses);

            if (device.connection === LedgerDeviceConnection.ble) {
              // if (!TransportBLE) {
              //   TransportBLE = (await import('@ledgerhq/react-native-hw-transport-ble')).default;
              // }

              const thisTransport = await TransportBLE.open(device);
              thisTransport.on('disconnect', async () => {
                console.debug('BLE disconnected');

                // NOTE: Need to get from store to make sure it's getting the latest data
                const { transport, ledgerBleId } = useLedgerStore.getState();

                if (thisTransport === transport) {
                  if (ledgerBleId) {
                    // Reset transport

                    setTransport(null);
                  } else {
                    setState(State.Initial);

                    setToastMessage(
                      'Your Ledger was disconnected. Please try again!',
                      ToastType.error
                    );
                  }
                }
              });

              setTransport(thisTransport);
              setLedgerBleId(device.id);
            } else if (device.connection === LedgerDeviceConnection.hid) {
              const thisTransport = await TransportHID.open(device as any);
              thisTransport.on('disconnect', () => {
                console.debug('HID disconnected');

                if (thisTransport === transport) {
                  setState(State.Initial);

                  setToastMessage(
                    'Your Ledger was disconnected. Please try again!',
                    ToastType.error
                  );
                }
              });

              setTransport(thisTransport);
            }
          }}
        />
      );

      const options: PresentModalProps['options'] = {
        onClose: () => {
          dismissModal();
          setState(State.Initial);
          setTransport(null);
        },
      };

      presentModal({
        title,
        content,
        options,
      });
    }
  }

  return (
    <SafeAreaScreen>
      <Heading>Connect Ledger</Heading>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>
        <TokenLogo chain={chainForChainID(chain!)} size={35} />
        <Text muted style={{ marginLeft: 10 }}>
          Connect to the {chain} network
        </Text>
      </View>

      {state > State.Connecting ? (
        <>
          {state === State.FetchedAddresses ? (
            <FlatList
              style={{ width: '100%', marginTop: 30 }}
              data={addresses}
              keyExtractor={(item) => item.address}
              renderItem={({ item, index }) => (
                <AddressItem
                  ledgerAddress={item}
                  onPress={async () => {
                    setLedgerAddresses(
                      produce(ledgerAddresses, (draft) => {
                        draft[chain!] = item;
                      })
                    );

                    if (isLastChain) {
                      setSelectedAddresses(true);
                    } else if (nextChain) {
                      setChain(nextChain);
                      setState(State.Initial);

                      if (ledgerBleId) {
                        // Disconnect transport
                        // NOTE: Transport cannot be re-initiated until it has emitted "disconnect" event
                        await TransportBLE.disconnect(ledgerBleId);
                        await transport?.close();
                        setTransport(null); // Reset transport
                      }
                    }
                  }}
                  chainService={chainService}
                  chainID={chain!}
                  style={index !== 0 && { marginTop: 15 }}
                />
              )}
            />
          ) : (
            <View style={[common.fill, { marginTop: 30 }]}>
              {pages.map((page, index) => (
                <View style={index !== 0 && { marginTop: 15 }} key={page}>
                  <Loading width="100%" height={54} />
                </View>
              ))}
            </View>
          )}

          <View style={styles.paginationContainer}>
            <TouchableOpacity
              onPress={() => {
                setState(State.FetchingAddresses);
                setPage((page) => page - 1);
              }}
              disabled={page === 1 || state === State.FetchingAddresses}
              style={[styles.paginationButton, themeStyles.cards]}
            >
              {isDarkMode ? <CaretLeftWhiteIcon /> : <CaretLeftBlackIcon />}
            </TouchableOpacity>
            {pages.map((pageNumber) => (
              <TouchableOpacity
                key={pageNumber}
                onPress={() => {
                  setState(State.FetchingAddresses);
                  setPage(pageNumber);
                }}
                disabled={state === State.FetchingAddresses}
                style={styles.pageNumber}
              >
                <Text center bold={page === pageNumber}>
                  {pageNumber.toString()}
                </Text>
              </TouchableOpacity>
            ))}
            <View style={styles.pageNumber}>
              <Text center>…</Text>
            </View>
            <TouchableOpacity
              onPress={() => {
                setState(State.FetchingAddresses);
                setPage((page) => page + 1);
              }}
              disabled={state === State.FetchingAddresses}
              style={[styles.paginationButton, themeStyles.cards]}
            >
              {isDarkMode ? <CaretRightWhiteIcon /> : <CaretRightBlackIcon />}
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <View style={[common.centerContent, styles.contentContainer, themeStyles.cards]}>
          <Text center>
            Connect and unlock your Ledger, then open the {getLedgerAppName(chain!)} app on your
            Ledger.
          </Text>

          <Button
            onPress={onConnect}
            working={state === State.Connecting}
            style={{ marginTop: 30 }}
          >
            Connect to Ledger
          </Button>

          <TextButton
            onPress={() => {
              if (isLastChain) {
                setSelectedAddresses(true);
              } else {
                nextChain && setChain(nextChain);
              }
            }}
            style={[{ marginTop: 25 }]}
            textStyle={isDarkMode && { color: colors.foreground }}
          >
            Skip for now
          </TextButton>
        </View>
      )}
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  contentContainer: {
    minHeight: 220,
    padding: 16,
    marginTop: 30,
  },
  paginationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 30,
  },
  paginationButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 10,
  },
  pageNumber: {
    width: 30,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
