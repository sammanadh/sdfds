import { Button, ButtonVariant } from '@/components/Button';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { TextInput, TextInputRef } from '@/components/TextInput';
import { Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import { common } from '@/utils/styles';
import { wait } from '@/utils/wait';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as Haptics from 'expo-haptics';
import { useEffect, useRef, useState } from 'react';
import { KeyboardAvoidingView, StyleSheet } from 'react-native';

interface FormErrors {
  passcode?: string | null;
}

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'ConfirmPassword'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'ConfirmPassword'>;

enum State {
  CurrentPassword,
  NewPassword,
  ConfirmNewPassword,
}

export function ConfirmPasswordScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const { isDarkMode } = useTheme();
  const { params } = useRoute<RouteProps>();
  const setIsBiometricVerified = params.setIsBiometricVerified;
  const setBiometricsEnabled = params.setBiometricsEnabled;

  const { verifyCredentials } = useVault();
  const [passcode, setPasscode] = useState('');
  const passcodeInput = useRef<TextInputRef>(null);
  const [attempts, setAttempts] = useState(0);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isWorking, setIsWorking] = useState(false);

  const [state, setState] = useState(State.CurrentPassword);

  const [currentPasscode, setCurrentPasscode] = useState('');

  useEffect(() => {
    setPasscode('');
    setBiometricsEnabled(true);
  }, [state]);

  async function handleUnlock() {
    if (isWorking) return;

    if (state === State.CurrentPassword) {
      const thisAttempt = attempts + 1;
      setAttempts(thisAttempt);
      await wait(); // ensure loading UI shows

      const success = await verifyCredentials({ passcode });

      if (success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setCurrentPasscode(passcode);
        setIsBiometricVerified(false);
        setBiometricsEnabled(false);
        setIsWorking(false);
        navigate('Advanced');
      } else {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        errors.passcode = `Incorrect passcode. You've had ${thisAttempt} attempt${
          thisAttempt !== 1 ? 's' : ''
        }.`;
        setPasscode('');
        wait().then(() => passcodeInput.current?.focus());
        setIsWorking(false);
        setBiometricsEnabled(true);
      }
    }
  }

  return (
    <KeyboardAvoidingView style={[common.fill, { marginTop: 12 }]} behavior="padding">
      <Heading style={styles.heading}>{'Current Password'}</Heading>
      <Text muted style={[{ marginTop: 10 }, isDarkMode && { color: colors.gray.watermark }]}>
        {'Enter your current password to disable biometric.'}
      </Text>

      <TextInput
        ref={passcodeInput}
        value={passcode}
        onChangeText={(text) => {
          if (errors.passcode) setErrors({ passcode: null });
          setPasscode(text);
        }}
        onSubmitEditing={handleUnlock}
        editable={!isWorking}
        autoFocus
        style={{ marginVertical: 70 }}
        blurOnSubmit={true}
        secureTextEntry
        placeholder="Enter your current password"
      />
      {errors.passcode && (
        <Text center small error>
          {errors.passcode}
        </Text>
      )}

      <Button
        variant={ButtonVariant.Primary}
        style={{ width: '100%', marginBottom: 20 }}
        onPress={handleUnlock}
        working={isWorking}
      >
        Continue
      </Button>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginTop: formatPixel(10, 'wHeight'),
  },
});
