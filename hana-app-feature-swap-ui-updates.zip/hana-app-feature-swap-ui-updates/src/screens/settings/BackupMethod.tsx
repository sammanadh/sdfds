import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { BackupMethodItem, BackupMethodItemType } from '@/components/Settings/BackupMethodItem';
import { AltHeading, Heading, Text } from '@/components/Typography';
import { WalletType } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useMemo } from 'react';
import { View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'BackupMethod'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'BackupMethod'>;

export function BackupMethodScreen() {
  const navigation = useNavigation<NavigationProps>();
  const { navigate } = navigation;
  const { isDarkMode } = useTheme();

  const {
    params: { wallet, passcode },
  } = useRoute<RouteProps>();

  const isHdWallet = useMemo(() => wallet.type === WalletType.HD, [wallet]);

  return (
    <>
      <SafeAreaScreen top={false} bottom={false}>
        <ScrollViewScreen>
          <Heading>Backup wallet</Heading>

          {isHdWallet ? (
            <Text
              muted
              style={[
                isDarkMode && {
                  color: colors.whiteSecond,
                },
                { marginTop: 10 },
              ]}
            >
              Backing up your seed phrase is recommended.
            </Text>
          ) : (
            <Text
              muted
              style={[
                isDarkMode && {
                  color: colors.whiteSecond,
                },
                { marginTop: 10 },
              ]}
            >
              Would you like to create a backup using your keystore file or private key?
            </Text>
          )}

          <View style={{ marginTop: 22 }}>
            {isHdWallet && (
              <>
                <AltHeading style={{ marginBottom: 16 }}>Recommended</AltHeading>

                <BackupMethodItem
                  type={BackupMethodItemType.SeedPhrase}
                  onPress={() => {
                    navigate('BackupSeedPhrase', {
                      passcode,
                    });
                  }}
                />
              </>
            )}

            {!isHdWallet && (
              <BackupMethodItem
                type={BackupMethodItemType.PrivateKey}
                onPress={() => {
                  navigate('BackupPrivateKey', {
                    wallet,
                    passcode,
                  });
                }}
              />
            )}
          </View>
        </ScrollViewScreen>
      </SafeAreaScreen>
    </>
  );
}
