import { IconAddBlack, IconAddWhite } from '@/assets/icons';
import { AddressBookItem } from '@/components/AddressBook/AddressBookItem';
import { ChainSelect } from '@/components/ChainSelect';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Heading, Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { ChainID } from '@/utils/chains';
import { getContacts } from '@/utils/contacts';
import { CompositeNavigationProp, useIsFocused, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isNil } from 'lodash-es';
import React, { useEffect, useLayoutEffect } from 'react';
import { Dimensions, StyleSheet, TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'AddressBook'>,
  StackNavigationProp<RootStackParams>
>;

export function AddressBook() {
  const { navigate, setOptions } = useNavigation<NavigationProps>();
  const { setHideTabBar } = useNavigationStore();

  const isFocused = useIsFocused();
  const { isDarkMode } = useTheme();

  const [selectedChain, setSelectedChain] = React.useState<ChainID | null>(null);

  const contacts = getContacts();
  const { height } = Dimensions.get('window');

  const contactsForSelectedChain = React.useMemo(() => {
    return (
      contacts?.filter((c) => {
        if (isNil(selectedChain)) {
          return true;
        }
        return c.chain === selectedChain;
      }) || []
    );
  }, [selectedChain, isFocused]);

  useLayoutEffect(() => {
    setOptions({
      headerRight: () => (
        <TouchableOpacity
          style={{ marginRight: 16 }}
          onPress={() => {
            setHideTabBar(true);
            navigate('AddContact', {});
          }}
        >
          {isDarkMode ? <IconAddWhite /> : <IconAddBlack />}
        </TouchableOpacity>
      ),
    });
  }, [isDarkMode]);

  useEffect(() => {
    if (isFocused) {
      setHideTabBar(false);
    }
  }, [isFocused]);

  return (
    <SafeAreaScreen bottom={false}>
      <ScrollViewScreen>
        <View style={styles.headerContainer}>
          <Heading style={styles.headTitle}>Addresses</Heading>

          <ChainSelect chain={selectedChain} onSelectChain={setSelectedChain} />
        </View>

        {contactsForSelectedChain.length ? (
          <View style={styles.contacts}>
            {contactsForSelectedChain.map((contact) => (
              <AddressBookItem
                key={contact?.address}
                contact={contact}
                onPress={() => {
                  setHideTabBar(true);
                  navigate('AddContact', {
                    contact,
                  });
                }}
                style={{ marginVertical: 7 }}
              />
            ))}
          </View>
        ) : (
          <View style={{ height: height * 0.5, justifyContent: 'center', alignItems: 'center' }}>
            <Text style={{ color: 'rgb(115, 107, 136)' }}>You have no contacts.</Text>
          </View>
        )}
      </ScrollViewScreen>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  contacts: {
    flex: 1,
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  headTitle: {
    marginBottom: 20,
    flex: 1,    
  },
});
