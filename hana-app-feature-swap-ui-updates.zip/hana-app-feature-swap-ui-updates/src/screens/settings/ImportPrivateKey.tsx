import { KeysIcon } from '@/assets/icons';
import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { TextInput } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import { wait } from '@/utils/wait';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import IconSDK from 'icon-sdk-js';
import { isEmpty } from 'lodash-es';
import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';

const { IconValidator } = IconSDK;

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'ImportPrivateKey'>,
  StackNavigationProp<RootStackParams>
>;

export function ImportPrivateKeyScreen() {
  const navigation = useNavigation<NavigationProps>();
  const { navigate, popToTop } = navigation;

  const [privateKey, setPrivateKey] = useState('');
  const [restoring, setRestoring] = useState(false);

  const { setToastMessage } = useNavigationStore();

  const { importPrivateKey } = useVault();
  const { isDarkMode } = useTheme();

  async function onRestore() {
    if (restoring) return;

    let error = false;

    if (isEmpty(privateKey.trim())) {
      setToastMessage('Please enter your private key', ToastType.error);
      error = true;
    } else if (!IconValidator.isPrivateKey(privateKey)) {
      setToastMessage('Please enter a valid private key', ToastType.error);
      error = true;
    }

    if (error) return;

    setRestoring(true);

    await wait(); // ensure loading UI shows

    try {
      await importPrivateKey(privateKey);

      popToTop();
      // @ts-expect-error not worth mapping navigation props to here
      navigate('HomeStack');
    } catch (error: any) {
      console.warn('Failed importing wallet.', error);
      const errorMessage = error.message.includes('already imported')
        ? 'You already have a wallet using this private key'
        : 'Failed importing wallet';

      setToastMessage(errorMessage, ToastType.error);
    }
  }

  return (
    <SafeAreaScreen bottom={false} top={false}>
      <ScrollViewScreen>
        <View style={styles.iconContainer}>
          <KeysIcon style={styles.icon} />
        </View>
        <Heading>Private key</Heading>
        <Text large muted style={[{ marginTop: 8 }, isDarkMode && { color: colors.whiteSecond }]}>
          Enter your wallet's private key to import it.
        </Text>

        <TextInput
          placeholder="Private key"
          label="Private key"
          labelTitle="Private key"
          value={privateKey}
          isDarkMode={isDarkMode}
          onChangeText={setPrivateKey}
          style={{ marginTop: 24 }}
          autoFocus
        />
      </ScrollViewScreen>

      <Footer>
        <Button working={restoring} onPress={onRestore}>
          Restore
        </Button>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  iconContainer: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.offPurple,
    marginBottom: 20,
  },
  icon: {
    color: colors.black,
    width: 24,
    height: 24,
  },
});
