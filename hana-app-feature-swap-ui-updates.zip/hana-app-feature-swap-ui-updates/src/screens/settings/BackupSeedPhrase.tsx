import { SeedingIcon } from '@/assets/icons';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { MNEMONIC_WORDS } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useEffect, useLayoutEffect, useMemo, useState } from 'react';
import { Dimensions, StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'BackupSeedPhrase'>,
  StackNavigationProp<RootStackParams>
>;
type RouteProps = RouteProp<SettingsStackParams, 'BackupSeedPhrase'>;

const WORD_LIST_COLUMNS = 2;
const WORD_LIST_SIZE = Math.floor(MNEMONIC_WORDS / WORD_LIST_COLUMNS);
const WORD_WIDTH = Dimensions.get('screen').width / WORD_LIST_COLUMNS - 30;

export function BackupSeedPhraseScreen() {
  const { setOptions } = useNavigation<NavigationProps>();
  const {
    params: { passcode },
  } = useRoute<RouteProps>();

  const { isDarkMode } = useTheme();

  const { backupVault } = useVault();

  const [seedPhrase, setSeedPhrase] = useState('');

  const words = useMemo(() => seedPhrase.split(' '), [seedPhrase]);
  const wordLists = useMemo(
    () =>
      Array.from(Array(WORD_LIST_COLUMNS), (_, index) =>
        words.slice(WORD_LIST_SIZE * index, WORD_LIST_SIZE * (index + 1))
      ),
    [words]
  );

  useEffect(() => {
    backupVault({ passcode }).then(setSeedPhrase);
  }, []);

  useLayoutEffect(() => {
    setOptions({
      headerRight: () => null,
    });
  }, []);

  return (
    <SafeAreaScreen>
      <ScrollViewScreen>
        <View
          style={{
            width: 45,
            height: 45,
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: colors.offPurple,
            marginBottom: 18,
          }}
        >
          <SeedingIcon color={colors.black} width={30} height={30} />
        </View>
        <Heading>Seed phrase</Heading>
        <Text muted style={[{ marginTop: 10 }, isDarkMode && { color: colors.whiteSecond }]}>
          These 12 words are the only way to recover your account. Store them somewhere safe!
        </Text>

        <View style={[styles.wordsContainer]}>
          {wordLists.map((wordList, listIndex) => (
            <View key={listIndex}>
              {wordList.map((word, wordIndex) => {
                const wordNumber = wordIndex + 1 + listIndex * WORD_LIST_SIZE;
                return (
                  <View
                    key={`${listIndex}-${wordIndex}-${word}`}
                    style={[
                      styles.wordContainer,
                      wordIndex !== 0 && { marginTop: 10 },
                      isDarkMode && {
                        backgroundColor: colors.purple.darkBlack,
                      },
                    ]}
                  >
                    <View
                      style={[
                        styles.containerNumber,
                        isDarkMode && { backgroundColor: colors.purple.darkBlacker },
                      ]}
                    >
                      <Text style={[isDarkMode && { color: colors.whiteSecond }]}>
                        {wordNumber}
                      </Text>
                    </View>
                    <Text
                      bold
                      style={[
                        styles.word,
                        { color: isDarkMode ? colors.whiteSecond : colors.black },
                      ]}
                    >
                      {word}
                    </Text>
                  </View>
                );
              })}
            </View>
          ))}
        </View>
      </ScrollViewScreen>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  wordsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 40,
  },
  wordContainer: {
    backgroundColor: '#f4f2f9',
    width: WORD_WIDTH,
    height: 46,
    borderRadius: 24,
    paddingHorizontal: 8,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  containerNumber: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  word: {
    lineHeight: 19,
    color: colors.primary,
    marginLeft: 8,
  },
});
