import { HomeButton } from '@/components/HomeButton';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { SettingsItem, SettingsItemType } from '@/components/Settings/SettingsItem';
import { SupportFooter } from '@/components/SupportFooter';
import { Heading } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { common } from '@/utils/styles';
import { CompositeNavigationProp, RouteProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useEffect } from 'react';
import { LayoutAnimation, Platform, StyleSheet, View } from 'react-native';
import { useIsFocused } from '@react-navigation/native';
import { useNavigationStore } from '@/stores/Navigation';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'Settings'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'Settings'>;

export function SettingsScreen() {
  const navigation = useNavigation<NavigationProps>();
  const { navigate } = navigation;
  const { isDarkMode } = useTheme();
  const isFocused = useIsFocused();
  const { setHideTabBar } = useNavigationStore();

  useEffect(() => {
    if (isFocused) {
      setHideTabBar(false);
    }
  }, [isFocused]);

  return (
    <SafeAreaScreen top padTop={false} bottom={false}>
      <ScrollViewScreen>
        <HomeButton />
        <View style={common.screen}>
          <Heading large style={styles.heading}>
            Settings
          </Heading>
          <SettingsItem
            type={SettingsItemType.AddressBook}
            onPress={() => {
              Platform.OS === 'ios' &&
                LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
              navigate('AddressBook');
            }}
          />

          <SettingsItem
            type={SettingsItemType.ManageWallet}
            onPress={() => {
              Platform.OS === 'ios' &&
                LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
              navigate('ManageWallets');
            }}
          />

          <SettingsItem
            type={SettingsItemType.ManageTokens}
            onPress={() => {
              Platform.OS === 'ios' &&
                LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
              navigate('ManageTokens');
            }}
          />

          <SettingsItem
            type={SettingsItemType.ConfigureChains}
            onPress={() => {
              Platform.OS === 'ios' &&
                LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
              navigate('ConfigureChains');
            }}
          />

          <SettingsItem
            type={SettingsItemType.AuthorizedDApps}
            onPress={() => {
              Platform.OS === 'ios' &&
                LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
              navigate('AuthorizedDApps');
            }}
          />
          <SettingsItem
            type={SettingsItemType.Advanced}
            onPress={() => {
              navigate('Advanced');
            }}
          />
          <SettingsItem
            type={SettingsItemType.HelpAndSupport}
            onPress={() => {
              Platform.OS === 'ios' &&
                LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
              navigate('HelpAndSupportScreen');
            }}
          />
        </View>

        <View style={common.screen}>
          <SupportFooter isDarkMode={isDarkMode} showThemeSwitch />
        </View>
      </ScrollViewScreen>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginVertical: 25,
  },
});
