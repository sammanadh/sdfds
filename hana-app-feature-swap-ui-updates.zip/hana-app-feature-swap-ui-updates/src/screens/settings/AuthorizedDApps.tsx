import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { AuthorizedDAppItem } from '@/components/Settings/AuthorizedDAppItem';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { AuthorizedDApp } from '@/models/Vault';
import { useNavigationStore } from '@/stores/Navigation';
import { useVault } from '@/stores/Vault';
import { removeAuthorizedDApp } from '@/utils/browser';
import { isEmpty } from 'lodash-es';
import React, { useEffect, useState } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';

export function AuthorizedDAppsScreen() {
  const { getActiveWallet } = useVault();
  const { setToastMessage } = useNavigationStore();

  const activeWallet = getActiveWallet();

  const [authorizedDApps, setAuthorizedDApps] = useState<AuthorizedDApp[]>([]);

  useEffect(() => {
    if (activeWallet) {
      setAuthorizedDApps(activeWallet.authorizedDApps);
    }
  }, []);

  const hasAuthorizedDApps = !isEmpty(authorizedDApps);

  return (
    <>
      <SafeAreaScreen bottom={false} top={false} >
        <Heading style={styles.heading}>Authorized dApps</Heading>
        {hasAuthorizedDApps ? (
          <FlatList
            data={authorizedDApps}
            renderItem={({ item: dapp }) => (
              <AuthorizedDAppItem
                dapp={dapp}
                onRevoke={() => {
                  if (activeWallet) {
                    setToastMessage(`Revoked ${dapp.host} dApp`, ToastType.info);
                    removeAuthorizedDApp(activeWallet, dapp.host);
                  }
                }}
              />
            )}
            keyExtractor={(item, index) => String(index)}
          />
        ) : (
          <View style={styles.none}>
            <Text muted>You haven't authorized any dApps yet.</Text>
          </View>
        )}
      </SafeAreaScreen>
    </>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginBottom: 20,
  },  
  none: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
