import KeysIcon from '@/assets/icons/keys.svg';
import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { ModalTextItem } from '@/components/ModalTextItem';
import { SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Select } from '@/components/Select';
import { SavePrivateKeyWarning } from '@/components/Settings/SavePrivateKeyWarning';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainID, ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { dismissModal, presentModal } from '@/utils/modal';
import Clipboard from '@react-native-clipboard/clipboard';
import { RouteProp, useRoute } from '@react-navigation/native';
import React, { useEffect, useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';

type RouteProps = RouteProp<SettingsStackParams, 'BackupPrivateKey'>;

export function BackupPrivateKeyScreen() {
  const {
    params: { wallet, passcode },
  } = useRoute<RouteProps>();

  const { isDarkMode } = useTheme();

  const { backupWallet } = useVault();
  const { setToastMessage } = useNavigationStore();

  const [privateKey, setPrivateKey] = useState('');
  const [chainID, setChainID] = useState(ChainID.ICON);

  const [fetchingPrivateKey, setFetchingPrivateKey] = useState(false);

  const { realm, getActiveWallet, getActiveChainWallets } = useVault();
  const activeWallet = getActiveWallet();

  const _getActiveChainWallets = getActiveChainWallets();

  const ALL_CHAINS_SEGMENT: String[] = [];

  const segments = React.useMemo(() => {
    const activeChainWallets = _getActiveChainWallets.filter((cw) => cw.isActive);
    const activeChains = activeChainWallets?.map((cw) => cw.type.toUpperCase());
    return ALL_CHAINS_SEGMENT.concat(activeChains);
  }, [_getActiveChainWallets, activeWallet]);

  useEffect(() => {
    async function fetchPrivateKey() {
      setFetchingPrivateKey(true);
      const privateKey = await backupWallet(wallet.id, chainID, { passcode });
      privateKey && setPrivateKey(privateKey);
      setFetchingPrivateKey(false);
    }

    fetchPrivateKey();
  }, [chainID]);

  const ChainIDs: string[] = [];

  for (const iterator in ChainID) {
    const small = iterator.toLowerCase();
    segments?.find((item) => small == item.toLowerCase() && ChainIDs.push(iterator));
  }

  function handleCopyToClipboard() {
    Clipboard.setString(privateKey);

    setToastMessage('Private key copied', ToastType.info);
  }

  const modalContent = useMemo(
    () =>
      ChainIDs.map((_chainID) => {
        const chain = chainForChainID(_chainID as ChainID);
        return (
          <ModalTextItem
            title={chain?.name}
            onPress={() => {
              setChainID(_chainID as ChainID);
              dismissModal();
            }}
            chain={chain}
            isActive={chainID === _chainID}
            key={_chainID}
          />
        );
      }),
    [chainID, isDarkMode]
  );

  return (
    <>
      <SafeAreaScreen bottom={false} top={false} padTop>
        <ScrollViewScreen>
          <View style={styles.iconContainer}>
            <KeysIcon style={styles.icon} />
          </View>
          <Heading style={styles.header}>Private key</Heading>
          <Text muted>Copy the private key for this wallet and keep it somewhere secure.</Text>

          <SavePrivateKeyWarning content="It is recommended that you backup your seed phrase instead." />

          <Select
            placeholder="Chain"
            value={chainID ? chainForChainID(chainID)?.name : null}
            onPress={() => {
              presentModal({
                title: 'Select a chain',
                content: modalContent,
              });
            }}
            chain={chainForChainID(chainID)}
            style={{ marginVertical: 10 }}
          />

          <View
            style={[
              styles.privateKey,
              { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.white },
            ]}
          >
            <Text numberOfLines={1}>
              {fetchingPrivateKey ? 'Getting private key...' : privateKey}
            </Text>
          </View>
        </ScrollViewScreen>
      </SafeAreaScreen>

      <Footer>
        <Button onPress={handleCopyToClipboard}>Copy</Button>
      </Footer>
    </>
  );
}

const styles = StyleSheet.create({
  privateKey: {
    width: '100%',
    minHeight: 50,
    borderRadius: 25,
    justifyContent: 'center',
    paddingHorizontal: 20,
    marginTop: 12,
    paddingVertical: 12,
    borderWidth: 2,
    borderColor: colors.gray.meta,
  },
  header: {
    marginTop: 20,
  },
  icon: {
    color: colors.black,
    width: 24,
    height: 24,
  },
  iconContainer: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.offPurple,
  },
});
