import { Button, ButtonVariant } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { TextInput } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { Heading } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty } from 'lodash-es';
import { useState } from 'react';
import { StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'RenameWallet'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'RenameWallet'>;

export function RenameWallet() {
  const navigation = useNavigation<NavigationProps>();
  const { goBack } = navigation;
  const {
    params: { wallet },
  } = useRoute<RouteProps>();
  const { renameWallet } = useVault();

  const [name, setName] = useState(wallet.name);
  const { setToastMessage } = useNavigationStore();
  const { isDarkMode } = useTheme();

  return (
    <SafeAreaScreen top={false} bottom={false}>
      <ScrollViewScreen>
        <View>
          <Heading style={styles.heading}>{wallet.name}</Heading>
        </View>

        <TextInput
          label="Name"
          labelTitle="Name"
          value={name}
          isDarkMode={isDarkMode}
          onChangeText={(text) => setName(text)}
          style={{ marginTop: 10 }}
          styleInputContainer={{ height: 60, borderRadius: 30 }}
          autoFocus
        />
      </ScrollViewScreen>

      <Footer>
        <View style={styles.footer}>
          <Button
            style={{ width: '40%', backgroundColor: colors.gray.cards }}
            textStyle={{ color: colors.black }}
            onPress={() => goBack()}
          >
            Cancel
          </Button>
          <Button
            variant={ButtonVariant.Primary}
            style={{ flex: 1, marginLeft: 12 }}
            onPress={() => {
              if (isEmpty(name.trim())) {
                setToastMessage('Name cannot be empty!', ToastType.error);
                return;
              }
              renameWallet(wallet.id, name);
              goBack();
            }}
          >
            Save
          </Button>
        </View>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  footer: {
    width: '100%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
  },
  heading: {
    marginBottom: 20,
  },
});
