import { FileLockIcon } from '@/assets/icons';
import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { ModalTextItem } from '@/components/ModalTextItem';
import { SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Select } from '@/components/Select';
import { SaveKeystoreFileWarning } from '@/components/Settings/SaveKeystoreFileWarning';
import { TextInput } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainID, ChainID } from '@/utils/chains';
import { VALIDATE_PASSWORD_REGEXP } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { dismissModal, presentModal } from '@/utils/modal';
import { RouteProp, useRoute } from '@react-navigation/native';
import { isEmpty, lt } from 'lodash-es';
import React, { useMemo, useState } from 'react';
import { View } from 'react-native';

type RouteProps = RouteProp<SettingsStackParams, 'SaveKeystoreFile'>;

const selectableChainIDs = [ChainID.ICON, ChainID.Ethereum];

export function SaveKeystoreFileScreen() {
  const {
    params: { wallet, passcode },
  } = useRoute<RouteProps>();

  const [chainID, setChainID] = useState(ChainID.ICON);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const { backupWallet } = useVault();
  const { setToastMessage } = useNavigationStore();

  const { isDarkMode } = useTheme();

  const [saving, setSaving] = useState(false);

  const modalContent = useMemo(
    () =>
      selectableChainIDs.map((_chainID) => {
        const chain = chainForChainID(_chainID);
        return (
          <ModalTextItem
            title={chain?.name}
            onPress={() => {
              setChainID(_chainID);
              dismissModal();
            }}
            chain={chain}
            isActive={chainID === _chainID}
            key={_chainID}
          />
        );
      }),
    [chainID]
  );

  function verifyPasswords() {
    if (isEmpty(password.trim())) {
      setToastMessage('Please enter a password', ToastType.error);
      return false;
    } else if (lt(password.length, 8)) {
      setToastMessage('Your password should be at least 8 characters', ToastType.error);
      return false;
    } else if (!VALIDATE_PASSWORD_REGEXP.test(password)) {
      setToastMessage(
        'Your password should contain uppercase, lowercase, numeric and non-letter characters',
        ToastType.error
      );
      return false;
    }

    if (isEmpty(confirmPassword.trim())) {
      setToastMessage('Please confirm the password', ToastType.error);
      return false;
    } else if (confirmPassword !== password) {
      setToastMessage('The passwords you entered are different', ToastType.error);
      return false;
    }

    return true;
  }

  async function handleSave() {
    if (verifyPasswords()) {
      setSaving(true);

      await backupWallet(wallet.id, chainID, { passcode }, password);

      setSaving(false);
    }
  }

  return (
    <>
      <SafeAreaScreen bottom={false} top={false}>
        <ScrollViewScreen>
          <View
            style={{
              marginTop: 12,
              width: 40,
              height: 40,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: colors.offPurple,
              marginBottom: 20,
            }}
          >
            <FileLockIcon style={{ width: 24, height: 24 }} color={colors.black} />
          </View>
          <Heading>Keystore file</Heading>
          <Text muted style={[{ marginTop: 10 }, isDarkMode && { color: colors.whiteSecond }]}>
            To save your keystore file, confirm the network and create a secure password for it.
          </Text>

          <SaveKeystoreFileWarning />

          <Select
            placeholder="Chain"
            value={chainID ? chainForChainID(chainID)?.name : null}
            chain={chainForChainID(chainID)}
            onPress={() => {
              presentModal({
                title: 'Select a chain',
                content: modalContent,
              });
            }}
            style={{ marginTop: 30 }}
          />

          <TextInput
            label="Enter your password"
            labelTitle="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            isDarkMode={isDarkMode}
            style={{ marginTop: 12 }}
          />

          <TextInput
            label="Confirm your password"
            labelTitle="Confirm password"
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            secureTextEntry
            isDarkMode={isDarkMode}
            style={{ marginTop: 12 }}
          />
        </ScrollViewScreen>
      </SafeAreaScreen>

      <Footer>
        <Button onPress={handleSave} working={saving}>
          Save keystore file
        </Button>
      </Footer>
    </>
  );
}
