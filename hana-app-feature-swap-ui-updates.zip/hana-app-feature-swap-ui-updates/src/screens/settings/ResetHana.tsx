import { IconResetHana } from '@/assets/icons';
import { Button, ButtonVariant } from '@/components/Button';
import { colors } from '@/utils/designTokens';
import { EntityImage } from '@/components/EntityImage';
import { Footer } from '@/components/Footer';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { WalletTypeBadge } from '@/components/Settings/WalletTypeBadge';
import { Heading, Text } from '@/components/Typography';
import { WalletType } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { card } from '@/utils/styles';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useMemo } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'ResetHana'>,
  StackNavigationProp<RootStackParams>
>;

export function ResetHana() {
  const { navigate } = useNavigation<NavigationProps>();
  const { wallets } = useVault();

  const { styles: themeStyles } = useTheme();

  const hasImportedWallets = useMemo(
    () => wallets.some((wallet) => wallet.type !== WalletType.HD),
    [wallets]
  );

  function onContinue() {
    navigate(hasImportedWallets ? 'ResetWithImported' : 'ResetConfirm');
  }

  return (
    <SafeAreaScreen bottom={false}>
      <IconResetHana
        width={40}
        height={40}
        style={{ backgroundColor: colors.negative, marginBottom: 10 }}
      />    
      <Heading>Reset Hana</Heading>
      <Text muted style={styles.altHeading}>
        Resetting will remove the following wallets.
      </Text>

      <FlatList
        style={styles.flatList}
        data={wallets}
        keyExtractor={(wallet) => wallet.id}
        renderItem={({ item: wallet }) => {
          return (
            <View style={[card.base, styles.item, themeStyles.cards]}>
              <EntityImage name={wallet?.name} />

              <Text bold style={styles.itemTitle}>
                {wallet.name}
              </Text>

              <WalletTypeBadge wallet={wallet} />
            </View>
          );
        }}
        ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
      />

      <Footer>
        <Button onPress={onContinue} variant={ButtonVariant.DangerTertiary} hasNextIcon>
          Continue
        </Button>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  altHeading: {
    marginTop: 10,
  },
  itemTitle: {
    marginLeft: 16,
    flex: 1,
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  flatList: {
    marginTop: 24,
  },
});
