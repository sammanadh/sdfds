import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Select } from '@/components/Select';
import { TextInput } from '@/components/TextInput';
import { Heading, Text } from '@/components/Typography';
import { RealmContact } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainID, ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { formatAddress } from '@/utils/format';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty, isNil } from 'lodash-es';
import debounce from 'lodash/debounce';
import React, { useLayoutEffect, useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'EditContact'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'EditContact'>;

export function EditContact() {
  const navigation = useNavigation<NavigationProps>();
  const {
    params: { contact },
  } = useRoute<RouteProps>();
  const { isDarkMode } = useTheme();

  const { realm, getActiveChainWallets } = useVault();

  const [chainID, setChainID] = React.useState<ChainID | null>(ChainID.ICON);
  const [name, setName] = React.useState('');
  const [address, setAddress] = React.useState('');

  const [chainError, setChainError] = React.useState<string | null>(null);
  const [nameError, setNameError] = React.useState<string | null>(null);
  const [addressError, setAddressError] = React.useState<string | null>(null);
  const [isReady, setReady] = useState(false);

  const [savingContact, setSavingContact] = React.useState(false);

  const activeChainWallets = getActiveChainWallets();
  const selectableChainIDs = useMemo(
    () => activeChainWallets.filter((cw) => cw.isActive).map((cw) => cw.type),
    [activeChainWallets]
  );

  React.useEffect(() => {
    setChainError(null);
  }, [chainID]);

  React.useEffect(() => {
    setNameError(null);
  }, [name]);

  React.useEffect(() => {
    setAddressError(null);
  }, [address]);

  React.useEffect(() => {
    if (contact) {
      setChainID(contact.chain);
      setName(contact.name);
      setAddress(contact.address);
    }
  }, [contact]);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => <View />,
    });
  }, []);

  useLayoutEffect(() => {
    debounce(() => {
      setReady(true);
    }, 250)();
  }, []);

  const verifyFields = () => {
    let errors = false;

    if (isNil(chainID)) {
      setChainError('Please select a Chain');
      errors = true;
    }

    if (isEmpty(name)) {
      setNameError('Please provide a name');
      errors = true;
    }

    if (isEmpty(address)) {
      setAddressError('Please provide an address');
      errors = true;
    }

    return !errors;
  };

  const onSaveContact = React.useMemo(() => {
    return () => {
      if (!verifyFields()) {
        return;
      }

      setSavingContact(true);

      if (contact && chainID) {
        // Update
        realm?.write(() => {
          contact.name = name;
          contact.address = address;
          contact.chain = chainID;
        });
      } else {
        // Create new
        realm?.write(() => {
          realm.create('Contact', {
            name,
            address,
            chain: chainID,
          });
        });
      }

      setSavingContact(false);

      chainID &&
        navigation.navigate('AddContact', {
          contact: {
            ...contact,
            name,
            address,
            chain: chainID,
          } as RealmContact,
        });
    };
  }, [contact, chainID, name, address]);

  return (
    <SafeAreaScreen bottom={false}>
      <ScrollViewScreen contentContainerStyle={{ marginBottom: 10, flexGrow: 1 }}>
        <Heading>{contact?.name || '-'}</Heading>
        <Text small muted style={{ marginTop: 8 }}>
          {formatAddress(contact?.address || '-')}
        </Text>
        <Select
          placeholder="Chain"
          disabled
          value={chainID ? chainForChainID(chainID)?.name : null}
          chain={chainID ? chainForChainID(chainID) : undefined}
          style={{ marginTop: 30 }}
        />

        {chainError && <Text style={styles.errorMessage}>{chainError}</Text>}

        <TextInput
          label="E.g. Elong Musk"
          labelTitle="Name"
          key={`${isReady}-EditContactName`}
          value={name}
          isDarkMode={isDarkMode}
          onChangeText={(text) => setName(text)}
          error={!!nameError}
          msgError={nameError}
          style={{ marginTop: 14 }}
          autoFocus
        />

        <TextInput
          label="E.g. hx429731644462ebcfd22185df387272"
          labelTitle="Address"
          key={`${isReady}-EditContactAddress`}
          value={address}
          isDarkMode={isDarkMode}
          error={!!addressError}
          msgError={addressError}
          onChangeText={(text) => setAddress(text)}
          style={{ marginTop: 14 }}
        />
      </ScrollViewScreen>
      <Footer
        containerStyle={{
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}
      >
        <Button
          onPress={() => navigation.goBack()}
          isDarkMode={isDarkMode}
          style={{ width: '40%', backgroundColor: colors.gray.cards }}
          textStyle={{ color: colors.black }}
        >
          Cancel
        </Button>

        <Button working={savingContact} style={{ flex: 1, marginLeft: 12 }} onPress={onSaveContact}>
          Save
        </Button>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  errorMessage: {
    color: colors.red,
    marginTop: 8,
  },
});
