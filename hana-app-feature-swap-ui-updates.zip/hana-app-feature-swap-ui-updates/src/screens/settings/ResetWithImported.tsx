import { IconResetHana } from '@/assets/icons';
import { Button, ButtonVariant } from '@/components/Button';
import { EntityImage } from '@/components/EntityImage';
import { Footer } from '@/components/Footer';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { WalletTypeBadge } from '@/components/Settings/WalletTypeBadge';
import { Heading, Text } from '@/components/Typography';
import { WalletType } from '@/models/Vault';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import { card } from '@/utils/styles';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useMemo } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'ResetHana'>,
  StackNavigationProp<RootStackParams>
>;

export function ResetWithImported() {
  const { navigate } = useNavigation<NavigationProps>();
  const { wallets } = useVault();
  const { styles: themeStyles } = useTheme();

  const importedWallets = useMemo(
    () => wallets.filter((wallet) => wallet.type !== WalletType.HD),
    [wallets]
  );

  function onContinue() {
    navigate('ResetConfirm');
  }

  return (
    <>
      <SafeAreaScreen bottom={false} style={{ marginTop: -20 }}>
        <IconResetHana
          width={40}
          height={40}
          style={{ backgroundColor: colors.negative, marginBottom: 10 }}
        />

        <Heading style={styles.heading}>Imported wallets</Heading>

        <View style={styles.warningContainer}>
          <View style={[styles.warningInnerContainer, themeStyles.cards]}>
            <Text large bold>
              Warning
            </Text>
            <Text>
              Ensure you have backed up the private key or keystore file for the following wallets.
              They cannot be restored with your seed phrase.
            </Text>
          </View>
        </View>

        <FlatList
          style={styles.flatList}
          data={importedWallets}
          keyExtractor={(wallet) => wallet.id}
          renderItem={({ item: wallet }) => {
            return (
              <View style={[card.base, styles.item, themeStyles.cards]}>
                <EntityImage name={wallet?.name} />

                <Text large bold style={styles.itemTitle}>
                  {wallet.name}
                </Text>

                <WalletTypeBadge wallet={wallet} />
              </View>
            );
          }}
          ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
        />

        <Footer>
          <Button onPress={onContinue} variant={ButtonVariant.DangerTertiary} hasNextIcon>
            Continue
          </Button>
        </Footer>
      </SafeAreaScreen>
    </>
  );
}

const styles = StyleSheet.create({
  itemTitle: {
    marginLeft: 16,
    flex: 1,
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  flatList: {
    marginTop: 24,
  },
  warningContainer: {
    paddingBottom: 20,
    paddingTop: 20,
  },
  warningInnerContainer: {
    borderLeftWidth: 5,
    padding: 15,
    borderLeftColor: colors.negative,
  },
  heading: {
    width: 320,
  },
});
