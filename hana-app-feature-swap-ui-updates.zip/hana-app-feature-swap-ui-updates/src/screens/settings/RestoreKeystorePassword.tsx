import { FileLockIcon } from '@/assets/icons';
import { Button } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { TextInput } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import { isValidPolkadotKeystore } from '@/utils/keystoreFile';
import { wait } from '@/utils/wait';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import IconSDK from 'icon-sdk-js';
import { isEmpty } from 'lodash-es';
import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';

const { IconWallet } = IconSDK;

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'RestoreKeystorePassword'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'RestoreKeystorePassword'>;

export function RestoreKeystorePassword() {
  const navigation = useNavigation<NavigationProps>();
  const { navigate, popToTop } = navigation;
  const {
    params: { keystore },
  } = useRoute<RouteProps>();

  const { isDarkMode } = useTheme();

  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const { setToastMessage } = useNavigationStore();
  const { importPrivateKey } = useVault();

  async function onContinue() {
    console.debug('onContinue');
    if (isEmpty(password.trim())) {
      setToastMessage('Please enter the keystore password', ToastType.error);
      return;
    }

    setLoading(true);
    await wait(); // ensure loading UI shows

    try {
      if (isValidPolkadotKeystore(keystore)) {
        try {
          // NOTE: Commented out so it can run on Android
          // const keyring = new Keyring();
          // const importPair = keyring.addFromJson(keystore as any as KeyringPair$Json);
          // importPair.decodePkcs8(password);
          // const address = keyring.encodeAddress(importPair.publicKey);
          // await vault.importDotKeystore(keyring.toJson(address));
          // TODO;
        } catch (error) {
          setLoading(false);
        }
      } else {
        try {
          const iconWallet = IconWallet.loadKeystore(keystore as any, password, true);
          const privateKey = iconWallet.getPrivateKey();
          await importPrivateKey(privateKey);

          setLoading(false);

          popToTop();
          // @ts-expect-error not worth mapping navigation props to here
          navigate('HomeStack');
        } catch (error: any) {
          setLoading(false);
          const errorMessage = error.message.includes('already imported')
            ? error.message
            : 'Failed importing wallet';

          setToastMessage(errorMessage, ToastType.error);
        }
      }
    } catch (error) {
      setLoading(false);
      setToastMessage('Incorrect password for the provided keystore', ToastType.error);
    }
  }

  return (
    <SafeAreaScreen bottom={false}>
      <ScrollViewScreen>
        <View style={styles.iconContainer}>
          <FileLockIcon style={styles.icon} />
        </View>
        <Heading>Keystore password</Heading>
        <Text small muted style={{ marginTop: 8 }}>
          Enter the password used when creating the keystore file.
        </Text>

        <TextInput
          label="Keystore password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          isDarkMode={isDarkMode}
          style={{ marginTop: 12 }}
        />
      </ScrollViewScreen>

      <Footer>
        <Button onPress={onContinue} working={loading}>
          Restore
        </Button>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  iconContainer: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.offPurple,
    marginBottom: 20,
  },
  icon: {
    color: colors.black,
    width: 24,
    height: 24,
  },
});
