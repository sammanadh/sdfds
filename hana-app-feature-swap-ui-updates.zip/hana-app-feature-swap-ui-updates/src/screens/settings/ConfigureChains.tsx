import { OnboardingStackParams, RootStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { SearchInput } from '@/components/SearchInput';
import { Switch } from '@/components/Switch';
import { TokenLogo } from '@/components/TokenLogo';
import { AltHeading, Heading, Text } from '@/components/Typography';
import { useChainServices } from '@/stores/ChainServices';
import { useTheme } from '@/stores/Theme';
import { ChainDetails, chainFilter, ChainID, chains, isSubstrateChain } from '@/utils/chains';
import { card } from '@/utils/styles';
import { wait } from '@/utils/wait';
import { CompositeNavigationProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty, isNil, without } from 'lodash-es';
import { useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { ActivityIndicator } from '@/components/ActivityIndicator';
import { colors } from '@/utils/designTokens';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<OnboardingStackParams, 'ConfigureChains'>,
  StackNavigationProp<RootStackParams>
>;

const availableChains = chains.filter(
  (chain) => chain.enabled && !chain.isTestnet && isNil(chain.affiliatedChainID)
);

export function ConfigureChainsScreen() {
  const { styles: themeStyles } = useTheme();
  const chainServices = useChainServices();

  const { selectingChains } = chainServices;

  const [selectedChainIds, setSelectedChainIds] = useState<Array<ChainID>>(
    chainServices.connectedChains.map((chain) => chain.id)
  );
  const [query, setQuery] = useState('');
  const filteredChains = useMemo(
    () =>
      !isEmpty(query)
        ? availableChains.filter((chain) => chainFilter(chain, query))
        : availableChains,
    [query]
  );

  async function handleToggle(chain: ChainDetails, enabled: boolean) {
    let updatedSelectedChainIds = selectedChainIds;
    setSelectedChainIds((selectedChainIds) => {
      if (enabled) {
        updatedSelectedChainIds = [...selectedChainIds, chain.id];
      } else {
        updatedSelectedChainIds = without(selectedChainIds, chain.id);
      }
      return updatedSelectedChainIds;
    });

    // Enabling/disabling chains is expensive and affects UI rendering
    // This allows the switch to finish moving before updating the service
    // await wait(300);
    // chainServices.selectChains(updatedSelectedChainIds);

    if (enabled) {
      await chainServices.selectChain(chain.id);
    } else {
      await chainServices.deselectChain(chain.id);
    }
  }

  return (
    <SafeAreaScreen bottom={false}>
      <ScrollViewScreen>
        <Heading>Connected chains</Heading>

        <SearchInput
          value={query}
          onChangeText={setQuery}
          placeholder="Search"
          style={{ marginTop: 30 }}
        />

        {filteredChains.map((chain, index) => {
          const isEnabled = selectedChainIds.includes(chain.id);

          return (
            <View
              key={chain.id}
              style={[card.base, styles.item, themeStyles.cards, index === 0 && { marginTop: 20 }]}
            >
              <TokenLogo chain={chain} />
              <View style={styles.content}>
                <Text large bold numberOfLines={1}>
                  {chain.name}
                </Text>
                <AltHeading numberOfLines={1} style={{ marginTop: 6 }}>
                  {chain.token.symbol}
                </AltHeading>
              </View>
              {selectingChains.includes(chain.id) ? (
                <ActivityIndicator color={colors.primary} />
              ) : (
                <Switch
                  value={isEnabled}
                  onChange={(enabled) => handleToggle(chain, enabled)}
                  disabled={isEnabled && selectedChainIds.length <= 1}
                />
              )}
            </View>
          );
        })}
      </ScrollViewScreen>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 14,
    shadowOpacity: 0,
    elevation: 0,
    borderRadius: 0,
  },
  content: {
    flex: 1,
    marginHorizontal: 15,
  },
});
