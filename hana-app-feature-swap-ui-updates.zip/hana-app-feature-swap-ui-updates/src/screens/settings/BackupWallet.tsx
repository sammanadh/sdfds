import { Button, ButtonVariant } from '@/components/Button';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { TextInput, TextInputRef } from '@/components/TextInput';
import { Heading, Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useVault } from '@/stores/Vault';
import { common } from '@/utils/styles';
import { wait } from '@/utils/wait';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as Haptics from 'expo-haptics';
import { useRef, useState } from 'react';
import { KeyboardAvoidingView, View } from 'react-native';

interface FormErrors {
  passcode?: string | null;
}

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'BackupWallet'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'BackupWallet'>;

export function BackupWalletScreen() {
  const navigation = useNavigation<NavigationProps>();
  const { goBack, navigate } = navigation;

  const { setHideTabBar } = useNavigationStore();

  const {
    params: { wallet },
  } = useRoute<RouteProps>();

  const { verifyCredentials } = useVault();
  const [passcode, setPasscode] = useState('');
  const passcodeInput = useRef<TextInputRef>(null);
  const [attempts, setAttempts] = useState(0);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isWorking, setIsWorking] = useState(false);

  async function handleUnlock() {
    if (isWorking) return;

    const thisAttempt = attempts + 1;
    setAttempts(thisAttempt);
    setIsWorking(true);
    await wait(); // ensure loading UI shows

    const success = await verifyCredentials({ passcode });

    if (success) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

      goBack();
      setHideTabBar(true);
      navigate('BackupMethod', { wallet, passcode });
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      errors.passcode = `Incorrect passcode. You've had ${thisAttempt} attempt${
        thisAttempt !== 1 ? 's' : ''
      }.`;
      setPasscode('');
      wait().then(() => passcodeInput.current?.focus());
      setIsWorking(false);
    }
  }

  return (
    <KeyboardAvoidingView style={[common.fill, { marginTop: 16 }]} behavior="padding">
      <View>
        <Heading>Backup wallet</Heading>
        <Text muted style={{ marginTop: 10 }}>
          Confirm your password to backup your wallet.
        </Text>
      </View>

      <TextInput
        ref={passcodeInput}
        value={passcode}
        onChangeText={(text) => {
          if (errors.passcode) setErrors({ passcode: null });
          setPasscode(text);
        }}
        onSubmitEditing={handleUnlock}
        editable={!isWorking}
        autoFocus
        style={{ marginTop: 50, marginBottom: 25 }}
        placeholder="Confirm your password"
        secureTextEntry
      />
      {errors.passcode && (
        <Text center small error style={{ marginBottom: 25 }}>
          {errors.passcode}
        </Text>
      )}

      <Button hasNextIcon
        variant={ButtonVariant.Primary}
        style={{ width: '100%', marginBottom: 20 }}
        onPress={handleUnlock}
        working={isWorking}
      >
        Continue
      </Button>
    </KeyboardAvoidingView>
  );
}
