import { EntityImage } from '@/components/EntityImage';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { WalletTypeBadge } from '@/components/Settings/WalletTypeBadge';
import { Heading, Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import { CompositeNavigationProp, useIsFocused, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useEffect } from 'react';
import { FlatList, StyleSheet, TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'Settings'>,
  StackNavigationProp<RootStackParams>
>;

export function ManageWallets() {
  const navigation = useNavigation<NavigationProps>();
  const { navigate } = navigation;
  const { wallets } = useVault();
  const { isDarkMode } = useTheme();

  const isFocused = useIsFocused();
  const { setHideTabBar } = useNavigationStore();

  useEffect(() => {
    if (isFocused) {
      setHideTabBar(false);
    }
  }, [isFocused]);

  return (
    <FlatList
      data={wallets}
      style={{ marginTop: 8 }}
      ListHeaderComponent={() => (
        <View>
          <Heading style={styles.header}>Wallets</Heading>
        </View>
      )}
      keyExtractor={(wallet) => wallet.id}
      renderItem={({ item: wallet }) => {
        return (
          <TouchableOpacity
            style={styles.itemContainer}
            onPress={() => {
              setHideTabBar(true);
              navigate('WalletDetails', {
                wallet,
              });
            }}
          >
            <View
              style={[
                styles.itemContent,
                {
                  backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards,
                  borderColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards,
                },
              ]}
            >
              <EntityImage name={wallet?.name} />

              <Text
                bold
                style={[
                  styles.itemTitle,
                  { color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack },
                ]}
              >
                {wallet.name}
              </Text>

              <WalletTypeBadge wallet={wallet} />
            </View>
          </TouchableOpacity>
        );
      }}
      ItemSeparatorComponent={() => <View style={{ height: 15 }} />}
    />
  );
}

const styles = StyleSheet.create({
  header: {
    marginTop: 26,
    marginBottom: 38,
  },
  itemContainer: {
    marginVertical: 0,
  },
  itemContent: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    borderRadius: 0,
    borderWidth: 1,
    marginBottom: 0,
    padding: 16,
  },
  itemTitle: {
    lineHeight: 19.5,
    paddingVertical: 16,
    paddingHorizontal: 8,
    flex: 1,
  },
});
