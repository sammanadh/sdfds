import { Button, ButtonVariant } from '@/components/Button';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { TextInput, TextInputRef } from '@/components/TextInput';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { VALIDATE_PASSWORD_REGEXP } from '@/utils/constants';
import { colors } from '@/utils/designTokens';
import { formatPixel } from '@/utils/format';
import { common } from '@/utils/styles';
import { wait } from '@/utils/wait';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as Haptics from 'expo-haptics';
import { isEmpty, lt } from 'lodash-es';
import { useEffect, useMemo, useRef, useState } from 'react';
import { KeyboardAvoidingView, LayoutAnimation, StyleSheet, View } from 'react-native';

interface FormErrors {
  password?: string | null;
}

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'ChangePassword'>,
  StackNavigationProp<RootStackParams>
>;

enum State {
  CurrentPassword,
  NewPassword,
}

export function ChangePasswordScreen() {
  const navigation = useNavigation<NavigationProps>();
  const { popToTop } = navigation;
  const { isDarkMode } = useTheme();

  const { verifyCredentials } = useVault();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const passwordInput = useRef<TextInputRef>(null);
  const confirmPasswordInput = useRef<TextInputRef>(null);
  const [attempts, setAttempts] = useState(0);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isWorking, setIsWorking] = useState(false);
  const [isFocus, setIsFocus] = useState(false);

  const [state, setState] = useState(State.CurrentPassword);

  const [currentPassword, setCurrentPassword] = useState('');

  const { changePasscode } = useVault();
  const { setToastMessage } = useNavigationStore();

  useEffect(() => {
    setPassword('');
  }, [state]);

  const message = useMemo(() => {
    switch (state) {
      case State.CurrentPassword:
        return 'Enter your current password before choosing a new one.';
      case State.NewPassword:
        return 'Enter a new password for accessing Hana.';
    }
  }, [state]);

  function validate(password: string, confirmPassword: string) {
    const errors: FormErrors = {};
    let valid = false;

    if (isEmpty(password.trim())) {
      errors.password = 'Please enter a password';
    } else if (lt(password.length, 8)) {
      errors.password = 'Your password should be at least 8 characters';
    } else if (!VALIDATE_PASSWORD_REGEXP.test(password)) {
      errors.password =
        'Your password should contain uppercase, lowercase, numeric and non-letter characters';
    } else if (isEmpty(confirmPassword.trim())) {
      errors.password = 'Please confirm the password';
    } else if (confirmPassword !== password) {
      errors.password = 'The passwords you entered are different';
    }

    if (errors.password) {
      passwordInput.current?.focus();
    } else {
      valid = true;
    }

    setErrors(errors);
    return valid;
  }

  async function handleUnlock() {
    if (isWorking) return;

    if (state === State.CurrentPassword) {
      const thisAttempt = attempts + 1;
      setAttempts(thisAttempt);
      await wait(); // ensure loading UI shows

      const success = await verifyCredentials({ passcode: password });

      if (success) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

        setCurrentPassword(password);
        setState(State.NewPassword);

        wait().then(() => passwordInput.current?.focus());

        setIsWorking(false);
      } else {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        errors.password = `Incorrect password. You've had ${thisAttempt} attempt${
          thisAttempt !== 1 ? 's' : ''
        }.`;
        setPassword('');
        wait().then(() => passwordInput.current?.focus());
        setIsWorking(false);
      }
    } else if (state === State.NewPassword) {
      if (validate(password, confirmPassword)) {
        // Update password
        setIsWorking(true);

        await changePasscode(confirmPassword, currentPassword);

        setIsWorking(false);

        popToTop();

        setToastMessage('Your password has been updated', ToastType.info);
      } else {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        errors.password = `Incorrect password. Please confirm the new password you've just entered.`;
        setPassword('');
        setConfirmPassword('');
        wait().then(() => passwordInput.current?.focus());

        setIsWorking(false);
      }
    }
  }

  return (
    <KeyboardAvoidingView style={[common.fill, { marginTop: 12 }]} behavior="padding">
      <Heading style={styles.heading}>Change password</Heading>
      <Text muted style={[{ marginTop: 10 }, isDarkMode && { color: colors.gray.watermark }]}>
        {message}
      </Text>

      <View style={{ marginBottom: 35 }}>
        <TextInput
          label={
            state === State.CurrentPassword ? 'Enter your current password' : 'Enter New password'
          }
          ref={passwordInput}
          value={password}
          onChangeText={(text) => {
            if (errors.password) setErrors({ password: null });
            setPassword(text);
          }}
          onSubmitEditing={() => {
            if (state === State.NewPassword) {
              confirmPasswordInput.current?.focus();
            } else {
              handleUnlock();
            }
          }}
          editable={!isWorking}
          autoFocus
          style={{ marginTop: 50 }}
          blurOnSubmit={true}
          onFocus={() => {
            LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
            setIsFocus(true);
          }}
          onBlur={() => {
            LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
            setIsFocus(false);
          }}
          placeholder={
            state === State.CurrentPassword ? 'Enter your current password' : 'Enter New password'
          }
          secureTextEntry
        />

        {state === State.NewPassword && (
          <TextInput
            label="Confirm your new password"
            ref={confirmPasswordInput}
            value={confirmPassword}
            onChangeText={(text) => {
              if (errors.password) setErrors({ password: null });
              setConfirmPassword(text);
            }}
            onSubmitEditing={handleUnlock}
            editable={!isWorking}
            autoFocus
            style={{ marginTop: 16 }}
            blurOnSubmit={true}
            onFocus={() => {
              LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
              setIsFocus(true);
            }}
            onBlur={() => {
              LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
              setIsFocus(false);
            }}
            placeholder={'Confirm your new password'}
            secureTextEntry
          />
        )}
      </View>

      {errors.password && (
        <Text center small error style={{ marginBottom: 35 }}>
          {errors.password}
        </Text>
      )}

      <Button hasNextIcon
        variant={ButtonVariant.Primary}
        style={{ width: '100%', marginBottom: 20 }}
        onPress={handleUnlock}
        working={isWorking}
      >
        {state === State.CurrentPassword ? 'Continue' : 'Change password'}
      </Button>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginTop: formatPixel(10, 'wHeight'),
  },
});
