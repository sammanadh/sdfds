import { FileLockIcon } from '@/assets/icons';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { UploadFileButton } from '@/components/Settings/UploadFileButton';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import { readKeystoreFile } from '@/utils/keystoreFile';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useState } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import DocumentPicker from 'react-native-document-picker';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'RestoreKeystoreFile'>,
  StackNavigationProp<RootStackParams>
>;

export function RestoreKeystoreFileScreen() {
  const navigation = useNavigation<NavigationProps>();
  const { navigate } = navigation;
  const { isDarkMode } = useTheme();

  const [keystoreFile, setKeystoreFile] = useState(null);
  const { setToastMessage } = useNavigationStore();

  async function handleUploadFile() {
    setKeystoreFile(null);

    try {
      const document = await DocumentPicker.pickSingle({
        type: Platform.OS === 'ios' ? ['public.item'] : DocumentPicker.types.allFiles,
      });

      const keystore = await readKeystoreFile(document.uri);

      navigate('RestoreKeystorePassword', { keystore });
    } catch (error) {
      if (error) {
        setToastMessage('Failed choosing your keystore file', ToastType.error);
      }
      // if (DocumentPicker.isCancel(error)) {
      //   setToastMessage('Please choose your keystore file', ToastType.error);
      // } else {
      //   setToastMessage('Failed choosing your keystore file', ToastType.error);
      // }
    }
  }

  return (
    <SafeAreaScreen bottom={false}>
      <View style={styles.iconContainer}>
        <FileLockIcon style={styles.icon} />
      </View>
      <Heading>Keystore file</Heading>
      <Text muted style={[{ marginTop: 8 }, isDarkMode && { color: colors.whiteSecond }]}>
        Choose a keystore file you've exported from another app.
      </Text>

      <UploadFileButton onPress={handleUploadFile} isDarkMode={isDarkMode} />
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  iconContainer: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.offPurple,
    marginBottom: 20,
  },
  icon: {
    color: colors.black,
    width: 24,
    height: 24,
  },
});
