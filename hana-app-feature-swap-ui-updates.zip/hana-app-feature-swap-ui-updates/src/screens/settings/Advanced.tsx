import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { SettingsItem, SettingsItemType } from '@/components/Settings/SettingsItem';
import { Switch } from '@/components/Switch';
import { Heading, Text } from '@/components/Typography';
import { AuthorizedDApp } from '@/models/Vault';
import { useNavigationStore } from '@/stores/Navigation';
import { useSettings } from '@/stores/Settings';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import { CompositeNavigationProp, useIsFocused, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import * as LocalAuthentication from 'expo-local-authentication';
import React, { useEffect, useState } from 'react';
import { Alert, Linking, StyleSheet, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'Advanced'>,
  StackNavigationProp<RootStackParams>
>;

export function AdvancedScreen() {
  const { navigate } = useNavigation<NavigationProps>();
  const { getActiveWallet } = useVault();
  const { isDarkMode } = useTheme();
  const { biometricsEnabled, setBiometricsEnabled } = useSettings();
  const { setHideTabBar } = useNavigationStore();
  const isFocused = useIsFocused();

  const activeWallet = getActiveWallet();

  const [authorizedDApps, setAuthorizedDApps] = useState<AuthorizedDApp[]>([]);
  useEffect(() => {
    if (activeWallet) {
      setAuthorizedDApps(activeWallet.authorizedDApps);
    }
  }, []);

  const [isBiometricSupported, setIsBiometricSupported] = useState(false);
  const [isBiometricVerified, setIsBiometricVerified] = useState<any>(false || biometricsEnabled);

  useEffect(() => {
    (async () => {
      const compatible = await LocalAuthentication.supportedAuthenticationTypesAsync();
      const check = compatible.includes(1) || compatible.includes(2);
      setIsBiometricSupported(check);
    })();
  }, []);

  async function checkBiometrics() {
    const savedBiometrics = await LocalAuthentication.isEnrolledAsync();

    if (savedBiometrics) {
      const biometricAuth = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Login with Biometrics',
        disableDeviceFallback: true,
        cancelLabel: 'Cancel',
      });

      if (biometricAuth.success === true) {
        setIsBiometricVerified(true);
        setBiometricsEnabled(true);
      } else if (biometricAuth.success === false) {
        setIsBiometricVerified(false);
        setBiometricsEnabled(false);
      }
    } else if (!savedBiometrics) {
      Alert.alert(
        'Please Enable Biometric',
        "It's look like you don't allow permission for this application",
        [
          {
            text: 'Cancel',
          },
          {
            text: 'Settings',
            onPress: () => Linking.openSettings(),
          },
        ]
      );
    }
  }

  const onToggle = (
    isBiometricSupported: boolean,
    biometricsEnabled: boolean,
    isBiometricVerified: boolean
  ) => {
    if (
      isBiometricSupported === true &&
      biometricsEnabled === false &&
      isBiometricVerified === true
    ) {
      navigate('ConfirmPassword', {
        setIsBiometricVerified: setIsBiometricVerified,
        setBiometricsEnabled: setBiometricsEnabled,
      });
    }
    if (
      isBiometricSupported === true &&
      biometricsEnabled === true &&
      isBiometricVerified === false
    ) {
      checkBiometrics();
    }
    if (
      isBiometricSupported === true &&
      biometricsEnabled === true &&
      isBiometricVerified === true
    ) {
      setBiometricsEnabled(true);
    }
  };

  React.useEffect(() => {
    if (isFocused) {
      setHideTabBar(false);
    }
  }, [isFocused]);

  return (
    <SafeAreaScreen>
      <Heading style={styles.heading}>Advanced</Heading>

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginTop: 36,
        }}
      >
        <Text style={isDarkMode && { color: colors.whiteSecond }}>Biometrics Authentication</Text>
        <Switch
          value={biometricsEnabled}
          onChange={(biometricsEnabled) => {
            onToggle(isBiometricSupported, biometricsEnabled, isBiometricVerified);
          }}
        />
      </View>
      <View
        style={[
          styles.separator,
          { backgroundColor: isDarkMode ? colors.purple.darkBlack : colors.gray.cards },
        ]}
      />
      <SettingsItem
        type={SettingsItemType.ChangePassword}
        onPress={() => {
          setHideTabBar(true);
          navigate('ChangePassword');
        }}
      />
      <SettingsItem
        type={SettingsItemType.ResetHana}
        onPress={() => {
          setHideTabBar(true);
          navigate('ResetHana');
        }}
      />
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  heading: {
    marginBottom: 20,
  },
  separator: {
    height: 1,
    marginVertical: 30,
  },
});
