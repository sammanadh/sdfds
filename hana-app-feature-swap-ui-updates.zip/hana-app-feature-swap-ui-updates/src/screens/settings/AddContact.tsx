import { IconEdit, IconEditWhite } from '@/assets/icons';
import { Button, ButtonVariant } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { ModalTextItem } from '@/components/ModalTextItem';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { Select } from '@/components/Select';
import { TextInput } from '@/components/TextInput';
import { Heading, Text } from '@/components/Typography';
import { serviceForChainID } from '@/stores/ChainServices';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { chainForChainID, ChainID } from '@/utils/chains';
import { colors } from '@/utils/designTokens';
import { formatAddress } from '@/utils/format';
import { dismissModal, presentModal } from '@/utils/modal';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { isEmpty, isNil } from 'lodash-es';
import debounce from 'lodash/debounce';
import React, { useLayoutEffect, useMemo, useState } from 'react';
import { ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'AddContact'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'AddContact'>;

export function AddContact() {
  const navigation = useNavigation<NavigationProps>();
  const { goBack } = navigation;
  const {
    params: { contact },
  } = useRoute<RouteProps>();
  const { isDarkMode } = useTheme();

  const { realm, getActiveChainWallets } = useVault();
  const [isReady, setReady] = useState(false);

  const [chainID, setChainID] = React.useState<ChainID | null>(ChainID.ICON);
  const [name, setName] = React.useState('');
  const [address, setAddress] = React.useState('');

  const [chainError, setChainError] = React.useState<string | null>(null);
  const [nameError, setNameError] = React.useState<string | null>(null);
  const [addressError, setAddressError] = React.useState<string | null>(null);

  const [savingContact, setSavingContact] = React.useState(false);

  const activeChainWallets = getActiveChainWallets();
  const selectableChainIDs = useMemo(
    () => activeChainWallets.filter((cw) => cw.isActive).map((cw) => cw.type),
    [activeChainWallets]
  );

  useLayoutEffect(() => {
    debounce(() => {
      setReady(true);
    }, 250)();
  }, []);

  React.useEffect(() => {
    setChainError(null);
  }, [chainID]);

  React.useEffect(() => {
    setNameError(null);
  }, [name]);

  React.useEffect(() => {
    setAddressError(null);
  }, [address]);

  React.useEffect(() => {
    if (contact) {
      setChainID(contact.chain);
      setName(contact.name);
      setAddress(contact.address);
    }
  }, [contact]);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => null,
    });
  }, []);

  const modalContent = React.useMemo(() => {
    return (
      <ScrollView contentContainerStyle={{ marginTop: 20 }}>
        {selectableChainIDs.map((_chainID) => {
          const chain = chainForChainID(_chainID);
          return (
            <ModalTextItem
              title={chain?.name}
              onPress={() => {
                setChainID(_chainID);
                dismissModal();
              }}
              chain={chain}
              isActive={chainID === _chainID}
              key={_chainID}
            />
          );
        })}
      </ScrollView>
    );
  }, [chainID, isDarkMode]);

  function verifyFields() {
    let errors = false;

    if (isNil(chainID)) {
      setChainError('Please select a Chain');
      errors = true;
    }

    if (isEmpty(name)) {
      setNameError('Please provide a name');
      errors = true;
    }

    if (isEmpty(address)) {
      setAddressError('Please provide an address');
      errors = true;
    }

    if (chainID && !isEmpty(address)) {
      const service = serviceForChainID(chainID);
      const isValidAddress = service?.isValidAddress(address) === true;

      if (!isValidAddress) {
        setAddressError('Please provide a valid address');
        errors = true;
      }
    }

    return !errors;
  }

  const onSaveContact = React.useMemo(() => {
    return () => {
      if (!verifyFields()) {
        return;
      }

      setSavingContact(true);

      if (contact && chainID) {
        // Update
        realm?.write(() => {
          contact.name = name;
          contact.address = address;
          contact.chain = chainID;
        });
      } else {
        // Create new
        realm?.write(() => {
          realm.create('Contact', {
            name,
            address,
            chain: chainID,
          });
        });
      }

      setSavingContact(false);

      goBack();
    };
  }, [contact, chainID, name, address]);

  useLayoutEffect(() => {
    if (contact) {
      navigation.setOptions({
        headerRight: () => (
          <TouchableOpacity
            onPress={() => {
              navigation.navigate('EditContact', { contact });
            }}
          >
            <View style={{ width: 45 }}>
              {isDarkMode ? (
                <IconEditWhite width={25} height={25} />
              ) : (
                <IconEdit width={25} height={25} />
              )}
            </View>
          </TouchableOpacity>
        ),
      });
    }
  }, [isDarkMode]);

  const onDeleteContact = React.useMemo(() => {
    return () => {
      if (contact) {
        const content = (
          <>
            <Text style={{ color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack }}>
              You are about to delete the contact{' '}
              <Text large bold>
                {name}
              </Text>
              ?
            </Text>

            <View style={styles.deleteContactButtonsContainer}>
              <Button
                style={{ flex: 1, marginLeft: 12 }}
                variant={ButtonVariant.DangerTertiary}
                onPress={() => {
                  dismissModal();

                  realm?.beginTransaction();
                  realm?.commitTransaction();
                  setTimeout(() => {
                    goBack();
                    realm?.write(() => {
                      realm?.delete(contact);
                    });
                  }, 500);
                }}
              >
                Delete
              </Button>
              <Button
                style={{ width: 120 }}
                variant={ButtonVariant.PurpleSecondary}
                onPress={() => dismissModal()}
              >
                Cancel
              </Button>
            </View>
          </>
        );

        presentModal({
          title: 'Delete this contact',
          content,
          options: {
            withCloseButton: false,
          },
        });
      }
    };
  }, [contact, name]);

  return (
    <SafeAreaScreen bottom={false}>
      <ScrollViewScreen contentContainerStyle={{ marginBottom: 10, flexGrow: 1 }}>
        <Heading>{contact?.name || 'Add a contact'}</Heading>
        {contact?.address && (
          <Text small muted style={{ marginTop: 8 }}>
            {formatAddress(contact?.address || '-')}
          </Text>
        )}
        <Select
          placeholder="Chain"
          isRemoveDropdown={!!contact}
          disabled={!!contact}
          value={chainID ? chainForChainID(chainID)?.name : null}
          chain={chainID ? chainForChainID(chainID) : undefined}
          onPress={() => {
            presentModal({
              title: 'Select Chain',
              content: modalContent,
            });
          }}
          style={{ marginTop: 30 }}
        />

        {chainError && <Text style={styles.errorMessage}>{chainError}</Text>}

        <TextInput
          label="E.g. Elong Musk"
          labelTitle="Name"
          value={name}
          key={`${isReady}-ContactName`}
          editable={!contact}
          isDarkMode={isDarkMode}
          onChangeText={(text) => setName(text)}
          error={!!nameError}
          msgError={nameError}
          style={{ marginTop: 14 }}
          autoFocus
        />

        <TextInput
          label="E.g. hx429731644462ebcfd22185df387272"
          labelTitle="Address"
          value={address}
          key={`${isReady}-ContactAddress`}
          editable={!contact}
          isDarkMode={isDarkMode}
          error={!!addressError}
          msgError={addressError}
          onChangeText={(text) => setAddress(text)}
          style={{ marginTop: 14 }}
        />
      </ScrollViewScreen>
      <Footer>
        {!contact && (
          <Button working={savingContact} style={{}} onPress={onSaveContact}>
            Save contact
          </Button>
        )}

        {contact && (
          <Button
            onPress={onDeleteContact}
            variant={ButtonVariant.DangerTertiary}
            style={{ marginTop: 14 }}
          >
            Delete this contact
          </Button>
        )}
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  errorMessage: {
    color: colors.red,
    marginTop: 8,
  },
  deleteContactButtonsContainer: {
    flexDirection: 'row-reverse',
    marginTop: 38,
  },
});
