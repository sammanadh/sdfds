import { IconResetHana } from '@/assets/icons';
import { Button, ButtonVariant } from '@/components/Button';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { TextInput, TextInputRef } from '@/components/TextInput';
import { Heading, Text } from '@/components/Typography';
import { useOnboardingFlags } from '@/stores/OnboardingFlags';
import { useSettings } from '@/stores/Settings';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import { wait } from '@/utils/wait';
import { useNavigation } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import React, { useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';

interface FormErrors {
  passcode?: string | null;
}

export function ResetConfirm() {
  const navigation = useNavigation();
  const { styles: themeStyles } = useTheme();

  const { verifyCredentials, resetVault } = useVault();
  const [passcode, setPasscode] = useState('');
  const passcodeInput = useRef<TextInputRef>(null);
  const [attempts, setAttempts] = useState(0);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isWorking, setIsWorking] = useState(false);
  const { setBiometricsEnabled } = useSettings();
  const { reset: resetOnboardingFlags } = useOnboardingFlags();

  async function handleUnlock() {
    if (isWorking) return;

    const thisAttempt = attempts + 1;
    setAttempts(thisAttempt);
    setIsWorking(true);
    await wait(); // ensure loading UI shows

    const success = await verifyCredentials({ passcode });

    if (success) {
      try {
        await resetVault();
        setBiometricsEnabled(false);
        resetOnboardingFlags();

        navigation.reset({ index: 0, routes: [{ name: 'OnboardingStack' }] });
      } catch (error: any) {
        console.warn('Failed resetting vault.', error.message);
      }
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      errors.passcode = `Incorrect passcode. You've had ${thisAttempt} attempt${
        thisAttempt !== 1 ? 's' : ''
      }.`;
      setPasscode('');
      wait().then(() => passcodeInput.current?.focus());
      setIsWorking(false);
    }
  }

  return (
    <SafeAreaScreen>
      <IconResetHana
        width={40}
        height={40}
        style={{ backgroundColor: colors.negative, marginBottom: 10 }}
      />
      <Heading>Reset Hana</Heading>
      <Text muted style={styles.title}>
        Enter your password to confirm
      </Text>
      <TextInput
        label="Enter your password"
        ref={passcodeInput}
        value={passcode}
        onChangeText={(text) => {
          if (errors.passcode) setErrors({ passcode: null });
          setPasscode(text);
        }}
        onSubmitEditing={handleUnlock}
        editable={!isWorking}
        autoFocus
        style={{ marginTop: 40, marginBottom: 20 }}
        secureTextEntry
      />
      {errors.passcode && (
        <Text center small error style={{ marginBottom: 20 }}>
          {errors.passcode}
        </Text>
      )}

      <View style={[styles.containerWarning, themeStyles.cards]}>
        <View style={styles.dotWarning} />
        <View style={styles.contentWarning}>
          <Text bold style={styles.txtWarning}>
            Warning
          </Text>
          <Text style={{ marginTop: 5 }}>
            This action cannot be undone. Ensure you have backed up your wallets before continuing.
          </Text>
        </View>
      </View>

      <Button
        variant={ButtonVariant.DangerTertiary}
        style={{ width: '100%', marginBottom: 20 }}
        onPress={handleUnlock}
        working={isWorking}
      >
        Reset Hana
      </Button>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  title: {
    marginTop: 10,
  },
  containerWarning: {
    width: '100%',
    height: 120,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  dotWarning: {
    width: 6,
    height: 120,
    backgroundColor: colors.negative,
  },
  contentWarning: {
    paddingHorizontal: 20,
  },
  txtWarning: {
    lineHeight: 19,
  },
});
