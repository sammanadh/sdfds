import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { RestoreWalletItem, RestoreWalletItemType } from '@/components/Settings/RestoreWalletItem';
import { Heading, Text } from '@/components/Typography';
import { useTheme } from '@/stores/Theme';
import { colors } from '@/utils/designTokens';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useEffect, useMemo } from 'react';
import { IconBack, IconBackWhite } from '@/assets/icons';
import { TouchableOpacity, View } from 'react-native';
import { navigationStyles } from '@/components/Navigation/utils';
import { HIT_SLOP_XLARGE } from '@/utils/constants';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'RestoreWallet'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'RestoreWallet'>;

export function RestoreWallet() {
  const navigation = useNavigation<NavigationProps>();
  const { navigate } = navigation;
  const { isDarkMode } = useTheme();
  const { params } = useRoute<RouteProps>();

  const fromDrawer = useMemo(() => {
    if (params) {
      return params.fromDrawer || false;
    }

    return false;
  }, [params]);

  // This is only used when fromDrawer is true
  function onBack() {
    // @ts-expect-error not worth mapping navigation props to here
    navigate('HomeStack');
  }

  useEffect(() => {
    if (fromDrawer) {
      navigation.setOptions({
        headerLeft: () => (
          <View style={navigationStyles.headerLeft}>
            <TouchableOpacity onPress={onBack} hitSlop={HIT_SLOP_XLARGE}>
              {isDarkMode ? <IconBackWhite /> : <IconBack />}
            </TouchableOpacity>
          </View>
        ),
      });
    }
  }, [navigation, fromDrawer]);

  return (
    <SafeAreaScreen bottom={false}>
      <Heading>Restore wallet</Heading>
      <Text
        muted
        style={[
          {
            marginTop: 10,
            marginBottom: 25,
          },
          isDarkMode && { color: colors.whiteSecond },
        ]}
      >
        Would you like to use your private key or a keystore file?
      </Text>

      <RestoreWalletItem
        type={RestoreWalletItemType.PrivateKey}
        onPress={() => {
          navigate('ImportPrivateKey');
        }}
        isDarkMode={isDarkMode}
      />

      <RestoreWalletItem
        type={RestoreWalletItemType.KeystoreFile}
        onPress={() => {
          navigate('RestoreKeystoreFile');
        }}
        isDarkMode={isDarkMode}
      />
    </SafeAreaScreen>
  );
}
