import { IconEdit, IconEditWhite } from '@/assets/icons';
import { Button, ButtonVariant } from '@/components/Button';
import { Footer } from '@/components/Footer';
import { ConfirmRemoveWalletModal } from '@/components/Modals/ConfirmRemoveWalletModal';
import { RootStackParams, SettingsStackParams } from '@/components/Navigation';
import { SafeAreaScreen } from '@/components/SafeAreaScreen';
import { ScrollViewScreen } from '@/components/ScrollViewScreen';
import { ToastType } from '@/components/Toast.types';
import { Heading, Text } from '@/components/Typography';
import { WalletType } from '@/models/Vault';
import { useNavigationStore } from '@/stores/Navigation';
import { useTheme } from '@/stores/Theme';
import { useVault } from '@/stores/Vault';
import { colors } from '@/utils/designTokens';
import { dismissModal, presentModal } from '@/utils/modal';
import {
  CompositeNavigationProp,
  RouteProp,
  useIsFocused,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useEffect, useLayoutEffect, useState } from 'react';
import { StyleSheet, TouchableOpacity, View } from 'react-native';

type NavigationProps = CompositeNavigationProp<
  StackNavigationProp<SettingsStackParams, 'WalletDetails'>,
  StackNavigationProp<RootStackParams>
>;

type RouteProps = RouteProp<SettingsStackParams, 'WalletDetails'>;

export function WalletDetails() {
  const isFocused = useIsFocused();

  const navigation = useNavigation<NavigationProps>();
  const { navigate, goBack, setOptions } = navigation;
  const {
    params: { wallet },
  } = useRoute<RouteProps>();

  const [name, setName] = useState(wallet.name);

  const { removeWallet, wallets } = useVault();
  const { setToastMessage } = useNavigationStore();
  const { isDarkMode } = useTheme();

  useLayoutEffect(() => {
    setOptions({
      headerRight: () => (
        <TouchableOpacity
          style={{ paddingHorizontal: 20 }}
          onPress={() => navigate('RenameWallet', { wallet })}
        >
          {isDarkMode ? (
            <IconEditWhite height={24} width={24} />
          ) : (
            <IconEdit height={24} width={24} />
          )}
        </TouchableOpacity>
      ),
    });
  }, [isDarkMode]);

  useEffect(() => {
    if (isFocused) {
      setName(wallet.name);
    }
  }, [isFocused]);

  function handleRemoveWallet() {
    if (wallets.length === 1) {
      setToastMessage('Reset Hana to remove all wallets', ToastType.error);
      return;
    }

    goBack();
    setTimeout(() => {
      removeWallet(wallet.id);
    }, 1000);
  }

  function handleConfirmRemove() {
    const title = `${
      wallet.type === WalletType.HD
        ? 'Hide'
        : wallet.type === WalletType.Ledger
        ? 'Disconnect'
        : 'Remove'
    }  wallet`;

    const content = (
      <View style={{ marginTop: 20 }}>
        <ConfirmRemoveWalletModal
          wallet={wallet}
          onCancel={() => {
            dismissModal();
          }}
          onConfirm={() => {
            dismissModal();
            handleRemoveWallet();
          }}
        />
      </View>
    );

    presentModal({
      title,
      content,
      options: {
        withCloseButton: false,
      },
    });
  }

  const removeButtonTitle = `${
    wallet.type === WalletType.HD
      ? 'Hide'
      : wallet.type === WalletType.Ledger
      ? 'Disconnect'
      : 'Remove'
  } this wallet`;

  return (
    <SafeAreaScreen top={false} bottom={false} padTop>
      <ScrollViewScreen>
        <Heading style={styles.header}>{name}</Heading>

        <View
          style={[
            styles.itemContent,
            { backgroundColor: isDarkMode ? colors.purple.darkBlacker : colors.white },
          ]}
        >
          <Text bold muted style={{ fontSize: 12 }}>
            name
          </Text>
          <Text bold style={{ color: isDarkMode ? colors.whiteSecond : colors.purple.darkBlack }}>
            {name}
          </Text>
        </View>
      </ScrollViewScreen>

      <Footer>
        {wallet.type !== WalletType.Ledger && (
          <Button hasNextIcon
            onPress={() => {
              navigate('BackupWallet', { wallet });
            }}
          >
            Backup wallet
          </Button>
        )}

        <Button
          variant={ButtonVariant.DangerSecondary}
          style={{ marginTop: 14, backgroundColor: '#fabdcf', borderWidth: 0 }}
          textStyle={{ color: colors.purple.darkBlack }}
          onPress={() => {
            wallet.type === WalletType.HD ? 'Hide' && handleRemoveWallet() : handleConfirmRemove();
          }}
        >
          {removeButtonTitle}
        </Button>
      </Footer>
    </SafeAreaScreen>
  );
}

const styles = StyleSheet.create({
  header: {
    marginBottom: 20,
  },
  itemContent: {
    width: '100%',
    height: 60,
    paddingHorizontal: 20,
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.gray.meta,
    borderRadius: 30,
  },
});
