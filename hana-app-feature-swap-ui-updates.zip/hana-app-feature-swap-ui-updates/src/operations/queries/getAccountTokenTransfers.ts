import type { Transaction } from '@/models/Transaction';
import { TokenTransferDetailsFragment } from '@/operations/fragments/tokenTransferDetails';
import { gql } from 'graphql-request';

interface ChainAccountWhereUniqueInput {
  chainType: string;
  address: string;
}

export interface GetAccountTokenTransfersVariables {
  where: ChainAccountWhereUniqueInput;
}

export interface GetAccountTokenTransfersData {
  accountTokenTransfers: Array<Partial<Transaction> & { gas: string }>;
}

export const GET_ACCOUNT_TOKEN_TRANSFERS = gql`
  query GetAccountTokenTransfers($where: ChainAccountWhereUniqueInput!) {
    accountTokenTransfers(where: $where) {
      ...TokenTransferDetails
    }
  }
  ${TokenTransferDetailsFragment}
`;
