import type { Collectable } from '@/models/Collectable';
import { TokenDetailsFragment } from '@/operations/fragments/tokenDetails';
import { gql } from 'graphql-request';

interface ChainTokenWhereUniqueInput {
  chainType: string;
  contract: string;
  tokenId: number;
}

export interface GetTokenDetailsVariables {
  where: ChainTokenWhereUniqueInput;
}

export interface GetTokenDetailsData {
  tokenDetails: Collectable;
}

export const GET_TOKEN_DETAILS = gql`
  query GetTokenDetails($where: ChainTokenWhereUniqueInput!) {
    tokenDetails(where: $where) {
      ...TokenDetails
    }
  }
  ${TokenDetailsFragment}
`;
