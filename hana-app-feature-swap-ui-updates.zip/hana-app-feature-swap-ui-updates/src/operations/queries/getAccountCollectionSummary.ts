import type { CollectionDetails } from '@/models/Collectable';
import { CollectionDetailsFragment } from '@/operations/fragments/collectionDetails';
import { gql } from 'graphql-request';

interface ChainAccountWhereUniqueInput {
  chainType: string;
  address: string;
}

export interface GetAccountCollectionSummaryVariables {
  where: ChainAccountWhereUniqueInput;
}

export interface GetAccountCollectionSummaryData {
  accountCollectionSummary: Array<CollectionDetails>;
}

export const GET_ACCOUNT_COLLECTION_SUMMARY = gql`
  query GetAccountCollectionSummary($where: ChainAccountWhereUniqueInput!) {
    accountCollectionSummary(where: $where) {
      collection {
        ...CollectionDetails
      }
      tokensCount
      coverImage
    }
  }
  ${CollectionDetailsFragment}
`;
