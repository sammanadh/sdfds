import type { Collectable, Collection } from '@/models/Collectable';
import { CollectionDetailsFragment } from '@/operations/fragments/collectionDetails';
import { TokenDetailsFragment } from '@/operations/fragments/tokenDetails';
import { gql } from 'graphql-request';

interface AccountCollectionWhereUniqueInput {
  chainType: string;
  contract: string;
  address: string;
}

export interface GetAccountCollectionDetailsVariables {
  where: AccountCollectionWhereUniqueInput;
}

export interface GetAccountCollectionDetailsData {
  accountCollectionDetails: {
    collection: Collection;
    tokens: Array<Collectable>;
  };
}

export const GET_ACCOUNT_COLLECTION_DETAILS = gql`
  query GetAccountCollectionDetails($where: AccountCollectionWhereUniqueInput!) {
    accountCollectionDetails(where: $where) {
      collection {
        ...CollectionDetails
      }
      tokens {
        ...TokenDetails
      }
    }
  }
  ${CollectionDetailsFragment}
  ${TokenDetailsFragment}
`;
