import { gql } from 'graphql-request';

export const TokenTransferDetailsFragment = gql`
  fragment TokenTransferDetails on TokenTransfer {
    hash
    nonce
    title
    date
    from
    to
    amount
    gas
    gasPrice
    tokenContract
    tokenSymbol
    tokenId
    imageUrl
  }
`;
