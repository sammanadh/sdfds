import { gql } from 'graphql-request';

export const CollectionDetailsFragment = gql`
  fragment CollectionDetails on Collection {
    id
    contract
    name
    standard
    chain {
      type
    }
  }
`;
