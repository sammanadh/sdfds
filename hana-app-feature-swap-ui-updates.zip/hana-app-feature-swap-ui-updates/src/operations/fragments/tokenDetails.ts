import { gql } from 'graphql-request';

export const TokenDetailsFragment = gql`
  fragment TokenDetails on Token {
    id
    tokenId
    name
    description
    imageUrl
    originalImageUrl
    attributes
  }
`;
