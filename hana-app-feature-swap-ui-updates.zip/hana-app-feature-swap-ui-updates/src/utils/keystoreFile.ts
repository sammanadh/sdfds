import { isNil } from 'lodash-es';
import { Platform } from 'react-native';
import RNFS from 'react-native-fs';

type KeyValue = Record<string, any>;

export interface Keystore {
  version: number;
  id: string;
  address: string;
  coinType: string;
  crypto: KeyValue;

  // Polkadot JS
  encoded?: string;
  encoding?: KeyValue;
  meta?: KeyValue;
}

export enum KEYSTORE_ERRORS {
  INVALID_KEYSTORE = 'invalid_keystore',
  FAILED_READING_FILE = 'failed_reading_file',
}

export function isValidPolkadotKeystore(keystore: Keystore | KeyValue) {
  return (
    !isNil(keystore.encoded) &&
    !isNil(keystore.encoding) &&
    !isNil(keystore.address) &&
    !isNil(keystore.meta)
  );
}

export async function readKeystoreFile(uri: string) {
  try {
    const fileUri = Platform.OS === 'ios' ? decodeURIComponent(uri) : uri;
    const fileContents = await RNFS.readFile(fileUri);
    const keystore = JSON.parse(fileContents.trim());
    if (!validate(keystore)) throw new Error(KEYSTORE_ERRORS.INVALID_KEYSTORE);
    return keystore;
  } catch (error) {
    console.debug('error: ', error);
    throw new Error(KEYSTORE_ERRORS.FAILED_READING_FILE);
  }
}

function validate(keystore: Keystore | KeyValue) {
  if (isValidPolkadotKeystore(keystore)) {
    // Polkadot JS keystore
    return true;
  }

  return !(isNil(keystore.version) || isNil(keystore.id) || isNil(keystore.address));
}
