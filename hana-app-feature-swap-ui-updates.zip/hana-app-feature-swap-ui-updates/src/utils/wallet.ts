import {
  ChainWallet,
  ChainWalletSubstrateSignatureType,
  CustomNetwork,
  Token,
  Wallet,
} from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useSettings } from '@/stores/Settings';
import { useVault } from '@/stores/Vault';
import { ChainDetails, ChainID, chains, getSS58Prefix, isSubstrateChain } from '@/utils/chains';
import { CoinType, getCoinHDPath } from '@/utils/coinTypes';
import { SubstrateKeyDerivationMethod } from '@/utils/constants';
import { TestnetConfig } from '@/utils/networks';
import { getKeyringPairForWallet } from '@/utils/polkadot';
import { isCustomNetwork, isTestnetConfig } from '@/utils/types';
import type { Keyring } from '@polkadot/keyring';
import { cryptoWaitReady } from '@polkadot/util-crypto';
import { fromSeed } from 'bip32';
import { mnemonicToSeedSync as bip39MnemonicToSeedSync } from 'bip39';
import bs58 from 'bs58';
import { derivePath } from 'ed25519-hd-key';
import IconSDK from 'icon-sdk-js';
import { KeyPair } from 'near-api-js';
import nacl from 'tweetnacl';
import Web3 from 'web3';

let _Keyring: typeof Keyring | undefined = undefined;

cryptoWaitReady().then(() => {
  import('@polkadot/keyring').then((keyring) => {
    _Keyring = keyring.Keyring;
  });
});

const { IconWallet } = IconSDK;

export async function derivePrivateKey(seedKey: string, hdPath: string) {
  const rootKey = fromSeed(Buffer.from(seedKey, 'hex'));
  const derivedKey = rootKey.derivePath(hdPath);
  return derivedKey.privateKey!.toString('hex');
}

export function getCoinWalletAddressUsingPrivateKey(privateKey: string, chain: ChainDetails) {
  switch (chain.coinType) {
    case CoinType.ETH:
      const web3 = new Web3();
      const account = web3.eth.accounts.privateKeyToAccount(privateKey);
      return account.address;

    case CoinType.ICX:
    case CoinType.HVH:
      const iconWallet = IconWallet.loadPrivateKey(privateKey);
      return iconWallet.getAddress();

    case CoinType.DOT:
    case CoinType.KSM:
      // REMINDER: Need to keep this for legacy support
      if (!_Keyring) {
        throw new Error('No Keyring available');
      }

      const { substrateKeyDerivationMethod } = useSettings.getState();
      const signatureType =
        substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.MnemonicSr25519
          ? 'sr25519'
          : 'ed25519';

      const dotKeyring: Keyring = new _Keyring({ type: signatureType });

      const dotPair = dotKeyring.createFromUri('0x' + privateKey, undefined, signatureType);

      return dotKeyring.encodeAddress(dotPair.publicKey, getSS58Prefix(chain.id));

    case CoinType.NEAR:
      // Get public key from a NEAR private key
      const keyPair = KeyPair.fromString(privateKey);

      const splitArray = keyPair.getPublicKey().toString().split(':');
      const bytes = bs58.decode(splitArray[1]);

      return Buffer.from(bytes).toString('hex');
  }
}

export function getCoinWalletAddressUsingMnemonic(
  mnemonic: string,
  wallet: Wallet,
  chain: ChainDetails
) {
  if (
    chain.coinType !== CoinType.DOT &&
    chain.coinType !== CoinType.KSM &&
    chain.coinType !== CoinType.NEAR
  ) {
    throw new Error('Mnemonic derivation is unsupported for this coin type');
  }

  if (chain.coinType === CoinType.DOT || chain.coinType === CoinType.KSM) {
    if (!_Keyring) {
      throw new Error('No Keyring available');
    }

    const dotKeyring: Keyring = new _Keyring({ type: 'sr25519' });
    const dotPair = getKeyringPairForWallet(wallet, mnemonic);

    return dotKeyring.encodeAddress(dotPair.publicKey, getSS58Prefix(chain.id));
  }

  if (chain.coinType === CoinType.NEAR) {
    const hexSeed = bip39MnemonicToSeedSync(mnemonic).toString('hex');
    const hdPath = getCoinHDPath(CoinType.NEAR, wallet.hdIndex!);
    const { key, chainCode } = derivePath(hdPath, hexSeed);

    const keyPair = nacl.sign.keyPair.fromSeed(key);
    // Convert key to base58
    const publicKey = 'ed25519:' + bs58.encode(Buffer.from(keyPair.publicKey));
    const secretKey = 'ed25519:' + bs58.encode(Buffer.from(keyPair.secretKey));

    // NOTE: Secretkey is later used to construct KeyPair for NEAR

    const splitArray = publicKey.split(':');
    const bytes = bs58.decode(splitArray[1]);

    const address = Buffer.from(bytes).toString('hex');
    return address;
  }
}

export function createKeystore(privateKey: string, password: string, chainId: ChainID) {
  const chain = chains.find((chain) => chain.id === chainId)!;
  switch (chain.coinType) {
    case CoinType.ETH:
      const web3 = new Web3();
      return web3.eth.accounts.encrypt(privateKey, password);

    case CoinType.ICX:
      const iconWallet = IconWallet.loadPrivateKey(privateKey);
      return iconWallet.store(password);

    // case CoinType.DOT:
    // case CoinType.KSM:
    //   try {
    //     const keyring = new Keyring();
    //     keyring.addFromUri('0x' + privateKey);
    //     return keyring.toJson(getChainWalletAddress(privateKey, chainId), password);
    //   } catch (error) {
    //     console.warn('Failed creating keystore.', error);
    //     return null;
    // }
  }
}

export function tokensForChainWallet(chainWallet: ChainWallet): Token[] {
  const { otherNetwork } = useChainServices.getState();
  const { realm } = useVault.getState();

  const tokens = realm?.objects<Token>('Token');

  if (isTestnetConfig(otherNetwork)) {
    if (chainWallet.type !== otherNetwork.chainType) {
      return [];
    }

    const testnetConfig = otherNetwork as TestnetConfig;

    return [...(tokens?.filtered(`networkRef == $0`, testnetConfig.ref) || [])];
  }

  if (isCustomNetwork(otherNetwork)) {
    if (chainWallet.type !== otherNetwork.chain) {
      return [];
    }

    const customNetwork = otherNetwork as CustomNetwork;

    return [...(tokens?.filtered('customNetworkId == $0', customNetwork.id) || [])];
  }

  return [...(tokens?.filtered(`chainId == $0`, chainWallet.type) || [])];
}

export function isChainWalletValid(chainWallet: ChainWallet) {
  if (isSubstrateChain(chainWallet.type)) {
    const { substrateKeyDerivationMethod } = useSettings.getState();

    if (substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.Bip44Ed25519) {
      return chainWallet.substrateSignatureType === ChainWalletSubstrateSignatureType.ed25519;
    }

    if (substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.MnemonicSr25519) {
      return chainWallet.substrateSignatureType === ChainWalletSubstrateSignatureType.sr25519;
    }
  }

  return true;
}

export function chainWalletForChain(chain: ChainID) {
  const { getActiveWalletAllChainWallets } = useVault.getState();
  const chainWallets = getActiveWalletAllChainWallets();

  return chainWallets.find((chainWallet) => chainWallet.type === chain);
}
