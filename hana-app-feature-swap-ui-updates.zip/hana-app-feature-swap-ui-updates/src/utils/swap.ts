import { SwapStatus, SwappableToken } from '@/models/SwapService';
import { Transaction } from '@/models/Transaction';
import { useChainServices } from '@/stores/ChainServices';
import { usePendingTransactions } from '@/stores/PendingTransactions';
import { useSwapServices } from '@/stores/SwapServices';
import { generateKey, useTransactions } from '@/stores/Transactions';
import { wait } from '@/utils/wait';
import produce from 'immer';
import { isNil } from 'lodash-es';

export async function watchSwapTransaction(transaction: Transaction) {
  const { serviceForProvider } = useSwapServices.getState();

  const swapService = transaction.provider ? serviceForProvider(transaction.provider) : undefined;

  if (!swapService) return;

  while (true) {
    try {
      // Get updated swap status, do this first because it's async
      const { status, label, receiveAmount } = await swapService.getSwapStatus(transaction);

      if (transaction.statusLabel !== label) {
        console.debug('boom');
        const { pendingTransactions } = usePendingTransactions.getState();

        const { transactions } = useTransactions.getState();

        const updatedPendingTransactions = produce(pendingTransactions, (draft) => {
          const index = draft.findIndex((t) => t.hash === transaction.hash);

          if (index >= 0) {
            draft[index].statusLabel = label;
            draft[index].isPending = status === SwapStatus.Pending;
            draft[index].isFailed = status === SwapStatus.Failed;
            draft[index].toAmount = receiveAmount;
          }
        });

        const updatedTransactions = transactions;

        if (!transaction.chainID || !transaction.from) return;

        const { otherNetwork } = useChainServices.getState();

        const key = generateKey(transaction.chainID, transaction.from, otherNetwork);

        const transactionsForKey = updatedTransactions.get(key) || [];

        const index = transactionsForKey.findIndex((t) => t.hash === transaction.hash);

        if (index >= 0) {
          transactionsForKey[index].isPending = false;
        }

        updatedTransactions.set(key, transactionsForKey);

        usePendingTransactions.setState({
          pendingTransactions: updatedPendingTransactions,
        });

        useTransactions.setState({
          transactions: updatedTransactions,
        });
      }

      if (status === SwapStatus.Failed) {
        throw new Error('SWAP_FAILED');
      } else if (status === SwapStatus.Pending) {
        // Throw here so we can wait and continue the loop
        throw new Error('SWAP_STILL_PENDING');
      }

      // Swap has succeeded, exit the loop
      console.debug('EXITING LOOP');
      return;
    } catch (error: any) {
      if (error.message === 'SWAP_FAILED') {
        throw new Error(`${transaction.provider} swap ${transaction.hash} failed.`);
      } else if (error.message === 'NO_CHAIN_WALLET' || error.message === 'SWAP_NOT_FOUND') {
        throw new Error(
          `Stopped waiting for ${transaction.provider} swap ${transaction.hash}. Error: ${error.message}`
        );
      }

      console.debug('Waiting for swap to complete...');

      await wait(10000);
    }
  }
}

export function formatSwappableTokens(formattedSwappables: Array<SwappableToken>, providerTokens: Array<SwappableToken>) {
  let providerTokensCopy: Array<SwappableToken> = JSON.parse(JSON.stringify(providerTokens));

  formattedSwappables.forEach((swappable, index) => {
    const { chainId, isNative, contract } = swappable;
    const commonTokenIndex = providerTokensCopy.findIndex(
      (t) =>
        t.chainId === chainId &&
        ((t.isNative && isNative) ||
          (!isNil(t.contract) && t.contract?.toLowerCase() === contract?.toLowerCase()))
    );
    if (commonTokenIndex > -1) {
      formattedSwappables[index].providers = Array.from(
        new Set([
          ...formattedSwappables[index].providers,
          ...providerTokensCopy[commonTokenIndex].providers,
        ])
      );
      // recover contract address for ICX
      if (!isNil(providerTokensCopy[commonTokenIndex].contract)) {
        formattedSwappables[index].contract = providerTokensCopy[commonTokenIndex].contract;
      }
      providerTokensCopy.splice(commonTokenIndex, 1);
    }
  });
  formattedSwappables.push(...providerTokensCopy);
}