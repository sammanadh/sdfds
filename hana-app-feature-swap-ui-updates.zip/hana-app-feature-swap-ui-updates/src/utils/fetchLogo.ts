import { isEmpty, isNil } from 'lodash-es';

const ICON_GRABBER_BASE_URL = `https://favicongrabber.com/api/grab`;
const FALLBACK_IMAGE = `https://res.cloudinary.com/reliantnode/image/upload/w_40,bo_10px_solid_transparent/v1683089686/hana/dapp-logos/dapp.png`;
const IS_PNG = /\.png$/;

export async function fetchLogo(url: string): Promise<string> {
  try {
    const iconUrl = `${ICON_GRABBER_BASE_URL}/${url}/`;
    const response = await fetch(iconUrl);
    const data = (await response.json()) as FaviconResponse;
    if (!isEmpty(data.error)) throw new Error(data.error!);
    for (let i = 0, n = data.icons.length; i < n; i++) {
      const icon = data.icons[i];
      if (icon.type === 'image/png' || IS_PNG.test(icon.src)) {
        return icon.src;
      }
    }

    // Fallback to first icon if PNG not found
    if (!isNil(data.icons[0]?.src)) return data.icons[0].src;
  } catch (error) {}

  return FALLBACK_IMAGE;
}

interface FaviconResponse {
  domain: string;
  error?: string;
  icons: Array<{
    src: string;
    sizes?: string;
    type?: string;
  }>;
}
