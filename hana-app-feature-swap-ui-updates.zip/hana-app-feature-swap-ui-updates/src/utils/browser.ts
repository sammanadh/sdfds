import { AuthorizedDApp, Wallet } from '@/models/Vault';
import { useVault } from '@/stores/Vault';
import { isNil } from 'lodash-es';
import { ChainID } from './chains';

export function getAuthorizedDApps() {
  const { realm } = useVault.getState();

  return realm?.objects<AuthorizedDApp>('AuthorizedDApp');
}

export function getAuthorizedDapps(wallet: Wallet) {
  return wallet.authorizedDApps;
}

export function hasAuthorizedDApp(wallet: Wallet, host: string) {
  const authorizedDApp = wallet.authorizedDApps.find(
    (authorizedDApp) => authorizedDApp.host === host
  );
  return !isNil(authorizedDApp);
}

export function addAuthorizedDApp(
  wallet: Wallet,
  host: string,
  title: string,
  faviconUrl?: string,
  chainId?: ChainID
) {
  const { realm } = useVault.getState();

  realm?.write(() => {
    const authorizedDApp = wallet.authorizedDApps.find(
      (authorizedDApp) => authorizedDApp.host === host
    );

    if (isNil(authorizedDApp)) {
      wallet.authorizedDApps.push({ host, title, faviconUrl, chainId });
    } else {
      authorizedDApp.chainId = chainId;
    }
  });
}

export function removeAuthorizedDApp(wallet: Wallet, host: string) {
  const { realm } = useVault.getState();

  realm?.write(() => {
    const authorizedDApp = wallet.authorizedDApps.find(
      (authorizedDApp) => authorizedDApp.host === host
    );
    if (!isNil(authorizedDApp)) realm?.delete(authorizedDApp);
  });
}

export function getChainIDForAuthorizedDApp(wallet: Wallet, host: string) {
  const authorizedDApp = wallet.authorizedDApps.find(
    (authorizedDApp) => authorizedDApp.host === host
  );
  return authorizedDApp?.chainId;
}

export function updateChainIDForAuthorizedDApp(wallet: Wallet, host: string, chainId: ChainID) {
  const { realm } = useVault.getState();

  realm?.write(() => {
    const authorizedDApp = wallet.authorizedDApps.find(
      (authorizedDApp) => authorizedDApp.host === host
    );
    if (!isNil(authorizedDApp)) authorizedDApp.chainId = chainId;
  });
}
