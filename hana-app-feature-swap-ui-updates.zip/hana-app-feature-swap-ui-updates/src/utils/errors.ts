export function getErrorMessage(error: Error, fallback: string) {
  if (error.message.includes('E2003:FutureTx') || error.message.includes('E2002:Expired')) {
    return 'Tx failed, check your computer clock';
  }
  if (error.message.includes('Insufficient ICX')) {
    return 'Tx failed, insufficient ICX';
  }

  return fallback;
}
