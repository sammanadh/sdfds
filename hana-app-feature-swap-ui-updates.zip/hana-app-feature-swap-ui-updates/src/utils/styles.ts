import { colors } from '@/utils/designTokens';
import { StyleSheet } from 'react-native';

export const common = StyleSheet.create({
  center: {
    alignSelf: 'center',
  },
  centerContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerText: {
    alignSelf: 'center',
    textAlign: 'center',
  },
  fill: {
    flex: 1,
  },
  screen: {
    paddingHorizontal: 20,
  },
  negateScreen: {
    marginHorizontal: -20,
  }
});

export const card = StyleSheet.create({
  base: {
    backgroundColor: colors.white,
    borderRadius: 14,
    padding: 20,
  },
  pressed: {
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.24,
    shadowRadius: 7,
    elevation: 12,
  },
});
