import { Token } from '@/models/Vault';
import { isNil } from 'lodash-es';
import Web3 from 'web3';

export async function getTokenLogo(token: Token): Promise<string | undefined> {
  if (isNil(token.contract)) return undefined;

  try {
    const address = Web3.utils.toChecksumAddress(token.contract);
    const url = `https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/${address}/logo.png`;
    const response = await fetch(url);
    if (response.ok) return url;
  } catch (error) {
    // ignore
  }
}

export function tokenFilter(token: Token, query: string) {
  const lowerQuery = query.toLowerCase();
  return (
    token.name.toLowerCase().includes(lowerQuery) || token.symbol.toLowerCase().includes(lowerQuery)
  );
}
