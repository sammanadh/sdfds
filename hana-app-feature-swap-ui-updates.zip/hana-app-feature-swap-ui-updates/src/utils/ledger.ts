import AppEth from '@ledgerhq/hw-app-eth';
import { byContractAddressAndChainId } from '@ledgerhq/hw-app-eth/src/services/ledger/erc20';
import AppIcx from '@ledgerhq/hw-app-icx';
import Transport from '@ledgerhq/hw-transport';
import type { Keyring } from '@polkadot/keyring';
import { cryptoWaitReady } from '@polkadot/util-crypto';
import { newKusamaApp, newPolkadotApp, SubstrateApp } from '@zondax/ledger-substrate';
import { isNil } from 'lodash-es';
import { Client as NearApp, createClient } from 'near-ledger-js';
import { ChainID } from './chains';

let _Keyring: typeof Keyring | undefined = undefined;

cryptoWaitReady().then(() => {
  import('@polkadot/keyring').then((keyring) => {
    _Keyring = keyring.Keyring;
  });
});

export enum AppType {
  ETH = 'ETH',
  ICX = 'ICX',
  DOT = 'DOT',
  KSM = 'KSM',
  WND = 'WND',
  NEAR = 'NEAR',
}

export enum LedgerErrors {
  NotSupported = 'NotSupported',
  NotConnected = 'NotConnected',
  NoAddress = 'NoAddress',
  IncorrectDevice = 'IncorrectDevice',
}

export interface EthSignature {
  v: string | number;
  r: string;
  s: string;
}

const BASE_PATHS = {
  ETH: `44'/60'/0'/0`,
  ICX: `44'/4801368'/0'/0'`,
  DOT: `44'/354'/account'/0'/0'`,
  KSM: `44'/434'/account'/0'/0'`,
  WND: `44'/354'/account'/0'/0'`,
  NEAR: `44'/397'/0'/0'`,
};

export interface LedgerAddress {
  index: number;
  hdPath: string;
  address: string;
}

export type LedgerAddresses = PartialRecord<ChainID, LedgerAddress>;

export const LEDGER_DEFAULT_DOT_ACCOUNT = 0x80000000;
export const LEDGER_DEFAULT_DOT_CHANGE = 0x80000000;
export const LEDGER_DEFAULT_DOT_INDEX = 0x80000000;

const WND_SS58_DECIMAL = 42; // For encoding address

export async function getLedgerAddresses(
  transport: Transport,
  appType: AppType,
  take: number,
  skip: number
): Promise<Array<LedgerAddress>> {
  console.debug('skip :', skip);

  let app: AppEth | AppIcx | SubstrateApp | NearApp | undefined;

  try {
    app = await getLedgerApp(transport, appType);
    const addresses: Array<LedgerAddress> = [];
    for (let i = skip, n = take + skip; i < n; i++) {
      addresses.push(await getLedgerAddress(app, appType, i));
    }
    return addresses;
  } catch (error) {
    throw error;
  }
}

export async function getLedgerApp(
  transport: Transport,
  appType: AppType
): Promise<AppEth | AppIcx | SubstrateApp | NearApp> {
  switch (appType) {
    case AppType.ETH:
      return getAppEth(transport);

    case AppType.ICX:
      return getAppIcx(transport);

    case AppType.DOT:
      return getAppDot(transport);

    case AppType.KSM:
      return getAppKsm(transport);

    case AppType.WND:
      return getAppWnd(transport);

    case AppType.NEAR:
      return getAppNear(transport);
  }
}

async function getAppEth(transport: Transport): Promise<AppEth> {
  try {
    const app = new AppEth(transport);
    await getLedgerAddress(app, AppType.ETH, 0);
    return app;
  } catch (error) {
    console.warn('Hana LedgerBridge', `Failed creating ${AppType.ETH} app.`, error);
    throw new Error(LedgerErrors.NoAddress);
  }
}

async function getAppIcx(transport: Transport): Promise<AppIcx> {
  try {
    const app = new AppIcx(transport);
    await getLedgerAddress(app, AppType.ICX, 0);
    return app;
  } catch (error) {
    console.warn('Hana LedgerBridge', `Failed creating ${AppType.ICX} app.`, error);
    throw new Error(LedgerErrors.NoAddress);
  }
}

async function getAppDot(transport: Transport): Promise<SubstrateApp> {
  try {
    const app = newPolkadotApp(transport);
    await getLedgerAddress(app, AppType.DOT, 0);
    return app;
  } catch (error) {
    console.warn('Hana LedgerBridge', `Failed creating ${AppType.DOT} app.`, error);
    throw new Error(LedgerErrors.NoAddress);
  }
}

async function getAppKsm(transport: Transport): Promise<SubstrateApp> {
  try {
    const app = newKusamaApp(transport);
    await getLedgerAddress(app, AppType.KSM, 0);
    return app;
  } catch (error) {
    console.warn('Hana LedgerBridge', `Failed creating ${AppType.KSM} app.`, error);
    throw new Error(LedgerErrors.NoAddress);
  }
}

async function getAppWnd(transport: Transport): Promise<SubstrateApp> {
  try {
    const app = newKusamaApp(transport);
    await getLedgerAddress(app, AppType.WND, 0);
    return app;
  } catch (error) {
    console.warn('Hana LedgerBridge', `Failed creating ${AppType.WND} app.`, error);
    throw new Error(LedgerErrors.NoAddress);
  }
}

async function getAppNear(transport: Transport): Promise<NearApp> {
  try {
    const app = await createClient(transport);
    await getLedgerAddress(app, AppType.NEAR, 0);
    return app;
  } catch (error) {
    console.warn('Hana LedgerBridge', `Failed creating ${AppType.NEAR} app.`, error);
    throw new Error(LedgerErrors.NoAddress);
  }
}

async function getLedgerAddress(
  app: AppEth | AppIcx | SubstrateApp | NearApp,
  appType: AppType,
  index: number
): Promise<LedgerAddress> {
  const hdPath = getAddressPath(appType, index);
  switch (appType) {
    case AppType.ETH:
      let { address: ethAddress } = await (app as AppEth).getAddress(hdPath, false, true);
      return { index, hdPath, address: ethAddress };

    case AppType.ICX:
      let { address: icxAddress } = await (app as AppIcx).getAddress(hdPath, false, true);
      return { index, hdPath, address: icxAddress.toString() };

    case AppType.DOT:
    case AppType.KSM:
    case AppType.WND:
      if (!_Keyring) {
        throw new Error('No Keyring available');
      }

      const keyring: Keyring = new _Keyring();

      let { address: dotAddress } = await (app as SubstrateApp).getAddress(
        LEDGER_DEFAULT_DOT_ACCOUNT,
        LEDGER_DEFAULT_DOT_CHANGE,
        LEDGER_DEFAULT_DOT_INDEX + index
      );

      if (appType === AppType.WND) {
        return { index, hdPath, address: keyring.encodeAddress(dotAddress, WND_SS58_DECIMAL) };
      }

      return { index, hdPath, address: dotAddress };

    case AppType.NEAR:
      let nearAddress = await (app as NearApp).getPublicKey(hdPath);
      return { index, hdPath, address: nearAddress.toString('hex') };
  }
}

function getAddressPath(appType: AppType, index: number): string {
  const basePath = getBasePath(appType);

  if (appType === AppType.DOT || appType === AppType.KSM || appType === AppType.WND) {
    return `${basePath.replace('account', String(index))}`;
  }

  let addressPath = `${basePath}/${index}`;

  if (appType === AppType.ICX || appType === AppType.NEAR) addressPath += `'`;

  return addressPath;
}

function getBasePath(appType: AppType): string {
  switch (appType) {
    case AppType.ETH:
      return BASE_PATHS.ETH;

    case AppType.ICX:
      return BASE_PATHS.ICX;

    case AppType.DOT:
    case AppType.WND:
      return BASE_PATHS.DOT;

    case AppType.KSM:
      return BASE_PATHS.KSM;

    case AppType.NEAR:
      return BASE_PATHS.NEAR;
  }
}

export async function signTransaction(
  app: AppEth | AppIcx | SubstrateApp | NearApp,
  appType: AppType,
  fromAddress: LedgerAddress,
  serializedTx: any,
  toAddress?: string
): Promise<EthSignature | string> {
  const { hdPath, index } = fromAddress;

  if (appType === AppType.ETH && !isNil(toAddress)) {
    const tokenInfo = byContractAddressAndChainId(toAddress, 1); // TODO Chain ID
    if (!isNil(tokenInfo)) await (app as AppEth).provideERC20TokenInformation(tokenInfo);
  }

  switch (appType) {
    case AppType.ETH:
      const ethResponse: EthSignature = await (app as AppEth).signTransaction(hdPath, serializedTx);
      return {
        v: `0x${ethResponse.v}`,
        r: `0x${ethResponse.r}`,
        s: `0x${ethResponse.s}`,
      };

    case AppType.ICX:
      const icxResponse = await (app as AppIcx).signTransaction(hdPath, serializedTx);
      return icxResponse.signedRawTxBase64;

    case AppType.DOT:
    case AppType.KSM:
    case AppType.WND:
      const dotResponse = await (app as SubstrateApp).sign(
        LEDGER_DEFAULT_DOT_ACCOUNT,
        LEDGER_DEFAULT_DOT_CHANGE,
        LEDGER_DEFAULT_DOT_INDEX + index,
        Buffer.from(serializedTx, 'hex')
      );
      return dotResponse.signature.toString('hex');

    case AppType.NEAR:
      const nearResponse = await (app as NearApp).sign(serializedTx, hdPath);
      return nearResponse.toString('hex');
  }
}

export async function signMessage(
  app: AppEth | AppIcx | SubstrateApp | NearApp,
  appType: AppType,
  fromAddress: LedgerAddress,
  message: string
): Promise<string | undefined> {
  const { hdPath, index } = fromAddress;

  if (/^0x/.test(message)) message = message.slice(2);

  console.debug('dataToSign: ', message);

  if (appType === AppType.ETH) {
    const result = await (app as AppEth).signPersonalMessage(hdPath, message);

    const v = result['v'] - 27;
    let vString = v.toString(16);
    if (vString.length < 2) {
      vString = '0' + v;
    }

    const signature = `0x${result.r}${result.s}${vString}`;

    return signature;
  }

  // TODO for ICX and Polkadot?

  return undefined;
}

export function appTypeForChainID(chainID: ChainID) {
  switch (chainID) {
    case ChainID.Ethereum:
    case ChainID.Binance:
    case ChainID.Moonbeam:
    case ChainID.Moonriver:
      return AppType.ETH;
    case ChainID.ICON:
      return AppType.ICX;
    case ChainID.Polkadot:
      return AppType.DOT;
    case ChainID.Kusama:
      return AppType.KSM;
    case ChainID.Westend:
      return AppType.WND;
    case ChainID.NEAR:
      return AppType.NEAR;

    default:
      return undefined;
  }
}

export function getLedgerAppName(chainId: ChainID) {
  switch (chainId) {
    case ChainID.ICON:
      return 'ICON';

    case ChainID.Ethereum:
    case ChainID.Moonbeam:
    case ChainID.Moonriver:
    case ChainID.Binance:
    case ChainID.Harmony:
    case ChainID.Arctic_EVM:
    case ChainID.SNOW_EVM:
    case ChainID.Astar_EVM:
    case ChainID.Shiden_EVM:
      return 'Ethereum';

    case ChainID.Polkadot:
      return 'Polkadot';

    case ChainID.Kusama:
    case ChainID.Westend:
      return 'Kusama';

    case ChainID.Arctic:
    case ChainID.SNOW:
    case ChainID.Astar:
    case ChainID.Shiden:
      return ''; // TODO
  }
}

export function initialIndexForChainID(chainID: ChainID) {
  switch (chainID) {
    case ChainID.NEAR: // NOTE: Default NEAR wallet starts from 1
      return 1;
    default:
      return 0;
  }
}
