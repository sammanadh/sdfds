import { NativeModules } from 'react-native';
import { Aes as AesType } from 'react-native-aes-crypto';
const Aes: typeof AesType = NativeModules.Aes;

const ALGORITHM: AesType.Algorithms = 'aes-256-cbc';
const HASH_ITERATIONS = 5000;
const HASH_KEY_LENGTH = 256;
const RANDOM_KEY_LENGTH = 32;
const IV_LENGTH = 16;

interface Payload {
  cipher: string;
  iv: string;
  salt: string;
}

export async function encrypt(passcode: string, data: string) {
  const salt = await generateRandomKey();
  const derivedKey = await hash(passcode, salt);
  const iv = await generateRandomKey(IV_LENGTH);
  const cipher = await Aes.encrypt(data, derivedKey, iv, ALGORITHM);
  const payload: Payload = { cipher, iv, salt };
  return JSON.stringify(payload);
}

export async function decrypt(passcode: string, encryptedData: string) {
  const payload = JSON.parse(encryptedData) as Payload;
  const derivedKey = await hash(passcode, payload.salt);
  return Aes.decrypt(payload.cipher, derivedKey, payload.iv, ALGORITHM);
}

export async function hash(passcode: string, salt: string) {
  return Aes.pbkdf2(passcode, salt, HASH_ITERATIONS, HASH_KEY_LENGTH);
}

export async function generateRandomKey(length = RANDOM_KEY_LENGTH) {
  return Aes.randomKey(length);
}

export function encodeKey(key: string) {
  const encoder = new TextEncoder();
  return encoder.encode(key);
}

export function decodeKey(key: Uint8Array) {
  const decoder = new TextDecoder();
  return decoder.decode(key);
}
