import { ChainWallet } from '@/models/Vault';
import { CoinType } from '@/utils/coinTypes';
import { isEmpty } from 'lodash-es';

/**
 * Should match up to an implemented chain service
 * E.g. EVM compatible chains should use ChainService.ETH
 */
export enum ChainServiceType {
  ICON = 'ICON',
  Ethereum = 'Ethereum',
  Polkadot = 'Polkadot',
  NEAR = 'NEAR',
}

export enum ChainID {
  ICON = 'ICON',
  HAVAH = 'HAVAH',
  Arctic_EVM = 'Arctic_EVM',
  Arctic = 'Arctic',
  SNOW = 'SNOW',
  SNOW_EVM = 'SNOW_EVM',
  Ethereum = 'Ethereum',
  Polkadot = 'Polkadot',
  Kusama = 'Kusama',
  Westend = 'Westend',
  Moonbeam = 'Moonbeam',
  Moonriver = 'Moonriver',
  Binance = 'Binance',
  NEAR = 'NEAR',
  Harmony = 'Harmony',
  Wanchain = 'Wanchain',
  Avalanche = 'Avalanche',
  Polygon = 'Polygon',
  Arbitrum = 'Arbitrum',
  Optimism = 'Optimism',
  Astar = 'Astar',
  Astar_EVM = 'Astar EVM',
  Shiden = 'Shiden',
  Shiden_EVM = 'Shiden EVM',
  Shibuya = 'Shibuya',
  Shibuya_EVM = 'Shibuya EVM',
}

export enum TokenType {
  Contract = 'Contract',
  Asset = 'Asset',
}

export interface NativeToken {
  chainId: ChainID;
  name: string;
  symbol: string;
  decimals: number;
  coinId?: string; // this should be a CoinGecko coin ID (https://api.coingecko.com/api/v3/coins/list)
}

export const MORALIS_CHAIN_IDS: PartialRecord<ChainID, string> = {
  [ChainID.Ethereum]: 'eth',
  [ChainID.Polygon]: 'polygon',
  [ChainID.Avalanche]: 'avalanche',
  [ChainID.Arbitrum]: 'arbitrum',
  [ChainID.Binance]: 'bsc',
};

export interface ChainDetails {
  id: ChainID;
  name: string;
  coinType: CoinType;
  service: ChainServiceType;
  token: NativeToken;
  tags?: string; // Extra strings used for searching
  enabled: boolean; // Allows disabling certain chains that are not supported or under development i.e. Polkadot/Kusama
  isTestnet?: boolean;
  hasCollectables?: boolean;
  tokenType?: TokenType;
  affiliatedChainID?: ChainID;
  canSetGasPrice?: boolean;
  supportsLedger?: boolean;
}

/**
 * These are the chains as can be enabled/disabled by users
 */
export const chains: Array<ChainDetails> = [
  {
    id: ChainID.ICON,
    name: 'ICON',
    coinType: CoinType.ICX,
    service: ChainServiceType.ICON,
    token: {
      chainId: ChainID.ICON,
      name: 'ICON',
      symbol: 'ICX',
      decimals: 18,
      coinId: 'icon',
    },
    enabled: true,
    hasCollectables: true,
    tokenType: TokenType.Contract,
  },
  // {
  //   id: ChainID.HAVAH,
  //   name: 'HAVAH',
  //   coinType: CoinType.HVH,
  //   service: ChainServiceType.ICON,
  //   token: {
  //     chainId: ChainID.HAVAH,
  //     name: 'HAVAH',
  //     symbol: 'HVH',
  //     decimals: 18,
  //   },
  //   enabled: true,
  //   hasCollectables: true,
  //   tokenType: TokenType.Contract,
  //   supportsLedger: false,
  // },
  {
    id: ChainID.Ethereum,
    name: 'Ethereum',
    coinType: CoinType.ETH,
    service: ChainServiceType.Ethereum,
    token: {
      chainId: ChainID.Ethereum,
      name: 'Ethereum',
      symbol: 'ETH',
      decimals: 18,
      coinId: 'ethereum',
    },
    enabled: true,
    hasCollectables: true,
    tokenType: TokenType.Contract,
    canSetGasPrice: true,
  },
  // {
  //   id: ChainID.Arctic,
  //   name: 'Arctic',
  //   coinType: CoinType.DOT,
  //   service: ChainServiceType.Polkadot,
  //   token: {
  //     chainId: ChainID.Arctic,
  //     name: 'Arctic',
  //     symbol: 'ICZ',
  //     decimals: 18,
  //   },
  //   enabled: true,
  //   isTestnet: true,
  //   tokenType: TokenType.Asset,
  // },
  // {
  //   id: ChainID.Arctic_EVM,
  //   name: 'Arctic EVM',
  //   coinType: CoinType.ETH,
  //   service: ChainServiceType.Ethereum,
  //   token: {
  //     chainId: ChainID.Arctic_EVM,
  //     name: 'Arctic EVM',
  //     symbol: 'ICZ',
  //     decimals: 18,
  //   },
  //   enabled: true,
  //   hasCollectables: true,
  //   tokenType: TokenType.Contract,
  //   affiliatedChainID: ChainID.Arctic,
  //   isTestnet: true,
  // },
  // {
  //   id: ChainID.SNOW,
  //   name: 'Snow',
  //   coinType: CoinType.DOT,
  //   service: ChainServiceType.Polkadot,
  //   token: {
  //     chainId: ChainID.SNOW,
  //     name: 'SNOW',
  //     symbol: 'ICZ',
  //     decimals: 18,
  //   },
  //   enabled: true,
  //   tokenType: TokenType.Asset,
  //   supportsLedger: false,
  // },
  // {
  //   id: ChainID.SNOW_EVM,
  //   name: 'SNOW EVM',
  //   coinType: CoinType.ETH,
  //   service: ChainServiceType.Ethereum,
  //   token: {
  //     chainId: ChainID.SNOW_EVM,
  //     name: 'SNOW EVM',
  //     symbol: 'ICZ',
  //     decimals: 18,
  //   },
  //   tags: 'BSC',
  //   enabled: true,
  //   hasCollectables: true,
  //   tokenType: TokenType.Contract,
  //   affiliatedChainID: ChainID.SNOW,
  // },
  {
    id: ChainID.Binance,
    name: 'Binance (BSC)',
    coinType: CoinType.ETH,
    service: ChainServiceType.Ethereum,
    token: {
      chainId: ChainID.Binance,
      name: 'Binance Smart Chain',
      symbol: 'BNB',
      decimals: 18,
      coinId: 'binancecoin',
    },
    enabled: true,
    hasCollectables: true,
    tokenType: TokenType.Contract,
  },
  // {
  //   id: ChainID.Wanchain,
  //   name: 'Wanchain',
  //   coinType: CoinType.ETH,
  //   service: ChainServiceType.Ethereum,
  //   token: {
  //     chainId: ChainID.Wanchain,
  //     name: 'Wanchain',
  //     symbol: 'WAN',
  //     decimals: 18,
  //     coinId: 'wanchain',
  //   },
  //   enabled: true,
  //   tokenType: TokenType.Contract,
  // },
  {
    id: ChainID.Avalanche,
    name: 'Avalanche',
    coinType: CoinType.ETH,
    service: ChainServiceType.Ethereum,
    token: {
      chainId: ChainID.Avalanche,
      name: 'Avalanche',
      symbol: 'AVAXC',
      decimals: 18,
      coinId: 'avalanche-2',
    },
    enabled: true,
    hasCollectables: true,
    tokenType: TokenType.Contract,
  },
  {
    id: ChainID.Polygon,
    name: 'Polygon',
    coinType: CoinType.ETH,
    service: ChainServiceType.Ethereum,
    token: {
      chainId: ChainID.Polygon,
      name: 'Polygon',
      symbol: 'MATIC',
      decimals: 18,
      coinId: 'matic-network',
    },
    enabled: true,
    hasCollectables: true,
    tokenType: TokenType.Contract,
  },
  {
    id: ChainID.Arbitrum,
    name: 'Arbitrum',
    coinType: CoinType.ETH,
    service: ChainServiceType.Ethereum,
    token: {
      chainId: ChainID.Arbitrum,
      name: 'Arbitrum',
      symbol: 'ETH',
      decimals: 18,
    },
    enabled: true,
    hasCollectables: true,
    tokenType: TokenType.Contract,
  },
  {
    id: ChainID.Optimism,
    name: 'Optimism',
    coinType: CoinType.ETH,
    service: ChainServiceType.Ethereum,
    token: {
      chainId: ChainID.Optimism,
      name: 'Optimism',
      symbol: 'ETH',
      decimals: 18,
    },
    enabled: true,
    tokenType: TokenType.Contract,
  },
  // {
  //   id: ChainID.Kusama,
  //   name: 'Kusama',
  //   coinType: CoinType.KSM,
  //   service: ChainServiceType.Polkadot,
  //   token: {
  //     chainId: ChainID.Kusama,
  //     name: 'Kusama',
  //     symbol: 'KSM',
  //     decimals: 12,
  //     coinId: 'kusama',
  //   },
  //   enabled: true,
  // },
  {
    id: ChainID.Moonbeam,
    name: 'Moonbeam',
    coinType: CoinType.ETH,
    service: ChainServiceType.Ethereum,
    token: {
      chainId: ChainID.Moonbeam,
      name: 'Moonbeam',
      symbol: 'GLMR',
      decimals: 18,
      coinId: 'moonbeam',
    },
    enabled: true,
    tokenType: TokenType.Contract,
  },
  {
    id: ChainID.Moonriver,
    name: 'Moonriver',
    coinType: CoinType.ETH,
    service: ChainServiceType.Ethereum,
    token: {
      chainId: ChainID.Moonriver,
      name: 'Moonriver',
      symbol: 'MOVR',
      decimals: 18,
      coinId: 'moonriver',
    },
    enabled: true,
    tokenType: TokenType.Contract,
  },
  // {
  //   id: ChainID.Polkadot,
  //   name: 'Polkadot',
  //   coinType: CoinType.DOT,
  //   service: ChainServiceType.Polkadot,
  //   token: {
  //     chainId: ChainID.Polkadot,
  //     name: 'Polkadot',
  //     symbol: 'DOT',
  //     decimals: 10,
  //     coinId: 'polkadot',
  //   },
  //   enabled: true,
  // },
  {
    id: ChainID.Westend,
    name: 'Westend',
    coinType: CoinType.DOT,
    service: ChainServiceType.Polkadot,
    token: { chainId: ChainID.Westend, name: 'Westies', symbol: 'WND', decimals: 12 },
    enabled: true,
    isTestnet: true,
  },
  // {
  //   id: ChainID.NEAR,
  //   name: 'NEAR',
  //   coinType: CoinType.NEAR,
  //   service: ChainServiceType.NEAR,
  //   token: {
  //     chainId: ChainID.NEAR,
  //     name: 'NEAR',
  //     symbol: 'NEAR',
  //     decimals: 18,
  //     coinId: 'near',
  //   },
  //   enabled: false,
  //   tokenType: TokenType.Contract,
  //   isTestnet: true, // TODO: Add mainnet later
  // },
  // {
  //   id: ChainID.Astar,
  //   name: 'Astar',
  //   coinType: CoinType.DOT,
  //   service: ChainServiceType.Polkadot,
  //   token: {
  //     chainId: ChainID.Astar,
  //     name: 'Astar',
  //     symbol: 'ASTR',
  //     decimals: 18,
  //   },
  //   enabled: true,
  //   tokenType: TokenType.Asset,
  //   supportsLedger: false,
  // },
  // {
  //   id: ChainID.Astar_EVM,
  //   name: 'Astar EVM',
  //   coinType: CoinType.ETH,
  //   service: ChainServiceType.Ethereum,
  //   token: {
  //     chainId: ChainID.Astar_EVM,
  //     name: 'Astar EVM',
  //     symbol: 'ASTR',
  //     decimals: 18,
  //   },
  //   tags: 'BSC',
  //   enabled: true,
  //   hasCollectables: false,
  //   tokenType: TokenType.Contract,
  //   affiliatedChainID: ChainID.Astar,
  // },
  // {
  //   id: ChainID.Shiden,
  //   name: 'Shiden',
  //   coinType: CoinType.DOT,
  //   service: ChainServiceType.Polkadot,
  //   token: {
  //     chainId: ChainID.Shiden,
  //     name: 'Shiden',
  //     symbol: 'SDN',
  //     decimals: 18,
  //   },
  //   enabled: true,
  //   tokenType: TokenType.Asset,
  //   supportsLedger: false,
  // },
  // {
  //   id: ChainID.Shiden_EVM,
  //   name: 'Shiden EVM',
  //   coinType: CoinType.ETH,
  //   service: ChainServiceType.Ethereum,
  //   token: {
  //     chainId: ChainID.Shiden_EVM,
  //     name: 'Shiden EVM',
  //     symbol: 'SDN',
  //     decimals: 18,
  //   },
  //   tags: 'BSC',
  //   enabled: true,
  //   hasCollectables: false,
  //   tokenType: TokenType.Contract,
  //   affiliatedChainID: ChainID.Shiden,
  // },
  // {
  //   id: ChainID.Shibuya,
  //   name: 'Shibuya',
  //   coinType: CoinType.DOT,
  //   service: ChainServiceType.Polkadot,
  //   token: {
  //     chainId: ChainID.Shibuya,
  //     name: 'Shibuya',
  //     symbol: 'SBY',
  //     decimals: 18,
  //   },
  //   enabled: true,
  //   isTestnet: true,
  //   tokenType: TokenType.Asset,
  // },
  // {
  //   id: ChainID.Shibuya_EVM,
  //   name: 'Shibuya EVM',
  //   coinType: CoinType.ETH,
  //   service: ChainServiceType.Ethereum,
  //   token: {
  //     chainId: ChainID.Shibuya_EVM,
  //     name: 'Shibuya EVM',
  //     symbol: 'SBY',
  //     decimals: 18,
  //   },
  //   enabled: true,
  //   hasCollectables: false,
  //   tokenType: TokenType.Contract,
  //   affiliatedChainID: ChainID.Shibuya,
  //   isTestnet: true,
  // },
  {
      id: ChainID.Harmony,
      name: 'Harmony',
      coinType: CoinType.ETH,
      service: ChainServiceType.Ethereum,
      token: {
        chainId: ChainID.Harmony,
        name: 'Harmony',
        symbol: 'ONE',
        decimals: 18,
        coinId: 'harmony',
      },
      enabled: true,
      tokenType: TokenType.Contract,
    },  
];

export const testnetChains = chains.filter((c) => c.isTestnet === true && c.enabled);
export const testnetChainIds = testnetChains.map((c) => c.id);

export function chainFilter(chain: ChainDetails, query: string) {
  const lowerQuery = query.toLowerCase();
  return (
    chain.name.toLowerCase().includes(lowerQuery) ||
    chain.token.symbol.toLowerCase().includes(lowerQuery) ||
    (!isEmpty(chain.tags) && chain.tags!.toLowerCase().includes(lowerQuery))
  );
}

export function chainForChainWallet(wallet: ChainWallet) {
  return chains.find((chain) => chain.id === wallet.type);
}

export function coinTypeForChainType(id: ChainID) {
  return chains.find((chain) => chain.id === id)?.coinType;
}

export function chainForChainID(id: ChainID) {
  return chains.find((chain) => chain.id === id);
}

// For Polkadot/Substrate based networks
export function getSS58Prefix(chainId: ChainID) {
  switch (chainId) {
    case ChainID.Polkadot:
      return 0;
    case ChainID.Kusama:
      return 2;
    case ChainID.Westend:
      return 42;
    case ChainID.Arctic:
      return 2208;
    case ChainID.SNOW:
      return 2207;
    case ChainID.Astar:
    case ChainID.Shiden:
    case ChainID.Shibuya:
      return 5;
  }

  return undefined;
}

export function isSubstrateChain(id: ChainID) {
  return (
    id === ChainID.Polkadot ||
    id === ChainID.Kusama ||
    id === ChainID.Westend ||
    id === ChainID.Arctic ||
    id === ChainID.SNOW ||
    id === ChainID.Astar ||
    id === ChainID.Shiden ||
    id === ChainID.Shibuya
  );
}

export function getSubstrateFeeRoundingDecimals(id: ChainID) {
  switch (id) {
    case ChainID.Polkadot:
    case ChainID.Westend:
      return 3;
    case ChainID.Arctic:
      return 1;
    case ChainID.SNOW:
      return 3; // TODO: Can actually be 3 when there are no assets in the account
    case ChainID.Kusama:
    case ChainID.Astar:
    case ChainID.Shiden:
    case ChainID.Shibuya:
      return 5;
    default:
      return 1;
  }
}

export function getTransactionUrlPath(chainId: ChainID) {
  const chain = chains.find((chain) => chain.id === chainId)!;
  switch (chain.coinType) {
    case CoinType.ICX:
      return '/transaction';

    case CoinType.HVH:
      return '/txn';

    case CoinType.ETH:
      return '/tx';

    case CoinType.DOT:
    case CoinType.KSM:
      return '/extrinsic';

    case CoinType.NEAR:
      return '/transactions';
  }
}

export function getGenesisHashForChain(chainId: ChainID) {
  if (!isSubstrateChain(chainId)) {
    throw new Error("Can't get genesis hash for non-substrate chain");
  }

  switch (chainId) {
    case ChainID.Polkadot:
      return '0x91b171bb158e2d3848fa23a9f1c25182fb8e20313b2c1eb49219da7a70ce90c3';
    case ChainID.Kusama:
      return '0xb0a8d493285c2df73290dfb7e61f870f17b41801197a149ca93654499ea3dafe';
    case ChainID.Westend:
      return '0xe143f23803ac50e8f6f8e62695d1ce9e4e1d68aa36c1cd2cfd15340213f3423e';
    case ChainID.Arctic:
      return '0x5c4207232d344710a176b1982471acf9b058f40b4a57470c25410b68b684c766';
    case ChainID.SNOW:
      return '0xb34f6cd03a41f0fab38ba9fd5b11cce5f303633c46f39f0c6fdc7c3c602bafa9';
    case ChainID.Astar:
      return '0x9eb76c5184c4ab8679d2d5d819fdf90b9c001403e9e17da2e14b6d8aec4029c6';
    case ChainID.Shiden:
      return '0xf1cf9022c7ebb34b162d5b5e34e705a5a740b2d0ecc1009fb89023e62a488108';
    case ChainID.Shibuya:
      return '0xddb89973361a170839f80f152d2e9e38a376a5a7eccefcade763f46a8e567019';
  }
}

export function isAffiliatedChain(chainId: ChainID) {
  return chains.find((c) => c.id === chainId)?.affiliatedChainID !== undefined;
}

export function isIconChain(chainId: ChainID) {
  return chainId === ChainID.ICON || chainId === ChainID.HAVAH;
}
