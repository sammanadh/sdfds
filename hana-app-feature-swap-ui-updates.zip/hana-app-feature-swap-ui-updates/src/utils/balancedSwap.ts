import { IconNetworkRef } from './networks';

export const BALANCED_CONFIG = {
  [IconNetworkRef.Mainnet]: {
    NETWORK_ID: 1,
    NETWORK_REF: IconNetworkRef.Mainnet,
    API_BASE: 'https://balanced.icon.community/api/v1',
    GET_TOKENS_PATH: '/tokens',
    HANA_WALLET_ROUTER: 'cxc7d2b2ea91af80d4535dbbee0318399d3aedb6b1',
    BALANCED_ROUTER_ADDRESS: 'cx21e94c08c03daee80c25d8ee3ea22a20786ec231',
    BALANCED_DEX_ADDRESS: 'cxa0af3165c08318e988cb30993b3048335b94af6c',
    BALANCED_MULTICALL_ADDRESS: 'cxa4aa9185e23558cff990f494c1fd2845f6cbf741',
    GET_POOL_STATS_BY_ID: 'getPoolStats',
    GET_SWAP_SERVICE_FEE: 'getFeePercentage',
    GET_POOL_STATS_BY_PAIR: 'getPoolStatsForPair',
    TRY_AGGREGATE: 'tryAggregate',
  },
  [IconNetworkRef.Lisbon]: {
    NETWORK_ID: 2,
    NETWORK_REF: IconNetworkRef.Lisbon,
    API_BASE: 'https://balanced.icon.community/api/v1',
    GET_TOKENS_PATH: '/tokens',
    HANA_WALLET_ROUTER: 'cxc7d2b2ea91af80d4535dbbee0318399d3aedb6b1',
    BALANCED_ROUTER_ADDRESS: 'cx21e94c08c03daee80c25d8ee3ea22a20786ec231',
    BALANCED_DEX_ADDRESS: 'cxa0af3165c08318e988cb30993b3048335b94af6c',
    BALANCED_MULTICALL_ADDRESS: 'cxa4aa9185e23558cff990f494c1fd2845f6cbf741',
    GET_POOL_STATS_BY_ID: 'getPoolStats',
    GET_SWAP_SERVICE_FEE: 'getFeePercentage',
    GET_POOL_STATS_BY_PAIR: 'getPoolStatsForPair',
    TRY_AGGREGATE: 'tryAggregate',
  },
};

export const ICX_CONTRACT = 'cx0000000000000000000000000000000000000000';
export const ICX_CONTRACT_ALIAS = 'ICX';
export const SICX_ICX_POOL_ID = 1;
export const BALANCED_GENERAL_SWAP_FEE = 0.003;
export const BALANCED_ICX_SWAP_FEE = 0.01;
export const BALANCED_SWAP_SLIPPAGE = 0.01;

export const BALANCED_BRIDGED_TOKENS = ['BUSD', 'ETH', 'BTCB'];

export const POOL_DATA_REFRESH_PERIOD = 20_000;
export const CALL_AGGREGATE_CHUNK_SIZE = 20;

export interface TokensListResponse {
  chain_id: number;
  name: string;
  symbol: string;
  address: string;
  decimals: number;
  type: 'balanced' | 'community';
  pools: Array<number>;
}

export interface PoolDetailsResponse {
  base: string;
  base_decimals: string;
  base_token: string;
  price: string;
  quote: string;
  quote_decimals: string;
  quote_token: string;
  name?: string;
}

export interface MultiPoolDetailsResponse {
  returnData: Array<{ returnData: PoolDetailsResponse }>;
}
