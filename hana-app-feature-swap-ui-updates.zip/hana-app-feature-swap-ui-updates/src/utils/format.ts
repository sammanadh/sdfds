import { BigNumber } from '@/utils/bignumber';
import { gt, isEmpty, trimEnd, truncate } from 'lodash-es';
import { Dimensions, Platform } from 'react-native';

const { width, height } = Dimensions.get('window');

export function formatAddress(address: string, start = 8, end = 8): string {
  return `${address.slice(0, start)}…${address.slice(-end)}`;
}

export function formatNumber(
  value: BigNumber.Value,
  decimalPlaces = 0,
  trimZeros = true,
  roundingMode: BigNumber.RoundingMode = BigNumber.ROUND_FLOOR
): string {
  const bigValue = new BigNumber(value);
  if (bigValue.isInteger()) return bigValue.toFormat(undefined);

  const minimumValue = new BigNumber(`0.${'0'.repeat(decimalPlaces)}1`);
  if (bigValue.absoluteValue().isLessThan(minimumValue)) return '0';

  const formatted = bigValue.toFormat(decimalPlaces, roundingMode);
  if (!trimZeros || decimalPlaces === 0) return formatted;

  const [integer, decimals] = formatted.split('.');
  return `${integer}.${trimEnd(decimals, '0').padEnd(1, '0')}`;
}

export function formatPrice(price: BigNumber.Value, withPrefix: Boolean = true): string {
  return `$${formatNumber(price, 2, false, BigNumber.ROUND_UP)}${withPrefix ? ' USD' : ''}`;
}

export function formatLargeNumber(value: BigNumber.Value): string {
  const bigValue = new BigNumber(value);
  const absoluteValue = bigValue.absoluteValue();

  if (absoluteValue.isGreaterThan(500000000)) {
    return formatNumber(bigValue.shiftedBy(-9), 1) + 'B';
  }
  if (absoluteValue.isGreaterThan(500000)) {
    return formatNumber(bigValue.shiftedBy(-6), 1) + 'M';
  }
  if (absoluteValue.isGreaterThan(500)) {
    return formatNumber(bigValue.shiftedBy(-3), 1) + 'K';
  }

  return formatNumber(bigValue);
}

export function formatAmount(value: BigNumber.Value): string {
  const bigValue = new BigNumber(value);
  return formatNumber(bigValue, bigValue.absoluteValue().isGreaterThanOrEqualTo(10) ? 2 : 5);
}

export function formatCurrency(value: BigNumber.Value, includeDecimals = true): string {
  const bigValue = new BigNumber(value);
  const sign = bigValue.lt(0) ? '-' : '';
  const symbol = '$';
  return (
    sign +
    symbol +
    formatNumber(bigValue.absoluteValue(), includeDecimals ? 2 : 0, false, BigNumber.ROUND_HALF_UP)
  );
}

export function convertAndFormatCurrency(value: BigNumber.Value, price: BigNumber.Value): string {
  const bigValue = new BigNumber(value);
  const bigPrice = new BigNumber(price);
  if (!bigValue.isFinite() || !bigPrice.isFinite()) return '';

  return formatCurrency(bigValue.times(bigPrice));
}

export function formatPixel(pixel: number = 12, type?: 'wWidth' | 'wHeight') {
  // TODO: review this, for now using on Android only
  if (Platform.OS === 'ios') return pixel;

  const currentWidth = 375;
  const currentHeight = 812;
  const deviceWidth = width;
  const deviceHeight = height;

  const scaleWidth = deviceWidth / currentWidth;
  const scaleHeight = deviceHeight / currentHeight;

  const scale = Math.min(scaleWidth, scaleHeight);

  if (type === 'wWidth') {
    return Math.ceil(scaleWidth * pixel);
  }
  if (type === 'wHeight') {
    return Math.ceil(scaleHeight * pixel);
  }
  return Math.ceil(scale * pixel);
}

export function formatInitials(name: string, take: number = 3): string {
  if (isEmpty(name)) return '';

  const initials = name
    .replace(/\([^\)]*\)/g, '') // Remove anything in brackets
    .replace(/[^\w\s]/g, '') // Remove anything that's not a "word" character or space
    .split(/\s+/) // Split words on spaces
    .map((namePart) => namePart[0]) // Take the first character
    .join('')
    .toUpperCase();

  const length = initials.length;

  if (gt(take, 1) && length === 1) {
    // Return truncation of first word for 1-word names
    return truncate(name, { length: take, omission: '' }).toUpperCase();
  } else {
    // Return truncation of initials
    return gt(length, take) ? truncate(initials, { length: take, omission: '' }) : initials;
  }
}
