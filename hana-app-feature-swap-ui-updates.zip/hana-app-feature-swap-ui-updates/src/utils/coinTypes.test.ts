import { CoinType, getCoinHDPath } from './coinTypes';

describe('getCoinHDPath', () => {
  test.each([
    [CoinType.ETH, 0, `m/44'/60'/0'/0/0`],
    [CoinType.ICX, 1, `m/44'/74'/0'/0/1`],
    [CoinType.HVH, 2, `m/44'/858'/0'/0/2`],
    [CoinType.DOT, 99, `m/44'/354'/0'/0/99`],
    [CoinType.KSM, 5, `m/44'/434'/0'/0/5`],
  ])('%s, %d returns %s', (coinType, index, expected) => {
    expect(getCoinHDPath(coinType, index)).toBe(expected);
  });
});
