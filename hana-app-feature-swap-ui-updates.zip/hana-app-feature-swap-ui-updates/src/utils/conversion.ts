import type { BigNumber } from '@/utils/bignumber';
import IconService from 'icon-sdk-js';

const { IconAmount, IconConverter } = IconService;

export function convertLoopToToken(
  value: BigNumber.Value,
  digits: BigNumber.Value = IconAmount.Unit.ICX
): BigNumber {
  return IconConverter.toBigNumber(
    IconAmount.of(value, IconAmount.Unit.LOOP).convertUnit(digits).value
  );
}

export function convertTokenToLoop(
  value: BigNumber.Value,
  digits: BigNumber.Value = IconAmount.Unit.ICX
) {
  return IconAmount.of(value, digits).toLoop();
}

/**
 * @param {number} icxValue
 * @param {number} usdtPrice
 * @returns {string} USD value of ICX
 */
export function convertIcxToUsdt(icxValue: BigNumber, usdtPrice: BigNumber) {
  return icxValue.multipliedBy(usdtPrice).toFixed(2);
}
