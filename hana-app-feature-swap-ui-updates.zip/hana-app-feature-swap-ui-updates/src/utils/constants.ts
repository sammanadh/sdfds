import { BigNumber } from '@/utils/bignumber';
import { Animated, ImageRequireSource, Insets } from 'react-native';

export const TRUE = 'true';
export const ZERO = new BigNumber(0);
export const ONE = new BigNumber(1);
export const TWO = new BigNumber(2);
export const TEN = new BigNumber(10);
export const WITHHOLD_BALANCE = ONE;

export const ICX_GOVERNANCE_ADDRESS = 'cx0000000000000000000000000000000000000001';
export const ICX_SCORE_INSTALL_ADDRESS = 'cx0000000000000000000000000000000000000000';
export const ICX_CONTRACT = ICX_SCORE_INSTALL_ADDRESS;
export const ICX_API_VERSION = 3;
export const ICX_CALL_TRANSACTION_STEP_COST = new BigNumber(1000000);

export const NEAR_SEND_NEAR_GAS = 450000000000;
export const NEAR_FT_MINIMUM_STORAGE_BALANCE = '1250000000000000000000';
export const NEAR_FT_MINIMUM_STORAGE_BALANCE_LARGE = '12500000000000000000000';
export const NEAR_FT_STORAGE_DEPOSIT_GAS = '30000000000000';
export const NEAR_FT_TRANSFER_GAS = '15000000000000';
export const NEAR_TOKEN_TRANSFER_DEPOSIT = '1';

export const MIN_ICX_FOR_TRANSACTION_FEE = new BigNumber(0.01);
export const DEFAULT_DOT_ESTIMATED_FEE = new BigNumber(0.02);
export const DEFAULT_ICZ_ESTIMATED_FEE = new BigNumber(1);
export const DEFAULT_DOT_ED = new BigNumber(1);

export const TX_STEP_BUFFER = new BigNumber(10000);

export const MNEMONIC_WORDS = 12;
export const PINCODE_LENGTH = 6;
export const NUMBER_OF_TRANSACTIONS = 100;

export const VALIDATE_PASSWORD_REGEXP =
  /^(?=.*\d)(?=.*[a-zA-Z])(?=.*[?!:;.,%+-/*=<>{}()[\]`"'~_^\\|@#$&]).{8,}$/;

export const MAX_SAFE_CHAIN_ID = new BigNumber(4503599627370476);

export enum STORAGE_KEY {
  ENCRYPTION_KEY = 'hana.encryption_key',
  MNEMONIC = 'hana.mnemonic',
  SEED_KEY = 'hana.seed_key',
  PRIVATE_KEY = 'hana.private_key',
  IMPORTED_WALLETS = 'hana.imported_wallets',

  ONBOARDING_FLAGS = 'hana.onboarding_flags',
  CONNECTED_CHAINS = 'hana.connected_chains',

  TESTNET = 'hana.testnet',
  CUSTOM_NETWORK = 'hana.custom_network',

  SUBSTRATE_KEY_DERIVATION_METHOD = 'hana.substrate_key_derivation_method',

  BIOMETRICS_ENABLED = 'hana.biometrics_enabled',
  THEME = 'hana.theme',
}

export enum SubstrateKeyDerivationMethod {
  MnemonicSr25519 = 'MnemonicSr25519',
  Bip44Ed25519 = 'Bip44Ed25519',
}

export enum REALM_PATH {
  VAULT = 'hana.vault',
}

export const ANIMATION_DEFAULTS: Animated.SpringAnimationConfig = {
  toValue: 0,
  bounciness: 0,
  useNativeDriver: true,
};

export const HIT_SLOP_XLARGE: Insets = { top: 15, right: 15, bottom: 15, left: 15 };
export const HIT_SLOP_LARGE: Insets = { top: 10, right: 10, bottom: 10, left: 10 };
export const HIT_SLOP_SMALL: Insets = { top: 5, right: 5, bottom: 5, left: 5 };

export enum JOURNEY {
  // Onboarding
  CREATE_SEED_PHRASE,
  IMPORT_SEED_PHRASE,
}

// Override "mainnet" in development
// export const ICON_MAINNET_ID = __DEV__ ? 83 : 1; // Sejong
// export const ETHEREUM_MAINNET_ID = __DEV__ ? 4 : 1; // Rinkeby

export const ICON_MAINNET_ID = 1;
export const ETHEREUM_MAINNET_ID = 1;

export const DAPP_LOGOS: Record<string, ImageRequireSource> = {
  'Balanced.png': require('@/assets/dapp-logos/Balanced.png'),
  'DAOblackjack.png': require('@/assets/dapp-logos/DAOblackjack.png'),
  'DAOdice.png': require('@/assets/dapp-logos/DAOdice.png'),
  'DAOlette.png': require('@/assets/dapp-logos/DAOlette.png'),
  'DAOlevels.png': require('@/assets/dapp-logos/DAOlevels.png'),
  'DAOlottery.png': require('@/assets/dapp-logos/DAOlottery.png'),
  'Epicx.png': require('@/assets/dapp-logos/Epicx.png'),
  'FutureICX.png': require('@/assets/dapp-logos/FutureICX.png'),
  'ICONswap.png': require('@/assets/dapp-logos/ICONswap.png'),
  'ICONvote.png': require('@/assets/dapp-logos/ICONvote.png'),
  'KeeKeeSocial.png': require('@/assets/dapp-logos/KeeKeeSocial.png'),
  'LiquidICX.png': require('@/assets/dapp-logos/LiquidICX.png'),
  'Lottery.png': require('@/assets/dapp-logos/Lottery.png'),
  'Marvelous.png': require('@/assets/dapp-logos/Marvelous.png'),
  'NFTBazaar.png': require('@/assets/dapp-logos/NFTBazaar.png'),
  'ProjectNebula.png': require('@/assets/dapp-logos/ProjectNebula.png'),
  'Stakin.png': require('@/assets/dapp-logos/Stakin.png'),
  'Unifi.png': require('@/assets/dapp-logos/Unifi.png'),
  'logo-iconbet.png': require('@/assets/dapp-logos/logo-iconbet.png'),
  'logo-iconpreps.png': require('@/assets/dapp-logos/logo-iconpreps.png'),
};

export const MORALIS_API_URL = 'https://deep-index.moralis.io/api/v2';
export const MORALIS_API_KEY = process.env.MORALIS_API_KEY || 'test';