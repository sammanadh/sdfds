import { ModalProps } from '@/components/Modal';
import { useAltModal, useModal } from '@/stores/Modal';

export interface PresentModalProps {
  title: string;
  content: React.ReactNode;
  options?: ModalProps;
}

export function presentModal({ title, content, options }: PresentModalProps) {
  const { setModalTitle, setModalContent, setModalOpen, setModalOptions } = useModal.getState();

  setModalTitle(title);
  setModalContent(content);
  options && setModalOptions(options);
  setModalOpen(true);
}

export function dismissModal() {
  const { setModalOpen } = useModal.getState();
  setModalOpen(false);
}

export function presentAltModal({ title, content, options }: PresentModalProps) {
  const { setModalTitle, setModalContent, setModalOpen, setModalOptions } = useAltModal.getState();

  setModalTitle(title);
  setModalContent(content);
  options && setModalOptions(options);
  setModalOpen(true);
}

export function dismissAltModal() {
  const { setModalOpen } = useAltModal.getState();
  setModalOpen(false);
}
