import { BigNumber } from 'bignumber.js';

BigNumber.config({ ROUNDING_MODE: BigNumber.ROUND_FLOOR });

export function toNumber(number: BigNumber) {
  return Number(number.toPrecision(16, BigNumber.ROUND_FLOOR));
}

export { BigNumber };
