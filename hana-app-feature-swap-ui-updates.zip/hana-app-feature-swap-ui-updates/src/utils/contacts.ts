import { Contact, Wallet } from '@/models/Vault';
import { useVault } from '@/stores/Vault';
import { ChainID } from './chains';

export function getContacts() {
  const { realm } = useVault.getState();

  return realm?.objects<Contact>('Contact');
}

export function getContactsForChain(chain: ChainID) {
  const { realm } = useVault.getState();

  return realm?.objects<Contact>('Contact').filtered(`chain = '${chain}'`);
}

export interface TransactionContact {
  name: string | null;
  address: string;
}

export function findContactOrWallet(address: string, chainId: ChainID): TransactionContact {
  const { realm } = useVault.getState();

  let name = null;

  const contact = realm
    ?.objects<Contact>('Contact')
    .filtered(`address = '${address}' AND chain = '${chainId}'`);

  if (contact?.length) {
    name = contact[0].name;
  }

  const wallets = realm?.objects<Wallet>('Wallet');

  wallets?.forEach((wallet) => {
    wallet.chainWallets.forEach((chainWallet) => {
      if (chainWallet.address === address) {
        name = wallet.name;
      }
    });
  });

  return {
    name,
    address,
  };
}
