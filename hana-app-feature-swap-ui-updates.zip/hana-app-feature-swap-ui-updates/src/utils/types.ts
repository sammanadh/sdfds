import { CustomNetwork } from '@/models/Vault';
import { TestnetConfig } from './networks';

export function isTestnetConfig(
  network?: TestnetConfig | CustomNetwork | null
): network is TestnetConfig {
  return (
    (network as TestnetConfig)?.chainType !== undefined &&
    (network as TestnetConfig)?.ref !== undefined
  );
}

export function isCustomNetwork(
  network?: TestnetConfig | CustomNetwork | null
): network is CustomNetwork {
  return (
    (network as CustomNetwork)?.id !== undefined && (network as CustomNetwork)?.chain !== undefined
  );
}
