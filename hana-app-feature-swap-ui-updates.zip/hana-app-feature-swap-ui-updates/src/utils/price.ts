import { ChainWallet, Token } from '@/models/Vault';
import { usePrices } from '@/stores/Price';
import { useVault } from '@/stores/Vault';
import { BigNumber, toNumber } from '@/utils/bignumber';
import { chainForChainWallet } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import { tokensForChainWallet } from '@/utils/wallet';

export function getValueForNativeTokensInChainWallet(cw: ChainWallet) {
  const { getNativePrice } = usePrices.getState();
  const chain = chainForChainWallet(cw);

  if (chain) {
    const price = getNativePrice(chain);

    return price.multipliedBy(cw.balance);
  }

  return ZERO;
}

export function getValueForChainWallet(cw: ChainWallet) {
  const nativeTokensValue = getValueForNativeTokensInChainWallet(cw);
  const tokens = tokensForChainWallet(cw);

  const totalForTokens = tokens.reduce(
    (a, b) => a + toNumber(getValueForTokensInChainWallet(cw, b)),
    0
  );

  return nativeTokensValue.plus(totalForTokens);
}

export function getValueForTokensInChainWallet(cw: ChainWallet, token: Token) {
  const { getTokenPrice } = usePrices.getState();
  const chain = chainForChainWallet(cw);
  const balance = token.balances.find((b) => b.address === cw.address)?.balance || 0;

  if (chain && token.contract) {
    const price = getTokenPrice(token.contract);
    return price.multipliedBy(balance);
  }

  return ZERO;
}

export function getTotalValueForActiveWallet() {
  const { getActiveChainWallets } = useVault.getState();
  const activeChainWallets = getActiveChainWallets();

  const total = activeChainWallets.reduce((a, b) => a + toNumber(getValueForChainWallet(b)), 0);

  return total ? new BigNumber(total) : ZERO;
}
