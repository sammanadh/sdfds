import { Wallet } from '@/models/Vault';
import { mnemonicToSeedSync as bip39MnemonicToSeedSync } from 'bip39';
import bs58 from 'bs58';
import { derivePath } from 'ed25519-hd-key';
import { KeyPair } from 'near-api-js';
import nacl from 'tweetnacl';
import { CoinType, getCoinHDPath } from './coinTypes';

export function getKeypairForWallet(wallet: Wallet, mnemonic: string) {
  const hexSeed = bip39MnemonicToSeedSync(mnemonic).toString('hex');
  const hdPath = getCoinHDPath(CoinType.NEAR, wallet.hdIndex!);
  const { key } = derivePath(hdPath, hexSeed);
  const naclKeyPair = nacl.sign.keyPair.fromSeed(key);

  const secretKey = 'ed25519:' + bs58.encode(Buffer.from(naclKeyPair.secretKey));

  const keyPair = KeyPair.fromString(secretKey);
  return keyPair;
}

const is64CharactersHexString = (value: string): boolean => /^[0-9a-fA-F]{64}$/.test(value);

export function isValidNearAddress(address: string) {
  const isImplicitAccount = is64CharactersHexString(address);
  const isAccountId = /^(([a-z\d]+[\-_])*[a-z\d]+\.)*([a-z\d]+[\-_])*[a-z\d]+$/.test(address);

  return isImplicitAccount || isAccountId;
}
