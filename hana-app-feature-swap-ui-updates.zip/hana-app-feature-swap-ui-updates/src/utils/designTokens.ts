export const palette = {
  white: '#ffffff',
  black: '#16073a',
  primary: '#3308a8',
  offPurple: '#d4c5f9',
  gray: {
    cards: '#f4f2f9',
    watermark: '#b9b5c3',
    meta: '#736b88',
  },
  positive: '#bcfbe3',
  negative: '#fbbccf',
  negativeDarker: '#f66994',
  chains: {
    ICON: '#1aaaba',
    Ethereum: '#5e79e3',
    Polkadot: '#e6007a',
    Kusama: 'rgb(230, 0, 122)',
    Moonbeam: '#0d1126',
    Moonriver: '#0e122f',
    Binance: 'rgb(240, 185, 11)',
    Harmony: '#00aee9',
    Arctic: '#2b23b4',
    Arctic_EVM: '#ffffff',
    SNOW: '#2b23b4',
    SNOW_EVM: '#ffffff',
  },
};

export const paletteDark = {
  blacker: '#0d0229',
  primary: '#4d1fcd',
  offPurple: '#ac95e5',
  foreground: `${palette.white}e6`, // white * 0.9
  cards: '#1f133f',
  divider: '#2c1b57',
};

export const colors = {
  ...palette,
  background: palette.white,
  foreground: palette.black,
  foregroundMuted: palette.gray.meta,
  foregroundHighlight: palette.primary,
  cards: palette.gray.cards,
  divider: palette.gray.cards,

  // TODO: remove these
  whiteSecond: 'rgba(255, 255, 255, 0.9)',
  red: '#db2721',
  green: '#4fb83b',
  yellow: '#f5f9c5',
  brand: {
    primary: '#5c6ac4',
    dark: '#1c2260',
    light: '#eef0fa',
  },
  gray: {
    ...palette.gray,
    background: '#f4f6f8',
    border: '#e7e9eb',
    placeholder: 'rgba(16, 15, 16, 0.25)',
    altHeading: '#9398ac',
    inactive: '#cbced4',
    breakLineDarkMode: 'rgba(44, 27, 87, 1.0)',
    subTitleDarkMode: 'rgb(185, 181, 195)',
    subTitleLightMode: 'rgb(115, 107, 136)',
  },
  shadow: '#121317',
  purple: {
    light: '#e9e1f9',
    dark: '#4300cc',
    darkOff: paletteDark.offPurple,
    darkPrimary: paletteDark.primary,
    darkBlack: palette.black,
    darkBlacker: paletteDark.blacker,
  },
};

export const fontAssets = {
  'Agrandir GrandHeavy': require('@/assets/fonts/PPAgrandir-GrandHeavy.otf'),
  'Proxima Nova regular': require('@/assets/fonts/ProximaNova-Regular.otf'),
  'Proxima Nova semi bold': require('@/assets/fonts/ProximaNova-SemiBold.otf'),
};

interface FontStyles {
  regular: string;
  semiBold: string;
  heavy: string;
}

/**
 * Regular: 400
 * Semi bold: 600
 * Heavy: 800
 */
export const fonts: FontStyles = {
  regular: 'Proxima Nova regular',
  semiBold: 'Proxima Nova semi bold',
  heavy: 'Agrandir GrandHeavy',
};
