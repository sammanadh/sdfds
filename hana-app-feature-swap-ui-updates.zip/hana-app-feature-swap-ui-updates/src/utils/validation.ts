import { BigNumber } from '@/utils/bignumber';
import { MAX_SAFE_CHAIN_ID } from '@/utils/constants';

type Protocols = 'web' | 'provider' | Array<string>;

const webProtocols = ['http:', 'https:'];
const providerProtocols = [...webProtocols, 'wss:'];

export function isValidUrl(input: string, allowedProtocols: Protocols = 'web') {
  try {
    const url = new URL(input);
    const { protocol } = url;

    const protocols =
      allowedProtocols === 'web'
        ? webProtocols
        : allowedProtocols === 'provider'
        ? providerProtocols
        : allowedProtocols;
    return protocols.includes(protocol);
  } catch (_error) {
    return false;
  }
}

const validSymbolRegExp = /^[A-Z0-9]{2,7}$/i;

export function isValidSymbol(input: string) {
  return validSymbolRegExp.test(input);
}

export function isValidNetworkId(input: string) {
  const value = new BigNumber(input);
  return value.isInteger() && value.isPositive() && value.lte(MAX_SAFE_CHAIN_ID);
}

export function isValidPositiveNum(input: string) {
  return /^[+-]?((\d+\.?\d*)|(\.\d+))$/.test(input);
}