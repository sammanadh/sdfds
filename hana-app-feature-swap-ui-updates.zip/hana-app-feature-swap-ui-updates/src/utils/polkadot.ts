import { ChainWallet, Wallet } from '@/models/Vault';
import { useVault } from '@/stores/Vault';
import { isNil } from 'lodash-es';
import { ChainID } from './chains';

import type { Keyring } from '@polkadot/keyring';
import { cryptoWaitReady, evmToAddress } from '@polkadot/util-crypto';

let _Keyring: typeof Keyring | undefined = undefined;

cryptoWaitReady().then(() => {
  import('@polkadot/keyring').then((keyring) => {
    _Keyring = keyring.Keyring;
  });
});

export function getChainWalletForPolkadotSignerWallet(address: string): ChainWallet | undefined {
  if (!_Keyring) {
    throw new Error('No Keyring available');
  }

  const keyring: Keyring = new _Keyring();

  const { getActiveWallet } = useVault.getState();
  const activeWallet = getActiveWallet();

  if (!activeWallet) {
    throw new Error('No wallet available');
  }

  const signerSubstrateAddress = keyring.encodeAddress(address, 42);

  let signerChainWallet: ChainWallet | undefined = undefined;

  const chainIDs = [ChainID.Polkadot, ChainID.Kusama, ChainID.Westend];
  chainIDs.forEach((chainID) => {
    const chainWallet = activeWallet.chainWallets.find((w) => w.type === chainID);
    if (!isNil(chainWallet)) {
      const thisSubstrateAddress = keyring.encodeAddress(chainWallet.address, 42);
      if (thisSubstrateAddress === signerSubstrateAddress) {
        signerChainWallet = chainWallet;
      }
    }
  });

  return signerChainWallet;
}

export enum SubstratePrefix {
  ICZ = 2207,
  ICY = 2208,
}

export function getSubstrateAddressForEvmAddress(address: string, prefix?: SubstratePrefix) {
  return evmToAddress(address, prefix);
}

export function getKeyringPairForWallet(wallet: Wallet, mnemonic: string) {
  if (!_Keyring) {
    throw new Error('No Keyring available');
  }

  const { hdIndex } = wallet;

  const derivationPath = hdIndex! > 0 ? `//${hdIndex! - 1}` : '';
  const uri = `${mnemonic}${derivationPath}`;

  const dotKeyring: Keyring = new _Keyring({ type: 'sr25519' });
  const dotPair = dotKeyring.createFromUri(uri);

  return dotPair;
}
