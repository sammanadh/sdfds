import { CustomNetwork } from '@/models/Vault';
import { useVault } from '@/stores/Vault';
import { ChainDetails, ChainID, NativeToken } from '@/utils/chains';
import {
  BSCSCAN_API_KEY,
  ETHERSCAN_API_KEY,
  INFURA_PROJECT_ID,
  MOONSCAN_MOONBEAM_API_KEY,
  MOONSCAN_MOONRIVER_API_KEY,
  ONFINALITY_API_KEY,
  OPTIMISM_API_KEY,
  AVALANCHE_API_KEY,
  POLYGON_API_KEY,
} from 'dotenv';

export enum IconNetworkRef {
  Mainnet = 'IconMainnet',
  Sejong = 'IconSejong',
  Lisbon = 'IconLisbon',
  Berlin = 'IconBerlin',
  BTP = 'IconBTP',
  Custom = 'IconCustom',
}

export enum EthereumNetworkRef {
  Mainnet = 'EthereumMainnet',
  Goerli = 'EthereumGoerli',
  Sepolia = 'EthereumSepolia',
  Custom = 'EthereumCustom',
}

export enum PolkadotNetworkRef {
  Mainnet = 'PolkadotMainnet',
}

export enum WestendNetworkRef {
  Testnet = 'WestendTestnet',
}

export enum KusamaNetworkRef {
  Mainnet = 'KusamaMainnet',
}

export enum MoonbeamNetworkRef {
  Mainnet = 'MoonbeamMainnet',
  Moonbase = 'MoonbeamMoonbase',
}

export enum MoonriverNetworkRef {
  Mainnet = 'MoonriverMainnet',
}

export enum BinanceNetworkRef {
  Mainnet = 'BinanceMainnet',
  Testnet = 'BinanceTestnet',
}

export enum IceNetworkRef {
  Arctic = 'IceArctic',
  ArcticEVM = 'IceArcticEVM',
  Snow = 'IceSnow',
  SnowEVM = 'IceSnowEVM',
}

export enum AstarNetworkRef {
  Astar = 'Astar',
  AstarEVM = 'AstarEVM',
  Shiden = 'Shiden',
  ShidenEVM = 'ShidenEVM',
  Shibuya = 'Shibuya',
  ShibuyaEVM = 'ShibuyaEVM',
}

export enum NearNetworkRef {
  Testnet = 'NearTestnet',
}

export enum HarmonyNetworkRef {
  Mainnet = 'HarmonyMainnet',
  Testnet = 'HarmonyTestnet',
  Devnet = 'HarmonyDevnet',
}

export enum WanchainNetworkRef {
  Mainnet = 'WanchainMainnet',
  Testnet = 'WanchainTestnet',
}

export enum HavahNetworkRef {
  Mainnet = 'HavahMainnet',
  Vega = 'HavahVega',
  Custom = 'HavahCustom',
}

export enum AvalancheNetworkRef {
  Mainnet = 'AvalancheMainnet',
  FujiTestnet = 'AvalancheFujiTestnet',
}

export enum PolygonNetworkRef {
  Mainnet = 'PolygonMainnet',
  MumbaiTestnet = 'PolygonMumbaiTestnet',
}

export enum ArbitrumNetworkRef {
  One = 'ArbitrumOne',
  Nova = 'ArbitrumNova',
  RinkArbyTestnet = 'ArbitrumRinkArbyTestnet',
  NitroGoerliRollupTestnet = 'ArbitrumNitroGoerliRollupTestnet',
}

export enum OptimismNetworkRef {
  Mainnet = 'OptimismMainnet',
  Goerli = 'OptimismGoerli',
}

export type NetworkRef =
  | IconNetworkRef
  | EthereumNetworkRef
  | PolkadotNetworkRef
  | WestendNetworkRef
  | KusamaNetworkRef
  | MoonbeamNetworkRef
  | MoonriverNetworkRef
  | BinanceNetworkRef
  | IceNetworkRef
  | NearNetworkRef
  | HarmonyNetworkRef
  | WanchainNetworkRef
  | HavahNetworkRef
  | AvalancheNetworkRef
  | PolygonNetworkRef
  | ArbitrumNetworkRef
  | OptimismNetworkRef
  | AstarNetworkRef;

export interface TestnetConfig {
  chainType: ChainID;
  ref: NetworkRef;
}

export interface NetworkDetails {
  ref: NetworkRef;
  chainType: ChainID;
  name: string;
  shortName: string;
  providerApi: string;
  blockExplorerApi?: string;
  blockExplorerUrl?: string;
  aggregationApi?: string;
  token?: Partial<NativeToken>; // If testnet native token is different to chain type native token
}

export interface IconNetworkDetails extends NetworkDetails {
  ref: IconNetworkRef;
  balancedMulticallAddress?: string;
  networkId: number;
}

export interface NearNetworkDetails extends NetworkDetails {
  ref: NearNetworkRef;
  // NOTE: nodeUrl is providerApi
  networkId: string;
}

export const iconNetworks: Array<IconNetworkDetails> = [
  {
    ref: IconNetworkRef.Mainnet,
    chainType: ChainID.ICON,
    name: 'ICON mainnet',
    shortName: 'Mainnet',
    networkId: 1,
    providerApi: 'https://ctz.solidwallet.io/api/v3',
    blockExplorerApi: 'https://tracker.icon.foundation/v3',
    blockExplorerUrl: 'https://iconwat.ch',
    aggregationApi: 'https://api.myiconwallet.com/v2/icx/mainnet',
    balancedMulticallAddress: "cxa4aa9185e23558cff990f494c1fd2845f6cbf741"
  },
  {
    ref: IconNetworkRef.Sejong,
    chainType: ChainID.ICON,
    name: 'Sejong testnet',
    shortName: 'Sejong',
    networkId: 83,
    providerApi: 'https://sejong.net.solidwallet.io/api/v3',
    blockExplorerApi: 'https://sejong.tracker.solidwallet.io/v3',
    blockExplorerUrl: 'https://sejong.tracker.solidwallet.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/icx/sejong',
  },
  {
    ref: IconNetworkRef.Lisbon,
    chainType: ChainID.ICON,
    name: 'Lisbon testnet',
    shortName: 'Lisbon',
    networkId: 2,
    providerApi: 'https://lisbon.net.solidwallet.io/api/v3',
    blockExplorerApi: 'https://lisbon.tracker.solidwallet.io/v3',
    blockExplorerUrl: 'https://lisbon.tracker.solidwallet.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/icx/lisbon',
  },
  {
    ref: IconNetworkRef.Berlin,
    chainType: ChainID.ICON,
    name: 'Berlin testnet',
    shortName: 'Berlin',
    networkId: 7,
    providerApi: 'https://berlin.net.solidwallet.io/api/v3',
    blockExplorerApi: 'https://berlin.tracker.solidwallet.io/v3',
    blockExplorerUrl: 'https://berlin.tracker.solidwallet.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/icx/berlin',
  },
  {
    ref: IconNetworkRef.BTP,
    chainType: ChainID.ICON,
    name: 'BTP testnet',
    shortName: 'BTP',
    networkId: 66,
    providerApi: 'https://btp.net.solidwallet.io/api/v3',
    blockExplorerApi: 'https://btp.tracker.solidwallet.io/v3',
    blockExplorerUrl: 'https://btp.tracker.solidwallet.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/icx/btp',
  },
];

export interface EthereumNetworkDetails extends NetworkDetails {
  chainId: number;
}

export const ethereumNetworks: Array<EthereumNetworkDetails> = [
  {
    ref: EthereumNetworkRef.Mainnet,
    chainType: ChainID.Ethereum,
    name: 'Ethereum mainnet',
    shortName: 'Mainnet',
    chainId: 1,
    providerApi: `wss://mainnet.infura.io/ws/v3/${INFURA_PROJECT_ID}`,
    blockExplorerApi: `https://api.etherscan.io/api?apikey=${ETHERSCAN_API_KEY}`,
    blockExplorerUrl: 'https://etherscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/eth/mainnet',
  },
  {
    ref: EthereumNetworkRef.Goerli,
    chainType: ChainID.Ethereum,
    name: 'Görli test network (PoA)',
    shortName: 'Görli',
    chainId: 5,
    providerApi: `wss://goerli.infura.io/ws/v3/${INFURA_PROJECT_ID}`,
    blockExplorerApi: `https://api-goerli.etherscan.io/api?apikey=${ETHERSCAN_API_KEY}`,
    blockExplorerUrl: 'https://goerli.etherscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/eth/goerli',
  },
  {
    ref: EthereumNetworkRef.Sepolia,
    chainType: ChainID.Ethereum,
    name: 'Sepolia testnet (PoW)',
    shortName: 'Sepolia',
    chainId: 11155111,
    providerApi: `wss://sepolia.infura.io/ws/v3/${INFURA_PROJECT_ID}`,
    blockExplorerApi: `https://api-sepolia.etherscan.io/api?apikey=${ETHERSCAN_API_KEY}`,
    blockExplorerUrl: 'https://sepolia.etherscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/eth/sepolia',
  },
];

export const polkadotNetworks: Array<
  NetworkDetails & { ref: PolkadotNetworkRef; chainType: ChainID.Polkadot }
> = [
  {
    ref: PolkadotNetworkRef.Mainnet,
    chainType: ChainID.Polkadot,
    name: 'Polkadot mainnet',
    shortName: 'Polkadot',
    providerApi: 'wss://rpc.polkadot.io',
    blockExplorerApi: 'https://polkadot.api.subscan.io/api',
    blockExplorerUrl: 'https://polkadot.subscan.io',
  },
];

export const westendNetworks: Array<
  NetworkDetails & { ref: WestendNetworkRef; chainType: ChainID.Westend }
> = [
  {
    ref: WestendNetworkRef.Testnet,
    chainType: ChainID.Westend,
    name: 'Westend testnet',
    shortName: 'Westend',
    providerApi: 'wss://westend-rpc.polkadot.io',
    blockExplorerApi: 'https://westend.api.subscan.io/api',
    blockExplorerUrl: 'https://westend.subscan.io',
  },
];

export const kusamaNetworks: Array<
  NetworkDetails & { ref: KusamaNetworkRef; chainType: ChainID.Kusama }
> = [
  {
    ref: KusamaNetworkRef.Mainnet,
    chainType: ChainID.Kusama,
    name: 'Kusama mainnet',
    shortName: 'Kusama',
    providerApi: 'wss://kusama-rpc.polkadot.io',
    blockExplorerApi: 'https://kusama.api.subscan.io/api',
    blockExplorerUrl: 'https://kusama.subscan.io',
  },
];

export const moonbeamNetworks: Array<
  EthereumNetworkDetails & { ref: MoonbeamNetworkRef; chainType: ChainID.Moonbeam }
> = [
  {
    ref: MoonbeamNetworkRef.Mainnet,
    chainType: ChainID.Moonbeam,
    name: 'Moonbeam',
    shortName: 'Moonbeam',
    chainId: 1284,
    providerApi: `wss://moonbeam.api.onfinality.io/ws?apikey=${ONFINALITY_API_KEY}`,
    blockExplorerApi: `https://api-moonbeam.moonscan.io/api?apikey=${MOONSCAN_MOONBEAM_API_KEY}`,
    blockExplorerUrl: 'https://moonbeam.moonscan.io',
  },
  {
    ref: MoonbeamNetworkRef.Moonbase,
    chainType: ChainID.Moonbeam,
    name: 'Moonbase Alpha',
    shortName: 'Moonbase',
    chainId: 1287,
    providerApi: `wss://moonbeam-alpha.api.onfinality.io/ws?apikey=${ONFINALITY_API_KEY}`,
    blockExplorerApi: `https://api-moonbase.moonscan.io/api?apikey=${MOONSCAN_MOONBEAM_API_KEY}`,
    blockExplorerUrl: 'https://moonbase.moonscan.io',
    token: { symbol: 'DEV', name: 'Moonbase' },
  },
];

export const moonriverNetworks: Array<
  EthereumNetworkDetails & { ref: MoonriverNetworkRef; chainType: ChainID.Moonriver }
> = [
  {
    ref: MoonriverNetworkRef.Mainnet,
    chainType: ChainID.Moonriver,
    name: 'Moonriver',
    shortName: 'Moonriver',
    chainId: 1285,
    providerApi: `wss://moonriver.api.onfinality.io/ws?apikey=${ONFINALITY_API_KEY}`,
    blockExplorerApi: `https://api-moonriver.moonscan.io/api?apikey=${MOONSCAN_MOONRIVER_API_KEY}`,
    blockExplorerUrl: 'https://moonriver.moonscan.io',
  },
];

export const binanceNetworks: Array<
  EthereumNetworkDetails & { ref: BinanceNetworkRef; chainType: ChainID.Binance }
> = [
  {
    ref: BinanceNetworkRef.Mainnet,
    chainType: ChainID.Binance,
    name: 'Binance mainnet',
    shortName: 'Mainnet',
    chainId: 56,
    providerApi: 'https://bsc-dataseed.binance.org',
    blockExplorerApi: `https://api.bscscan.com/api?apikey=${BSCSCAN_API_KEY}`,
    blockExplorerUrl: 'https://bscscan.com',
    aggregationApi: 'https://api.myiconwallet.com/v2/bsc/mainnet',
  },
  {
    ref: BinanceNetworkRef.Testnet,
    chainType: ChainID.Binance,
    name: 'Binance testnet',
    shortName: 'Testnet',
    chainId: 97,
    providerApi: 'https://data-seed-prebsc-1-s1.binance.org:8545',
    blockExplorerApi: `https://api-testnet.bscscan.com/api?apikey=${BSCSCAN_API_KEY}`,
    blockExplorerUrl: 'https://testnet.bscscan.com',
    aggregationApi: 'https://api.myiconwallet.com/v2/bsc/testnet',
  },
];

export const arcticNetworks: Array<
  NetworkDetails & { ref: IceNetworkRef; chainType: ChainID.Arctic }
> = [
  {
    ref: IceNetworkRef.Arctic,
    chainType: ChainID.Arctic,
    name: 'Arctic Network',
    shortName: 'Arctic',
    providerApi: 'wss://arctic-rpc.icenetwork.io:9944',
    blockExplorerApi: 'https://arctic.api.subscan.io/api',
    blockExplorerUrl: 'https://arctic.subscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/ice/arctic',
  },
];

export const arcticEvmNetworks: Array<
  EthereumNetworkDetails & { ref: IceNetworkRef; chainType: ChainID.Arctic_EVM }
> = [
  {
    ref: IceNetworkRef.ArcticEVM,
    chainType: ChainID.Arctic_EVM,
    name: 'Arctic Network EVM',
    shortName: 'ArcticEVM',
    chainId: 552,
    providerApi: 'https://arctic-rpc.icenetwork.io:9933',
    blockExplorerApi: 'https://arctic.api.subscan.io/api',
    blockExplorerUrl: 'https://arctic.subscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/ice/arctic-evm',
  },
];

export const snowNetworks: Array<NetworkDetails & { ref: IceNetworkRef; chainType: ChainID.SNOW }> =
  [
    {
      ref: IceNetworkRef.Snow,
      chainType: ChainID.SNOW,
      name: 'SNOW network',
      shortName: 'SNOW',
      providerApi: 'wss://snow-rpc.icenetwork.io',
      blockExplorerApi: 'https://snow.api.subscan.io/api',
      blockExplorerUrl: 'https://snow.subscan.io',
      aggregationApi: 'https://api.myiconwallet.com/v2/ice/snow',
    },
  ];

export const snowEvmNetworks: Array<
  EthereumNetworkDetails & { ref: IceNetworkRef; chainType: ChainID.SNOW_EVM }
> = [
  {
    ref: IceNetworkRef.SnowEVM,
    chainType: ChainID.SNOW_EVM,
    name: 'SNOW EVM network',
    shortName: 'SnowEVM',
    chainId: 551,
    providerApi: 'https://snow-rpc.icenetwork.io:9933',
    blockExplorerApi: 'https://snow.api.subscan.io/api',
    blockExplorerUrl: 'https://snow.subscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/ice/snow-evm',
  },
];

export const astarNetworks: Array<
  NetworkDetails & { ref: AstarNetworkRef; chainType: ChainID.Astar }
> = [
  {
    ref: AstarNetworkRef.Astar,
    chainType: ChainID.Astar,
    name: 'Astar network',
    shortName: 'Astar',
    providerApi: 'wss://rpc.astar.network',
    blockExplorerApi: 'https://astar.api.subscan.io/api',
    blockExplorerUrl: 'https://astar.subscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/astar/astar',
  },
];

export const astarEvmNetworks: Array<
  EthereumNetworkDetails & { ref: AstarNetworkRef; chainType: ChainID.Astar_EVM }
> = [
  {
    ref: AstarNetworkRef.AstarEVM,
    chainType: ChainID.Astar_EVM,
    name: 'Astar EVM network',
    shortName: 'AstarEVM',
    chainId: 592,
    providerApi: 'wss://astar.api.onfinality.io/public-ws',
    blockExplorerApi: 'https://blockscout.com/astar/api',
    blockExplorerUrl: 'https://blockscout.com/astar',
    aggregationApi: 'https://api.myiconwallet.com/v2/astar/astar-evm',
  },
];

export const shidenNetworks: Array<
  NetworkDetails & { ref: AstarNetworkRef; chainType: ChainID.Shiden }
> = [
  {
    ref: AstarNetworkRef.Shiden,
    chainType: ChainID.Shiden,
    name: 'Shiden network',
    shortName: 'Shiden',
    providerApi: 'wss://shiden-rpc.dwellir.com',
    blockExplorerApi: 'https://shiden.api.subscan.io/api',
    blockExplorerUrl: 'https://shiden.subscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/astar/shiden',
  },
];

export const shidenEvmNetworks: Array<
  EthereumNetworkDetails & { ref: AstarNetworkRef; chainType: ChainID.Shiden_EVM }
> = [
  {
    ref: AstarNetworkRef.ShidenEVM,
    chainType: ChainID.Shiden_EVM,
    name: 'Shiden EVM network',
    shortName: 'ShidenEVM',
    chainId: 336,
    providerApi: 'wss://shiden.api.onfinality.io/public-ws',
    blockExplorerApi: 'https://blockscout.com/shiden/api',
    blockExplorerUrl: 'https://blockscout.com/shiden',
    aggregationApi: 'https://api.myiconwallet.com/v2/astar/shiden-evm',
  },
];

export const shibuyaNetworks: Array<
  NetworkDetails & { ref: AstarNetworkRef; chainType: ChainID.Shibuya }
> = [
  {
    ref: AstarNetworkRef.Shibuya,
    chainType: ChainID.Shibuya,
    name: 'Shibuya network',
    shortName: 'Shibuya',
    providerApi: 'wss://shibuya-rpc.dwellir.com',
    blockExplorerApi: 'https://shibuya.api.subscan.io/api',
    blockExplorerUrl: 'https://shibuya.subscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/astar/shibuya',
  },
];

export const shibuyaEvmNetworks: Array<
  EthereumNetworkDetails & { ref: AstarNetworkRef; chainType: ChainID.Shibuya_EVM }
> = [
  {
    ref: AstarNetworkRef.ShibuyaEVM,
    chainType: ChainID.Shibuya_EVM,
    name: 'Shibuya EVM network',
    shortName: 'ShibuyaEVM',
    chainId: 81,
    providerApi: 'wss://shibuya-rpc.dwellir.com',
    blockExplorerApi: 'https://blockscout.com/shibuya/api',
    blockExplorerUrl: 'https://blockscout.com/shibuya',
    aggregationApi: 'https://api.myiconwallet.com/v2/astar/shibuya-evm',
  },
];

export const nearNetworks: Array<NearNetworkDetails & { chainType: ChainID.NEAR }> = [
  {
    ref: NearNetworkRef.Testnet,
    chainType: ChainID.NEAR,
    name: 'Near testnet',
    shortName: 'Near',
    networkId: 'testnet',
    providerApi: 'https://rpc.testnet.near.org',
    blockExplorerApi: 'https://testnet.nearblocks.io/api',
    blockExplorerUrl: 'https://explorer.testnet.near.org',
  },
];

export const harmonyNetworks: Array<
  EthereumNetworkDetails & { ref: HarmonyNetworkRef; chainType: ChainID.Harmony }
> = [
  {
    ref: HarmonyNetworkRef.Mainnet,
    chainType: ChainID.Harmony,
    name: 'Harmony mainnet',
    shortName: 'Mainnet',
    chainId: 1666600000,
    providerApi: 'https://api.harmony.one',
    blockExplorerUrl: 'https://explorer.harmony.one',
  },
  {
    ref: HarmonyNetworkRef.Testnet,
    chainType: ChainID.Harmony,
    name: 'Harmony testnet',
    shortName: 'Testnet',
    chainId: 1666700000,
    providerApi: 'https://api.s0.b.hmny.io',
    blockExplorerUrl: 'https://explorer.pops.one',
  },
  {
    ref: HarmonyNetworkRef.Devnet,
    chainType: ChainID.Harmony,
    name: 'Harmony devnet',
    shortName: 'Devnet',
    chainId: 1666900000,
    providerApi: 'https://api.s0.ps.hmny.io',
    blockExplorerUrl: 'https://explorer.ps.hmny.io',
  },
];

export const wanchainNetworks: Array<
  EthereumNetworkDetails & { ref: WanchainNetworkRef; chainType: ChainID.Wanchain }
> = [
  {
    ref: WanchainNetworkRef.Mainnet,
    chainType: ChainID.Wanchain,
    name: 'Wanchain mainnet',
    shortName: 'Mainnet',
    chainId: 888,
    providerApi: 'https://gwan-ssl.wandevs.org:56891',
    blockExplorerUrl: 'https://wanscan.org',
    aggregationApi: 'https://api.myiconwallet.com/v2/wanchain/mainnet',
  },
  {
    ref: WanchainNetworkRef.Testnet,
    chainType: ChainID.Wanchain,
    name: 'Wanchain testnet',
    shortName: 'Testnet',
    chainId: 999,
    providerApi: 'https://gwan-ssl.wandevs.org:46891',
    blockExplorerUrl: 'https://testnet.wanscan.org',
    aggregationApi: 'https://api.myiconwallet.com/v2/wanchain/testnet',
  },
];

const avalancheNetworks: Array<
  EthereumNetworkDetails & { ref: AvalancheNetworkRef; chainType: ChainID.Avalanche }
> = [
  {
    ref: AvalancheNetworkRef.Mainnet,
    chainType: ChainID.Avalanche,
    name: 'Avalanche mainnet',
    shortName: 'Mainnet',
    chainId: 43114,
    providerApi: 'https://api.avax.network/ext/bc/C/rpc',
    blockExplorerApi: `https://api.snowtrace.io/api?apikey=${process.env.AVALANCHE_API_KEY}`,
    blockExplorerUrl: 'https://snowtrace.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/avalanche/mainnet',
  },
  {
    ref: AvalancheNetworkRef.FujiTestnet,
    chainType: ChainID.Avalanche,
    name: 'Avalanche Fuji testnet',
    shortName: 'Testnet',
    chainId: 43113,
    providerApi: 'https://api.avax-test.network/ext/bc/C/rpc',
    blockExplorerUrl: 'https://testnet.snowtrace.io',
  },
];

const polygonNetworks: Array<
  EthereumNetworkDetails & { ref: PolygonNetworkRef; chainType: ChainID.Polygon }
> = [
  {
    ref: PolygonNetworkRef.Mainnet,
    chainType: ChainID.Polygon,
    name: 'Polygon mainnet',
    shortName: 'Mainnet',
    chainId: 137,
    providerApi: 'https://polygon-rpc.com',
    blockExplorerApi: `https://api.polygonscan.com/api?apikey=${process.env.POLYGON_API_KEY}`,
    blockExplorerUrl: 'https://polygonscan.com',
    aggregationApi: 'https://api.myiconwallet.com/v2/polygon/mainnet',
  },
  {
    ref: PolygonNetworkRef.MumbaiTestnet,
    chainType: ChainID.Polygon,
    name: 'Polygon Mumbai testnet',
    shortName: 'Testnet',
    chainId: 80001,
    providerApi: 'https://rpc-mumbai.maticvigil.com',
    blockExplorerUrl: 'https://mumbai.polygonscan.com',
  },
];

const arbitrumNetworks: Array<
  EthereumNetworkDetails & { ref: ArbitrumNetworkRef; chainType: ChainID.Arbitrum }
> = [
  {
    ref: ArbitrumNetworkRef.One,
    chainType: ChainID.Arbitrum,
    name: 'Arbitrum One',
    shortName: 'One',
    chainId: 42161,
    providerApi: 'https://arb1.arbitrum.io/rpc',
    blockExplorerUrl: 'https://arbiscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/arbitrum/mainnet',
  },
  {
    ref: ArbitrumNetworkRef.Nova,
    chainType: ChainID.Arbitrum,
    name: 'Arbitrum Nova',
    shortName: 'Nova',
    chainId: 42170,
    providerApi: 'https://nova.arbitrum.io/rpc',
    blockExplorerUrl: 'https://nova.arbiscan.io',
  },
  {
    ref: ArbitrumNetworkRef.RinkArbyTestnet,
    chainType: ChainID.Arbitrum,
    name: 'Arbitrum RinkArby testnet',
    shortName: 'RinkArby',
    chainId: 421611,
    providerApi: 'https://rinkeby.arbitrum.io/rpc',
    blockExplorerUrl: 'https://rinkeby-explorer.arbitrum.io',
  },
  {
    ref: ArbitrumNetworkRef.NitroGoerliRollupTestnet,
    chainType: ChainID.Arbitrum,
    name: 'Arbitrum Nitro Goerli Rollup testnet',
    shortName: 'NitroGoerli',
    chainId: 421613,
    providerApi: 'https://goerli-rollup.arbitrum.io/rpc',
    blockExplorerUrl: 'https://goerli-rollup-explorer.arbitrum.io',
  },
];

const optimismNetworks: Array<
  EthereumNetworkDetails & { ref: OptimismNetworkRef; chainType: ChainID.Optimism }
> = [
  {
    ref: OptimismNetworkRef.Mainnet,
    chainType: ChainID.Optimism,
    name: 'Optimism mainnet',
    shortName: 'Mainnet',
    chainId: 10,
    providerApi: 'https://mainnet.optimism.io',
    blockExplorerApi: `https://api-optimistic.etherscan.io/api?apikey=${process.env.OPTIMISM_API_KEY}`,
    blockExplorerUrl: 'https://optimistic.etherscan.io',
    aggregationApi: 'https://api.myiconwallet.com/v2/optimism/mainnet',
  },
  {
    ref: OptimismNetworkRef.Goerli,
    chainType: ChainID.Optimism,
    name: 'Optimism Goerli testnet',
    shortName: 'Goerli',
    chainId: 420,
    providerApi: 'https://goerli.optimism.io',
    blockExplorerUrl: 'https://goerli-optimistic.etherscan.io',
  },
];

export interface HavahNetworkDetails extends NetworkDetails {
  ref: HavahNetworkRef;
  chainType: ChainID.HAVAH;
  networkId: number;
}

export const havahNetworks: Array<
  HavahNetworkDetails & { ref: HavahNetworkRef; chainType: ChainID.HAVAH }
> = [
  {
    ref: HavahNetworkRef.Mainnet,
    chainType: ChainID.HAVAH,
    name: 'HAVAH Mainnet',
    shortName: 'Mainnet',
    networkId: 256,
    providerApi: 'https://ctz.havah.io/api/v3',
    blockExplorerApi: 'https://scan.havah.io/v3',
    blockExplorerUrl: 'https://scan.havah.io',
  },
  {
    ref: HavahNetworkRef.Vega,
    chainType: ChainID.HAVAH,
    name: 'Vega testnet',
    shortName: 'Vega',
    networkId: 257,
    providerApi: 'https://ctz.vega.havah.io/api/v3',
    blockExplorerApi: 'https://scan.vega.havah.io/v3',
    blockExplorerUrl: 'https://scan.vega.havah.io',
  },
];

export const mainnets: PartialRecord<ChainID, NetworkDetails> = {
  [ChainID.ICON]: iconNetworks.find((network) => network.ref === IconNetworkRef.Mainnet)!,
  [ChainID.HAVAH]: havahNetworks.find((network) => network.ref === HavahNetworkRef.Mainnet)!,
  [ChainID.Ethereum]: ethereumNetworks.find(
    (network) => network.ref === EthereumNetworkRef.Mainnet
  )!,
  [ChainID.Polkadot]: polkadotNetworks[0],
  [ChainID.Kusama]: kusamaNetworks[0],
  [ChainID.Moonbeam]: moonbeamNetworks.find(
    (network) => network.ref === MoonbeamNetworkRef.Mainnet
  )!,
  [ChainID.Moonriver]: moonriverNetworks[0],
  [ChainID.Binance]: binanceNetworks.find((network) => network.ref === BinanceNetworkRef.Mainnet)!,
  [ChainID.Harmony]: harmonyNetworks[0],
  [ChainID.SNOW]: snowNetworks[0],
  [ChainID.SNOW_EVM]: snowEvmNetworks[0],
  [ChainID.Wanchain]: wanchainNetworks[0],
  [ChainID.Avalanche]: avalancheNetworks[0],
  [ChainID.Polygon]: polygonNetworks[0],
  [ChainID.Arbitrum]: arbitrumNetworks[0],
  [ChainID.Optimism]: optimismNetworks[0],
  [ChainID.Astar]: astarNetworks[0],
  [ChainID.Astar_EVM]: astarEvmNetworks[0],
  [ChainID.Shiden]: shidenNetworks[0],
  [ChainID.Shiden_EVM]: shidenEvmNetworks[0],
};

export const testnets: PartialRecord<ChainID, Array<NetworkDetails>> = {
  [ChainID.ICON]: iconNetworks.filter((network) => network.ref !== IconNetworkRef.Mainnet),
  [ChainID.HAVAH]: havahNetworks.filter((network) => network.ref !== HavahNetworkRef.Mainnet),
  [ChainID.Arctic]: arcticNetworks,
  [ChainID.Arctic_EVM]: arcticEvmNetworks,
  [ChainID.Ethereum]: ethereumNetworks.filter(
    (network) => network.ref !== EthereumNetworkRef.Mainnet
  ),
  [ChainID.Westend]: westendNetworks,
  [ChainID.Moonbeam]: moonbeamNetworks.filter(
    (network) => network.ref !== MoonbeamNetworkRef.Mainnet
  ),
  [ChainID.Binance]: binanceNetworks.filter((network) => network.ref !== BinanceNetworkRef.Mainnet),
  [ChainID.NEAR]: nearNetworks,
  [ChainID.Harmony]: harmonyNetworks.filter((network) => network.ref !== HarmonyNetworkRef.Mainnet),
  [ChainID.Wanchain]: wanchainNetworks.filter(
    (network) => network.ref !== WanchainNetworkRef.Mainnet
  ),
  [ChainID.Avalanche]: avalancheNetworks.filter(
    (network) => network.ref !== AvalancheNetworkRef.Mainnet
  ),
  [ChainID.Polygon]: polygonNetworks.filter((network) => network.ref !== PolygonNetworkRef.Mainnet),
  [ChainID.Arbitrum]: arbitrumNetworks.filter((network) => network.ref !== ArbitrumNetworkRef.One),
  [ChainID.Optimism]: optimismNetworks.filter(
    (network) => network.ref !== OptimismNetworkRef.Mainnet
  ),
  [ChainID.Shibuya]: shibuyaNetworks,
  [ChainID.Shibuya_EVM]: shibuyaEvmNetworks,
};

export function networkDetailsForTestnet(testnet: TestnetConfig) {
  const { chainType, ref } = testnet;

  return testnets[chainType]?.find((network) => network.ref === ref);
}

export function networkDetailsForChain(chain: ChainDetails) {
  return networkDetailsForChainID(chain.id);
}

export function networkDetailsForChainID(chainID: ChainID) {
  if (chainID === ChainID.Westend) {
    return westendNetworks[0];
  }

  if (chainID === ChainID.Arctic) {
    return arcticNetworks[0];
  }

  if (chainID === ChainID.NEAR) {
    return nearNetworks[0];
  }

  return mainnets[chainID];
}

export const evmNetworks = [
  ...ethereumNetworks,
  ...moonbeamNetworks,
  ...moonriverNetworks,
  ...binanceNetworks,
  ...arcticEvmNetworks,
  ...snowEvmNetworks,
  ...harmonyNetworks,
  ...wanchainNetworks,
  ...avalancheNetworks,
  ...polygonNetworks,
  ...arbitrumNetworks,
  ...optimismNetworks,
  ...astarEvmNetworks,
  ...shidenEvmNetworks,
  ...shibuyaEvmNetworks,
];

export const evmChains = [
  ChainID.Binance,
  ChainID.Moonbeam,
  ChainID.Moonriver,
  ChainID.Arctic_EVM,
  ChainID.SNOW_EVM,
  ChainID.Harmony,
  ChainID.Wanchain,
  ChainID.Avalanche,
  ChainID.Polygon,
  ChainID.Arbitrum,
  ChainID.Optimism,
  ChainID.Astar_EVM,
  ChainID.Shiden_EVM,
  ChainID.Shibuya_EVM,
];

export function isEvmChain(chain: ChainDetails) {
  return evmChains.includes(chain.id);
}

export function isEvmChainID(chainID: ChainID) {
  return evmChains.includes(chainID);
}

export function isEthOrEvmChainID(chainID: ChainID) {
  return chainID === ChainID.Ethereum || evmChains.includes(chainID);
}

export const evmMainnets = [
  mainnets[ChainID.Ethereum],
  mainnets[ChainID.Binance],
  mainnets[ChainID.Moonriver],
  mainnets[ChainID.Moonbeam],
  mainnets[ChainID.Harmony],
  mainnets[ChainID.SNOW_EVM],
  mainnets[ChainID.Wanchain],
  mainnets[ChainID.Avalanche],
  mainnets[ChainID.Polygon],
  mainnets[ChainID.Arbitrum],
  mainnets[ChainID.Optimism],
  mainnets[ChainID.Astar_EVM],
  mainnets[ChainID.Shiden_EVM],
] as Array<EthereumNetworkDetails>;

export function getCustomNetworks() {
  const { realm } = useVault.getState();

  return realm?.objects<CustomNetwork>('CustomNetwork');
}

export function getCustomNetworksForChain(chain: ChainID) {
  const { realm } = useVault.getState();

  return realm?.objects<CustomNetwork>('CustomNetwork').filtered(`chain = '${chain}'`);
}

// Chains that allow adding custom tokens
export const customTokenChains = [
  ChainID.ICON,
  ChainID.HAVAH,
  ChainID.Arctic_EVM,
  ChainID.Arctic,
  ChainID.SNOW,
  ChainID.SNOW_EVM,
  ChainID.Ethereum,
  ChainID.Binance,
  ChainID.Moonriver,
  ChainID.Moonbeam,
  ChainID.Harmony,
  ChainID.Wanchain,
];

export const allNetworks = [
  ...iconNetworks,
  ...havahNetworks,
  ...ethereumNetworks,
  ...westendNetworks,
  ...moonbeamNetworks,
  ...moonriverNetworks,
  ...binanceNetworks,
  ...arcticNetworks,
  ...arcticEvmNetworks,
  ...snowNetworks,
  ...snowEvmNetworks,
  ...nearNetworks,
  ...harmonyNetworks,
  ...wanchainNetworks,
];
