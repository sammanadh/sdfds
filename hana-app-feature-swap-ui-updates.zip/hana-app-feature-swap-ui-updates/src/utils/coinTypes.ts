import { BigNumber } from '@/utils/bignumber';
import { ChainDetails } from '@/utils/chains';
import { get, isEmpty, isNil } from 'lodash-es';

/**
 * Should match up to a BIP44 coin type
 * https://github.com/satoshilabs/slips/blob/master/slip-0044.md
 */
export enum CoinType {
  ETH = 'ETH',
  ICX = 'ICX',
  DOT = 'DOT',
  KSM = 'KSM',
  NEAR = 'NEAR',
  HVH = 'HVH',
}

/**
 * Returns the coin-specific BIP32 path for deriving hierarchical deterministic wallets
 */
const bip44Constants: Record<CoinType, number> = {
  [CoinType.ETH]: 60,
  [CoinType.ICX]: 74,
  [CoinType.HVH]: 858,
  [CoinType.DOT]: 354,
  [CoinType.KSM]: 434,
  [CoinType.NEAR]: 397,
};

export function getCoinHDPath(coinType: CoinType, accountIndex: number) {
  // NOTE: If NEAR, then first account is m/44'/397'/0'
  // Second account onwards i m/44'/397'/0'/0'/[1...n]'
  if (coinType === CoinType.NEAR) {
    if (accountIndex === 0) {
      return `m/44'/397'/0'`;
    }

    return `m/44'/397'/0'/0'/${accountIndex}'`;
  }

  return `m/44'/${bip44Constants[coinType]}'/0'/0/${accountIndex}`;
}

export async function getNativeTokenPrice(chain: ChainDetails) {
  const symbol = chain.token.symbol;

  try {
    const url = `https://api.binance.com/api/v3/trades?symbol=${symbol}USDT&limit=1`;
    const response = await fetch(url);
    const transactions = await response.json();
    const price = get(transactions, '[0].price');
    return !isEmpty(price) ? new BigNumber(price) : undefined;
  } catch (error: any) {
    console.warn(`Failed fetching ${symbol}/USD price.`, error.message);
    return undefined;
  }
}

export async function getTokenPrice(chain: ChainDetails, contractAddress: string) {
  try {
    if (isNil(chain.token.coinId)) throw new Error('Chain unsupported on CoinGecko API.');
    const url = `https://api.coingecko.com/api/v3/simple/token_price/${chain.token.coinId}?contract_addresses=${contractAddress}&vs_currencies=usd`;

    const response = await fetch(url);
    const priceInfo = await response.json();
    const price = get(priceInfo, `${contractAddress.toLowerCase()}.usd`);
    return !isNil(price) ? new BigNumber(price) : undefined;
  } catch (error: any) {
    console.warn(
      `Failed fetching USD price for ${chain.name} token ${contractAddress}.`,
      error.message
    );
    return undefined;
  }
}
