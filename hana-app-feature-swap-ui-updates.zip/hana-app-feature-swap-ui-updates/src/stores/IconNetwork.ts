import { CoinAssets, IconAssets } from '@/models/Asset';
import { Delegation } from '@/models/Delegation';
import { PRep } from '@/models/PRep';
import { useVault } from '@/stores/Vault';
import type { BigNumber } from '@/utils/bignumber';
import { ChainID } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import produce from 'immer';
import { create } from 'zustand';
import { serviceForChainID } from './ChainServices';

interface State {
  pReps: PRep[];
  refreshPReps: () => unknown;
  icxAssets: Map<string, IconAssets>;
  refreshICXAssets: () => unknown;
  icxAssetsForWallet: () => IconAssets | null | undefined;
  updateDelegations: (delegations: Delegation[]) => unknown;
  updateStaked: (staked: BigNumber) => unknown;
  delegateNewPRep: (pRep: PRep) => unknown;
  resetIScore: () => unknown;
}

function getIconWallet() {
  const { getActiveWallet } = useVault.getState();
  const activeWallet = getActiveWallet();

  return activeWallet?.chainWallets.find((cw) => cw.type === ChainID.ICON);
}

export const useIconNetwork = create<State>((set, get) => ({
  pReps: [],
  refreshPReps: async () => {
    try {
      const iconService = serviceForChainID(ChainID.ICON);
      const networkDetails = iconService?.getNetworkDetails();

      if (networkDetails) {
        const response = await fetch(`${networkDetails.aggregationApi}/preps`);
        const pReps: Array<PRep> = await response.json();

        set({
          pReps,
        });
      }
    } catch (error: any) {
      console.warn('Failed fetching and updating P-Reps.', error.message);
    }
  },
  icxAssets: new Map<string, CoinAssets>(),
  refreshICXAssets: async () => {
    const iconWallet = getIconWallet();

    if (iconWallet) {
      const { address } = iconWallet;
      const iconService = serviceForChainID(ChainID.ICON);
      const assetsForAddress = await iconService?.getAssets(address);

      const existingAssets = get().icxAssets;

      const existingZeroDelegations = existingAssets
        .get(address)
        ?.delegations?.filter((d) => d.amount.isZero());

      assetsForAddress &&
        set({
          icxAssets: produce(existingAssets, (draft) => {
            draft.set(address, assetsForAddress);
          }),
        });

      if (existingZeroDelegations && existingZeroDelegations.length > 0) {
        set({
          icxAssets: produce(existingAssets, (draft) => {
            const newDelegations = draft.get(address)!.delegations || [];

            // Add zero delegations if they don't already exist
            existingZeroDelegations.forEach((zd) => {
              if (!newDelegations.find((d) => d.address === zd.address)) {
                newDelegations.push(zd);
              }
            });

            draft.get(address)!.delegations = newDelegations;
          }),
        });
      }
    }

    console.debug('refreshICXAssets done');
  },
  icxAssetsForWallet: () => {
    const iconWallet = getIconWallet();

    if (iconWallet) {
      const { address } = iconWallet;
      return get().icxAssets.get(address);
    }

    return null;
  },
  updateDelegations: (delegations) => {
    const iconWallet = getIconWallet();

    if (iconWallet) {
      const { address } = iconWallet;
      const existingAssets = get().icxAssets;

      set({
        icxAssets: produce(existingAssets, (draft) => {
          if (draft.has(address)) {
            draft.get(address)!.delegations = delegations;
          } else {
            draft.set(address, {
              delegations,
            });
          }
        }),
      });
    }
  },
  updateStaked: (staked) => {
    const iconWallet = getIconWallet();

    if (iconWallet) {
      const { address } = iconWallet;
      const existingAssets = get().icxAssets;

      set({
        icxAssets: produce(existingAssets, (draft) => {
          if (draft.has(address)) {
            draft.get(address)!.staked = staked;
          }
        }),
      });
    }
  },
  delegateNewPRep: (pRep) => {
    const iconWallet = getIconWallet();

    if (iconWallet) {
      const { address } = iconWallet;
      const existingAssets = get().icxAssets;

      const delegation = { address: pRep.address, amount: ZERO };

      set({
        icxAssets: produce(existingAssets, (draft) => {
          if (draft.has(address)) {
            draft.get(address)!.delegations?.push(delegation);
          } else {
            draft.set(address, {
              delegations: [delegation],
            });
          }
        }),
      });
    }
  },
  resetIScore: () => {
    const iconWallet = getIconWallet();

    if (iconWallet) {
      const { address } = iconWallet;
      const existingAssets = get().icxAssets;

      set({
        icxAssets: produce(existingAssets, (draft) => {
          if (draft.has(address)) {
            draft.get(address)!.iScore = ZERO;
            draft.get(address)!.iScoreEstimatedIcx = ZERO;
          }
        }),
      });
    }
  },
}));
