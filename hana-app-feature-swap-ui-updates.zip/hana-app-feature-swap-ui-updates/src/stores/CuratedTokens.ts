import { CuratedToken } from '@/models/Token';
import { Token } from '@/models/Vault';
import { ChainID, chains } from '@/utils/chains';
import { allNetworks, EthereumNetworkRef, IconNetworkRef } from '@/utils/networks';
import { isNil } from 'lodash-es';
import { create } from 'zustand';
import { useVault } from './Vault';

const LEGACY_ETH_CONTRACT = '0x0000000000000000000000000000000000000000';
const LEGACY_ICX_CONTRACT = 'cx0000000000000000000000000000000000000000';

interface State {
  refreshCuratedTokens: () => unknown;
}

export const useCuratedTokens = create<State>((set, get) => ({
  curatedTokens: new Map(),
  refreshCuratedTokens: async () => {
    const { realm } = useVault.getState();

    const allTokens = realm?.objects<Token>('Token');

    allNetworks.forEach(async (networkDetails) => {
      if (networkDetails.aggregationApi) {
        const url = `${networkDetails.aggregationApi}/tokens`;
        const response = await fetch(url);
        const _tokens: Array<CuratedToken> = await response.json();

        const curatedTokens = _tokens.filter(
          (t) => t.contract !== LEGACY_ETH_CONTRACT && t.contract !== LEGACY_ICX_CONTRACT
        );

        const isEthTestnet =
          networkDetails.chainType === ChainID.Ethereum &&
          networkDetails.ref !== EthereumNetworkRef.Mainnet;

        const isIcxTestnet =
          networkDetails.chainType === ChainID.ICON &&
          networkDetails.ref !== IconNetworkRef.Mainnet;

        // Ethereum testnet
        if (isEthTestnet || isIcxTestnet) {
          curatedTokens.forEach((token) => {
            if (
              isNil(
                allTokens?.find(
                  (t) => t.networkRef === networkDetails.ref && t.contract === token.contract
                )
              )
            ) {
              const { contract, name, symbol, decimals, logoUrl } = token;

              realm?.write(() => {
                const token = realm.create<Token>(
                  'Token',
                  new Token(networkDetails.chainType, name, symbol, +decimals, logoUrl)
                );

                token.contract = contract;
                token.networkRef = networkDetails.ref;
              });
            }
          });
        } else {
          // Mainnet
          const chain = chains.find((c) => c.id === networkDetails.chainType);

          curatedTokens.forEach((token) => {
            if (
              isNil(
                allTokens?.find((t) => t.contract === token.contract || t.assetId === token.assetId)
              )
            ) {
              const { contract, assetId, name, symbol, decimals, logoUrl } = token;

              realm?.write(() => {
                const token = realm.create<Token>(
                  'Token',
                  new Token(networkDetails.chainType, name, symbol, +decimals, logoUrl)
                );

                token.contract = contract;
                token.assetId = assetId;

                if (chain?.isTestnet === true) {
                  token.networkRef = networkDetails.ref;
                }
              });
            }
          });
        }
      }
    });
  },
}));
