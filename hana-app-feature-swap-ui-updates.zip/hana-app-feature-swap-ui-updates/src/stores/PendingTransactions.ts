import { Transaction, TransactionType } from '@/models/Transaction';
import { serviceForChainID, useChainServices } from '@/stores/ChainServices';
import { watchSwapTransaction } from '@/utils/swap';
import AsyncStorage from '@react-native-async-storage/async-storage';
import produce from 'immer';
import { StateCreator, create } from 'zustand';
import { PersistOptions, persist } from 'zustand/middleware';
import { generateKey, useTransactions } from './Transactions';

interface State {
  pendingTransactions: Transaction[];
  addPendingTransaction: (transaction: Transaction) => unknown;
}

type Persist = (config: StateCreator<State>, options: PersistOptions<State>) => StateCreator<State>;

export const usePendingTransactions = create<State>(
  (persist as Persist)(
    (set, get) => ({
      pendingTransactions: [],
      addPendingTransaction: async (transaction: Transaction) => {
        set({
          pendingTransactions: [...get().pendingTransactions, transaction],
        });

        // Setup a watch for this pending transaction
        if (transaction.type === TransactionType.TokenSwap) {
          watchSwapTransaction(transaction);
        } else {
          if (!transaction.chainID) return;

          const chainService = serviceForChainID(transaction.chainID);

          chainService
            ?.waitForTransaction(transaction.hash)
            .then(() => true)
            .catch(() => false)
            .then((success) => {
              if (success) {
                const { pendingTransactions } = get();

                const { transactions } = useTransactions.getState();

                // Set this transaction isPending = false
                const updatedPendingTransactions = produce(pendingTransactions, (draft) => {
                  const index = draft.findIndex((t) => t.hash === transaction.hash);

                  if (index >= 0) {
                    draft[index].isPending = false;
                  }
                });

                const updatedTransactions = transactions;

                if (!transaction.chainID || !transaction.from) return;

                const { otherNetwork } = useChainServices.getState();

                const key = generateKey(transaction.chainID, transaction.from, otherNetwork);

                const transactionsForKey = updatedTransactions.get(key) || [];

                const index = transactionsForKey.findIndex((t) => t.hash === transaction.hash);

                if (index >= 0) {
                  transactionsForKey[index].isPending = false;
                }

                updatedTransactions.set(key, transactionsForKey);

                set({
                  pendingTransactions: updatedPendingTransactions,
                });

                useTransactions.setState({
                  transactions: updatedTransactions,
                });
              }
            });
        }
      },
    }),
    {
      name: 'pending-transactions-storage',
      storage: {
        getItem: async (name) => {
          const str = await AsyncStorage.getItem(name);

          if (str) {
            // Parse string and fix dates
            const parsed = JSON.parse(str);

            const fixed = produce(parsed, (draft: any) => {
              draft.state.pendingTransactions.forEach((t: Transaction) => {
                t.date = new Date(t.date);

                console.debug('date is now: ', t.date);
              });
            });

            (fixed as any).state.pendingTransactions.forEach((t: Transaction) => {
              // Add watcher for swap transactions
              if (t.type === TransactionType.TokenSwap && t.isPending === true) {
                watchSwapTransaction(t);
              }
            });

            return fixed as any;
          }

          return {
            state: {
              pendingTransactions: [],
            },
          };
        },
        setItem: async (name, newValue) => {
          await AsyncStorage.setItem(name, JSON.stringify(newValue));
        },
        removeItem: async (name) => {
          await AsyncStorage.removeItem(name);
        },
      },
    }
  )
);
