import { ModalProps } from '@/components/Modal';
import React from 'react';
import { create } from 'zustand';

interface State {
  modalOpen: boolean;
  modalTitle: string;
  modalContent: React.ReactNode;
  modalOptions: ModalProps;
  modalOnClose: (() => unknown) | null;
  setModalOpen: (open: boolean) => unknown;
  setModalTitle: (title: string) => unknown;
  setModalContent: (content: React.ReactNode) => unknown;
  setModalOnClose: (onClose: (() => unknown) | null) => unknown;
  setModalOptions: (options: ModalProps) => void;
}

const initialState = {
  modalOpen: false,
  modalTitle: '',
  modalContent: null,
  modalOnClose: null,
  modalOptions: {},
};

export const useModal = create<State>((set, get) => ({
  ...initialState,
  setModalOpen: (open) => {
    set({
      modalOpen: open,
    });
  },
  setModalTitle: (title: string) => {
    set({
      modalTitle: title,
    });
  },
  setModalContent: (content) => {
    set({
      modalContent: content,
    });
  },
  setModalOnClose: (onClose) => {
    set({
      modalOnClose: onClose,
    });
  },
  setModalOptions: (options: ModalProps) => {
    set({
      modalOptions: options,
    });
  },
}));

export const useAltModal = create<State>((set, get) => ({
  ...initialState,
  setModalOpen: (open) => {
    set({
      modalOpen: open,
    });
  },
  setModalTitle: (title: string) => {
    set({
      modalTitle: title,
    });
  },
  setModalContent: (content) => {
    set({
      modalContent: content,
    });
  },
  setModalOnClose: (onClose) => {
    set({
      modalOnClose: onClose,
    });
  },
  setModalOptions: (options: ModalProps) => {
    set({
      modalOptions: options,
    });
  },
}));
