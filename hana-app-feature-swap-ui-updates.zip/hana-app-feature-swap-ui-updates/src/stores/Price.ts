import { useChainServices } from '@/stores/ChainServices';
import { useVault } from '@/stores/Vault';
import { BigNumber } from '@/utils/bignumber';
import { ChainDetails, chainForChainID, chainForChainWallet, chains } from '@/utils/chains';
import { CoinType, getNativeTokenPrice, getTokenPrice } from '@/utils/coinTypes';
import { ZERO } from '@/utils/constants';
import { NetworkDetails } from '@/utils/networks';
import { tokensForChainWallet } from '@/utils/wallet';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { isNil } from 'lodash-es';
import { create, StateCreator } from 'zustand';
import { persist, PersistOptions } from 'zustand/middleware';

interface State {
  nativePrices: Map<string, BigNumber>;
  getNativePrice: (chain: ChainDetails) => BigNumber;
  getNativePriceForSymbol: (symbol: string) => BigNumber;
  getNativePriceForNetwork: (network: NetworkDetails) => BigNumber;
  tokenPrices: Map<string, BigNumber>;
  getTokenPrice: (contractAddress: string) => BigNumber;
  refreshPrices: () => unknown;
}

type Persist = (config: StateCreator<State>, options: PersistOptions<State>) => StateCreator<State>;

export const usePrices = create<State>(
  (persist as Persist)(
    (set, get) => ({
      nativePrices: new Map<CoinType, BigNumber>(),
      getNativePrice: (chain) => {
        const { otherNetwork: testnet } = useChainServices.getState();

        if (!isNil(testnet)) return ZERO;

        return get().nativePrices.get(chain.token.symbol) || ZERO;
      },
      getNativePriceForSymbol: (symbol) => {
        return get().nativePrices.get(symbol) || ZERO;
      },
      getNativePriceForNetwork: (network: NetworkDetails) => {
        const chainDetails = chainForChainID(network.chainType);

        return chainDetails ? get().getNativePrice(chainDetails) : ZERO;
      },
      tokenPrices: new Map<string, BigNumber>(),
      getTokenPrice: (contractAddress) => {
        return get().tokenPrices.get(contractAddress) || ZERO;
      },
      refreshPrices: async () => {
        const { nativePrices } = get();
        await Promise.all(
          chains.map(async (chain) => {
            const price = await getNativeTokenPrice(chain);
            if (price) {
              nativePrices.set(chain.token.symbol, price);
            }
          })
        );
        set({
          nativePrices,
        });
        const { getActiveWallet } = useVault.getState();
        const activeWallet = getActiveWallet();

        const { tokenPrices } = get();

        if (activeWallet) {
          await Promise.all(
            activeWallet.chainWallets.map(async (wallet) => {
              const chain = chainForChainWallet(wallet);
              const tokens = tokensForChainWallet(wallet);

              chain &&
                tokens.forEach(async (token) => {
                  const { contract } = token;

                  if (contract) {
                    const price = await getTokenPrice(chain, contract);

                    price && tokenPrices.set(contract, price);
                  }
                });
            })
          );
          set({
            tokenPrices,
          });
        }

        console.debug('refreshPrices done');
      },
    }),
    {
      name: 'price-storage',
      storage: {
        // NOTE: This is a hack to get around the fact that zustand doesn't support serializing Maps
        getItem: async (name) => {
          const str = await AsyncStorage.getItem(name);

          if (str) {
            const nativePrices = new Map(JSON.parse(str).state.nativePrices);
            // Convert all values to BigNumber
            nativePrices.forEach((value, key) => {
              nativePrices.set(key, new BigNumber(value as string));
            });

            const tokenPrices = new Map(JSON.parse(str).state.tokenPrices);
            // Convert all values to BigNumber
            tokenPrices.forEach((value, key) => {
              tokenPrices.set(key, new BigNumber(value as string));
            });

            return {
              state: {
                ...JSON.parse(str).state,
                nativePrices,
                tokenPrices,
              },
            };
          }

          return {
            state: {
              nativePrices: new Map(),
              tokenPrices: new Map(),
            },
          };
        },
        // NOTE: This is a hack to get around the fact that zustand doesn't support serializing Maps
        setItem: async (name, newValue) => {
          const str = JSON.stringify({
            state: {
              ...newValue.state,
              nativePrices: Array.from(newValue.state.nativePrices),
              tokenPrices: Array.from(newValue.state.tokenPrices),
            },
          });

          await AsyncStorage.setItem(name, str);
        },
        removeItem: async (name) => {
          await AsyncStorage.removeItem(name);
        },
      },
    }
  )
);
