import { STORAGE_KEY } from '@/utils/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as LocalAuthentication from 'expo-local-authentication';
import { isNil } from 'lodash-es';
import { create } from 'zustand';

interface Flags {
  confirmSeedPhrase: boolean;
  configureChains: boolean;
  acceptDisclaimer: boolean;
  enableBiometrics: boolean;
}

type OnboardingFlagName = keyof Flags;

const defaultOnboardingFlags: Flags = {
  confirmSeedPhrase: false,
  configureChains: false,
  acceptDisclaimer: false,
  enableBiometrics: false,
};

interface State extends Flags {
  initialize: () => unknown;
  ready: boolean;
  update: (name: OnboardingFlagName, value: boolean) => void;
  reset: () => void;
}

export const useOnboardingFlags = create<State>((set, get) => ({
  ...defaultOnboardingFlags,
  initialize: async () => {
    const [flags, hasHardware, isEnrolled] = await Promise.all([
      AsyncStorage.getItem(STORAGE_KEY.ONBOARDING_FLAGS),
      LocalAuthentication.hasHardwareAsync(),
      LocalAuthentication.isEnrolledAsync(),
    ]);

    let updatedFlags = (!isNil(flags) ? JSON.parse(flags) : {}) as Flags;

    // Don't show biometrics prompt if it's not available
    if (!hasHardware || !isEnrolled) updatedFlags.enableBiometrics = true;

    set({
      ...updatedFlags,
      ready: true,
    });
  },
  ready: false,
  update: (name: OnboardingFlagName, value: boolean) => {
    set((state) => {
      const updatedFlags = { ...state, [name]: value };
      AsyncStorage.setItem(STORAGE_KEY.ONBOARDING_FLAGS, JSON.stringify(updatedFlags));
      return updatedFlags;
    });
  },
  reset: () => {
    set(defaultOnboardingFlags);
    AsyncStorage.removeItem(STORAGE_KEY.ONBOARDING_FLAGS);
  },
}));
