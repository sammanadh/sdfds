import { ChainWallet, CustomNetwork } from '@/models/Vault';
import { ChainService } from '@/models/ChainService';
import { EthereumService } from '@/services/chainServices/EthereumService';
import { ICONService } from '@/services/chainServices/IconService';
import { NearService } from '@/services/chainServices/NearService';
import { PolkadotService } from '@/services/chainServices/PolkadotService';
import { ChainDetails, ChainID, chains } from '@/utils/chains';
import { CoinType } from '@/utils/coinTypes';
import { STORAGE_KEY } from '@/utils/constants';
import {
  arcticEvmNetworks,
  binanceNetworks,
  EthereumNetworkDetails,
  EthereumNetworkRef,
  ethereumNetworks,
  evmChains,
  HavahNetworkDetails,
  HavahNetworkRef,
  havahNetworks,
  IconNetworkDetails,
  IconNetworkRef,
  iconNetworks,
  isEvmChainID,
  mainnets,
  moonbeamNetworks,
  NearNetworkDetails,
  NetworkDetails,
  networkDetailsForChain,
  networkDetailsForTestnet,
  TestnetConfig,
  testnets,
  wanchainNetworks,
} from '@/utils/networks';
import { isCustomNetwork, isTestnetConfig } from '@/utils/types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { isEqual, isNil } from 'lodash-es';
import { create } from 'zustand';

interface State {
  initialize: () => unknown;
  ready: boolean;
  connectedChains: ChainDetails[];
  services: Map<ChainID, ChainService>;
  selectChain: (chainId: ChainID) => Promise<ChainDetails | undefined>;
  selectChains: (selectedChainIds: Array<ChainID>) => unknown;
  deselectChain: (chainId: ChainID) => Promise<boolean>;
  selectingChains: ChainID[];
  otherNetwork: TestnetConfig | CustomNetwork | null;
  selectOtherNetwork: (testnet: TestnetConfig | CustomNetwork | null) => unknown;
  servicesUpdatedAt: Date;
}

function chainServiceForChain(chain: ChainDetails) {
  const { otherNetwork } = useChainServices.getState();

  // if (
  //   (otherNetwork as TestnetConfig)?.chainType &&
  //   (otherNetwork as TestnetConfig)?.chainType !== chain.id
  // ) {
  //   return undefined;
  // }

  if ((otherNetwork as CustomNetwork)?.id && (otherNetwork as CustomNetwork)?.chain !== chain.id) {
    return undefined;
  }

  switch (chain.coinType) {
    case CoinType.ICX:
      if (
        (otherNetwork as TestnetConfig)?.chainType &&
        (otherNetwork as TestnetConfig)?.chainType === ChainID.ICON
      ) {
        const testnet = otherNetwork as TestnetConfig;
        const network = iconNetworks.find((network) => network.ref === testnet.ref)!;

        return new ICONService(network);
      }

      if (
        (otherNetwork as CustomNetwork)?.id &&
        (otherNetwork as CustomNetwork)?.chain === ChainID.ICON
      ) {
        const customNetwork = otherNetwork as CustomNetwork;

        const networkDetails = {
          ref: IconNetworkRef.Custom,
          chainType: ChainID.ICON,
          name: customNetwork.name,
          shortName: customNetwork.name,
          networkId: customNetwork.networkId,
          providerApi: customNetwork.providerRpcUrl,
          blockExplorerApi: customNetwork.blockExplorerApi,
          blockExplorerUrl: customNetwork.blockExplorerUrl,
          token: {
            symbol: customNetwork.symbol,
          },
        } as IconNetworkDetails;

        return new ICONService(networkDetails);
      }

      return new ICONService(mainnets[ChainID.ICON] as IconNetworkDetails);

    case CoinType.HVH:
      if (
        (otherNetwork as TestnetConfig)?.chainType &&
        (otherNetwork as TestnetConfig)?.chainType === ChainID.HAVAH
      ) {
        const testnet = otherNetwork as TestnetConfig;
        const network = havahNetworks.find((network) => network.ref === testnet.ref)!;

        return new ICONService(network);
      }

      if (
        (otherNetwork as CustomNetwork)?.id &&
        (otherNetwork as CustomNetwork)?.chain === ChainID.HAVAH
      ) {
        const customNetwork = otherNetwork as CustomNetwork;

        const networkDetails = {
          ref: HavahNetworkRef.Custom,
          chainType: ChainID.HAVAH,
          name: customNetwork.name,
          shortName: customNetwork.name,
          networkId: customNetwork.networkId,
          providerApi: customNetwork.providerRpcUrl,
          blockExplorerApi: customNetwork.blockExplorerApi,
          blockExplorerUrl: customNetwork.blockExplorerUrl,
          token: {
            symbol: customNetwork.symbol,
          },
        } as HavahNetworkDetails;

        return new ICONService(networkDetails);
      }

      return new ICONService(mainnets[ChainID.HAVAH] as HavahNetworkDetails);

    case CoinType.ETH:
      if ((otherNetwork as TestnetConfig)?.chainType) {
        const testnet = otherNetwork as TestnetConfig;
        const networkDetails = networkDetailsForTestnet(testnet) as EthereumNetworkDetails;

        if (networkDetails) {
          return new EthereumService(networkDetails);
        }
      }

      if (
        (otherNetwork as CustomNetwork)?.id &&
        isEvmChainID((otherNetwork as CustomNetwork)?.chain)
      ) {
        const customNetwork = otherNetwork as CustomNetwork;

        const networkDetails = {
          chainId: customNetwork.networkId,
          ref: EthereumNetworkRef.Custom,
          chainType: customNetwork.chain,
          name: customNetwork.name,
          shortName: customNetwork.name,
          providerApi: customNetwork.providerRpcUrl,
          blockExplorerApi: customNetwork.blockExplorerApi,
          blockExplorerUrl: customNetwork.blockExplorerUrl,
          token: {
            symbol: customNetwork.symbol,
          },
        } as EthereumNetworkDetails;

        return new EthereumService(networkDetails);
      }

      if (evmChains.includes(chain.id)) {
        if (chain.isTestnet === true) {
          // Get this testnet from testnets
          const testnet = (testnets[chain.id] as NetworkDetails[])?.[0];

          console.debug('testnet', testnet);
          const network = testnet as EthereumNetworkDetails;
          return new EthereumService(network);
        } else {
          const network = mainnets[chain.id] as EthereumNetworkDetails;
          return new EthereumService(network);
        }
      }

      return new EthereumService(mainnets[ChainID.Ethereum] as EthereumNetworkDetails);

    case CoinType.DOT:
    case CoinType.KSM:
      const network = networkDetailsForChain(chain);
      return network && new PolkadotService(network);

    case CoinType.NEAR:
      const nearNetwork = networkDetailsForChain(chain) as NearNetworkDetails;
      return nearNetwork && new NearService(nearNetwork);

    default:
      return undefined;
  }
}

async function initialize() {
  // Testnets
  // Note: remember to set these first as connectedChains rely on these data
  const testnetData = await AsyncStorage.getItem(STORAGE_KEY.TESTNET);

  const testnet = !isNil(testnetData) ? JSON.parse(testnetData) : null;

  if (testnet) {
    useChainServices.setState({
      otherNetwork: testnet,
    });
  }

  const customNetworkData = await AsyncStorage.getItem(STORAGE_KEY.CUSTOM_NETWORK);
  const customNetwork = !isNil(customNetworkData) ? JSON.parse(customNetworkData) : null;

  if (customNetwork) {
    useChainServices.setState({
      otherNetwork: customNetwork,
    });
  }

  updateServices();
}

async function updateServices() {
  const data = await AsyncStorage.getItem(STORAGE_KEY.CONNECTED_CHAINS);
  const chainIds: Array<ChainID> = !isNil(data) ? JSON.parse(data) : [];

  const connectedChains = chains.filter(
    (chain) =>
      chain.enabled &&
      (chainIds.includes(chain.id) ||
        (chain.affiliatedChainID && chainIds.includes(chain.affiliatedChainID))) &&
      !chain.isTestnet
  );

  const { services, otherNetwork } = useChainServices.getState();

  services.clear();

  connectedChains.forEach((chain) => {
    const chainService = chainServiceForChain(chain);

    chainService && services.set(chain.id, chainService);
  });

  // Make sure to initialise services for testnet and custom networks

  if (isTestnetConfig(otherNetwork) && !Object.keys(services).includes(otherNetwork.chainType)) {
    const chainService = chainServiceForChain(
      chains.find((chain) => chain.id === otherNetwork.chainType)!
    );

    chainService && services.set(otherNetwork.chainType, chainService);

    const affiliatedChain = chains.find(
      (chain) => chain.affiliatedChainID === otherNetwork.chainType
    );

    console.debug('testnet affiliatedChain', affiliatedChain);

    if (affiliatedChain) {
      const affiliatedChainService = chainServiceForChain(affiliatedChain);

      affiliatedChainService && services.set(affiliatedChain.id, affiliatedChainService);
    }
  }

  if (isCustomNetwork(otherNetwork) && !Object.keys(services).includes(otherNetwork.chain)) {
    const chainService = chainServiceForChain(
      chains.find((chain) => chain.id === otherNetwork.chain)!
    );

    chainService && services.set(otherNetwork.chain, chainService);
  }

  useChainServices.setState({
    connectedChains,
    services,
    ready: true,
    servicesUpdatedAt: new Date(),
  });
}

export function serviceForChainID(chainID: ChainID) {
  const chain = chains.find((chain) => chain.id === chainID);

  const { services } = useChainServices.getState();

  return chain && services.get(chain.id);
}

export function serviceForChainWallet(wallet: ChainWallet) {
  return serviceForChainID(wallet.type);
}

export const useChainServices = create<State>((set, get) => ({
  initialize,
  ready: false,
  connectedChains: [],
  services: new Map<ChainID, ChainService>(),
  selectChain: async (chainId: ChainID) => {
    set({
      selectingChains: [...get().selectingChains, chainId],
    });

    const { connectedChains, services } = get();

    const selectedChainIds = connectedChains.map((chain) => chain.id);

    if (selectedChainIds.includes(chainId)) return;

    selectedChainIds.push(chainId);

    await AsyncStorage.setItem(STORAGE_KEY.CONNECTED_CHAINS, JSON.stringify(selectedChainIds));

    const selectedChain = chains.find((chain) => chain.id === chainId);

    if (selectedChain) {
      const chainService = chainServiceForChain(selectedChain);

      chainService && services.set(selectedChain.id, chainService);

      set({
        connectedChains: [...connectedChains, selectedChain],
        services,
      });
    }

    set({
      selectingChains: get().selectingChains.filter((id) => id !== chainId),
    });

    updateServices();

    return selectedChain;
  },
  selectChains: async (selectedChainIds: Array<ChainID>) => {
    const { connectedChains, services } = get();

    const hasChanged = !isEqual(
      selectedChainIds.sort(),
      connectedChains.map((chain) => chain.id).sort()
    );
    if (!hasChanged) return;

    await AsyncStorage.setItem(STORAGE_KEY.CONNECTED_CHAINS, JSON.stringify(selectedChainIds));
    const selectedChains = chains.filter((chain) => selectedChainIds.includes(chain.id));

    selectedChains.forEach((chain) => {
      const chainService = chainServiceForChain(chain);

      chainService && services.set(chain.id, chainService);
    });

    set({
      connectedChains: selectedChains,
      services,
    });

    updateServices();
  },
  deselectChain: async (chainId: ChainID) => {
    const { connectedChains, services } = get();

    const data = await AsyncStorage.getItem(STORAGE_KEY.CONNECTED_CHAINS);
    const selectedChainIds: Array<ChainID> = !isNil(data) ? JSON.parse(data) : [];

    if (!selectedChainIds.includes(chainId)) return false;

    const index = selectedChainIds.indexOf(chainId);

    selectedChainIds.splice(index, 1);

    AsyncStorage.setItem(STORAGE_KEY.CONNECTED_CHAINS, JSON.stringify(selectedChainIds));

    // Remove the chain service
    services.delete(chainId);

    // Remove the affiliated chain service
    const affiliatedChain = chains.find((chain) => chain.affiliatedChainID === chainId);

    if (affiliatedChain) {
      services.delete(affiliatedChain.id);
    }

    set({
      connectedChains: connectedChains.filter((chain) => chain.id !== chainId),
      services,
    });

    updateServices();

    return true;
  },
  selectingChains: [],
  otherNetwork: null,
  selectOtherNetwork: async (network: TestnetConfig | CustomNetwork | null) => {
    if ((network as TestnetConfig)?.chainType) {
      await AsyncStorage.setItem(STORAGE_KEY.TESTNET, JSON.stringify(network));
      await AsyncStorage.removeItem(STORAGE_KEY.CUSTOM_NETWORK);
    } else if ((network as CustomNetwork)?.id) {
      await AsyncStorage.setItem(STORAGE_KEY.CUSTOM_NETWORK, JSON.stringify(network));
      await AsyncStorage.removeItem(STORAGE_KEY.TESTNET);
    } else {
      await AsyncStorage.removeItem(STORAGE_KEY.CUSTOM_NETWORK);
      await AsyncStorage.removeItem(STORAGE_KEY.TESTNET);
    }

    set({
      otherNetwork: network,
    });

    updateServices();
  },
  servicesUpdatedAt: new Date(),
}));
