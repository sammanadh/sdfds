import { ToastType } from '@/components/Toast.types';
import { create } from 'zustand';

interface State {
  hideTabBar: boolean;
  setHideTabBar: (hide: boolean) => unknown;
  headerHeight: number;
  setHeaderHeight: (height: number) => unknown;
  toastType: ToastType;
  toastMessage: string | null;
  setToastMessage: (message: string | null, type?: ToastType) => unknown;
}

export const useNavigationStore = create<State>((set, get) => ({
  hideTabBar: false,
  setHideTabBar: (hide: boolean) => {
    set({
      hideTabBar: hide,
    });
  },
  headerHeight: 0,
  setHeaderHeight: (height) => {
    set({
      headerHeight: height,
    });
  },
  toastType: ToastType.success | ToastType.error | ToastType.info,
  toastMessage: null,
  setToastMessage: (message, type) => {
    set({
      toastMessage: message,
      toastType: type!,
    });
  },
}));
