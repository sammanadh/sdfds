import { ToastType } from '@/components/Toast.types';
import {
  AuthorizedDApp,
  ChainWallet,
  ChainWalletSubstrateSignatureType,
  Contact,
  CustomNetwork,
  RealmWallet,
  Token,
  TokenBalance,
  Wallet,
  WalletType,
} from '@/models/Vault';
import { EvmChainService, SubstrateChainService } from '@/models/ChainService';
import { NearService } from '@/services/chainServices/NearService';
import { useChainServices } from '@/stores/ChainServices';
import { useNavigationStore } from '@/stores/Navigation';
import { useOnboardingFlags } from '@/stores/OnboardingFlags';
import { useSettings } from '@/stores/Settings';
import { useTheme } from '@/stores/Theme';
import { toNumber } from '@/utils/bignumber';
import { ChainDetails, ChainID, chains, isSubstrateChain, testnetChains } from '@/utils/chains';
import { CoinType, getCoinHDPath } from '@/utils/coinTypes';
import { REALM_PATH, STORAGE_KEY, SubstrateKeyDerivationMethod, ZERO } from '@/utils/constants';
import { decrypt, encrypt } from '@/utils/encryption';
import { LedgerAddresses } from '@/utils/ledger';
import { mainnets, TestnetConfig } from '@/utils/networks';
import {
  createKeystore,
  derivePrivateKey,
  getCoinWalletAddressUsingMnemonic,
  getCoinWalletAddressUsingPrivateKey,
  isChainWalletValid,
  tokensForChainWallet,
} from '@/utils/wallet';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { generateMnemonic, mnemonicToSeed, validateMnemonic } from 'bip39';
import * as SecureStore from 'expo-secure-store';
import { isEmpty, isNil, last, without } from 'lodash-es';
import { PermissionsAndroid, Platform } from 'react-native';
import RNFS from 'react-native-fs';
import Share from 'react-native-share';
import Realm from 'realm';
import { create } from 'zustand';

const realmConfig: Realm.Configuration = {
  path: REALM_PATH.VAULT,
  schemaVersion: 2, // TODO: This bump might not be enough, as it might be clashing with other feature branches
  schema: [
    Wallet.schema,
    ChainWallet.schema,
    Token.schema,
    TokenBalance.schema,
    Contact.schema,
    CustomNetwork.schema,
    AuthorizedDApp.schema,
  ],
};

const SecureStoreOptions: SecureStore.SecureStoreOptions = {
  keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
};

type AuthenticateCredentials =
  | { passcode: string; useBiometrics?: boolean }
  | { passcode?: string; useBiometrics: boolean };

export enum ChainWalletCreationStatus {
  NOT_CREATED= 1,
  LOADING = 2,
  CREATED = 3
}

interface CreateVaultCredentials {
  passcode: string;
}

interface ImportVaultCredentials {
  seedPhrase: string;
  passcode: string;
}

interface InternalState {
  encryptionKey: string | null;
}

const useInternalState = create<InternalState>(() => ({
  encryptionKey: null,
}));

interface State {
  initialize: () => unknown;
  ready: boolean;
  isUnlocked: boolean;
  setIsUnlocked: (isUnlocked: boolean) => void;
  hasVault: boolean;
  wallets: Array<RealmWallet>;
  getActiveWallet: () => RealmWallet | null;
  getActiveChainWallets: () => ChainWallet[];
  getActiveWalletAllChainWallets: () => ChainWallet[];

  verifyCredentials(credentials: AuthenticateCredentials): Promise<boolean>;
  unlockVault(credentials: AuthenticateCredentials): Promise<void>;
  lockVault(): Promise<void>;

  createVault(credentials: CreateVaultCredentials): Promise<string>;
  importVault(credentials: ImportVaultCredentials): Promise<void>;
  confirmVault(seedPhrase: string): Promise<void>;
  backupVault(credentials: AuthenticateCredentials): Promise<string>;
  resetVault(): Promise<void>;

  isCreatingWallet: boolean;
  chainWalletCreatingStatus: ChainWalletCreationStatus;
  createWallet(name?: string): Promise<RealmWallet>;
  selectWallet(walletId: string): Promise<void>;
  renameWallet(walletId: string, name: string): void;
  removeWallet(walletId: string): void;
  backupWallet(
    walletId: string,
    chainId: ChainID,
    credentials: AuthenticateCredentials,
    keystorePassword?: string
  ): Promise<void | string>;

  importPrivateKey(privateKey: string, name?: string): Promise<RealmWallet | void>;
  importLedger(ledgerAddresses: LedgerAddresses, ledgerBleId: string | null): Promise<RealmWallet>;
  importLedgerExistingWallet(
    ledgerAddresses: LedgerAddresses,
    ledgerBleId: string | null
  ): Promise<void>;

  refreshWalletBalances: () => unknown;

  changePasscode(passcode: string, currentPasscode: string): Promise<void>;

  realm: Realm | null;

  lastCreatedWalletAt: Date | null;
}

async function verifyCredentials(credentials: AuthenticateCredentials) {
  if (credentials.useBiometrics) {
    return true;
  }
  if (isNil(credentials.passcode)) {
    throw new Error(`Passcode is required`);
  }

  const encryptedMnemonic = await SecureStore.getItemAsync(
    STORAGE_KEY.MNEMONIC,
    SecureStoreOptions
  );
  if (isNil(encryptedMnemonic)) {
    throw new Error(`Encrypted mnemonic doesn't exist`);
  }

  try {
    await decrypt(credentials.passcode, encryptedMnemonic);
    return true;
  } catch (error: any) {
    console.warn(`Failed verifying credentials.`, error.message);
    return false;
  }
}

async function openRealm() {
  const realm = await Realm.open(realmConfig);
  useVault.setState({
    realm,
  });

  // Set wallets
  const wallets = realm.objects<Wallet>(Wallet.schema.name);
  useVault.setState({
    wallets: [...wallets],
  });

  try {
    wallets.addListener(() => {
      useVault.setState({
        wallets: [...wallets],
      });
    });
  } catch (error: any) {
    console.warn(`Failed updating wallets state.`, error.message);
  }

  return realm;
}

async function closeRealm() {
  useVault.setState({
    wallets: [],
  });

  const { realm } = useVault.getState();
  realm?.removeAllListeners();
  realm?.close();

  useVault.setState({
    realm: null,
  });
}

async function unlockVault(credentials: AuthenticateCredentials) {
  const { isUnlocked, hasVault, setIsUnlocked } = useVault.getState();
  if (!hasVault) {
    throw new Error(`You don't have a vault yet`);
  }
  if (isUnlocked) {
    throw new Error(`Vault is already unlocked`);
  }

  let encryptionKey: string;
  if (credentials.useBiometrics) {
    // Get encryptionKey from Secure Store
    const storedEncryptionKey = await SecureStore.getItemAsync(
      STORAGE_KEY.ENCRYPTION_KEY,
      SecureStoreOptions
    );
    if (isNil(storedEncryptionKey)) {
      throw new Error(`Encryption key doesn't exist`);
    }
    encryptionKey = storedEncryptionKey;
  } else {
    if (isNil(credentials.passcode)) {
      throw new Error(`Passcode is required`);
    }

    encryptionKey = credentials.passcode;
  }

  if (!(await verifyCredentials(credentials))) {
    throw new Error(`Invalid credentials`);
  }

  const encryptedMnemonic = await SecureStore.getItemAsync(
    STORAGE_KEY.MNEMONIC,
    SecureStoreOptions
  );
  if (isNil(encryptedMnemonic)) {
    throw new Error(`You don't have a vault`);
  }
  const mnemonic = await decrypt(encryptionKey, encryptedMnemonic);
  if (!validateMnemonic(mnemonic)) {
    throw new Error(`You don't have a vault`);
  }

  // Verify that user has seed key stored, won't have if vault was created before storing seed key
  const encryptedSeedKey = await SecureStore.getItemAsync(STORAGE_KEY.MNEMONIC, SecureStoreOptions);
  if (isNil(encryptedSeedKey)) {
    const seedKey = (await mnemonicToSeed(mnemonic)).toString('hex');
    const encryptedSeedKey = await encrypt(encryptionKey, seedKey);
    await SecureStore.setItemAsync(STORAGE_KEY.SEED_KEY, encryptedSeedKey, SecureStoreOptions);
  }

  useInternalState.setState({
    encryptionKey,
  });

  await openRealm();

  setIsUnlocked(true);
}

async function lockVault() {
  const { isUnlocked, setIsUnlocked } = useVault.getState();
  if (!isUnlocked) {
    throw new Error(`Vault is already locked`);
  }

  useInternalState.setState({
    encryptionKey: null,
  });

  await closeRealm();

  setIsUnlocked(false);
}

export async function createChainWallet(
  wallet: RealmWallet,
  chain: ChainDetails,
  providedPrivateKey?: string
) {
  console.debug('🪄 Creating chain wallet for chain:', chain);

  try {
    const { realm } = useVault.getState();
    const { substrateKeyDerivationMethod } = useSettings.getState();
    const { encryptionKey } = useInternalState.getState();
    const encryptedMnemonic = await SecureStore.getItemAsync(
      STORAGE_KEY.MNEMONIC,
      SecureStoreOptions
    );
    const encryptedSeedKey = await SecureStore.getItemAsync(
      STORAGE_KEY.SEED_KEY,
      SecureStoreOptions
    );
    if (isNil(encryptionKey) || isNil(encryptedMnemonic) || isNil(encryptedSeedKey)) {
      throw new Error(`You don't have a vault yet`);
    }
    const [mnemonic, seedKey] = await Promise.all([
      decrypt(encryptionKey, encryptedMnemonic),
      decrypt(encryptionKey, encryptedSeedKey),
    ]);

    let address: string;
    if (wallet.type === WalletType.PK) {
      let privateKey = providedPrivateKey;
      if (isNil(privateKey)) {
        const encryptedPrivateKey = await SecureStore.getItemAsync(
          `${STORAGE_KEY.PRIVATE_KEY}.${wallet.id}`,
          SecureStoreOptions
        );
        if (isNil(encryptedPrivateKey)) throw new Error(`Failed getting private key`);
        privateKey = await decrypt(encryptionKey, encryptedPrivateKey);
      }
      address = await getCoinWalletAddressUsingPrivateKey(privateKey, chain);
    } else if (wallet.type === WalletType.HD) {
      if (
        (chain.coinType === CoinType.DOT ||
          chain.coinType === CoinType.KSM ||
          chain.coinType === CoinType.NEAR) &&
        substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.MnemonicSr25519
      ) {
        address = await getCoinWalletAddressUsingMnemonic(mnemonic, wallet, chain)!;
      } else {
        const index = wallet.hdIndex!;
        const hdPath = getCoinHDPath(chain.coinType, index);
        const privateKey = await derivePrivateKey(seedKey, hdPath);
        address = await getCoinWalletAddressUsingPrivateKey(privateKey, chain);
      }
    } else {
      throw new Error(
        `Can't create chain wallet for wallet "${wallet.id}" and chain "${chain.id}"`
      );
    }

    if (
      !wallet.chainWallets.some(
        (chainWallet) => chainWallet.type === chain.id && isChainWalletValid(chainWallet)
      )
    ) {
      realm?.write(() => {
        const chainWallet = new ChainWallet(chain.id, address, wallet.hdIndex);

        if (isSubstrateChain(chain.id)) {
          if (substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.Bip44Ed25519) {
            chainWallet.substrateSignatureType = ChainWalletSubstrateSignatureType.ed25519;
          }

          if (substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.MnemonicSr25519) {
            chainWallet.substrateSignatureType = ChainWalletSubstrateSignatureType.sr25519;
          }
        }

        // Remove existingWallets
        wallet.chainWallets = wallet.chainWallets.filter((cw) => cw.type !== chain.id);

        // Add new wallet
        wallet.chainWallets.push(chainWallet);
      });

      // Trigger update
      useVault.setState({
        lastCreatedWalletAt: new Date(),
      });
    }
    console.debug('✅ Created chain wallet for chain:', chain);
  } catch (err) {
    throw err;
  }
}

async function createWallet(name?: string, providedRealm?: Realm) {
  useVault.setState({
    isCreatingWallet: true,
  });

  const { realm } = useVault.getState();
  if (isNil(realm) && isNil(providedRealm)) {
    throw new Error(`Vault realm isn't open`);
  }
  const vaultRealm = providedRealm ?? realm!;

  let wallet: RealmWallet;
  vaultRealm.write(() => {
    const wallets = vaultRealm.objects<Wallet>(Wallet.schema.name);
    const activeWallets = wallets.filtered(`isActive == true`);
    activeWallets.forEach((wallet) => {
      wallet.isActive = false;
    });

    const hdWallets = wallets.filtered(`type == '${WalletType.HD}'`);
    const highestIndex = hdWallets.reduce(
      (highestIndex, wallet) => (wallet.hdIndex! > highestIndex ? wallet.hdIndex! : highestIndex),
      -1
    );
    const nextIndex = highestIndex + 1;
    const walletName = name ?? `Wallet ${nextIndex + 1}`;

    wallet = vaultRealm.create<Wallet>(
      Wallet.schema.name,
      new Wallet(WalletType.HD, walletName, nextIndex)
    );
  });

  const { connectedChains } = useChainServices.getState();

  const chains = connectedChains.concat(testnetChains);

  await Promise.all(chains.map((chain) => createChainWallet(wallet, chain)));

  useVault.setState({
    lastCreatedWalletAt: new Date(),
    isCreatingWallet: false,
  });

  return wallet!;
}

async function renameWallet(walletId: string, name: string) {
  const { realm, wallets } = useVault.getState();
  const wallet = wallets.find((wallet) => wallet.id === walletId);

  if (wallet && realm) {
    realm?.write(() => {
      wallet.name = name;
    });
  }
}

async function removeWallet(walletId: string) {
  const { realm, wallets, selectWallet } = useVault.getState();
  const wallet = wallets.find((wallet) => wallet.id === walletId);

  if (wallet && realm) {
    const walletWasActive = wallet.isActive;

    realm.write(() => {
      realm.delete(wallet);
    });

    if (walletWasActive && wallets.length > 0) {
      const firstWallet = wallets[0];
      selectWallet(firstWallet.id);
    }
  }

  // Remove private key from secure store
  await SecureStore.deleteItemAsync(`${STORAGE_KEY.PRIVATE_KEY}.${walletId}`);
  let importedWalletIds: Array<string> = [];
  try {
    const storedImportedWalletIds = await SecureStore.getItemAsync(
      STORAGE_KEY.IMPORTED_WALLETS,
      SecureStoreOptions
    );
    if (!isNil(storedImportedWalletIds)) {
      importedWalletIds = JSON.parse(storedImportedWalletIds);
    }
  } catch (error) {}
  await SecureStore.setItemAsync(
    STORAGE_KEY.IMPORTED_WALLETS,
    JSON.stringify(without(importedWalletIds, walletId)),
    SecureStoreOptions
  );
}

async function importPrivateKey(privateKey: string, name?: string): Promise<RealmWallet | void> {
  const { realm } = useVault.getState();
  if (isNil(realm)) {
    throw new Error(`Vault realm isn't open`);
  }

  const wallets = realm.objects<Wallet>(Wallet.schema.name);

  const { encryptionKey } = useInternalState.getState();
  const existingPrivateKeys = await Promise.all(
    wallets
      .filter((wallet) => wallet.type === WalletType.PK)
      .map(async (wallet) => {
        const encryptedPrivateKey = await SecureStore.getItemAsync(
          `${STORAGE_KEY.PRIVATE_KEY}.${wallet.id}`,
          SecureStoreOptions
        );
        if (isNil(encryptionKey) || isNil(encryptedPrivateKey)) return '';
        return decrypt(encryptionKey, encryptedPrivateKey);
      })
  );
  if (existingPrivateKeys.includes(privateKey)) {
    throw new Error(`This wallet is already imported`);
  }

  let wallet: RealmWallet;
  realm?.write(() => {
    let walletName = name;
    if (isNil(walletName)) {
      const importedWallets = wallets.filter(
        (wallet) => wallet.type === WalletType.PK || wallet.type === WalletType.DotKeystore
      );
      walletName = `Imported Wallet ${importedWallets.length + 1}`;
    }

    const activeWallets = wallets.filtered(`isActive == true`);
    activeWallets.forEach((wallet) => (wallet.isActive = false));

    wallet = realm.create<Wallet>(Wallet.schema.name, new Wallet(WalletType.PK, walletName));
  });

  // Encrypt and store private key in SecureStore
  const encryptedPrivateKey = await encrypt(encryptionKey!, privateKey);
  await SecureStore.setItemAsync(
    `${STORAGE_KEY.PRIVATE_KEY}.${wallet!.id}`,
    encryptedPrivateKey,
    SecureStoreOptions
  );
  const storedPrivateKey = await SecureStore.getItemAsync(
    `${STORAGE_KEY.PRIVATE_KEY}.${wallet!.id}`,
    SecureStoreOptions
  );
  if ((await decrypt(encryptionKey!, storedPrivateKey!)) !== privateKey) {
    await SecureStore.deleteItemAsync(
      `${STORAGE_KEY.PRIVATE_KEY}.${wallet!.id}`,
      SecureStoreOptions
    );
    realm.delete(wallet!);
    throw new Error(`Failed storing imported private key`);
  }

  // Keep an array of known imported wallets so that we can clean them up when a user resets
  // Private keys will persist across re-installing the app, so could potentially be stored permanently
  let importedWalletIds: Array<string> = [];

  try {
    const storedImportedWalletIds = await SecureStore.getItemAsync(
      STORAGE_KEY.IMPORTED_WALLETS,
      SecureStoreOptions
    );
    if (!isNil(storedImportedWalletIds)) {
      importedWalletIds = JSON.parse(storedImportedWalletIds);
    }
  } catch (error) {
    console.warn(`Failed to get known imported wallets from secure store`);
  }

  importedWalletIds.push(wallet!.id);
  await SecureStore.setItemAsync(
    STORAGE_KEY.IMPORTED_WALLETS,
    JSON.stringify(importedWalletIds),
    SecureStoreOptions
  );

  const { connectedChains } = useChainServices.getState();

  connectedChains.forEach((chain) => createChainWallet(wallet, chain, privateKey));

  return wallet!;
}

async function importLedger(ledgerAddresses: LedgerAddresses, ledgerBleId: string | null) {
  if (isEmpty(ledgerAddresses)) {
    throw new Error('No Ledger addresses are being imported');
  }

  const { realm } = useVault.getState();

  let wallet: RealmWallet;
  realm?.write(() => {
    const wallets = realm.objects<Wallet>(Wallet.schema.name);

    const activeWallets = wallets.filtered(`isActive == true`);
    activeWallets.forEach((wallet) => (wallet.isActive = false));

    const [, firstLedgerAddress] = Object.entries(ledgerAddresses)[0];

    wallet = realm.create<Wallet>(
      Wallet.schema.name,
      new Wallet(WalletType.Ledger, 'Ledger Wallet', firstLedgerAddress.index)
    );

    Object.entries(ledgerAddresses).forEach(([chainID, ledgerAddress]) => {
      const cw = new ChainWallet(chainID as ChainID, ledgerAddress.address, ledgerAddress.index);
      cw.hdPath = ledgerAddress.hdPath;

      wallet.chainWallets.push(cw);
    });

    if (ledgerBleId) {
      wallet.ledgerBleId = ledgerBleId;
    }
  });

  return wallet!;
}

async function importLedgerExistingWallet(
  ledgerAddresses: LedgerAddresses,
  ledgerBleId: string | null
) {
  if (isEmpty(ledgerAddresses)) {
    throw new Error(`No Ledger addresses are being imported`);
  }

  const { getActiveWallet } = useVault.getState();
  const activeWallet = getActiveWallet();
  if (!activeWallet) {
    throw new Error(`No wallet selected`);
  }
  if (!isEmpty(activeWallet?.ledgerBleId) && activeWallet?.ledgerBleId !== ledgerBleId) {
    throw new Error(`This wallet was created with a different Ledger device`);
  }

  const { realm } = useVault.getState();
  realm?.write(() => {
    Object.entries(ledgerAddresses).forEach(([chainID, ledgerAddress]) => {
      const chainWallet = new ChainWallet(
        chainID as ChainID,
        ledgerAddress.address,
        ledgerAddress.index
      );
      chainWallet.hdPath = ledgerAddress.hdPath;

      activeWallet.chainWallets.push(chainWallet);
    });
  });
}

async function createVault(credentials: CreateVaultCredentials) {
  const { hasVault } = useVault.getState();
  if (hasVault) {
    throw new Error(`You already have a vault`);
  }

  // Make sure Realm is cleared before attempting to open
  Realm.deleteFile(realmConfig);
  const realm = await openRealm();

  const encryptionKey = credentials.passcode;

  const mnemonic = generateMnemonic();
  const encryptedMnemonic = await encrypt(encryptionKey, mnemonic);
  await SecureStore.setItemAsync(STORAGE_KEY.MNEMONIC, encryptedMnemonic, SecureStoreOptions);

  const seedKey = (await mnemonicToSeed(mnemonic)).toString('hex');
  const encryptedSeedKey = await encrypt(encryptionKey, seedKey);
  await SecureStore.setItemAsync(STORAGE_KEY.SEED_KEY, encryptedSeedKey, SecureStoreOptions);

  // Verify that mnemonic is encrypted and stored correctly
  const storedMnemonic = await SecureStore.getItemAsync(STORAGE_KEY.MNEMONIC, SecureStoreOptions);
  const storedSeedKey = await SecureStore.getItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);
  if (
    isNil(storedMnemonic) ||
    isNil(storedSeedKey) ||
    (await decrypt(encryptionKey, storedMnemonic)) !== mnemonic ||
    (await decrypt(encryptionKey, storedSeedKey)) !== seedKey
  ) {
    await SecureStore.deleteItemAsync(STORAGE_KEY.ENCRYPTION_KEY, SecureStoreOptions);
    await SecureStore.deleteItemAsync(STORAGE_KEY.MNEMONIC, SecureStoreOptions);
    await SecureStore.deleteItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);
    throw new Error(`Failed creating vault`);
  }

  useInternalState.setState({
    encryptionKey,
  });

  await createWallet('Wallet 1', realm);

  useVault.setState({
    isUnlocked: true,
    hasVault: true,
  });

  return mnemonic;
}

async function importVault(credentials: ImportVaultCredentials) {
  const { hasVault } = useVault.getState();
  if (hasVault) {
    throw new Error(`You already have a vault`);
  }
  if (!validateMnemonic(credentials.seedPhrase)) {
    throw new Error(`Invalid seed phrase`);
  }

  // Make sure Realm is cleared before attempting to open
  Realm.deleteFile(realmConfig);
  const realm = await openRealm();

  const encryptionKey = credentials.passcode;

  const encryptedMnemonic = await encrypt(encryptionKey, credentials.seedPhrase);
  await SecureStore.setItemAsync(STORAGE_KEY.MNEMONIC, encryptedMnemonic, SecureStoreOptions);

  const seedKey = (await mnemonicToSeed(credentials.seedPhrase)).toString('hex');
  const encryptedSeedKey = await encrypt(encryptionKey, seedKey);
  await SecureStore.setItemAsync(STORAGE_KEY.SEED_KEY, encryptedSeedKey, SecureStoreOptions);

  // Verify that mnemonic is encrypted and stored correctly
  const storedMnemonic = await SecureStore.getItemAsync(STORAGE_KEY.MNEMONIC, SecureStoreOptions);
  const storedSeedKey = await SecureStore.getItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);
  if (
    isNil(storedMnemonic) ||
    isNil(storedSeedKey) ||
    (await decrypt(encryptionKey, storedMnemonic)) !== credentials.seedPhrase ||
    (await decrypt(encryptionKey, storedSeedKey)) !== seedKey
  ) {
    await SecureStore.deleteItemAsync(STORAGE_KEY.ENCRYPTION_KEY, SecureStoreOptions);
    await SecureStore.deleteItemAsync(STORAGE_KEY.MNEMONIC, SecureStoreOptions);
    await SecureStore.deleteItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);
    throw new Error('Failed creating vault');
  }

  useInternalState.setState({
    encryptionKey,
  });

  await createWallet('Wallet 1', realm);

  useOnboardingFlags.getState().update('confirmSeedPhrase', true);

  useVault.setState({
    isUnlocked: true,
    hasVault: true,
  });
}

async function confirmVault(seedPhrase: string) {
  const { encryptionKey } = useInternalState.getState();
  const encryptedMnemonic = await SecureStore.getItemAsync(
    STORAGE_KEY.MNEMONIC,
    SecureStoreOptions
  );
  if (isNil(encryptionKey) || isNil(encryptedMnemonic)) {
    throw new Error(`You don't have a vault yet`);
  }

  const mnemonic = await decrypt(encryptionKey, encryptedMnemonic);
  if (seedPhrase !== mnemonic) {
    throw new Error(`Incorrect seed phrase`);
  }

  useOnboardingFlags.getState().update('confirmSeedPhrase', true);
}

async function backupVault(credentials: AuthenticateCredentials) {
  const { hasVault } = useVault.getState();
  const { encryptionKey } = useInternalState.getState();
  if (!hasVault || isNil(encryptionKey)) {
    throw new Error(`You don't have a vault yet`);
  }

  if (!(await verifyCredentials(credentials))) {
    throw new Error(`Invalid credentials`);
  }

  const encryptedMnemonic = await SecureStore.getItemAsync(
    STORAGE_KEY.MNEMONIC,
    SecureStoreOptions
  );
  if (isNil(encryptedMnemonic)) {
    throw new Error(`You don't have a vault`);
  }
  return await decrypt(encryptionKey, encryptedMnemonic);
}

async function resetVault() {
  // if (!(await verifyCredentials(credentials))) {
  //   throw new Error(`Invalid credentials`);
  // }

  // Clear vault secrets
  await SecureStore.deleteItemAsync(STORAGE_KEY.MNEMONIC, SecureStoreOptions);
  await SecureStore.deleteItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);
  await SecureStore.deleteItemAsync(STORAGE_KEY.ENCRYPTION_KEY, SecureStoreOptions);

  // Clear all stored private keys
  let importedWalletIds: Array<string> = [];
  try {
    const storedImportedWalletIds = await SecureStore.getItemAsync(
      STORAGE_KEY.IMPORTED_WALLETS,
      SecureStoreOptions
    );
    if (!isNil(storedImportedWalletIds)) {
      importedWalletIds = JSON.parse(storedImportedWalletIds);
    }
  } catch (error) {}
  importedWalletIds.forEach((walletId) =>
    SecureStore.deleteItemAsync(`${STORAGE_KEY.PRIVATE_KEY}.${walletId}`, SecureStoreOptions)
  );
  await SecureStore.deleteItemAsync(STORAGE_KEY.IMPORTED_WALLETS, SecureStoreOptions);

  // Clear all storage, settings and services
  await AsyncStorage.clear();
  useSettings.getState().initialize();
  useTheme.getState().initialize();
  useOnboardingFlags.getState().initialize();
  useChainServices.getState().initialize();

  await closeRealm();
  Realm.deleteFile(realmConfig);
  useVault.setState({
    isUnlocked: false,
    hasVault: false,
    wallets: [],
  });
  useInternalState.setState({
    encryptionKey: null,
  });
}

async function selectWallet(walletId: string) {
  const { realm } = useVault.getState();
  if (isNil(realm)) {
    throw new Error(`Vault realm isn't open`);
  }

  realm.write(() => {
    const selectedWallet = realm.objectForPrimaryKey<Wallet>(Wallet.schema.name, walletId);
    if (isNil(selectedWallet)) {
      throw new Error(`Unknown wallet ${walletId}`);
    }

    const activeWallets = realm.objects<Wallet>(Wallet.schema.name).filtered(`isActive == true`);
    activeWallets.forEach((wallet) => (wallet.isActive = false));

    selectedWallet.isActive = true;
  });
}

async function backupWallet(
  walletId: string,
  chainId: ChainID,
  credentials: AuthenticateCredentials,
  keystorePassword?: string
) {
  if (!(await verifyCredentials(credentials))) return;

  const { wallets } = useVault.getState();
  const wallet = wallets.find((wallet) => wallet.id === walletId);
  if (isNil(wallet)) {
    throw new Error(`Wallet ${walletId} not found`);
  }

  const chain = chains.find((chain) => chain.id === chainId)!;
  const privateKey: string = await getPrivateKey(wallet, chain.coinType);
  if (!privateKey) return;

  if (isEmpty(keystorePassword)) return privateKey;

  const keystore = createKeystore(privateKey, keystorePassword!, chainId);
  const filename = `${wallet.name} (${keystore?.address}).keystore`; // TODO
  // const keystoreFile = new File([JSON.stringify(keystore)], filename);
  // browser.downloads.download({
  //   url: URL.createObjectURL(keystoreFile),
  //   saveAs: true,
  //   filename,
  // });

  const { setToastMessage } = useNavigationStore.getState();

  if (Platform.OS === 'ios') {
    try {
      const fileUri = `${RNFS.CachesDirectoryPath}/${filename}`;
      await RNFS.writeFile(fileUri, JSON.stringify(keystore));

      await Share.open({ url: `file://${fileUri}`, type: 'application/json' });

      setToastMessage('Saved keystore file', ToastType.info);
      RNFS.unlink(fileUri);
    } catch (error) {
      setToastMessage('Failed saving keystore file', ToastType.error);
    }
  } else {
    try {
      await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE);
      const fileUri = `${RNFS.DownloadDirectoryPath}/${filename}`;
      await RNFS.writeFile(fileUri, JSON.stringify(keystore));
      const downloadPathShort = last(RNFS.DownloadDirectoryPath.split('/'));
      setToastMessage(`Saved ${downloadPathShort}/${filename}`, ToastType.info);
    } catch (error) {
      setToastMessage('Failed saving keystore file', ToastType.error);
    }
  }
}

async function initialize() {
  const encryptedMnemonic = await SecureStore.getItemAsync(
    STORAGE_KEY.MNEMONIC,
    SecureStoreOptions
  );

  useVault.setState({
    ready: true,
    hasVault: !isNil(encryptedMnemonic),
  });
}

export async function getPrivateKey(wallet: Wallet | RealmWallet, coinType: CoinType) {
  const { encryptionKey } = useInternalState.getState();
  const encryptedSeedKey = await SecureStore.getItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);
  if (isNil(encryptionKey) || isNil(encryptedSeedKey)) {
    throw new Error(`You don't have a vault yet`);
  }
  const seedKey = await decrypt(encryptionKey, encryptedSeedKey);

  switch (wallet.type) {
    case WalletType.HD:
      const hdPath = getCoinHDPath(coinType, wallet.hdIndex!);
      return derivePrivateKey(seedKey, hdPath);

    case WalletType.PK:
      const encryptedPrivateKey = await SecureStore.getItemAsync(
        `${STORAGE_KEY.PRIVATE_KEY}.${wallet.id}`,
        SecureStoreOptions
      );
      if (isNil(encryptedPrivateKey)) throw new Error(`Failed getting private key`);
      return decrypt(encryptionKey, encryptedPrivateKey);

    default:
      throw new Error(`Can't get private key for ${wallet.type} wallets`);
  }
}

export async function getMnemonic() {
  const { encryptionKey } = useInternalState.getState();
  const encryptedMnemonic = await SecureStore.getItemAsync(
    STORAGE_KEY.MNEMONIC,
    SecureStoreOptions
  );
  if (isNil(encryptionKey) || isNil(encryptedMnemonic)) {
    throw new Error(`You don't have a vault yet`);
  }

  return decrypt(encryptionKey, encryptedMnemonic);
}

async function refreshWalletBalances() {
  const { getActiveChainWallets, realm } = useVault.getState();
  const activeChainWallets = getActiveChainWallets();

  const chainServices = useChainServices.getState();
  const { services } = chainServices;

  if (!isEmpty(activeChainWallets)) {
    // Native token balance
    const promises = activeChainWallets.map((chainWallet) => {
      const thisService = services.get(chainWallet.type);

      if (thisService) {
        return thisService.getBalance(chainWallet.address);
      }

      return ZERO;
    });

    const walletTokensMap: Map<ChainID, Token[]> = new Map();

    // Token and asset balances
    const tokenBalancePromises = activeChainWallets.map((chainWallet) => {
      const thisService = services.get(chainWallet.type);
      const thisWalletTokens = tokensForChainWallet(chainWallet);

      walletTokensMap.set(chainWallet.type, thisWalletTokens);

      if ((thisService as EvmChainService).getTokenBalances) {
        return (thisService as EvmChainService).getTokenBalances(
          chainWallet,
          thisWalletTokens
        );
      }

      if ((thisService as SubstrateChainService).getAssetBalances) {
        return (thisService as SubstrateChainService).getAssetBalances(
          chainWallet.address,
          thisWalletTokens
        );
      }

      if ((thisService as NearService).getTokenBalances) {
        return (thisService as NearService).getTokenBalances(chainWallet.address, thisWalletTokens);
      }

      return undefined;
    });

    await Promise.all(promises).then((values) => {
      realm?.write(() => {
        activeChainWallets.forEach((chainWallet, index) => {
          chainWallet.balance = toNumber(values[index]);
          chainWallet.balanceString = values[index].toString();
        });
      });
    });

    await Promise.all(tokenBalancePromises).then((valuesMap) => {
      realm?.write(() => {
        valuesMap.forEach((map, index) => {
          const thisChainWallet = activeChainWallets[index];
          const thisWalletTokens = walletTokensMap.get(thisChainWallet.type) || [];

          if (map) {
            Object.keys(map).forEach((key) => {
              const thisToken = thisWalletTokens.find(
                (token) => token.contract === key || token.assetId === key
              );

              const thisTokenBalance = thisToken?.balances.find(
                (balance) => balance.address === thisChainWallet.address
              );

              const fetchedBalanceString = (map as any)[key].balance.toString();
              const fetchedBalance = toNumber((map as any)[key].balance);

              if (thisTokenBalance) {
                thisTokenBalance.balance = fetchedBalance;
                thisTokenBalance.balanceString = fetchedBalanceString;
              } else {
                const tokenBalance = realm.create<TokenBalance>(
                  'TokenBalance',
                  new TokenBalance(thisChainWallet.address, fetchedBalance, fetchedBalanceString)
                );

                thisToken?.balances.push(tokenBalance);
              }
            });
          }
        });
      });
    });

    walletTokensMap.clear();
  }
}

async function changePasscode(passcode: string, currentPasscode: string) {
  if (!(await verifyCredentials({ passcode: currentPasscode }))) {
    throw new Error(`Invalid passcode provided`);
  }

  useInternalState.setState({
    encryptionKey: passcode,
  });

  const { biometricsEnabled } = useSettings.getState();
  if (biometricsEnabled) {
    // Update password in secure store
    await SecureStore.setItemAsync(STORAGE_KEY.ENCRYPTION_KEY, passcode, SecureStoreOptions);
  }

  // Decrypt and re-encrypt mnemonic
  const encryptedMnemonic = await SecureStore.getItemAsync(
    STORAGE_KEY.MNEMONIC,
    SecureStoreOptions
  );
  if (isNil(encryptedMnemonic)) {
    throw new Error(`Mnemonic not found`);
  }

  const mnemonic = await decrypt(currentPasscode, encryptedMnemonic);
  const newEncryptedMnemonic = await encrypt(passcode, mnemonic);
  await SecureStore.setItemAsync(STORAGE_KEY.MNEMONIC, newEncryptedMnemonic, SecureStoreOptions);

  // Decrypt and re-encrypt seed key
  const encryptedSeedKey = await SecureStore.getItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);
  if (isNil(encryptedSeedKey)) {
    throw new Error(`Seed key not found`);
  }

  const seedKey = await decrypt(currentPasscode, encryptedSeedKey);
  const newEncryptedSeedKey = await encrypt(passcode, seedKey);
  await SecureStore.setItemAsync(STORAGE_KEY.SEED_KEY, newEncryptedSeedKey, SecureStoreOptions);

  // Verify that mnemonic is encrypted and stored correctly
  const storedMnemonic = await SecureStore.getItemAsync(STORAGE_KEY.MNEMONIC, SecureStoreOptions);
  const storedSeedKey = await SecureStore.getItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);

  if (
    isNil(storedMnemonic) ||
    isNil(storedSeedKey) ||
    (await decrypt(passcode, storedMnemonic)) !== mnemonic ||
    (await decrypt(passcode, storedSeedKey)) !== seedKey
  ) {
    await SecureStore.deleteItemAsync(STORAGE_KEY.ENCRYPTION_KEY, SecureStoreOptions);
    await SecureStore.deleteItemAsync(STORAGE_KEY.MNEMONIC, SecureStoreOptions);
    await SecureStore.deleteItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);

    // Re-encrypt using old passcode
    const oldEncryptedMnemonic = await encrypt(currentPasscode, mnemonic);
    const oldEncryptedSeedKey = await encrypt(currentPasscode, seedKey);

    await SecureStore.setItemAsync(STORAGE_KEY.ENCRYPTION_KEY, currentPasscode, SecureStoreOptions);
    await SecureStore.setItemAsync(STORAGE_KEY.MNEMONIC, oldEncryptedMnemonic, SecureStoreOptions);
    await SecureStore.setItemAsync(STORAGE_KEY.SEED_KEY, oldEncryptedSeedKey, SecureStoreOptions);

    // Check again
    const storedMnemonic = await SecureStore.getItemAsync(STORAGE_KEY.MNEMONIC, SecureStoreOptions);
    const storedSeedKey = await SecureStore.getItemAsync(STORAGE_KEY.SEED_KEY, SecureStoreOptions);

    if (
      isNil(storedMnemonic) ||
      isNil(storedSeedKey) ||
      (await decrypt(currentPasscode, storedMnemonic)) !== mnemonic ||
      (await decrypt(currentPasscode, storedSeedKey)) !== seedKey
    ) {
      // NOTE: Something could be wrong here? Maybe secure storage is offline?
      throw new Error(`Failed changing passcode`);
    }

    throw new Error(`Failed changing passcode`);
  }

  // Decrypt and re-encrypt PK wallets private keys
  const { realm } = useVault.getState();
  if (isNil(realm)) {
    throw new Error(`Vault realm isn't open`);
  }

  const wallets = realm.objects<Wallet>(Wallet.schema.name);
  wallets
    .filter((wallet) => wallet.type === WalletType.PK)
    .forEach(async (wallet) => {
      const storedPrivateKey = await SecureStore.getItemAsync(
        `${STORAGE_KEY.PRIVATE_KEY}.${wallet!.id}`,
        SecureStoreOptions
      );

      if (isNil(storedPrivateKey)) {
        throw new Error(`Private key not found for wallet ${wallet!.id}`);
      }

      const privateKey = await decrypt(currentPasscode, storedPrivateKey);

      const newEncryptedPrivateKey = await encrypt(passcode, privateKey);

      await SecureStore.setItemAsync(
        `${STORAGE_KEY.PRIVATE_KEY}.${wallet!.id}`,
        newEncryptedPrivateKey,
        SecureStoreOptions
      );
    });
}

export async function storeEncryptionKeyInSecureStore() {
  const { encryptionKey } = useInternalState.getState();
  if (isNil(encryptionKey)) {
    throw new Error(`Encryption key not available`);
  }

  await SecureStore.setItemAsync(STORAGE_KEY.ENCRYPTION_KEY, encryptionKey, SecureStoreOptions);
}

export async function removeEncryptionKeyFromSecureStore() {
  await SecureStore.deleteItemAsync(STORAGE_KEY.ENCRYPTION_KEY, SecureStoreOptions);
}

export const useVault = create<State>((set, get) => ({
  initialize,
  ready: false,
  isUnlocked: false,
  setIsUnlocked: (isUnlocked: boolean) => set({ isUnlocked }),
  hasVault: false,
  wallets: [],
  getActiveWallet: () => {
    const { wallets } = get();

    if (isEmpty(wallets)) return null;
    const activeWallet = wallets.find((wallet) => wallet.isActive);
    return activeWallet ?? wallets[0];
  },
  getActiveChainWallets: () => {
    const { getActiveWallet } = get();
    const activeWallet = getActiveWallet();

    const { otherNetwork, connectedChains } = useChainServices.getState();

    if (!isNil(otherNetwork)) {
      const otherNetworkChainWallets =
        activeWallet?.chainWallets.filter(
          (cw) =>
            cw.type === (otherNetwork as TestnetConfig)?.chainType ||
            cw.type === (otherNetwork as CustomNetwork)?.chain
        ) || [];

      if ((otherNetwork as TestnetConfig)?.chainType) {
        // Check affiliated chains
        const affiliatedChain = chains.find(
          (c) => c.affiliatedChainID === (otherNetwork as TestnetConfig)?.chainType
        );

        if (affiliatedChain) {
          const affiliatedChainWallets =
            activeWallet?.chainWallets.filter((cw) => cw.type === affiliatedChain.id) || [];

          return [...otherNetworkChainWallets, ...affiliatedChainWallets];
        }
      }

      return otherNetworkChainWallets;
    } else {
      const connectedChainTypes = connectedChains.map((chain) => chain.id);
      const mainnetChainIDs = Object.keys(mainnets);

      return (
        activeWallet?.chainWallets.filter(
          (cw) => connectedChainTypes.includes(cw.type) && mainnetChainIDs.includes(cw.type)
        ) || []
      );
    }
  },
  getActiveWalletAllChainWallets: () => {
    const { getActiveWallet } = get();
    const activeWallet = getActiveWallet();

    const mainnetChainIDs = Object.keys(mainnets);

    return activeWallet?.chainWallets.filter((cw) => mainnetChainIDs.includes(cw.type)) || [];
  },
  verifyCredentials,
  unlockVault,
  lockVault,
  createVault,
  importVault,
  confirmVault,
  backupVault,
  resetVault,

  isCreatingWallet: false,
  chainWalletCreatingStatus: ChainWalletCreationStatus.NOT_CREATED,
  createWallet,
  selectWallet,
  renameWallet,
  removeWallet,
  backupWallet,

  importPrivateKey,
  importLedger,
  importLedgerExistingWallet,

  refreshWalletBalances,

  changePasscode,

  realm: null,

  lastCreatedWalletAt: null,
}));
