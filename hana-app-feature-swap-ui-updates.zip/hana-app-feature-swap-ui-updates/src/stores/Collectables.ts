import { Collectable, Collection, CollectionDetails } from '@/models/Collectable';
import { ChainWallet, Wallet } from '@/models/Vault';
import {
  GetAccountCollectionDetailsData,
  GetAccountCollectionDetailsVariables,
  GET_ACCOUNT_COLLECTION_DETAILS,
} from '@/operations/queries/getAccountCollectionDetails';
import {
  GetAccountCollectionSummaryData,
  GetAccountCollectionSummaryVariables,
  GET_ACCOUNT_COLLECTION_SUMMARY,
} from '@/operations/queries/getAccountCollectionSummary';
import {
  GetTokenDetailsData,
  GetTokenDetailsVariables,
  GET_TOKEN_DETAILS,
} from '@/operations/queries/getTokenDetails';
import { ChainDetails, chainForChainWallet, ChainID, chains } from '@/utils/chains';
import { AGGREGATION_GRAPHQL_API } from 'dotenv';
import { request } from 'graphql-request';
import produce from 'immer';
import { isNil } from 'lodash-es';
import { create } from 'zustand';
import { useVault } from './Vault';

interface State {
  collectables: Map<string, CollectionDetails[]>;
  setCollectables: (collectables: Map<string, CollectionDetails[]>) => unknown;
  refreshCollectablesForActiveWallet: () => Promise<boolean>;
  refreshingCollectablesForActiveWallet: boolean;
  refreshCollectablesForCollection: (collection: Collection) => unknown;
  loadCollectable: (chainId: ChainID, wallet: Wallet, contract: string, tokenId: number) => unknown;
}

export const useCollectables = create<State>((set, get) => ({
  collectables: new Map(),
  setCollectables: (collectables) =>
    set({
      collectables,
    }),
  refreshCollectablesForActiveWallet: async () => {
    set({
      refreshingCollectablesForActiveWallet: true,
    });

    const { getActiveWallet, getActiveChainWallets } = useVault.getState();

    const activeWallet = getActiveWallet();

    if (!activeWallet) {
      return false;
    }

    const activeChainWallets = getActiveChainWallets();

    await Promise.all(activeChainWallets.map(async (cw) => await handleRefreshCollectables(cw)));

    set({
      refreshingCollectablesForActiveWallet: false,
    });

    return true;
  },
  refreshingCollectablesForActiveWallet: false,
  refreshCollectablesForCollection: (collection) => {
    const { getActiveWallet, getActiveChainWallets } = useVault.getState();

    const activeWallet = getActiveWallet();

    activeWallet && handleLoadCollection(collection.chain.type, activeWallet, collection.contract);
  },
  loadCollectable,
}));

function generateKey(chainID: ChainID, address: string) {
  return `${chainID}_${address}`;
}

async function handleRefreshCollectables(chainWallet: ChainWallet): Promise<boolean> {
  const chain = chainForChainWallet(chainWallet);

  if (!chain?.hasCollectables) return false;

  try {
    const newCollections = await getCollectionSummary(chain, chainWallet.address);

    const key = generateKey(chain.id, chainWallet.address);

    const { setCollectables, collectables } = useCollectables.getState();
    const collections = collectables.get(key) ?? [];

    for (let i = 0, n = newCollections.length; i < n; i++) {
      const existingCollection = collections.find(
        (c) => c.collection.contract === newCollections[i].collection.contract
      );
      newCollections[i].tokens = existingCollection?.tokens ?? [];
    }

    setCollectables(
      produce(collectables, (draft) => {
        draft.set(key, newCollections);
      })
    );

    return true;
  } catch (error) {
    console.warn('error: ', error);
    return false;
  }
}

async function handleLoadCollection(chainId: ChainID, wallet: Wallet, contract: string) {
  const chain = chains.find((chain) => chain.id === chainId)!;

  const chainWallet = wallet.chainWallets.find((cw) => cw.type === chainId);
  if (isNil(chainWallet)) {
    throw new Error(`No ${chain.id} wallet for ${wallet.name}`);
  }

  const collectionDetails = await getCollectionDetails(chain, contract, chainWallet.address);

  const key = generateKey(chainId, chainWallet.address);

  const { setCollectables, collectables } = useCollectables.getState();

  setCollectables(
    produce(collectables, (draft) => {
      const collections = draft.get(key) ?? [];

      const index = collections.findIndex((c) => c.collection.contract === contract);

      if (index < 0) return;
      const updatedCollection = collections[index];
      updatedCollection.collection = collectionDetails.collection;
      updatedCollection.tokens = collectionDetails.tokens;
      updatedCollection.tokensCount = collectionDetails.tokens.length;
      if (collectionDetails.tokens.length > 0) {
        updatedCollection.coverImage = collectionDetails.tokens[0].imageUrl;
      }

      collections[index] = updatedCollection;

      draft.set(key, collections);
    })
  );
}

async function loadCollectable(
  chainId: ChainID,
  wallet: Wallet,
  contract: string,
  tokenId: number
) {
  const chain = chains.find((chain) => chain.id === chainId)!;
  const chainWallet = wallet.chainWallets.find((cw) => cw.type === chainId);

  if (isNil(chainWallet)) {
    throw new Error(`No ${chain.id} wallet for ${wallet.name}`);
  }

  const tokenDetails = await getTokenDetails(chain, contract, tokenId);

  const key = generateKey(chainId, chainWallet.address);

  const { setCollectables, collectables } = useCollectables.getState();
  const collections = collectables.get(key) ?? [];

  // const collectables = (assets.collectables ?? []) as Array<CollectionDetails>;
  const collectionIndex = collections.findIndex((c) => c.collection.contract === contract);
  if (collectionIndex < 0) return;
  const updatedCollection = collections[collectionIndex];

  const tokens = updatedCollection.tokens ?? [];
  const tokenIndex = tokens.findIndex((t) => t.tokenId === tokenId);
  if (tokenIndex < 0) return;

  updatedCollection.tokens = [
    ...tokens.slice(0, tokenIndex),
    tokenDetails,
    ...tokens.slice(tokenIndex + 1),
  ];

  collections[collectionIndex] = updatedCollection;

  setCollectables(
    produce(collectables, (draft) => {
      draft.set(key, collections);
    })
  );
}

async function getCollectionSummary(chain: ChainDetails, address: string) {
  const response = await request<
    GetAccountCollectionSummaryData,
    GetAccountCollectionSummaryVariables
  >(AGGREGATION_GRAPHQL_API, GET_ACCOUNT_COLLECTION_SUMMARY, {
    where: { chainType: chain.id, address },
  });

  return response.accountCollectionSummary;
}

async function getCollectionDetails(chain: ChainDetails, contract: string, address: string) {
  const response = await request<
    GetAccountCollectionDetailsData,
    GetAccountCollectionDetailsVariables
  >(AGGREGATION_GRAPHQL_API, GET_ACCOUNT_COLLECTION_DETAILS, {
    where: { chainType: chain.id, contract, address },
  });

  return response.accountCollectionDetails;
}

async function getTokenDetails(chain: ChainDetails, contract: string, tokenId: number) {
  const response = await request<GetTokenDetailsData, GetTokenDetailsVariables>(
    AGGREGATION_GRAPHQL_API,
    GET_TOKEN_DETAILS,
    { where: { chainType: chain.id, contract, tokenId } }
  );

  return response.tokenDetails;
}

export function collectablesForActiveWallet(): CollectionDetails[] {
  const { collectables } = useCollectables.getState();
  const { getActiveChainWallets } = useVault.getState();

  let keys: string[] = [];

  getActiveChainWallets().forEach((cw) => {
    keys.push(generateKey(cw.type, cw.address));
  });

  let collections: CollectionDetails[] = [];

  keys.forEach((key) => {
    collections = [...collections, ...(collectables.get(key) || [])];
  });

  return collections.sort(sortByTokensCount);
}

export function itemsForCollection(collection: Collection): Collectable[] {
  const { getActiveWallet } = useVault.getState();

  const activeWallet = getActiveWallet();
  const chainWallet = activeWallet?.chainWallets.find((cw) => cw.type === collection.chain.type);

  if (!chainWallet) {
    throw new Error('No wallet available');
  }

  const { collectables } = useCollectables.getState();
  const key = generateKey(collection.chain.type, chainWallet?.address);

  const details = collectables.get(key)?.find((c) => c.collection.contract === collection.contract);

  return details?.tokens || [];
}

export function getCollectable(collection: Collection, tokenId: number): Collectable | null {
  const { getActiveWallet } = useVault.getState();

  const activeWallet = getActiveWallet();
  const chainWallet = activeWallet?.chainWallets.find((cw) => cw.type === collection.chain.type);

  if (!chainWallet) {
    throw new Error('No wallet available');
  }

  const { collectables } = useCollectables.getState();
  const key = generateKey(collection.chain.type, chainWallet?.address);

  const details = collectables.get(key)?.find((c) => c.collection.contract === collection.contract);

  return details?.tokens?.find((t) => t.tokenId === tokenId) || null;
}

function sortByTokensCount(a: CollectionDetails, b: CollectionDetails) {
  if (a.tokensCount > b.tokensCount) return -1;
  if (a.tokensCount < b.tokensCount) return 1;

  const aName = a.collection.name.toLowerCase();
  const bName = b.collection.name.toLowerCase();
  return aName < bName ? -1 : aName > bName ? 1 : 0;
}
