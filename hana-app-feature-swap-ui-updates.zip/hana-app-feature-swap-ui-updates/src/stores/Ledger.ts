import { LedgerDevice } from '@/models/Ledger';
import Transport from '@ledgerhq/hw-transport';
import { create } from 'zustand';

interface State {
  availableDevices: LedgerDevice[];
  setAvailableDevices: (devices: LedgerDevice[]) => unknown;
  transport: Transport | null;
  setTransport: (transport: Transport | null) => unknown;
  ledgerBleId: string | null;
  setLedgerBleId: (id: string | null) => unknown;
  connectingToLedger: boolean;
  setConnectingToLedger: (connecting: boolean) => unknown;
}

export const useLedgerStore = create<State>((set, get) => ({
  availableDevices: [],
  setAvailableDevices: (availableDevices) => {
    set({ availableDevices });
  },
  transport: null,
  setTransport: (transport) => {
    set({ transport });
  },
  ledgerBleId: null,
  setLedgerBleId: (id) => {
    set({ ledgerBleId: id });
  },
  connectingToLedger: false,
  setConnectingToLedger: (connecting) => {
    set({ connectingToLedger: connecting });
  },
}));
