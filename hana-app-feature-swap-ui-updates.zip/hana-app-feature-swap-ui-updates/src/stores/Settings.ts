import { STORAGE_KEY, SubstrateKeyDerivationMethod } from '@/utils/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { removeEncryptionKeyFromSecureStore, storeEncryptionKeyInSecureStore } from './Vault';

interface State {
  initialize: () => unknown;
  substrateKeyDerivationMethod: SubstrateKeyDerivationMethod;
  setSubstrateKeyDerivationMethod: (method: SubstrateKeyDerivationMethod) => void;
  biometricsEnabled: boolean;
  setBiometricsEnabled: (enabled: boolean) => void;
  reset: () => Promise<void>;
}

export const useSettings = create<State>((set, get) => ({
  initialize: async () => {
    const method = await AsyncStorage.getItem(STORAGE_KEY.SUBSTRATE_KEY_DERIVATION_METHOD);

    if (method) {
      set({
        substrateKeyDerivationMethod: method as SubstrateKeyDerivationMethod,
      });
    } else {
      // Set default
      set({
        substrateKeyDerivationMethod: SubstrateKeyDerivationMethod.MnemonicSr25519,
      });

      await AsyncStorage.setItem(
        STORAGE_KEY.SUBSTRATE_KEY_DERIVATION_METHOD,
        SubstrateKeyDerivationMethod.MnemonicSr25519
      );
    }

    const biometricsEnabled = await AsyncStorage.getItem(STORAGE_KEY.BIOMETRICS_ENABLED);

    if (biometricsEnabled) {
      set({
        biometricsEnabled: biometricsEnabled === 'true',
      });
    }
  },
  substrateKeyDerivationMethod: SubstrateKeyDerivationMethod.MnemonicSr25519, // Default
  setSubstrateKeyDerivationMethod: async (method: SubstrateKeyDerivationMethod) => {
    set({ substrateKeyDerivationMethod: method });

    await AsyncStorage.setItem(STORAGE_KEY.SUBSTRATE_KEY_DERIVATION_METHOD, method);
  },
  biometricsEnabled: false, // Default
  setBiometricsEnabled: async (enabled: boolean) => {
    if (enabled) {
      await storeEncryptionKeyInSecureStore();
    } else {
      await removeEncryptionKeyFromSecureStore();
    }

    set({ biometricsEnabled: enabled });

    await AsyncStorage.setItem(STORAGE_KEY.BIOMETRICS_ENABLED, JSON.stringify(enabled));
  },
  reset: async () => {
    await Promise.all([
      AsyncStorage.removeItem(STORAGE_KEY.SUBSTRATE_KEY_DERIVATION_METHOD),
      AsyncStorage.removeItem(STORAGE_KEY.BIOMETRICS_ENABLED),
    ]);
  },
}));
