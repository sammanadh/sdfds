import { TokenWithBalance } from '@/hooks/useTokens';
import { Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet, CustomNetwork, Token } from '@/models/Vault';
import { serviceForChainID, useChainServices } from '@/stores/ChainServices';
import { useVault } from '@/stores/Vault';
import { ChainID } from '@/utils/chains';
import { TestnetConfig } from '@/utils/networks';
import { isCustomNetwork, isTestnetConfig } from '@/utils/types';
import { flatten } from 'lodash-es';
import { create } from 'zustand';
import produce from 'immer';
import { useSwapServices } from './SwapServices';
import { wait } from '@/utils/wait';
import { SwapStatus } from '@/models/SwapService';
import { usePendingTransactions } from './PendingTransactions';
import { chainWalletForChain } from '@/utils/wallet';

export interface TransactionsKey {
  chainID: ChainID;
  address: string;
}

interface State {
  transactions: Map<string, Transaction[]>;
  transactionsUpdatedAt: Date;
  refreshTransactions: (chainID: ChainID, address: string) => Promise<boolean>;
  refreshTransactionsForActiveChainWallets: () => Promise<boolean>;
  refreshingTransactionsForActiveChainWallets: boolean;
  getTransactions: (
    chainID: ChainID,
    address: string,
    token?: Token | TokenWithBalance
  ) => Transaction[];
  getAllTransactionsForChainWallets: (wallets: ChainWallet[]) => Transaction[];
}

export function generateKey(
  chainID: ChainID,
  address: string,
  otherNetwork?: CustomNetwork | TestnetConfig | null
) {
  if (isCustomNetwork(otherNetwork)) {
    return `${chainID}_${address}_${otherNetwork.id}`;
  }

  if (isTestnetConfig(otherNetwork)) {
    return `${chainID}_${address}_${otherNetwork.ref}`;
  }

  return `${chainID}_${address}`;
}

export const useTransactions = create<State>((set, get) => ({
  transactions: new Map<string, Transaction[]>(),
  transactionsUpdatedAt: new Date(),

  refreshTransactions: async (chainID, address) => {
    const service = serviceForChainID(chainID);

    const { otherNetwork } = useChainServices.getState();

    let thisTransactions: Array<Transaction> | undefined;
    try {
      thisTransactions = await service?.getTransactions(address);
    } catch (error: any) {
      console.warn('Failed loading transactions', error.message);
      return false;
    }

    if (thisTransactions) {
      const key = generateKey(chainID, address, otherNetwork);
      const { transactions } = get();

      const { pendingTransactions } = usePendingTransactions.getState();

      const transactionHashes = thisTransactions.map((t) => t.hash);
      let pendingTransactionsToShow = pendingTransactions
        .filter((t) => t.chainID === chainID)
        .filter((t) => {
          return !transactionHashes.includes(t.hash) || t.type === TransactionType.TokenSwap;
        });

      // Fix chainWallet for pending transactions

      pendingTransactionsToShow = produce(pendingTransactionsToShow, (draft) => {
        draft.forEach((t) => {
          if (!t.chainWallet && t.chainID) {
            t.chainWallet = chainWalletForChain(t.chainID);
          }
        });
      });

      transactions.set(key, [...pendingTransactionsToShow, ...thisTransactions]);

      set({
        transactions,
        transactionsUpdatedAt: new Date(),
      });
    } else {
      set({
        transactionsUpdatedAt: new Date(),
      });
    }

    return true;
  },

  refreshTransactionsForActiveChainWallets: async () => {
    set({
      refreshingTransactionsForActiveChainWallets: true,
    });

    const { refreshTransactions } = get();

    const { getActiveChainWallets } = useVault.getState();
    const activeChainWallets = getActiveChainWallets();

    try {
      await Promise.all(
        activeChainWallets.map(async (cw) => {
          await refreshTransactions(cw.type, cw.address);
        })
      );
    } catch (error) {
      set({
        refreshingTransactionsForActiveChainWallets: false,
      });
    }

    set({
      refreshingTransactionsForActiveChainWallets: false,
    });

    return true;
  },

  refreshingTransactionsForActiveChainWallets: false,

  getTransactions: (chainID, address, token) => {
    const { otherNetwork } = useChainServices.getState();

    const key = generateKey(chainID, address, otherNetwork);

    const transactions = get().transactions.get(key) || [];

    if (token) {
      return transactions.filter(
        (t) => t.tokenSymbol?.toUpperCase() === token.symbol.toUpperCase()
      );
    } else {
      return transactions.filter(
        (t) =>
          t.type === TransactionType.SendNativeToken ||
          t.type === TransactionType.TokenTransfer ||
          t.type === TransactionType.TokenSwap
      );
    }
  },

  getAllTransactionsForChainWallets: (wallets) => {
    const { otherNetwork } = useChainServices.getState();

    return flatten(
      wallets.map((cw) => {
        const key = generateKey(cw.type, cw.address, otherNetwork);

        const transactions = get().transactions.get(key) || [];
        transactions.forEach((t) => {
          t.chainWallet = cw;
        });

        return transactions;
      })
    );
  },
}));
