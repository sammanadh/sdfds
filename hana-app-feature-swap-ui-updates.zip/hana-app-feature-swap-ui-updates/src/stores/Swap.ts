import { TokenWithBalance, useTokens } from '@/hooks/useTokens';
import { create } from 'zustand';

interface State {
  fromToken: TokenWithBalance | null;
  setFromToken: (token: TokenWithBalance) => void;
  toToken: TokenWithBalance | null;
  setToToken: (token: TokenWithBalance) => void;
}

export const useSwapStore = create<State>((set, get) => ({
  fromToken: null,
  setFromToken: (fromToken: TokenWithBalance) => {
    set({ fromToken });
  },
  toToken: null,
  setToToken: (toToken: TokenWithBalance) => {
    set({ toToken });
  },
}));
