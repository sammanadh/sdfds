import { STORAGE_KEY } from '@/utils/constants';
import { colors as baseColors, palette, paletteDark } from '@/utils/designTokens';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { isNil } from 'lodash-es';
import { Appearance, ColorSchemeName, StyleProp, StyleSheet, ViewStyle } from 'react-native';
import { create } from 'zustand';

type ThemeName = Exclude<ColorSchemeName, null | undefined>;

const lightColors: typeof baseColors = {
  ...baseColors, // TODO: should spread palette here after colors cleanup
  background: palette.white,
  foreground: palette.black,
  foregroundMuted: palette.gray.meta,
  foregroundHighlight: palette.primary,
  cards: palette.gray.cards,
  divider: palette.gray.cards,
};

const darkColors: typeof baseColors = {
  ...baseColors, // TODO: should spread palette here after colors cleanup
  primary: paletteDark.primary,
  offPurple: paletteDark.offPurple,
  negativeDarker: palette.negative,
  background: paletteDark.blacker,
  foreground: paletteDark.foreground,
  foregroundMuted: palette.gray.watermark,
  foregroundHighlight: palette.offPurple,
  cards: paletteDark.cards,
  divider: paletteDark.divider,
};

interface State {
  theme: ThemeName;
  isDarkMode: boolean;
  colors: typeof baseColors;
  styles: ThemeStyles;

  initialize: () => Promise<void>;
  setTheme(value: ThemeName): void;
}

const initTheme = Appearance.getColorScheme() ?? 'light';
const initColors = initTheme === 'dark' ? darkColors : lightColors;

export const useTheme = create<State>((set, get) => ({
  theme: initTheme,
  isDarkMode: initTheme === 'dark',
  colors: initColors,
  styles: buildStylesheet(initColors),

  async initialize() {
    let theme = (await AsyncStorage.getItem(STORAGE_KEY.THEME)) as ColorSchemeName;
    if (isNil(theme)) {
      theme = Appearance.getColorScheme() ?? 'light';
    }
    get().setTheme(theme);
  },

  setTheme(theme) {
    AsyncStorage.setItem(STORAGE_KEY.THEME, theme);

    const colors = theme === 'dark' ? darkColors : lightColors;
    set({
      theme,
      isDarkMode: theme === 'dark',
      colors,
      styles: buildStylesheet(colors),
    });
  },
}));

interface ThemeStyles {
  cards: StyleProp<ViewStyle>;
  screen: StyleProp<ViewStyle>;
}

function buildStylesheet(colors: typeof baseColors): ThemeStyles {
  return StyleSheet.create({
    cards: { backgroundColor: colors.cards },
    screen: { backgroundColor: colors.background },
  });
}
