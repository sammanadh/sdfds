import { SwappableToken, SwapService, SwapServiceProvider } from '@/models/SwapService';
import { ICONChainService } from '@/services/chainServices/IconService';
import { BalancedService } from '@/services/swapServices/BalancedService';
import { ChangeNowService } from '@/services/swapServices/ChangeNowService';
import { OneInchService } from '@/services/swapServices/OneInchService';
import { ChainDetails, ChainID, ChainServiceType } from '@/utils/chains';
import { EthereumNetworkDetails, networkDetailsForChainID } from '@/utils/networks';
import produce from 'immer';
import { isNil } from 'lodash-es';
import { create } from 'zustand';
import { useChainServices } from './ChainServices';
import { formatSwappableTokens } from '@/utils/swap';

interface State {
  services: Map<SwapServiceProvider, SwapService>;
  serviceForProvider: (provider: SwapServiceProvider) => SwapService | undefined;
  swappableTokens: Map<SwapServiceProvider, SwappableToken[]>;
  refreshSwappableTokensForProvider: (
    provider: SwapServiceProvider,
    activeChains: ChainDetails[]
  ) => Promise<void>;
  swappableTokensForProvider: (provider: SwapServiceProvider) => SwappableToken[];
  swappableTokensForProviders: (providers: SwapServiceProvider[]) => SwappableToken[];
  getAllSwappableTokens: () => SwappableToken[];
  getPossibleSwapsForToken: (token: SwappableToken) => SwappableToken[];
}

export const useSwapServices = create<State>((set, get) => ({
  services: new Map(),
  serviceForProvider: (provider: SwapServiceProvider) => {
    // Initialise if not available
    if (isNil(get().services.get(provider))) {
      switch (provider) {
        case SwapServiceProvider.ChangeNow: {
          const service = new ChangeNowService();
          get().services.set(provider, service);
          return service;
        }
        case SwapServiceProvider.OneInch: {
          const service = new OneInchService();
          get().services.set(provider, service);
          return service;
        }
        case SwapServiceProvider.BalancedNetwork:
          const { services } = useChainServices.getState();
          const iconService = services.get(ChainID.ICON);

          if (!iconService) return;

          const balanedNetworkService = new BalancedService(iconService as ICONChainService);
          get().services.set(provider, balanedNetworkService);
          return balanedNetworkService;
      }
    }

    return get().services.get(provider);
  },
  swappableTokens: new Map(),
  refreshSwappableTokensForProvider: async (
    provider: SwapServiceProvider,
    activeChains: ChainDetails[]
  ) => {
    const service = get().serviceForProvider(provider);

    const activeEvmChains = activeChains
      .filter((chain) => chain.service === ChainServiceType.Ethereum)
      .map((chain) => networkDetailsForChainID(chain.id)) as EthereumNetworkDetails[];

    if (isNil(service)) throw new Error(`Service for provider ${provider} not found`);

    const swappableTokens = await service.getTokens(activeEvmChains);

    set(
      produce((draft) => {
        draft.swappableTokens.set(provider, swappableTokens);
      })
    );
  },
  swappableTokensForProvider: (provider: SwapServiceProvider) => {
    return get().swappableTokens.get(provider) || [];
  },
  swappableTokensForProviders: (providers: SwapServiceProvider[]) => {
    let result: SwappableToken[] = [];
    providers.forEach((provider) => {
      result = [...result, ...get().swappableTokensForProvider(provider)];
    });
    return result;
  },
  getAllSwappableTokens: () => {
    const { swappableTokens } = get();
    let result: SwappableToken[] = [];
    swappableTokens.forEach((tokens) => {
      formatSwappableTokens(result, tokens);
    });
    return result;
  },
  getPossibleSwapsForToken: (token: SwappableToken) => {
    let result: Array<SwappableToken> = [];

    token.providers.forEach((provider) => {
      const service = get().serviceForProvider(provider);
      if (isNil(service)) throw new Error(`Service for provider ${provider} not found`);

      const serviceTokens = service.getPossibleSwaps(token);
      formatSwappableTokens(result, serviceTokens);
    });

    return result;
  },
}));
