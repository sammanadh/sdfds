import 'fastestsmallesttextencoderdecoder'; // For near-api-js to work
import 'fast-text-encoding';
import { enableMapSet } from 'immer';
import 'react-native-gesture-handler';
import 'react-native-get-random-values';
import 'react-native-url-polyfill/auto';
import '@ethersproject/shims';

// https://immerjs.github.io/immer/map-set
enableMapSet();
