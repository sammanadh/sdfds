export interface LedgerDevice {
  id: string;
  name: string;
  connection: LedgerDeviceConnection;
}

export enum LedgerDeviceConnection {
  ble,
  hid,
}
