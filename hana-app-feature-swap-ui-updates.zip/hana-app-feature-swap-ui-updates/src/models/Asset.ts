import type { Delegation } from '@/models/Delegation';
import type { FetchedTokenBalance } from '@/models/Token';
import type { Transaction } from '@/models/Transaction';
import type { BigNumber } from '@/utils/bignumber';

export interface CoinAssets {
  balance?: BigNumber;
  transactions?: Array<Transaction>;
}

export interface IconAssets extends CoinAssets {
  availableBalance?: BigNumber;
  tokenBalances?: Record<string, FetchedTokenBalance>;
  staked?: BigNumber;
  unstaking?: BigNumber;
  iScore?: BigNumber;
  iScoreEstimatedIcx?: BigNumber;
  delegations?: Array<Delegation>;
}
