interface EthereumRequestBase {
  id: string;
  method: string;
  params?: any;
}

export interface EthereumRequestChainId extends EthereumRequestBase {
  method: 'eth_chainId' | 'net_version';
}

export interface EthereumRequestAccounts extends EthereumRequestBase {
  method: 'eth_accounts' | 'eth_requestAccounts' | 'eth_coinbase';
}

export interface EthereumRequestTransactionParams {
  from: string;
  to: string;
  data?: string;
  gas?: string;
  gasPrice?: string;
  maxFeePerGas?: string;
  maxPriorityFeePerGas?: string;
  value?: string;
  nonce?: number;
}

export interface EthereumRequestSignTransaction extends EthereumRequestBase {
  method: 'eth_signTransaction' | 'eth_sendTransaction';
  params: Array<EthereumRequestTransactionParams>;
}

export interface EthereumRequestUnsupportedMethods extends EthereumRequestBase {
  method: 'eth_getBlockByNumber' | 'eth_getTransactionByHash';
}

export interface EthereumRequestSubscribe extends EthereumRequestBase {
  method: 'eth_subscribe';
  params:
    | [
        | 'newHeads'
        | 'newBlockHeaders'
        | 'pendingTransactions'
        | 'newPendingTransactions'
        | 'syncing'
      ]
    | ['logs', { fromBlock: number; address: string | Array<string>; topics: Array<unknown> }];
}

export interface EthereumRequestSign extends EthereumRequestBase {
  method: 'eth_sign' | 'personal_sign';
  params: [string, string];
}

export interface EthereumRequestAddAsset extends EthereumRequestBase {
  method: 'wallet_watchAsset';
  params: {
    options: {
      address: string;
      decimals: number;
      symbol: string;
    };
    type: 'ERC20';
  };
}

export interface EthereumRequestSwitchEthereumChain extends EthereumRequestBase {
  method: 'wallet_switchEthereumChain';
  params: [{ chainId: string }];
}

export interface EthereumRequestAddEthereumChain extends EthereumRequestBase {
  method: 'wallet_addEthereumChain';
  params: [
    {
      chainId: string;
      chainName: string;
      nativeCurrency: {
        name: string;
        symbol: string;
        decimals: number;
      };
      rpcUrls: Array<string>;
      blockExplorerUrls?: Array<string>;
      iconUrls?: Array<string>;
    }
  ];
}

export type EthereumRequest =
  | EthereumRequestAddEthereumChain
  | EthereumRequestSwitchEthereumChain
  | EthereumRequestAddAsset
  | EthereumRequestSubscribe
  | EthereumRequestSign
  | EthereumRequestChainId
  | EthereumRequestAccounts
  | EthereumRequestSignTransaction
  | EthereumRequestUnsupportedMethods;
