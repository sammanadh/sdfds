export interface DApp {
  url: string;
  title: string;
  description: string;
  logo?: string;
  logoUrl?: string;
  symbol?: string;
  symbolColor?: string;
  backgroundColor: string;
}
