import type { BigNumber } from '@/utils/bignumber';

export interface GasPriceOption {
  label: string;
  price: BigNumber | null;
  estimatedWait: number | null;
}
