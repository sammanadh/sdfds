import { ChainID } from '@/utils/chains';
import BigNumber from 'bignumber.js';
import type { ChainService, RawTxResponse } from './ChainService';
import type { Transaction } from './Transaction';
import type { ChainWallet } from './Vault';
import type { Token } from './Vault';
import { TransactionConfig } from 'web3-core';
import { EthereumNetworkDetails, NetworkDetails } from '@/utils/networks';
import type { TransactionOptions } from '@/models/ChainService';

export enum SwapServiceProvider {
  ChangeNow = 'ChangeNOW',
  Squid = 'Squid', // NOTE: Functionality code is in another branch feature/squidswap
  OneInch = 'OneInch',
  BalancedNetwork = 'BalancedNetwork',
}

export const ProviderWithSlippage = {
  OneInch: SwapServiceProvider.OneInch,
  BalancedNetwork: SwapServiceProvider.BalancedNetwork,
};

export const ProviderWithInstantSettlement = {
  BalancedNetwork: SwapServiceProvider.BalancedNetwork,
  OneInch: SwapServiceProvider.OneInch,
};

export const ProviderWithPriceImpact = {
  BalancedNetwork: SwapServiceProvider.BalancedNetwork,
};

export const ProviderWithFixedSlippage = {
  BalancedNetwork: SwapServiceProvider.BalancedNetwork,
  ChangeNow: SwapServiceProvider.ChangeNow,
};

export enum SwapStatus {
  Pending,
  Success,
  Failed,
}

export interface SwapService {
  provider: SwapServiceProvider;
  getTokens(networkDetailsArray?: NetworkDetails[]): Promise<Array<SwappableToken>>;
  getPossibleSwaps(from: SwappableToken): Array<SwappableToken>;
  getMinAmount(from: SwappableToken, to: SwappableToken): Promise<BigNumber>;
  getEstimate(
    from: SwappableToken,
    to: SwappableToken,
    amount: BigNumber,
    toAddress: string,
    chainWallet: ChainWallet
  ): Promise<GetEstimateResponse>;
  createSwap(
    chainWallet: ChainWallet,
    chainService: ChainService,
    params: CreateSwapParams,
    fromAddress: string,
    toAddress: string,
    slippage?: BigNumber
  ): Promise<CreatedSwap>;
  completeSwap(
    wallet: ChainWallet,
    chainService: ChainService,
    params: CreateSwapParams,
    fromAddress: string,
    toAddress: string,
    swap: CreatedSwap,
    options?: TransactionOptions,
    slippage?: BigNumber
  ): Promise<Transaction | RawTxResponse>;
  getSwapStatus(swap: Transaction, chainService?: ChainService): Promise<GetStatusResponse>;
}

export type SwappableToken = {
  providers: Array<SwapServiceProvider>;
  providerId: string; // unique ID of the token on the SwapServiceProvider
  chainId: ChainID;
  isNative: boolean;
  contract?: string;
};

export interface GetEstimateResponse {
  amount: BigNumber;
  speed: { min: number; max: number };
  priceImpactPercent?: BigNumber;
  message?: string;
  squidFees?: {
    gasFee: BigNumber;
    protocolFee: BigNumber;
  };
}

export interface CreateSwapParams {
  fromSwappable: SwappableToken;
  fromToken: Token;
  toSwappable: SwappableToken;
  toToken: Token;
  amount: BigNumber;
  estimate: {
    amount: BigNumber;
    speed: { min: number; max: number };
  };
}

export type CreatedSwapChangeNow = {
  id: string;
  payinAddress: string;
};

export type CreatedSwapBalanced = {
  txObj: { [k: string]: any };
  txOptions: TransactionOptions;
};

export type CreatedSwap = CreatedSwapBalanced | CreatedSwapChangeNow | CreatedSwapOneInch;

export interface GetStatusResponse {
  status: SwapStatus;
  label?: string;
  receiveAmount?: BigNumber;
  fee?: BigNumber;
}

export enum ONE_INCH_TX_TYPE {
  APPROVAL = 'approval',
  SWAP = 'swap',
}

export type CreatedSwapOneInch = {
  txn: TransactionConfig;
  type: ONE_INCH_TX_TYPE;
};

export const ONE_INCH_BROADCAST_API_URL = {
  BASE: 'https://api.1inch.dev/tx-gateway/v1.1',
  BROADCAST_SUFFIX: '/broadcast',
};

export const ONE_INCH_SUPPORTED_CHAINS = [
  ChainID.Ethereum,
  ChainID.Polygon,
  ChainID.Arbitrum,
  ChainID.Binance,
  ChainID.Optimism,
  ChainID.Avalanche,
];

export const ONE_INCH_API_BASE_URL = 'https://api.1inch.dev';
export const ONE_INCH_API_VERSION = {
  TOKEN: 'v1.2',
  SWAP: 'v5.2',
};

export const SLIPPAGE = new BigNumber(0.01); // percent

export interface EstimateResponse {
  toAmount: string;
}

export interface OneInchTokenResponse {
  [key: string]: {
    symbol: string;
    name: string;
    decimals: number;
    address: string;
    logoURI: string;
    tags: Array<string>;
    wrappedNative?: boolean;
  };
}