import type { PRep } from '@/models/PRep';
import type { BigNumber } from '@/utils/bignumber';

export interface Delegation {
  address: string;
  amount: BigNumber;
}

export type DelegatedPRep = Delegation & PRep;
