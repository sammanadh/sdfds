import type { BigNumber } from '@/utils/bignumber';

export interface FetchedTokenBalance {
  contract: string;
  balance: BigNumber;
}

export interface CuratedToken {
  contract?: string;
  assetId?: string;
  name: string;
  symbol: string;
  decimals: number;
  symbolColor: string;
  logoUrl?: string;
  backgroundColor: string;
}

export interface FetchedAssetBalance {
  assetId: string;
  balance: BigNumber;
}
