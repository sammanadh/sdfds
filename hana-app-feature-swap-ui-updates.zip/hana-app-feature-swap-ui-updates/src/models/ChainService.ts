import type { CoinAssets } from '@/models/Asset';
import type { Collectable, Collection } from '@/models/Collectable';
import type { FetchedAssetBalance, FetchedTokenBalance } from '@/models/Token';
import type { Transaction, TransactionType } from '@/models/Transaction';
import type { ChainWallet, Token } from '@/models/Vault';
import type { BigNumber } from '@/utils/bignumber';
import type { NetworkDetails } from '@/utils/networks';
import type { SignerPayloadJSON } from '@polkadot/types/types';
import { ethers } from 'ethers';
import TransactionResult from 'icon-sdk-js/build/data/Formatter/TransactionResult';

export interface EstimateTransactionParams {
  type: TransactionType;
  toAddress: string;
  token?: Token;
  amount: BigNumber;
}

export interface SendNativeTokenOptions extends TransactionOptions {
  dotTransferKeepAlive?: boolean;
}

export interface SendAssetOptions extends TransactionOptions {
  dotTransferKeepAlive?: boolean;
}

export interface GasPriceOptions {
  base?: BigNumber;
  low: BigNumber;
  lowWait: number;
  standard: BigNumber;
  standardWait: number;
  high: BigNumber;
  highWait: number;
}

export interface ChainService {
  getBalance(address: string): Promise<BigNumber>;
  sendNativeToken(
    wallet: ChainWallet,
    toAddress: string,
    amount: BigNumber,
    options?: SendNativeTokenOptions
  ): Promise<RawTxResponse | Transaction | string>;
  estimateTransaction(
    wallet: ChainWallet,
    params: EstimateTransactionParams
  ): Promise<TransactionEstimate>;
  isValidAddress(address: string): boolean;
  rpcTransaction(
    wallet: ChainWallet,
    transaction: any,
    options?: TransactionOptions
  ): Promise<RawTxResponse | RpcTransactionResponse | string | any>;
  getTransactions(address: string): Promise<Transaction[]>;
  getNetworkDetails(): NetworkDetails;
  getAssets(address: string): Promise<CoinAssets>;
  waitForTransaction(txHash: string, maxAttempts?: number): Promise<void | TransactionResult>;
}

export interface NearChainService extends ChainService {
  getTokenDetails(contract: string): Promise<Token>;
  getTokenBalance(address: string, token: Token): Promise<BigNumber>;
  getTokenBalances(
    address: string,
    tokens: Array<Token>
  ): Promise<{ [contract: string]: FetchedTokenBalance }>;
  sendToken(
    wallet: ChainWallet,
    token: Token,
    toAddress: string,
    amount: BigNumber,
    options?: TransactionOptions
  ): Promise<RawTxResponse | Transaction | string>;
  storageAvailable(contract: string, address: string): Promise<boolean>;
  transferStorageDeposit(
    fromAddress: string,
    contractName: string,
    receiverId: string,
    storageDepositAmount: string,
    options?: TransactionOptions
  ): void;
}

export interface SubstrateChainService extends ChainService {
  getExistentialDepositAmount(): Promise<BigNumber>;
  getGenesisHash(): Promise<string>;
  sign(data: unknown): Promise<string>;
  signPayload(payload: SignerPayloadJSON, getSerializedTx?: boolean): Promise<string>;
  getAssetBalance(address: string, asset: Token): Promise<BigNumber>;
  getAssetBalances(
    address: string,
    assets: Array<Token>
  ): Promise<{ [assetId: string]: FetchedAssetBalance }>;
  getAssetDetails(assetId: string): Promise<Token>;
  sendAsset(
    wallet: ChainWallet,
    asset: Token,
    toAddress: string,
    amount: BigNumber,
    options?: SendAssetOptions
  ): Promise<Transaction>;
}

export interface EvmChainService extends ChainService {
  getTokenBalance(address: string, token: Token): Promise<BigNumber>;
  getTokenBalances(
    chainWallet: ChainWallet,
    tokens: Array<Token>
  ): Promise<{ [contract: string]: FetchedTokenBalance }>;
  sendToken(
    wallet: ChainWallet,
    token: Token,
    toAddress: string,
    amount: BigNumber,
    options?: TransactionOptions
  ): Promise<RawTxResponse | Transaction | string>;

  getTokenDetails(contract: string): Promise<Token>;
  sign(data: any): Promise<string | undefined>;

  sendCollectable(
    wallet: ChainWallet,
    params: SendCollectableParams,
    options?: TransactionOptions
  ): Promise<Transaction | RawTxResponse>;
  getSigner(): Promise<ethers.Wallet>;
}

export interface RawTxResponse {
  rawTx: any;
  serializedTx: any;
}

export interface RpcTransactionResponse {
  rpcResponse: any;
  pendingTransaction?: Transaction;
}

export interface MoralisWalletTokensReponse {
  token_address: string;
  symbol: string;
  name: string;
  logo: string;
  thumbnail: string;
  decimals: number;
  balance: string;
  possible_spam: boolean;
}

export interface TransactionEstimate {
  amount: BigNumber;
  price: BigNumber;
  tokenPrice: BigNumber;
}

export interface TransactionOptions {
  getRawTx?: boolean;
  rawTx?: any;
  signature?: any;
  wait?: boolean;
  estimatingFee?: boolean;
  stepPrice?: BigNumber;
}

export interface SendCollectableParams {
  toAddress: string;
  collection: Collection;
  collectable: Collectable;
  stepPrice?: BigNumber;
}
