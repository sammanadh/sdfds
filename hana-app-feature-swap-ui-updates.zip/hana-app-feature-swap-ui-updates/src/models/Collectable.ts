import type { ChainID } from '@/utils/chains';

export interface Collection {
  contract: string;
  name: string;
  standard: string;
  chain: { type: ChainID };
}

export interface CollectableAttribute {
  trait_type: string;
  value: string | number;
  display_type?: string;
}

export interface Collectable {
  tokenId: number;
  name: string;
  description?: string;
  imageUrl?: string;
  originalImageUrl?: string;
  attributes?: Array<CollectableAttribute>;
}

export interface CollectionDetails {
  collection: Collection;
  coverImage?: string;
  tokensCount: number;
  tokens?: Array<Collectable>;
}
