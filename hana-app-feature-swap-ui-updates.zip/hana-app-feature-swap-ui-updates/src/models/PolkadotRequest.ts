import type { MetadataDef } from '@polkadot/extension-inject/types';
import type { SignerPayloadJSON, SignerPayloadRaw } from '@polkadot/types/types';
import type { KeypairType } from '@polkadot/util-crypto/types';

interface PolkadotRequestBase {
  id: string;
  method: string;
}

export interface PolkadotAccountsSubscribeRequest extends PolkadotRequestBase {
  method: 'polkadot_accounts_subscribe';
}

export interface PolkadotAccountsGetRequest extends PolkadotRequestBase {
  method: 'polkadot_accounts_get';
}

export interface PolkadotMetadataGetRequest extends PolkadotRequestBase {
  method: 'polkadot_metadata_get';
}

export interface PolkadotMetadataProvideRequest extends PolkadotRequestBase {
  method: 'polkadot_metadata_provide';
  definition: MetadataDef;
}

export interface PolkadotSignerSignPayloadRequest extends PolkadotRequestBase {
  method: 'polkadot_signer_sign_payload';
  payload: SignerPayloadJSON;
}

export interface PolkadotSignerSignRawRequest extends PolkadotRequestBase {
  method: 'polkadot_signer_sign_raw';
  payload: SignerPayloadRaw;
}

export type PolkadotRequest =
  | PolkadotAccountsSubscribeRequest
  | PolkadotAccountsGetRequest
  | PolkadotMetadataGetRequest
  | PolkadotMetadataProvideRequest
  | PolkadotSignerSignPayloadRequest
  | PolkadotSignerSignRawRequest;

export interface PolkadotAccountData {
  address: string;
  name: string;
  genesisHash: string;
  type: KeypairType;
}
