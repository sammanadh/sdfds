import type { ChainID } from '@/utils/chains';
import { isNil } from 'lodash-es';
import type Realm from 'realm';
import { v4 as uuid } from 'uuid';

export type RealmAuthorizedDApp = AuthorizedDApp & Realm.Object;
export class AuthorizedDApp {
  static schema: Realm.ObjectSchema = {
    name: 'AuthorizedDApp',
    properties: {
      host: 'string',
      title: 'string',
      faviconUrl: 'string?',
      chainId: 'string?',
    },
  };

  host: string;
  title: string;
  faviconUrl?: string;
  chainId?: ChainID;

  constructor(host: string, title: string, faviconUrl?: string) {
    this.host = host;
    this.title = title;
    this.faviconUrl = faviconUrl;
  }
}

export type RealmNetwork = CustomNetwork & Realm.Object;
export class CustomNetwork {
  static schema: Realm.ObjectSchema = {
    name: 'CustomNetwork',
    primaryKey: 'id',
    properties: {
      id: 'string',
      chain: 'string',
      name: 'string',
      providerRpcUrl: 'string',
      networkId: 'int',
      symbol: 'string',
      blockExplorerUrl: 'string?',
      blockExplorerApi: 'string?',
    },
  };

  id: string;
  chain: ChainID;
  name: string;
  providerRpcUrl: string;
  networkId: number;
  symbol: string;
  blockExplorerUrl?: string;
  blockExplorerApi?: string;

  constructor(
    chain: ChainID,
    name: string,
    providerRpcUrl: string,
    networkId: number,
    symbol: string
  ) {
    this.id = uuid();
    this.chain = chain;
    this.name = name;
    this.providerRpcUrl = providerRpcUrl;
    this.networkId = networkId;
    this.symbol = symbol;
  }
}

export type RealmContact = Contact & Realm.Object;
export class Contact {
  static schema: Realm.ObjectSchema = {
    name: 'Contact',
    properties: {
      chain: 'string',
      name: 'string',
      address: 'string',
    },
  };

  chain: ChainID;
  name: string;
  address: string;

  constructor(chain: ChainID, name: string, address: string) {
    this.chain = chain;
    this.name = name;
    this.address = address;
  }
}

export type RealmToken = Token & Realm.Object;
export class Token {
  static schema: Realm.ObjectSchema = {
    name: 'Token',
    properties: {
      chainId: 'string',
      contract: 'string?',
      name: 'string',
      symbol: 'string',
      decimals: 'int',
      isActive: 'bool',
      isCustom: 'bool',
      networkRef: 'string?',
      customNetworkId: 'string?',
      assetId: 'string?',
      logoUrl: 'string?',
      balances: { type: 'list', objectType: 'TokenBalance' },
    },
  };

  chainId: ChainID;
  contract?: string;
  name: string;
  symbol: string;
  decimals: number;
  isActive: boolean;
  isCustom: boolean;
  // Helps with identifying testnet and custom networks, if none of these are set then the token is for mainnet
  networkRef?: string;
  customNetworkId?: string;
  assetId?: string;
  logoUrl?: string;
  balances: Array<TokenBalance | RealmTokenBalance>;

  constructor(chainId: ChainID, name: string, symbol: string, decimals: number, logoUrl?: string) {
    this.chainId = chainId;
    this.name = name;
    this.symbol = symbol;
    this.decimals = decimals;
    this.isCustom = false;
    this.isActive = true;
    this.logoUrl = logoUrl;
    this.balances = [];
  }
}

export type RealmTokenBalance = TokenBalance & Realm.Object;
export class TokenBalance {
  static schema: Realm.ObjectSchema = {
    name: 'TokenBalance',
    properties: {
      address: 'string',
      balance: 'double',
      balanceString: 'string',
    },
  };

  address: string;
  balance: number;
  // NOTE: number type cannot store high precision numbers, so we use string to compensate in features such as "Send Max"
  balanceString: string;

  constructor(address: string, balance: number, balanceString: string) {
    this.address = address;
    this.balance = balance;
    this.balanceString = balanceString;
  }
}

export enum ChainWalletSubstrateSignatureType {
  sr25519 = 'sr25519',
  ed25519 = 'ed25519',
}

export type RealmChainWallet = ChainWallet & Realm.Object;
export class ChainWallet {
  static schema: Realm.ObjectSchema = {
    name: 'ChainWallet',
    properties: {
      type: 'string',
      address: 'string',
      hdIndex: 'int?',
      hdPath: 'string?',
      balance: 'double',
      balanceString: 'string',
      isActive: 'bool',
      substrateSignatureType: 'string?',
    },
  };

  type: ChainID;
  address: string;
  hdIndex?: number;
  hdPath?: string;
  balance: number;
  // NOTE: number type cannot store high precision numbers, so we use string to compensate in features such as "Send Max"
  balanceString: string;
  isActive: boolean;
  substrateSignatureType?: ChainWalletSubstrateSignatureType;

  constructor(type: ChainID, address: string, hdIndex?: number) {
    this.type = type;
    this.address = address;
    this.hdIndex = hdIndex;
    this.balance = 0;
    this.balanceString = '0';
    this.isActive = true;
  }
}

export enum WalletType {
  HD = 'HD',
  PK = 'PK',
  Ledger = 'Ledger',
  DotKeystore = 'DotKeystore', // TODO: needed?
}

export type RealmWallet = Wallet & Realm.Object;
export class Wallet {
  map(
    arg0: (cw: ChainWallet | undefined) => import('./Transaction').Transaction[]
  ):
    | import('lodash').List<import('lodash').Many<import('./Transaction').Transaction>>
    | null
    | undefined {
    throw new Error('Method not implemented.');
  }
  static schema: Realm.ObjectSchema = {
    name: 'Wallet',
    primaryKey: 'id',
    properties: {
      id: 'string',
      type: 'string',
      name: 'string',
      added: 'date',
      isActive: 'bool',
      hdIndex: 'int?',
      chainWallets: { type: 'list', objectType: ChainWallet.schema.name },
      ledgerBleId: 'string?',
      authorizedDApps: { type: 'list', objectType: AuthorizedDApp.schema.name },
    },
  };

  id: string;
  type: WalletType;
  name: string;
  added: Date;
  isActive: boolean;
  hdIndex?: number;
  chainWallets: Array<ChainWallet | RealmChainWallet>;
  ledgerBleId?: string;
  authorizedDApps: Array<AuthorizedDApp | RealmAuthorizedDApp>;

  constructor(type: WalletType, name: string, index?: number) {
    this.id = uuid();
    this.type = type;
    this.name = name;
    this.added = new Date();
    this.isActive = true;
    this.chainWallets = [];
    this.authorizedDApps = [];

    if (!isNil(index)) {
      this.hdIndex = index;
    }
  }
}
