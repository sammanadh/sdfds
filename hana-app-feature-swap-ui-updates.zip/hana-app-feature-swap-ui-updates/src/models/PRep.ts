export interface PRep {
  address: string;
  name: string;
  slug: string;
  logo?: string;
  country: string;
  city: string;
  email: string;
  website: string;
  twitter?: string;
  rank: number;
  votes: number;
  voters: number;
  featured?: number;
}
