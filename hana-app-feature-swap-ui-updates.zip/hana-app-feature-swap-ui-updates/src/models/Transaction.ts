import type { ChainWallet, Token } from '@/models/Vault';
import type { BigNumber } from '@/utils/bignumber';
import type { ChainID } from '@/utils/chains';
import type { SwapServiceProvider } from '@/models/SwapService';
import { gt, lt } from 'lodash-es';

export enum TransactionType {
  TokenTransfer = 'TokenTransfer',
  SendNativeToken = 'SendNativeToken',
  SendToken = 'SendToken',
  IScoreClaim = 'IScoreClaim',
  CollectableTransfer = 'CollectableTransfer',
  ContractCall = 'ContractCall',
  TokenSwap = 'TokenSwap',
}

export interface Transaction {
  type: TransactionType;
  hash: string;
  tokenSymbol?: string;
  from?: string;
  to?: string;
  amount: BigNumber;
  fee?: BigNumber;
  gasPrice?: BigNumber;
  date: Date;
  isPending?: boolean;
  isFailed?: boolean;
  chainID?: ChainID;
  chainWallet?: ChainWallet;
  token?: Token;
  title?: string;
  imageUrl?: string;
  rawTx?: any;
  nonce?: number;
  transactionUrl?: string;
  cosmosBroadcastTxMessages?: string;
  tokenContract?: string;
  tokenAssetId?: string;

  // Swap transaction extras
  provider?: SwapServiceProvider;
  // NOTE: Technically same as `token`, `amount` etc but these are much easier to serialize for persistence
  fromAmount?: BigNumber;
  fromChainId?: ChainID;
  fromTokenContract?: string;
  fromTokenAssetId?: string;
  fromTokenSymbol?: string;
  toToken?: Token;

  toAmount?: BigNumber;
  toChainId?: ChainID;
  toTokenContract?: string;
  toTokenAssetId?: string;
  toTokenSymbol?: string;
  toTokenDecimal?: number;
  fromToken?: Token;

  speedEstimate?: { min: number; max: number };
  statusLabel?: string;
}

export function sortByDate(a: Transaction, b: Transaction) {
  return gt(a.date, b.date) ? -1 : lt(a.date, b.date) ? 1 : 0;
}
