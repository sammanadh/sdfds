import { CoinAssets } from '@/models/Asset';
import {
  EthereumRequest,
  EthereumRequestSubscribe,
  EthereumRequestTransactionParams,
} from '@/models/EthereumRequest';
import { FetchedTokenBalance } from '@/models/Token';
import { sortByDate, Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet, Token } from '@/models/Vault';
import {
  GetAccountTokenTransfersData,
  GetAccountTokenTransfersVariables,
  GET_ACCOUNT_TOKEN_TRANSFERS,
} from '@/operations/queries/getAccountTokenTransfers';
import {
  EstimateTransactionParams,
  EvmChainService,
  GasPriceOptions,
  MoralisWalletTokensReponse,
  RawTxResponse,
  RpcTransactionResponse,
  SendCollectableParams,
  SendNativeTokenOptions,
  TransactionOptions,
} from '@/models/ChainService';
import { useChainServices } from '@/stores/ChainServices';
import { useTransactions } from '@/stores/Transactions';
import { getPrivateKey, useVault } from '@/stores/Vault';
import { ERC1155, ERC20, ERC721 } from '@/utils/abis';
import { BigNumber } from '@/utils/bignumber';
import {
  ChainDetails,
  chainForChainID,
  ChainID,
  coinTypeForChainType,
  MORALIS_CHAIN_IDS,
} from '@/utils/chains';
import {
  MORALIS_API_KEY,
  MORALIS_API_URL,
  NUMBER_OF_TRANSACTIONS,
  ONE,
  TWO,
  ZERO,
} from '@/utils/constants';
import { EthereumNetworkDetails, NetworkDetails } from '@/utils/networks';
import { isCustomNetwork, isTestnetConfig } from '@/utils/types';
import { wait } from '@/utils/wait';
import Common from '@ethereumjs/common';
import { Transaction as Tx, TxData } from '@ethereumjs/tx';
import { parse } from 'date-fns';
import { AGGREGATION_GRAPHQL_API } from 'dotenv';
import { request } from 'graphql-request';
import {
  flatten,
  get,
  isArray,
  isBoolean,
  isEmpty,
  isFunction,
  isNil,
  isNumber,
  isObject,
  isString,
  take,
  toLower,
  uniqBy,
} from 'lodash-es';
import { encode as rlpEncode } from 'rlp';
import Web3 from 'web3';
import { SignedTransaction, TransactionConfig } from 'web3-core';
import { Subscription } from 'web3-core-subscriptions';
import { TransactionEstimate } from '../../models/ChainService';
import { HttpProviderOptions, WebsocketProviderOptions } from 'web3-core-helpers';
import { usePendingTransactions } from '@/stores/PendingTransactions';
import { ethers } from 'ethers';

function hexify(data: any): any {
  if (isArray(data)) {
    return data.map(hexify);
  }
  if (isObject(data)) {
    return Object.keys(data).reduce((acc: { [key: string]: any }, key) => {
      acc[key] = hexify((data as { [key: string]: any })[key]);
      return acc;
    }, {});
  }
  if ((isString(data) || isNumber(data)) && !Web3.utils.isHexStrict(data)) {
    return Web3.utils.toHex(data);
  }
  if (isBoolean(data)) {
    return Web3.utils.toHex(Number(data));
  }

  return data;
}

interface EthereumChainService extends EvmChainService {
  subscribe(request: EthereumRequestSubscribe): Subscription<any>;
  estimateWeb3Transaction(transaction: any): Promise<TransactionEstimate>;
}

export class EthereumService implements EthereumChainService {
  private network: EthereumNetworkDetails;
  private web3: Web3;
  private txCommon: Common;
  private chain: ChainDetails;
  private tokenSymbol: string;

  constructor(network: EthereumNetworkDetails) {
    this.network = network;
    this.chain = chainForChainID(network.chainType)!;
    this.tokenSymbol = this.network.token?.symbol ?? this.chain.token.symbol;

    // https://web3js.readthedocs.io/en/v1.8.0/web3-eth.html
    const providerOptions: HttpProviderOptions | WebsocketProviderOptions = {
      timeout: 30000, // ms

      // Enable auto reconnection
      reconnect: {
        auto: true,
        delay: 5000, // ms
        maxAttempts: 5,
        onTimeout: false,
      },
    };

    const { protocol } = new URL(this.network.providerApi);
    if (protocol === 'wss:') {
      this.web3 = new Web3(
        new Web3.providers.WebsocketProvider(this.network.providerApi, providerOptions)
      );
    } else {
      this.web3 = new Web3(
        new Web3.providers.HttpProvider(this.network.providerApi, providerOptions)
      );
    }

    // Use custom chain constructor to support non-ETH chains
    const { name, chainId } = network;
    this.txCommon = Common.custom({ name, chainId });

    // if (network.chainType === ChainID.Ethereum && network.ref !== EthereumNetworkRef.Custom) {
    //   this.txCommon = new Common({ chain: this.network.chainId });
    // } else {
    //   // For non-ETH chains we have to use custom chain constructors
    //   const { name, chainId } = network;
    //   this.txCommon = Common.custom({ name, chainId });
    // }
  }

  public getNetworkDetails(): NetworkDetails {
    return this.network;
  }

  public async getBalance(address: string): Promise<BigNumber> {
    const balanceInWei = await this.web3.eth.getBalance(address);
    const balance = Web3.utils.fromWei(balanceInWei, 'ether');

    return new BigNumber(balance);
  }

  public async getTokenBalance(address: string, token: Token) {
    try {
      const contract = new this.web3.eth.Contract(ERC20, token.contract);
      const balanceInWei = await contract.methods.balanceOf(address).call();
      return new BigNumber(balanceInWei).div(new BigNumber(10).pow(token.decimals));
    } catch (_error) {
      return ZERO;
    }
  }

  public async getTokenBalances(
    chainWallet: ChainWallet,
    tokens: Token[]
  ): Promise<{ [contract: string]: FetchedTokenBalance }> {
    const { type: chain, address } = chainWallet;

    const chainIdentifier = MORALIS_CHAIN_IDS[chain];
    if (isNil(chainIdentifier) || isNil(address)) {
      return {};
    }

    try {
      const url = `${MORALIS_API_URL}/${address}/erc20?chain=${chainIdentifier}`;

      const walletTokensResObj = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': MORALIS_API_KEY,
        },
      });

      if (!walletTokensResObj.ok) {
        throw new Error(`HTTP error, status: ${walletTokensResObj.status}`);
      }

      const walletTokensArr: Array<MoralisWalletTokensReponse> = await walletTokensResObj.json();

      const walletTokenMap = walletTokensArr.reduce((obj, walletToken) => {
        obj[walletToken['token_address']] = walletToken;
        return obj;
      }, {} as { [token: string]: any });

      return tokens.reduce((tokenBalances, token, index) => {
        const contract = token.contract;

        const balance = walletTokenMap[toLower(contract)]?.balance || 0;
        const balanceBn = new BigNumber(balance).div(new BigNumber(10).pow(token.decimals));

        if (contract) {
          tokenBalances[contract] = {
            contract: contract,
            balance: balanceBn,
          };
        }

        return tokenBalances;
      }, {} as { [token: string]: FetchedTokenBalance });
    } catch (err: any) {
      console.warn(
        `Error fetching token balances in ethereum service for chain: ${chain}. `,
        err.message
      );
      return {};
    }
  }

  private async transactionConfigForSendingNativeToken(
    wallet: ChainWallet,
    toAddress: string,
    amount: BigNumber,
    options?: SendNativeTokenOptions,
    estimating: Boolean = false
  ): Promise<TransactionConfig> {
    // const coinType = coinTypeForChainType(this.network.chainType);

    // REMINDER: including chainId breaks with weird error. Need to investigate for other EVM chains?
    let transactionConfig: TransactionConfig = {
      // chainId: coinType === CoinType.ETH ? hexify(this.network.chainId) : undefined,
      nonce: await this.web3.eth.getTransactionCount(wallet.address),
      from: wallet.address,
      to: toAddress,
      // REMINDER: Estimating fees can fail if balance too low on EVM chains
      value: !estimating ? Web3.utils.toWei(amount.toString(), 'ether') : undefined,
    };

    transactionConfig.gas = await this.web3.eth.estimateGas(transactionConfig);
    // transactionConfig.gasPrice = await this.web3.eth.getGasPrice();
    transactionConfig = await this.setTransactionGasFee(transactionConfig, options);

    console.debug('transactionConfigForSendingNativeToken', { transactionConfig });

    return transactionConfig;
  }

  private async transactionConfigForSendingToken(
    wallet: ChainWallet,
    token: Token,
    toAddress: string,
    amount: BigNumber,
    options?: TransactionOptions
  ) {
    const contract = new this.web3.eth.Contract(ERC20, token.contract);
    const value = amount.times(new BigNumber(10).pow(token.decimals));

    let transactionConfig: TransactionConfig = {
      nonce: await this.web3.eth.getTransactionCount(wallet.address),
      from: wallet.address,
      to: token.contract,
      data: contract.methods.transfer(toAddress, value.toString()).encodeABI(),
    };

    transactionConfig.gas = await this.web3.eth.estimateGas(transactionConfig);
    // transactionConfig.gasPrice = await this.web3.eth.getGasPrice();
    transactionConfig = await this.setTransactionGasFee(transactionConfig, options);

    return transactionConfig;
  }

  private async setTransactionGasFee(
    transaction: TransactionConfig,
    options: TransactionOptions | SendNativeTokenOptions = {}
  ): Promise<TransactionConfig> {
    const maxFeePerGas = !isNil(options.stepPrice)
      ? Web3.utils.toWei(options.stepPrice.toFixed(), 'gwei')
      : await this.web3.eth.getGasPrice();

    const isEip1559 = Boolean(this.chain.canSetGasPrice);
    if (isEip1559) {
      const pendingBlock = await this.web3.eth.getBlock('pending');
      // NOTE: maxFeePerGas cannot be less than baseFeePerGas otherwise transaction could fail
      transaction.maxFeePerGas = BigNumber.maximum(
        pendingBlock.baseFeePerGas ?? 0,
        maxFeePerGas
      ).toString();
      const maxPriorityFee = new BigNumber(maxFeePerGas).minus(
        pendingBlock.baseFeePerGas ?? maxFeePerGas
      );

      const twoGwei = Web3.utils.toWei(TWO.toString(), 'gwei');

      transaction.maxPriorityFeePerGas = BigNumber.maximum(maxPriorityFee, twoGwei).toString();
    } else {
      transaction.gasPrice = maxFeePerGas;
    }

    return transaction;
  }

  public async sendNativeToken(
    wallet: ChainWallet,
    toAddress: string,
    amount: BigNumber,
    options: SendNativeTokenOptions = {}
  ): Promise<Transaction | RawTxResponse> {
    let rawTransaction: string;
    let rawTxForReceipt: any;

    if (!isNil(options.rawTx) && !isNil(options.signature)) {
      rawTransaction = this.buildSignedTransaction(options.rawTx, options.signature);
      rawTxForReceipt = options.rawTx;
    } else {
      const getRawTx = options.getRawTx === true;

      const transactionConfig = await this.transactionConfigForSendingNativeToken(
        wallet,
        toAddress,
        amount,
        options
      );

      const rawTxResponse = this.getRawTransaction(transactionConfig);

      if (getRawTx) {
        return rawTxResponse;
      } else {
        rawTxForReceipt = rawTxResponse.rawTx;
      }

      const signedTransaction = await this.signTransaction(transactionConfig);
      rawTransaction = signedTransaction?.rawTransaction!;
    }

    return new Promise<Transaction>((resolve, reject) =>
      this.web3.eth
        .sendSignedTransaction(rawTransaction)
        .once('error', reject)
        .once('transactionHash', (transactionHash) => {
          const gasPrice = !isNil(rawTxForReceipt)
            ? new BigNumber(rawTxForReceipt.maxFeePerGas ?? rawTxForReceipt.gasPrice)
            : undefined;

          return resolve({
            type: TransactionType.SendNativeToken,
            hash: transactionHash,
            from: wallet.address,
            to: toAddress,
            amount,
            date: new Date(),
            isPending: true,
            chainID: wallet.type,
            tokenSymbol: this.tokenSymbol,
            fee: !isNil(rawTxForReceipt)
              ? new BigNumber(
                  Web3.utils.fromWei(
                    new BigNumber(rawTxForReceipt.gas).times(gasPrice!).toString(),
                    'ether'
                  )
                )
              : undefined,
            gasPrice,
            rawTx: rawTxForReceipt,
          });
        })
    );
  }

  public async sendToken(
    wallet: ChainWallet,
    token: Token,
    toAddress: string,
    amount: BigNumber,
    options: TransactionOptions = {}
  ): Promise<RawTxResponse | Transaction | string> {
    const transactionConfig = await this.transactionConfigForSendingToken(
      wallet,
      token,
      toAddress,
      amount,
      options
    );

    let rawTransaction: string;
    let rawTxForReceipt: any;

    const getRawTx = options.getRawTx === true;

    const excludeGasLimit =
      options.estimatingFee === true &&
      (this.chain.id === ChainID.Moonbeam || this.chain.id === ChainID.Moonriver);
    const rawTxResponse = this.getRawTransaction(transactionConfig, !excludeGasLimit);

    if (getRawTx) {
      return rawTxResponse;
    } else {
      rawTxForReceipt = rawTxResponse.rawTx;
    }

    if (options.getRawTx) {
      const excludeGasLimit =
        options.estimatingFee === true &&
        (this.chain.id === ChainID.Moonbeam || this.chain.id === ChainID.Moonriver);
      return this.getRawTransaction(transactionConfig, !excludeGasLimit);
    }

    if (!isNil(options.rawTx) && !isNil(options.signature)) {
      rawTransaction = this.buildSignedTransaction(options.rawTx, options.signature);
      rawTxForReceipt = options.rawTx;
    } else {
      const signedTransaction = await this.signTransaction(transactionConfig);
      rawTransaction = signedTransaction?.rawTransaction!;
    }

    return new Promise<Transaction>((resolve, reject) =>
      this.web3.eth
        .sendSignedTransaction(rawTransaction)
        .once('error', reject)
        .once('transactionHash', (transactionHash) => {
          const gasPrice = !isNil(rawTxForReceipt)
            ? new BigNumber(rawTxForReceipt.maxFeePerGas ?? rawTxForReceipt.gasPrice)
            : undefined;

          return resolve({
            type: TransactionType.SendToken,
            hash: transactionHash,
            from: wallet.address,
            to: toAddress,
            amount,
            date: new Date(),
            isPending: true,
            tokenSymbol: token.symbol,
            token,
            chainID: wallet.type,
            fee: !isNil(rawTxForReceipt)
              ? new BigNumber(
                  Web3.utils.fromWei(
                    new BigNumber(rawTxForReceipt.gas).times(gasPrice!).toString(),
                    'ether'
                  )
                )
              : undefined,
            gasPrice,
            rawTx: rawTxForReceipt,
          });
        })
    );
  }

  public async estimateTransaction(
    wallet: ChainWallet,
    params: EstimateTransactionParams
  ): Promise<TransactionEstimate> {
    let transactionConfig;

    const { type, toAddress, token, amount } = params;

    if (type === TransactionType.SendNativeToken) {
      transactionConfig = await this.transactionConfigForSendingNativeToken(
        wallet,
        toAddress,
        amount,
        undefined,
        true
      );
    }

    if (type === TransactionType.SendToken && token) {
      transactionConfig = await this.transactionConfigForSendingToken(
        wallet,
        token,
        toAddress,
        amount
      );
    }

    if (transactionConfig) {
      const [gasEstimate, gasPrice] = await Promise.all([
        this.web3.eth.estimateGas(transactionConfig),
        this.web3.eth.getGasPrice(),
      ]);

      return {
        amount: new BigNumber(gasEstimate),
        price: new BigNumber(gasPrice),
        tokenPrice: new BigNumber(Web3.utils.fromWei(gasPrice, 'ether')),
      };
    }

    return {
      amount: new BigNumber(0),
      price: new BigNumber(0),
      tokenPrice: new BigNumber(0),
    };
  }

  public async estimateWeb3Transaction(transaction: any) {
    const [gasEstimate, gasPrice] = await Promise.all([
      this.web3.eth.estimateGas(transaction),
      this.web3.eth.getGasPrice(),
    ]);
    return {
      amount: new BigNumber(gasEstimate),
      price: new BigNumber(gasPrice),
      tokenPrice: new BigNumber(Web3.utils.fromWei(gasPrice, 'ether')),
    };
  }

  public isValidAddress(address: string): boolean {
    return Web3.utils.isAddress(address);
  }

  private getRawTransaction(
    transactionConfig: TransactionConfig,
    includeGasLimit: boolean = true
  ): RawTxResponse {
    let rawTx: TxData = hexify(transactionConfig);

    // NOTE: For Moonriver fee estimation, including gasLimit will fail but it's still required for Ledger transactions
    if (includeGasLimit) {
      rawTx.gasLimit = hexify(transactionConfig.gas);
    }

    const tx = Tx.fromTxData(rawTx, { common: this.txCommon });
    const message = tx.getMessageToSign(false);
    const serializedTx = rlpEncode(message).toString('hex');

    return {
      rawTx,
      serializedTx,
    };
  }

  private buildSignedTransaction(rawTx: TxData, signature: any): string {
    const tx = Tx.fromTxData({ ...rawTx, ...signature }, { common: this.txCommon });
    return `0x${tx.serialize().toString('hex')}`;
  }

  private async signTransaction(transaction: TransactionConfig) {
    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();
    const coinType = coinTypeForChainType(this.network.chainType);

    if (activeWallet && coinType) {
      const privateKey = await getPrivateKey(activeWallet, coinType);

      if (privateKey) {
        const signedTransaction: SignedTransaction = await this.web3.eth.accounts.signTransaction(
          transaction,
          privateKey
        );

        return signedTransaction;
      }
    }

    return undefined;
  }

  public async rpcTransaction(
    wallet: ChainWallet,
    transaction: EthereumRequest,
    options: TransactionOptions = {}
  ): Promise<RawTxResponse | RpcTransactionResponse | string> {
    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    const { pendingTransactions: allPendingTransactions } = usePendingTransactions.getState();

    if (!activeWallet) return '';

    let params: EthereumRequestTransactionParams;

    if (
      transaction.method === 'eth_sendTransaction' ||
      transaction.method === 'eth_signTransaction'
    ) {
      let rawTransaction: string;
      if (!isNil(options.rawTx) && !isNil(options.signature)) {
        params = options.rawTx;
        rawTransaction = this.buildSignedTransaction(options.rawTx, options.signature);
      } else {
        params = transaction.params[0];
        if (isEmpty(params.nonce)) {
          const evmWallet = activeWallet.chainWallets.find((w) => w.type === wallet.type)!;

          if (evmWallet.address !== wallet.address) return '';

          const pendingTransactions = allPendingTransactions.filter(
            (t) => t.from === evmWallet.address && t.chainID === wallet.type
          );

          const defaultNonce = await this.web3.eth.getTransactionCount(evmWallet.address);

          if (!isEmpty(pendingTransactions)) {
            const pendingNonces = pendingTransactions
              .filter((t) => !isNil(t.nonce))
              .map((t) => t.nonce!);

            // Get the largest nonce from pending transactions and also transaction count
            // If there are multiple users of the same wallet, defaultNonce could be larger
            const nonces = [Math.max(...pendingNonces) + 1, defaultNonce];

            params.nonce = Math.max(...nonces);
          } else {
            params.nonce = defaultNonce;
          }
        }

        const pendingBlock = await this.web3.eth.getBlock('pending');

        if (isEmpty(params.gas)) {
          const gasEstimate = await this.web3.eth.estimateGas(params);
          params.gas = Web3.utils.toHex(gasEstimate);
          // transactionDetails.gasLimit = undefined; // NOTE: Transaction can fail if gasLimit provided is lower than 21000, and gasLimit is not needed if we provide gas
        }
        if (isEmpty(params.maxFeePerGas) && isEmpty(params.gasPrice)) {
          const gasPrice = await this.web3.eth.getGasPrice();
          const isEip1559 = Boolean(this.chain.canSetGasPrice);
          if (isEip1559) {
            // NOTE: maxFeePerGas cannot be less than baseFeePerGas otherwise transaction could fail
            params.maxFeePerGas = Web3.utils.toHex(
              BigNumber.maximum(pendingBlock.baseFeePerGas ?? 0, gasPrice).toString()
            );
          } else {
            params.gasPrice = Web3.utils.toHex(gasPrice);
          }
        }
        if (!isEmpty(params.maxFeePerGas) && isEmpty(params.maxPriorityFeePerGas)) {
          const maxFeePerGas = new BigNumber(params.maxFeePerGas!);
          const maxPriorityFee = maxFeePerGas.minus(pendingBlock.baseFeePerGas ?? maxFeePerGas);

          // NOTE: 2 Gwei is the recommended minimum for maxPriorityFeePerGas for the transaction to be considered to be included/mined
          // If this value is ZERO then the transaction can fail or take a very long time (i.e. at least 1-2 hours) to be mined
          const twoGwei = Web3.utils.toWei(TWO.toString(), 'gwei');

          params.maxPriorityFeePerGas = Web3.utils.toHex(
            BigNumber.maximum(maxPriorityFee, twoGwei).toString()
          );
        }

        if (options.getRawTx) return this.getRawTransaction(params);

        const signedTransaction = await this.signTransaction(params);
        rawTransaction = signedTransaction!.rawTransaction!;
      }

      if (transaction.method === 'eth_signTransaction') return rawTransaction;

      return new Promise((resolve, reject) =>
        this.web3.eth
          .sendSignedTransaction(rawTransaction)
          .once('transactionHash', (transactionHash: string) => {
            let pendingTransaction: Transaction | undefined;
            if (!isNil(wallet)) {
              const isTransfer = isNil(params.data);
              const amount = !isNil(params.value)
                ? new BigNumber(Web3.utils.fromWei(params.value, 'ether'))
                : ZERO;
              const gasPrice = new BigNumber(params.maxFeePerGas ?? params.gasPrice!);
              pendingTransaction = {
                type: isTransfer ? TransactionType.SendNativeToken : TransactionType.ContractCall,
                hash: transactionHash,
                nonce: Number(params.nonce),
                title: isTransfer ? this.chain.token.name : 'Contract interaction',
                from: wallet.address,
                to: params.to,
                tokenSymbol: this.network.token?.symbol ?? this.chain.token.symbol,
                amount,
                fee: new BigNumber(
                  Web3.utils.fromWei(new BigNumber(params.gas!).times(gasPrice).toString(), 'ether')
                ),
                gasPrice,
                date: new Date(),
                isPending: true,
                rawTx: params,
                chainID: this.chain.id,
              };
            }

            resolve({ rpcResponse: transactionHash, pendingTransaction });
          })
          .once('error', reject)
      );
    }

    // Get a web3 function reference from the transaction.method string
    const methodParts = transaction.method.split('_');
    let method = get(this.web3, methodParts.join('.'));

    // Unsupported method workarounds
    if (transaction.method === 'eth_getBlockByNumber') {
      // getBlockByNumber -> getBlock
      method = get(this.web3, 'eth.getBlock');
    } else if (transaction.method === 'eth_getTransactionByHash') {
      // getTransactionByHash -> getTransaction
      method = get(this.web3, 'eth.getTransaction');
    }

    if (!isFunction(method)) {
      // Try prefixing last part with get, e.g. blockNumber -> getBlockNumber
      let functionName = methodParts[methodParts.length - 1];
      const firstLetter = functionName[0];
      functionName = `get${firstLetter.toUpperCase()}${functionName.slice(1)}`;
      methodParts[methodParts.length - 1] = functionName;

      method = get(this.web3, methodParts.join('.'));
      if (!isFunction(method)) {
        throw new Error('Unsupported method');
      }
    }

    const response = await method(...(transaction.params || []));
    return hexify(response);
  }

  public async getTokenDetails(contract: string) {
    const tokenContract = new this.web3.eth.Contract(ERC20, contract);

    const name = await tokenContract.methods.name().call();
    const symbol = await tokenContract.methods.symbol().call();
    const decimals = await tokenContract.methods.decimals().call();

    return {
      contract,
      name,
      symbol,
      decimals,
    } as Token;
  }

  public async sign(data: any): Promise<string | undefined> {
    console.debug('data: ', data);

    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();
    const coinType = coinTypeForChainType(this.network.chainType);

    if (activeWallet && coinType) {
      const privateKey = await getPrivateKey(activeWallet, coinType);

      if (privateKey) {
        const signed: SignedMesssage = await this.web3.eth.accounts.sign(data, privateKey);
        console.debug('signed: ', signed);
        return signed.signature;
      }
    }

    // TODO: Raw transaction? for Ledger
    return undefined;
  }

  public async getTransactions(address: string): Promise<Transaction[]> {
    const transactionsResults = await Promise.all([
      this.getEthTransactions(address).catch(() => []),
      this.getTokenTransactions(address).catch(() => []),
      this.getCollectableTransactions(address).catch(() => []),
    ]);
    const allTransactionsSorted = flatten(transactionsResults).sort(sortByDate);
    return take(allTransactionsSorted, NUMBER_OF_TRANSACTIONS);
  }

  private async getEthTransactions(address: string) {
    // const url = `${this.network.blockExplorerApi}&module=account&action=txlist&address=${address}&sort=desc&page=1&offset=100`;

    if (isNil(this.network.blockExplorerApi)) return [];

    let url = new URL(this.network.blockExplorerApi);
    let queryParams = new URLSearchParams(url.search);
    queryParams.set('address', address);
    queryParams.set('module', 'account');
    queryParams.set('action', 'txlist');
    queryParams.set('sort', 'desc');
    queryParams.set('page', '1');
    queryParams.set('offset', '100');
    url.search = queryParams.toString();

    console.debug('url: ', url);

    const response = await fetch(url.toString());
    const jsonResponse: HttpListResponse<TransactionResponse> = await response.json();

    if (jsonResponse.status !== '1') {
      if (isString(jsonResponse.result)) {
        console.warn('Failed getting ETH transactions.', jsonResponse.result);
      }
      return [];
    }
    return uniqBy(jsonResponse.result || [], 'hash').reduce((transactions, transaction) => {
      // Ignore if this is a token transaction
      if (!isEmpty(transaction.input) && transaction.input !== '0x') {
        return transactions;
      }

      const to = Web3.utils.toChecksumAddress(transaction.to);
      const from = Web3.utils.toChecksumAddress(transaction.from);
      const fee = new BigNumber(
        Web3.utils.fromWei(
          new BigNumber(transaction.gasUsed ?? transaction.gas)
            .times(transaction.gasPrice)
            .toString(),
          'ether'
        )
      );
      transactions.push({
        hash: transaction.hash,
        type: TransactionType.SendNativeToken,
        date: parse(transaction.timeStamp, 't', new Date()),
        amount: new BigNumber(Web3.utils.fromWei(transaction.value)),
        tokenSymbol: this.tokenSymbol,
        from,
        to,
        fee,
        gasPrice: new BigNumber(transaction.gasPrice),
        isFailed: transaction.isError === '1',
      });

      // console.debug('transactiions: ', transactions);

      return transactions;
    }, [] as Array<Transaction>);
  }

  private async getTokenTransactions(address: string) {
    // const url = `${this.network.blockExplorerApi}&module=account&action=tokentx&address=${address}&sort=desc&page=1&offset=${NUMBER_OF_TRANSACTIONS}`;

    if (isNil(this.network.blockExplorerApi)) return [];

    let url = new URL(this.network.blockExplorerApi);
    let queryParams = new URLSearchParams(url.search);
    queryParams.set('address', address);
    queryParams.set('module', 'account');
    queryParams.set('action', 'tokentx');
    queryParams.set('sort', 'desc');
    queryParams.set('page', '1');
    queryParams.set('offset', '50');
    url.search = queryParams.toString();

    const response = await fetch(url.toString());
    const jsonResponse: HttpListResponse<TokenTransactionResponse> = await response.json();
    if (jsonResponse.status !== '1') {
      if (isString(jsonResponse.result)) {
        console.warn('Failed getting ERC20 transactions.', jsonResponse.result);
      }
      return [];
    }
    return (jsonResponse.result || []).map((transaction) => {
      const to = Web3.utils.toChecksumAddress(transaction.to);
      const from = Web3.utils.toChecksumAddress(transaction.from);
      const fee = new BigNumber(
        Web3.utils.fromWei(
          new BigNumber(transaction.gasUsed ?? transaction.gas)
            .times(transaction.gasPrice)
            .toString(),
          'ether'
        )
      );

      const { tokenName, tokenSymbol, tokenDecimal, contractAddress } = transaction;

      const { otherNetwork } = useChainServices.getState();

      const token = new Token(this.chain.id, tokenName, tokenSymbol, +tokenDecimal);
      token.contract = contractAddress;

      if (isTestnetConfig(otherNetwork)) {
        token.networkRef = otherNetwork.ref;
      } else if (isCustomNetwork(otherNetwork)) {
        token.customNetworkId = otherNetwork.id;
      }

      return {
        hash: transaction.hash,
        type: TransactionType.SendToken,
        date: parse(transaction.timeStamp, 't', new Date()),
        amount: new BigNumber(transaction.value).div(
          new BigNumber(10).pow(+transaction.tokenDecimal)
        ),
        tokenSymbol: transaction.tokenSymbol,
        from,
        to,
        token,
        fee,
        gasPrice: new BigNumber(transaction.gasPrice),
        isFailed: transaction.isError === '1',
      };
    }) as Array<Transaction>;
  }

  private async getCollectableTransactions(address: string): Promise<Array<Transaction>> {
    const { otherNetwork } = useChainServices.getState();

    if (!isNil(otherNetwork)) return [];

    const response = await request<GetAccountTokenTransfersData, GetAccountTokenTransfersVariables>(
      AGGREGATION_GRAPHQL_API,
      GET_ACCOUNT_TOKEN_TRANSFERS,
      {
        where: { chainType: this.chain.id, address },
      }
    );

    return (response.accountTokenTransfers ?? []).map((transaction) => {
      transaction.type = TransactionType.CollectableTransfer;
      transaction.date = new Date(transaction.date!);
      transaction.amount = new BigNumber(transaction.amount!);
      transaction.gasPrice = new BigNumber(transaction.gasPrice!);
      transaction.fee = new BigNumber(
        Web3.utils.fromWei(
          new BigNumber(transaction.gas!).times(transaction.gasPrice).toString(),
          'ether'
        )
      );

      return transaction as Transaction;
    });
  }

  public async getAssets(address: string): Promise<CoinAssets> {
    return {};
  }

  public async waitForTransaction(txHash: string, maxAttempts = 20) {
    const MS_BETWEEN_ATTEMPS = 2000;

    let count = 0;
    while (true) {
      try {
        const transaction = await this.web3.eth.getTransactionReceipt(txHash);
        if (isNil(transaction)) throw new Error('NO_TRANSACTION_RECEIPT');
        if (!transaction.status) throw new Error('TRANSACTION_FAILED');

        return;
      } catch (error: any) {
        count++;
        if (error.message === 'TRANSACTION_FAILED') {
          throw new Error(`Transaction ${txHash} failed.`);
        } else if (count === maxAttempts) {
          throw new Error(`Gave up waiting for transaction ${txHash}, last error: ${error}`);
        }

        await wait(MS_BETWEEN_ATTEMPS);
      }
    }
  }

  public subscribe(request: EthereumRequestSubscribe) {
    switch (request.params[0]) {
      case 'pendingTransactions':
      case 'newPendingTransactions':
        return this.web3.eth.subscribe('pendingTransactions');

      case 'newBlockHeaders':
      case 'newHeads':
        return this.web3.eth.subscribe('newBlockHeaders');

      case 'syncing':
        return this.web3.eth.subscribe('syncing');

      case 'logs':
        // @ts-expect-error 'logs' is a valid subscription type, TS unhappy
        return this.web3.eth.subscribe('logs', request.params[1]);
    }
  }

  public async sendCollectable(
    wallet: ChainWallet,
    params: SendCollectableParams,
    options: TransactionOptions = {}
  ) {
    let rawTransaction: string;
    let rawTxForReceipt: any;

    if (!isNil(options.rawTx) && !isNil(options.signature)) {
      rawTransaction = this.buildSignedTransaction(options.rawTx, options.signature);
    } else {
      let nonce = await this.web3.eth.getTransactionCount(wallet.address);

      const { pendingTransactions } = usePendingTransactions.getState();

      nonce += pendingTransactions.length;

      let transactionConfig: TransactionConfig = {
        nonce,
        from: wallet.address,
        to: params.collection.contract,
        gasPrice: !isNil(params.stepPrice)
          ? Web3.utils.toWei(params.stepPrice.toString(), 'gwei')
          : undefined,
      };

      if (params.collection.standard === 'ERC721') {
        const contract = new this.web3.eth.Contract(ERC721, params.collection.contract);
        transactionConfig.data = contract.methods
          .safeTransferFrom(wallet.address, params.toAddress, params.collectable.tokenId)
          .encodeABI();
      } else if (params.collection.standard === 'ERC1155') {
        const contract = new this.web3.eth.Contract(ERC1155, params.collection.contract);
        transactionConfig.data = contract.methods
          .safeTransferFrom(wallet.address, params.toAddress, params.collectable.tokenId, 1)
          .encodeABI();
      }

      transactionConfig.gas = await this.web3.eth.estimateGas(transactionConfig);
      transactionConfig.gasPrice = await this.web3.eth.getGasPrice();

      const excludeGasLimit =
        options.estimatingFee === true &&
        (this.chain.id === ChainID.Moonbeam || this.chain.id === ChainID.Moonriver);
      const rawTxResponse = this.getRawTransaction(transactionConfig, !excludeGasLimit);

      if (options.getRawTx) {
        return rawTxResponse;
      } else {
        rawTxForReceipt = rawTxResponse.rawTx;
      }

      const signedTransaction = await this.signTransaction(transactionConfig);
      rawTransaction = signedTransaction!.rawTransaction!;
    }

    return new Promise<Transaction>((resolve, reject) =>
      this.web3.eth
        .sendSignedTransaction(rawTransaction)
        .once('error', reject)
        .once('transactionHash', (transactionHash) => {
          const transaction: Transaction = {
            type: TransactionType.CollectableTransfer,
            hash: transactionHash,
            from: wallet.address,
            to: params.toAddress,
            amount: ONE,
            date: new Date(),
            isPending: true,
            chainID: wallet.type,
            rawTx: rawTxForReceipt,
            title: params.collectable.name,
            imageUrl: params.collectable.imageUrl,
          };
          resolve(transaction);
        })
    );
  }

  public async getGasPrices(): Promise<GasPriceOptions> {
    try {
      // Attempt to get gas prices from the block explorer
      if (isNil(this.network.blockExplorerApi)) {
        throw new Error(`Gas price estimates not available for ${this.network.name}.`);
      }
      const url = buildUrl(this.network.blockExplorerApi, {
        module: 'gastracker',
        action: 'gasoracle',
      });
      const response = await fetch(url.toString());
      const jsonResponse: HttpResponse<GasTrackerResponse> = await response.json();
      if (jsonResponse.status !== '1') {
        if (isString(jsonResponse.result)) {
          console.warn('Failed getting gas prices.', jsonResponse.result);
        }
        throw new Error(`Failed getting gas price estimates.`);
      }

      let base: BigNumber | undefined;
      if (!isNil(jsonResponse.result.suggestBaseFee)) {
        base = new BigNumber(Web3.utils.toWei(jsonResponse.result.suggestBaseFee, 'gwei'));
      }

      const low = new BigNumber(Web3.utils.toWei(jsonResponse.result.SafeGasPrice, 'gwei'));
      const standard = new BigNumber(Web3.utils.toWei(jsonResponse.result.ProposeGasPrice, 'gwei'));
      const high = new BigNumber(Web3.utils.toWei(jsonResponse.result.FastGasPrice, 'gwei'));

      const [lowWait, standardWait, highWait] = await Promise.all([
        this.estimateGasWait(low),
        this.estimateGasWait(standard),
        this.estimateGasWait(high),
      ]);

      return {
        base,
        low,
        lowWait,
        standard,
        standardWait,
        high,
        highWait,
      };
    } catch (_error: any) {
      // Build gas prices from block explorer
      const pendingBlock = await this.web3.eth.getBlock('pending');
      const base = new BigNumber(pendingBlock.baseFeePerGas!);
      const baseGwei = Web3.utils.fromWei(base.toString(), 'gwei');

      const lowGwei = new BigNumber(baseGwei).integerValue(BigNumber.ROUND_UP);
      const low = new BigNumber(Web3.utils.toWei(lowGwei.toString(), 'gwei'));
      const lowWait = 45;

      const standard = new BigNumber(await this.web3.eth.getGasPrice());
      const standardGwei = Web3.utils.fromWei(standard.toString(), 'gwei');
      const standardWait = 30;

      const highGwei = new BigNumber(standardGwei).integerValue(BigNumber.ROUND_UP).plus(1);
      const high = new BigNumber(Web3.utils.toWei(highGwei.toString(), 'gwei'));
      const highWait = 24;

      return {
        base,
        low,
        lowWait,
        standard,
        standardWait,
        high,
        highWait,
      };
    }
  }

  public async estimateGasWait(gas: BigNumber) {
    if (isNil(this.network.blockExplorerApi)) {
      throw new Error(`Gas price estimates not available for ${this.network.name}.`);
    }

    const url = buildUrl(this.network.blockExplorerApi, {
      module: 'gastracker',
      action: 'gasestimate',
      gasprice: gas.toString(),
    });
    const response = await fetch(url.toString());
    const jsonResponse: HttpResponse<string> = await response.json();
    if (jsonResponse.status !== '1') {
      if (isString(jsonResponse.result)) {
        console.warn('Failed getting estimated gas wait.', jsonResponse.result);
      }
      throw new Error(`Failed getting gas wait estimate.`);
    }

    return Number(jsonResponse.result);
  }

  public async getSigner(): Promise<ethers.Wallet> {
    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    if (!activeWallet) {
      throw new Error('No active wallet');
    }

    const privateKey = await getPrivateKey(activeWallet, this.chain.coinType);

    const { protocol } = new URL(this.network.providerApi);

    console.debug('this.network.providerApi: ', this.network.providerApi);

    if (protocol === 'wss:' || protocol === 'ws:') {
      const provider = new ethers.providers.WebSocketProvider(this.network.providerApi);
      const signer = new ethers.Wallet(privateKey, provider);

      return signer;
    }

    const provider = new ethers.providers.JsonRpcProvider(this.network.providerApi);
    const signer = new ethers.Wallet(privateKey, provider);

    return signer;
  }
}

function buildUrl(baseUrl: string, queryParams: Record<string, string> = {}) {
  let url = new URL(baseUrl);
  let searchParams = new URLSearchParams(url.search);

  const keys = Object.keys(queryParams);
  for (let i = 0, n = keys.length; i < n; i++) {
    const key = keys[i];
    searchParams.set(key, queryParams[key]);
  }

  url.search = searchParams.toString();
  return url.toString();
}

interface HttpListOkResponse<T> {
  status: '1';
  message: 'OK';
  result: Array<T>;
}

interface HttpListErrorResponse {
  status: '0';
  message: 'NOTOK' | string;
  result: string | [];
}

type HttpListResponse<T> = HttpListOkResponse<T> | HttpListErrorResponse;

interface TransactionResponse {
  hash: string;
  timeStamp: string;
  from: string;
  to: string;
  value: string;
  input: string;
  gas: string;
  gasPrice: string;
  gasUsed: string;
  isError: string;
}

interface TokenTransactionResponse extends TransactionResponse {
  contractAddress: string;
  tokenName: string;
  tokenSymbol: string;
  tokenDecimal: string;
}

interface SignedMesssage extends SignedTransaction {
  message: string;
  signature: string;
}

interface GasTrackerResponse {
  LastBlock: string;
  SafeGasPrice: string;
  ProposeGasPrice: string;
  FastGasPrice: string;
  suggestBaseFee?: string;
  gasUsedRatio?: string;
}

interface HttpOkResponse<T> {
  status: '1';
  message: 'OK';
  result: T;
}

interface HttpErrorResponse {
  status: '0';
  message: 'NOTOK' | string;
  result: string | [];
}

type HttpResponse<T> = HttpOkResponse<T> | HttpErrorResponse;
