import { CoinAssets } from '@/models/Asset';
import { FetchedTokenBalance } from '@/models/Token';
import { Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet, Token, WalletType } from '@/models/Vault';
import {
  EstimateTransactionParams,
  NearChainService,
  RawTxResponse,
  SendNativeTokenOptions,
  TransactionEstimate,
  TransactionOptions,
} from '@/models/ChainService';
import { getMnemonic, useVault } from '@/stores/Vault';
import { BigNumber, toNumber } from '@/utils/bignumber';
import { ChainDetails, ChainID, chains } from '@/utils/chains';
import {
  NEAR_FT_MINIMUM_STORAGE_BALANCE,
  NEAR_FT_MINIMUM_STORAGE_BALANCE_LARGE,
  NEAR_FT_STORAGE_DEPOSIT_GAS,
  NEAR_FT_TRANSFER_GAS,
  NEAR_SEND_NEAR_GAS,
  NEAR_TOKEN_TRANSFER_DEPOSIT,
  ZERO,
} from '@/utils/constants';
import { getKeypairForWallet, isValidNearAddress } from '@/utils/near';
import { NearNetworkDetails } from '@/utils/networks';
import { hexToU8a } from '@polkadot/util';
import BN from 'bn.js';
import { get } from 'lodash-es';
import { connect, ConnectConfig, Near, providers, transactions } from 'near-api-js';
import { InMemoryKeyStore } from 'near-api-js/lib/key_stores';
import { Action, functionCall } from 'near-api-js/lib/transaction';
import { PublicKey } from 'near-api-js/lib/utils';
import { formatNearAmount, parseNearAmount } from 'near-api-js/lib/utils/format';
import { base_decode, serialize } from 'near-api-js/lib/utils/serialize';

const balanceReservedForTransactions = new BigNumber(0.05);

export class NearService implements NearChainService {
  private chain: ChainDetails;
  private near: Near | undefined;
  private keyStore: InMemoryKeyStore;
  private networkId: string;

  constructor(private network: NearNetworkDetails) {
    this.chain = chains.find((chain) => chain.id === network.chainType)!;

    const { networkId } = network;

    this.keyStore = new InMemoryKeyStore();
    this.networkId = networkId;

    this.initNear();
  }

  private async initNear() {
    const { networkId, providerApi, blockExplorerUrl } = this.network;

    const config = {
      networkId,
      keyStore: this.keyStore,
      nodeUrl: providerApi,
      explorerUrl: blockExplorerUrl,
      headers: {},
    } as ConnectConfig;

    this.near = await connect(config);
  }

  public async getBalance(address: string): Promise<BigNumber> {
    if (!this.near) {
      await this.initNear();
    }

    return new Promise((resolve, reject) => {
      this.near!.account(address)
        .then((account) => {
          account
            .getAccountBalance()
            .then((balance) => {
              const availableBalance = new BigNumber(formatNearAmount(balance.available));

              resolve(availableBalance.minus(balanceReservedForTransactions));
            })
            .catch((error) => {
              console.debug('error: ', error);
              // NOTE: Account may have not existed yet hence an error will be thrown
              resolve(ZERO);
            });
        })
        .catch((error) => {
          console.debug('error: ', error);
          resolve(ZERO);
        });
    });
  }

  public async sendNativeToken(
    wallet: ChainWallet,
    toAddress: string,
    amount: BigNumber,
    options?: SendNativeTokenOptions | undefined
  ): Promise<string | RawTxResponse | Transaction> {
    if (!this.near) {
      await this.initNear();
    }

    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    if (!activeWallet) {
      throw new Error('No active wallet');
    }

    const fromAddress = wallet.address;

    const amountToSend = parseNearAmount(amount.toString());

    if (!amountToSend) {
      throw new Error('Invalid amount');
    }

    if (activeWallet.type === WalletType.Ledger) {
      if (options?.getRawTx === true) {
        const transaction = await this.createNearTransaction(fromAddress, toAddress, [
          transactions.transfer(new BN(amountToSend)),
        ]);

        const serializedTx = serialize(transactions.SCHEMA, transaction);
        // const serializedTxHash = new Uint8Array(sha256.array(serializedTx));
        return {
          rawTx: transaction,
          serializedTx,
        } as RawTxResponse;
      } else if (options?.signature) {
        const hash = await this.signAndBroadcastTransaction(options.rawTx, options.signature);

        return {
          type: TransactionType.SendNativeToken,
          hash,
          from: wallet.address,
          to: toAddress,
          amount,
          date: new Date(),
          isPending: true,
          chainID: wallet.type,
        };
      }
    } else {
      const mnemonic = await getMnemonic();

      if (!mnemonic) {
        throw new Error('No mnemonic');
      }

      const keyPair = getKeypairForWallet(activeWallet, mnemonic);

      await this.keyStore.setKey(this.networkId, fromAddress, keyPair);

      const account = await this.near!.account(fromAddress);

      const sendMoney = await account.sendMoney(toAddress, new BN(amountToSend));

      const hash = sendMoney.transaction.hash;

      return {
        type: TransactionType.SendNativeToken,
        hash,
        from: wallet.address,
        to: toAddress,
        amount,
        date: new Date(),
        isPending: true,
        chainID: wallet.type,
      };
    }

    return '';
  }

  private async createNearTransaction(
    fromAddress: string,
    toAddress: string,
    actions: Action[]
  ): Promise<transactions.Transaction> {
    if (!this.near) {
      await this.initNear();
    }

    const account = await this.near!.account(fromAddress);
    const accessKeys = await account.getAccessKeys();

    const accessKey = accessKeys.find((a) => a.access_key.permission === 'FullAccess');

    if (!accessKey) {
      throw new Error('No access key found');
    }

    const publicKey = PublicKey.from(accessKey.public_key);

    // gets sender's public key information from NEAR blockchain
    const provider = new providers.JsonRpcProvider(`https://rpc.${this.networkId}.near.org`);

    const accessKeyInfo = await provider.query(
      `access_key/${fromAddress}/${publicKey.toString()}`,
      ''
    );

    const recentBlockHash = base_decode(accessKeyInfo.block_hash);

    const nonce: number = get(accessKeyInfo, 'nonce') + 1;

    const transaction = transactions.createTransaction(
      fromAddress,
      publicKey,
      toAddress,
      nonce,
      actions,
      recentBlockHash
    );

    return transaction;
  }

  private async signAndBroadcastTransaction(rawTx: any, signature: any): Promise<string> {
    // encodes transaction to serialized Borsh (required for all transactions)
    const signedTransaction = new transactions.SignedTransaction({
      transaction: rawTx,
      signature: new transactions.Signature({
        keyType: 0,
        data: hexToU8a(signature),
      }),
    });

    const signedSerializedTx = signedTransaction.encode();

    // sends transaction to NEAR blockchain via JSON RPC call and records the result
    const provider = new providers.JsonRpcProvider(`https://rpc.${this.networkId}.near.org`);

    const result = await provider.sendJsonRpc('broadcast_tx_commit', [
      Buffer.from(signedSerializedTx).toString('base64'),
    ]);

    const hash = get(result, 'transaction.hash');
    return hash;
  }

  // This is used to check if storage is available before transferring tokens
  // If storage is not available, we need to send a minimum storage deposit before transferring the tokens
  public async storageAvailable(contract: string, address: string): Promise<boolean> {
    if (!this.near) {
      await this.initNear();
    }

    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    const wallet = activeWallet?.chainWallets.find((w) => w.type === ChainID.NEAR);

    if (!wallet) {
      throw new Error('No wallet found');
    }

    const account = await this.near!.account(wallet.address);
    const storageBalance = await account.viewFunction(contract, 'storage_balance_of', {
      account_id: address,
    });

    const storageAvailable = storageBalance?.total !== undefined;

    return storageAvailable;
  }

  // REMINDER: packages/frontend/src/services/FungibleTokens.js
  public async transferStorageDeposit(
    fromAddress: string,
    contractName: string,
    receiverId: string,
    storageDepositAmount: string,
    options: TransactionOptions = {}
  ) {
    const actions = [
      functionCall(
        'storage_deposit',
        {
          account_id: receiverId,
          registration_only: true,
        },
        new BN(NEAR_FT_STORAGE_DEPOSIT_GAS),
        new BN(storageDepositAmount)
      ),
    ];

    if (options.getRawTx) {
      const { getActiveWallet } = useVault.getState();
      const activeWallet = getActiveWallet();

      const wallet = activeWallet?.chainWallets.find((w) => w.type === ChainID.NEAR);

      if (!wallet) {
        throw new Error('No wallet found');
      }

      const transaction = await this.createNearTransaction(wallet.address, contractName, actions);

      const serializedTx = serialize(transactions.SCHEMA, transaction);
      // const serializedTxHash = new Uint8Array(sha256.array(serializedTx));
      return {
        rawTx: transaction,
        serializedTx,
      } as RawTxResponse;
    } else if (options.signature) {
      const hash = this.signAndBroadcastTransaction(options.rawTx, options.signature);

      return hash;
    } else {
      if (!this.near) {
        await this.initNear();
      }

      const account = await this.near!.account(fromAddress);

      // NOTE: The function is (weirdly) protected at time of coding, hence we have to call it using this workaround
      return await account['signAndSendTransaction']({
        receiverId: contractName,
        actions,
      });
    }
  }

  public async sendToken(
    wallet: ChainWallet,
    token: Token,
    toAddress: string,
    amount: BigNumber,
    options: TransactionOptions | undefined = {}
  ): Promise<string | RawTxResponse | Transaction> {
    if (!this.near) {
      await this.initNear();
    }

    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();
    const mnemonic = await getMnemonic();

    if (!activeWallet) {
      throw new Error('No active wallet');
    }

    const amountToSend = amount.multipliedBy(new BigNumber(10).pow(token.decimals)).toString();

    const actions = [
      functionCall(
        'ft_transfer',
        {
          amount: amountToSend,
          receiver_id: toAddress,
        },
        new BN(NEAR_FT_TRANSFER_GAS),
        new BN(NEAR_TOKEN_TRANSFER_DEPOSIT)
      ),
    ];

    if (activeWallet.type === WalletType.Ledger) {
      if (options.getRawTx) {
        const transaction = await this.createNearTransaction(
          wallet.address,
          token.contract!,
          actions
        );
        const serializedTx = serialize(transactions.SCHEMA, transaction);
        // const serializedTxHash = new Uint8Array(sha256.array(serializedTx));
        return {
          rawTx: transaction,
          serializedTx,
        } as RawTxResponse;
      } else if (options.signature) {
        const hash = await this.signAndBroadcastTransaction(options.rawTx, options.signature);

        return hash;
      }
    } else {
      if (!mnemonic) {
        throw new Error('No mnemonic');
      }

      const keyPair = getKeypairForWallet(activeWallet, mnemonic);
      const fromAddress = wallet.address;

      await this.keyStore.setKey(this.networkId, fromAddress, keyPair);

      const account = await this.near!.account(fromAddress);

      // Check if storage is available
      // If not, send a storage deposit before transferring the tokens
      const storageAvailable = await this.storageAvailable(token.contract!, toAddress);

      if (!storageAvailable) {
        try {
          await this.transferStorageDeposit(
            fromAddress,
            token.contract!,
            toAddress,
            NEAR_FT_MINIMUM_STORAGE_BALANCE
          );
        } catch (e: any) {
          console.debug('error: ', e);

          // sic.typo in `mimimum` wording of responses, so we check substring
          // Original string was: 'attached deposit is less than the mimimum storage balance'
          // TODO: Call storage_balance_bounds: https://github.com/near/near-wallet/issues/2522
          if (e.message.includes('attached deposit is less than')) {
            console.debug('sending LARGER deposit');
            await this.transferStorageDeposit(
              fromAddress,
              token.contract!,
              toAddress,
              NEAR_FT_MINIMUM_STORAGE_BALANCE_LARGE
            );
          }
        }
      }

      // Send token
      // NOTE: The function is (weirdly) protected at time of coding, hence we have to call it using this workaround
      const transaction = await account['signAndSendTransaction']({
        receiverId: token.contract!,
        actions,
      });

      const hash = transaction.transaction.hash;

      return {
        type: TransactionType.SendToken,
        hash,
        from: wallet.address,
        to: toAddress,
        amount,
        date: new Date(),
        isPending: true,
        tokenSymbol: token.symbol,
        chainID: wallet.type,
      };
    }

    return '';
  }

  public async estimateTransaction(
    wallet: ChainWallet,
    params: EstimateTransactionParams
  ): Promise<TransactionEstimate> {
    if (!this.near) {
      await this.initNear();
    }

    const latestBlock = await this.near!.connection.provider.block({ finality: 'final' });

    const latestGasPrice = latestBlock.header.gas_price;

    if (params.type === TransactionType.SendNativeToken) {
      const totalGasFee = new BN(latestGasPrice).mul(new BN(NEAR_SEND_NEAR_GAS)).toString();

      return {
        amount: new BigNumber(1),
        price: ZERO,
        tokenPrice: new BigNumber(formatNearAmount(totalGasFee)),
      } as TransactionEstimate;
    }

    if (params.type === TransactionType.SendToken) {
      // Check if storage available
      const storageAvailable = await this.storageAvailable(
        params.token!.contract!,
        params.toAddress
      );

      let totalGasFee;

      if (!storageAvailable) {
        totalGasFee = new BN(latestGasPrice)
          .mul(new BN(NEAR_FT_TRANSFER_GAS).add(new BN(NEAR_FT_STORAGE_DEPOSIT_GAS)))
          .add(new BN(NEAR_FT_MINIMUM_STORAGE_BALANCE))
          .toString();
      } else {
        totalGasFee = new BN(latestGasPrice).mul(new BN(NEAR_FT_TRANSFER_GAS)).toString();
      }

      return {
        amount: new BigNumber(1),
        price: ZERO,
        tokenPrice: new BigNumber(formatNearAmount(totalGasFee)),
      } as TransactionEstimate;
    }

    return {
      amount: ZERO,
      price: ZERO,
      tokenPrice: ZERO,
    };
  }

  public isValidAddress(address: string) {
    return isValidNearAddress(address);
  }

  public async rpcTransaction(
    wallet: ChainWallet,
    transaction: any,
    options?: TransactionOptions | undefined
  ): Promise<RawTxResponse | any> {
    // TODO
  }

  public async getTransactions(address: string): Promise<Transaction[]> {
    let url = new URL(`${this.network.blockExplorerApi}/account/txns`);
    let queryParams = new URLSearchParams(url.search);
    queryParams.set('limit', '100');
    queryParams.set('offset', '0');
    queryParams.set('address', address);
    url.search = queryParams.toString();

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    const jsonResponse: TransactionsResponse = await response.json();

    return jsonResponse.txns
      .filter((txn) => txn.type.toLowerCase() === 'transfer')
      .map((txn) => {
        const { transaction_hash } = txn;
        const amountYoctoString = toNumber(new BigNumber(txn.deposit_value)).toLocaleString(
          'fullwide',
          { useGrouping: false }
        );

        return {
          hash: transaction_hash,
          type: TransactionType.SendNativeToken,
          date: new Date(txn.block_timestamp / 1000000),
          amount: new BigNumber(formatNearAmount(amountYoctoString)),
          tokenSymbol: this.network.token?.symbol ?? this.chain.token.symbol,
          from: txn.from,
          to: txn.to,
        } as Transaction;
      });
  }

  public getNetworkDetails() {
    return this.network;
  }

  public async getAssets(address: string): Promise<CoinAssets> {
    // TODO

    return undefined as any;
  }

  public async waitForTransaction(txHash: string, maxAttempts?: number): Promise<void> {
    // TODO
  }

  public async getTokenDetails(contract: string): Promise<Token> {
    if (!this.near) {
      await this.initNear();
    }

    if (!isValidNearAddress(contract)) {
      throw new Error('Invalid contract address');
    }

    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    const wallet = activeWallet?.chainWallets.find((w) => w.type === ChainID.NEAR);

    if (!wallet) {
      throw new Error('No wallet found');
    }

    const account = await this.near!.account(wallet.address);
    const metadata = await account.viewFunction(contract, 'ft_metadata', {});

    console.debug('metadata: ', metadata);

    const { name, symbol, decimals } = metadata;

    return {
      name,
      symbol,
      decimals,
    } as Token;
  }

  public async getTokenBalance(address: string, token: Token) {
    if (!this.near) {
      await this.initNear();
    }

    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    const wallet = activeWallet?.chainWallets.find((w) => w.type === ChainID.NEAR);

    if (!wallet) {
      throw new Error('No wallet found');
    }

    const account = await this.near!.account(wallet.address);
    const ftBalance = await account.viewFunction(token.contract!, 'ft_balance_of', {
      account_id: address,
    });

    return new BigNumber(ftBalance).div(new BigNumber(10).pow(token.decimals));
  }

  public async getTokenBalances(
    address: string,
    tokens: Token[]
  ): Promise<{ [contract: string]: FetchedTokenBalance }> {
    const tokenBalances = await Promise.all(
      tokens.map((token) => this.getTokenBalance(address, token).catch(() => ZERO))
    );
    return tokenBalances.reduce((tokenBalances, balance, index) => {
      const token = tokens[index];

      if (token.contract) {
        tokenBalances[token.contract] = { contract: token.contract, balance };
      }

      return tokenBalances;
    }, {} as { [token: string]: FetchedTokenBalance });
  }
}

interface TransactionsResponse {
  txns: TransactionsResponseTxn[];
}

interface TransactionsResponseTxn {
  transaction_hash: string;
  type: string;
  height: number;
  included_in_block_hash: string;
  block_timestamp: number;
  from: string;
  to: string;
  deposit_value: string;
  transaction_fee: string;
}
