import { IconAssets } from '@/models/Asset';
import { Delegation } from '@/models/Delegation';
import { FetchedTokenBalance } from '@/models/Token';
import { sortByDate, Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet, Token, Wallet } from '@/models/Vault';
import {
  EstimateTransactionParams,
  EvmChainService,
  SendCollectableParams,
  SendNativeTokenOptions,
  TransactionEstimate,
  TransactionOptions,
} from '@/models/ChainService';
import { useIconNetwork } from '@/stores/IconNetwork';
import { getPrivateKey, useVault } from '@/stores/Vault';
import { BigNumber } from '@/utils/bignumber';
import { ChainDetails, ChainID, chains } from '@/utils/chains';
import { CoinType } from '@/utils/coinTypes';
import {
  ICX_API_VERSION,
  ICX_CALL_TRANSACTION_STEP_COST,
  ICX_GOVERNANCE_ADDRESS,
  ICX_SCORE_INSTALL_ADDRESS,
  NUMBER_OF_TRANSACTIONS,
  ONE,
  TX_STEP_BUFFER,
  ZERO,
} from '@/utils/constants';
import { convertLoopToToken, convertTokenToLoop } from '@/utils/conversion';
import { HavahNetworkDetails, IconNetworkDetails, NetworkDetails } from '@/utils/networks';
import { wait } from '@/utils/wait';
import { parseISO } from 'date-fns';
import IconSDK from 'icon-sdk-js';
import { flatten, isEmpty, isNil, isNull, isUndefined, take } from 'lodash-es';
import { ethers } from 'ethers';
import TransactionResult from 'icon-sdk-js/build/data/Formatter/TransactionResult';
import { BALANCED_CONFIG } from '@/utils/balancedSwap';
import { SwapServiceProvider } from '@/models/SwapService';

const {
  IconBuilder,
  IconConverter,
  IconUtil,
  IconWallet,
  HttpProvider,
  SignedTransaction,
  IconValidator,
} = IconSDK;

const NFT_STANDARDS = ['IRC-3', 'HSP721'];
const NFT_MULTITOKEN_STANDARDS = ['IRC-31', 'HSP1155'];

export interface ICONChainService extends EvmChainService {
  claimIScore(
    wallet: Wallet,
    options?: TransactionOptions
  ): Promise<RawTxResponse | Transaction | string>;
  getAssets(address: string): Promise<IconAssets>;
  setDelegations(
    wallet: Wallet,
    params: SetDelegationsParams,
    options?: TransactionOptions
  ): Promise<RawTxResponse | string>;
  setStake(
    wallet: Wallet,
    params: SetStakeParams,
    options?: TransactionOptions
  ): Promise<RawTxResponse | string>;
  estimateRawTransaction(rawTransaction: any): Promise<TransactionEstimate>;
  sign(data: any): Promise<string | undefined>;
  getEstimatedFee(transaction: any): Promise<BigNumber>;
  readContract(contractAddress: string, method: string, params: any): Promise<any>;
  waitForTransaction(
    txHash: string,
    pollingTimeout?: number,
    maxAttempts?: number
  ): Promise<TransactionResult>;
}

export class ICONService implements ICONChainService {
  private network: IconNetworkDetails | HavahNetworkDetails;
  private chain: ChainDetails;
  private icon: IconSDK;
  private tokenSymbol: string;

  constructor(network: IconNetworkDetails | HavahNetworkDetails) {
    this.network = network;
    this.chain = chains.find((chain) => chain.id === network.chainType)!;

    const provider = new HttpProvider(this.network.providerApi);
    this.icon = new IconSDK(provider);
    this.tokenSymbol = network.token?.symbol || this.chain.token.symbol;
  }

  public getNetworkDetails(): NetworkDetails {
    return this.network;
  }

  public async getBalance(address: string): Promise<BigNumber> {
    return this.getAvailableBalance(address);
  }

  public async getTokenDetails(contract: string) {
    const { CallBuilder } = IconBuilder;
    const callBuilder = new CallBuilder();

    const nameCall = callBuilder.to(contract).method('name').build();
    const name = await this.icon.call(nameCall).execute();

    const symbolCall = callBuilder.to(contract).method('symbol').build();
    const symbol = await this.icon.call(symbolCall).execute();

    const decimalsCall = callBuilder.to(contract).method('decimals').build();
    const decimals = await this.icon.call(decimalsCall).execute();

    return {
      contract,
      name,
      symbol,
      decimals: parseInt(decimals, 16),
    } as Token;
  }

  public async getTokenBalance(address: string, token: Token): Promise<BigNumber> {
    if (!token.contract) {
      throw new Error('Internal error: No token contract address');
    }

    const builder = new IconBuilder.CallBuilder();
    const balanceOfCall = builder
      .to(token.contract)
      .method('balanceOf')
      .params({ _owner: address })
      .build();
    try {
      const balanceInLoop = await this.icon.call(balanceOfCall).execute();
      return convertLoopToToken(balanceInLoop, token.decimals);
    } catch (error) {
      throw new Error(`No balance available for '${address}' on contract '${token.contract}'`);
    }
  }

  public async getTokenBalances(
    chainWallet: ChainWallet,
    tokens: Token[]
  ): Promise<{ [contract: string]: FetchedTokenBalance }> {
    const { address } = chainWallet;
    let multicallAddr = (this.network as IconNetworkDetails)?.balancedMulticallAddress;

    if (multicallAddr) {
      const calls = tokens.map((token) => ({
        target: token.contract,
        method: 'balanceOf',
        params: [address],
      }));

      const builder = new IconBuilder.CallBuilder();
      const balanceOfCall = builder
        .to(multicallAddr)
        .method('tryAggregate')
        .params({
          requireSuccess: '0x0',
          calls,
        })
        .build();

      const balancesRes = await this.icon.call(balanceOfCall).execute();
      const balancesResData = balancesRes.returnData;

      return tokens.reduce((tokenBalances, token, index) => {
        const balanceHex =
          balancesResData[index]?.success === '0x1' ? balancesResData[index].returnData : '0x0';

        tokenBalances[token.contract!] = {
          contract: token.contract!,
          balance: new BigNumber(balanceHex, 16).div(new BigNumber(10).pow(token.decimals)),
        };
        return tokenBalances;
      }, {} as Record<string, FetchedTokenBalance>);
    } else {
      const tokenBalances = await Promise.all(
        tokens.map((token) => this.getTokenBalance(address, token).catch(() => ZERO))
      );
      return tokenBalances.reduce((tokenBalances, balance, index) => {
        const token = tokens[index];
        tokenBalances[token.contract!] = { contract: token.contract!, balance };
        return tokenBalances;
      }, {} as Record<string, FetchedTokenBalance>);
    }
  }

  private async getAvailableBalance(address: string) {
    const balanceInLoop = await this.icon.getBalance(address).execute();
    return convertLoopToToken(balanceInLoop);
  }

  private async getStake(address: string) {
    const builder = new IconBuilder.CallBuilder();
    const getStakeCall = builder
      .to(ICX_SCORE_INSTALL_ADDRESS)
      .method('getStake')
      .params({ address })
      .build();
    const response = (await this.icon.call(getStakeCall).execute()) as GetStakeResponse;

    return {
      staked: convertLoopToToken(response.stake),
      unstaking: !isNil(response.unstakes)
        ? response.unstakes.reduce(
            (unstaking, { unstake }) => unstaking.plus(convertLoopToToken(unstake)),
            ZERO
          )
        : ZERO,
    };
  }

  private async getIScore(address: string) {
    const builder = new IconBuilder.CallBuilder();
    const queryIScoreCall = builder
      .to(ICX_SCORE_INSTALL_ADDRESS)
      .method('queryIScore')
      .params({ address })
      .build();
    const response = (await this.icon.call(queryIScoreCall).execute()) as GetIScoreResponse;

    return {
      iScore: convertLoopToToken(response.iscore),
      estimatedIcx: convertLoopToToken(response.estimatedICX),
    };
  }

  private async getDelegations(address: string): Promise<Array<Delegation>> {
    const builder = new IconBuilder.CallBuilder();
    const getDelegationCall = builder
      .to(ICX_SCORE_INSTALL_ADDRESS)
      .method('getDelegation')
      .params({ address })
      .build();
    const response = (await this.icon.call(getDelegationCall).execute()) as GetDelegationsResponse;

    return response.delegations.map(({ address, value }) => ({
      address,
      amount: convertLoopToToken(value),
    }));
  }

  public async claimIScore(wallet: Wallet, _params: any, options: TransactionOptions = {}) {
    const icxWallet = this.getIconWallet(wallet);

    let signedTransaction: any;
    if (!isNil(options.rawTx) && !isNil(options.signature)) {
      signedTransaction = buildSignedTransaction(options.rawTx, options.signature);
    } else {
      const builder = new IconBuilder.CallTransactionBuilder();
      const claimIScoreTransaction = builder
        .method('claimIScore')
        .from(icxWallet.address)
        .to(ICX_SCORE_INSTALL_ADDRESS)
        .value(ZERO)
        .stepLimit(ICX_CALL_TRANSACTION_STEP_COST)
        .nid(this.network.networkId)
        .version(ICX_API_VERSION)
        .timestamp(Date.now() * 1000)
        .build();

      if (options.getRawTx) {
        return getRawTransaction(IconConverter.toRawTransaction(claimIScoreTransaction as any));
      }

      signedTransaction = await this.signTransaction(claimIScoreTransaction);
    }

    await this.verifyCanAffordTransaction(icxWallet, signedTransaction.getRawTransaction());

    const { icxAssetsForWallet, resetIScore } = useIconNetwork.getState();
    const assets = icxAssetsForWallet();

    try {
      const txHash = (await this.icon.sendTransaction(signedTransaction).execute()) as string;
      const transaction: Transaction = {
        type: TransactionType.IScoreClaim,
        hash: txHash,
        amount: new BigNumber(assets?.iScoreEstimatedIcx || ZERO),
        date: new Date(),
        isPending: true,
      };

      resetIScore();

      return transaction;
    } catch (error) {
      throw new Error(error as string);
    }
  }

  public async setDelegations(
    wallet: Wallet,
    params: SetDelegationsParams,
    options?: TransactionOptions
  ): Promise<string | RawTxResponse> {
    const icxWallet = this.getIconWallet(wallet);
    let signedTransaction: any;
    if (!isNil(options?.rawTx) && !isNil(options?.signature)) {
      signedTransaction = buildSignedTransaction(options!.rawTx, options!.signature);
    } else {
      const delegations = params.delegations.map(({ address, amount }) => ({
        address,
        value: IconConverter.toHexNumber(convertTokenToLoop(amount)),
      }));

      const builder = new IconBuilder.CallTransactionBuilder();
      const setDelegationCall = builder
        .method('setDelegation')
        .params({ delegations: delegations })
        .from(icxWallet.address)
        .to(ICX_SCORE_INSTALL_ADDRESS)
        .stepLimit(ICX_CALL_TRANSACTION_STEP_COST)
        .nid(this.network.networkId)
        .version(ICX_API_VERSION)
        .timestamp(Date.now() * 1000)
        .build();

      if (options?.getRawTx) {
        return getRawTransaction(IconConverter.toRawTransaction(setDelegationCall as any));
      }

      signedTransaction = await this.signTransaction(setDelegationCall);
    }

    await this.verifyCanAffordTransaction(icxWallet, signedTransaction.getRawTransaction());

    try {
      const txHash = await this.icon.sendTransaction(signedTransaction).execute();

      const { updateDelegations } = useIconNetwork.getState();
      updateDelegations(params.delegations);

      if (options?.wait === true) {
        await this.waitForTransaction(txHash);
      }

      return txHash;
    } catch (error) {
      throw new Error(error as string);
    }
  }

  public async setStake(wallet: Wallet, params: SetStakeParams, options: TransactionOptions = {}) {
    const icxWallet = this.getIconWallet(wallet);
    let signedTransaction: any;
    if (!isNil(options.rawTx) && !isNil(options.signature)) {
      signedTransaction = buildSignedTransaction(options.rawTx, options.signature);
    } else {
      const builder = new IconBuilder.CallTransactionBuilder();
      const stakeIcxTransaction = builder
        .method('setStake')
        .params({ value: IconConverter.toHexNumber(convertTokenToLoop(params.amount)) })
        .from(icxWallet.address)
        .to(ICX_SCORE_INSTALL_ADDRESS)
        .stepLimit(ICX_CALL_TRANSACTION_STEP_COST)
        .nid(this.network.networkId)
        .version(ICX_API_VERSION)
        .timestamp(Date.now() * 1000)
        .build();

      if (options.getRawTx) {
        return getRawTransaction(IconConverter.toRawTransaction(stakeIcxTransaction as any));
      }
      signedTransaction = await this.signTransaction(stakeIcxTransaction);
    }

    await this.verifyCanAffordTransaction(icxWallet, signedTransaction.getRawTransaction());

    try {
      const txHash = (await this.icon.sendTransaction(signedTransaction).execute()) as string;
      const { updateStaked } = useIconNetwork.getState();
      updateStaked(params.amount);

      if (options?.wait === true) {
        await this.waitForTransaction(txHash);
      }

      return txHash;
    } catch (error) {
      throw new Error(error as string);
    }
  }

  private getIconWallet(wallet: Wallet): ChainWallet {
    const icxWallet = wallet.chainWallets.find((cw) => cw.type === ChainID.ICON);

    if (isNil(icxWallet)) throw new Error(`No ${CoinType.ICX} wallet for ${wallet.name}`);
    return icxWallet;
  }

  private async getIcxTransaction(wallet: ChainWallet, toAddress: string, amount: BigNumber) {
    const defaultStepCost = await this.getDefaultStepCost();
    const builder = new IconBuilder.IcxTransactionBuilder();
    const sendIcxTransaction = builder
      .nid(this.network.networkId)
      .from(wallet.address)
      .to(toAddress)
      .value(convertTokenToLoop(amount))
      .stepLimit(defaultStepCost)
      .version(ICX_API_VERSION)
      .timestamp(Date.now() * 1000)
      .build();

    return sendIcxTransaction;
  }

  private async getTokenTransaction(
    wallet: ChainWallet,
    token: Token,
    toAddress: string,
    amount: BigNumber
  ) {
    if (!token.contract) {
      throw new Error('Internal error: No token contract address');
    }

    const builder = new IconBuilder.CallTransactionBuilder();
    const transferTransaction = builder
      .method('transfer')
      .params({
        _to: toAddress,
        _value: IconConverter.toHexNumber(convertTokenToLoop(amount, token.decimals)),
      })
      .from(wallet.address)
      .to(token.contract)
      .nid(this.network.networkId)
      .version(ICX_API_VERSION)
      .timestamp(Date.now() * 1000)
      .build();

    return transferTransaction;
  }

  public async sendNativeToken(
    wallet: ChainWallet,
    toAddress: string,
    amount: BigNumber,
    options: SendNativeTokenOptions = {}
  ): Promise<Transaction | RawTxResponse> {
    const sendIcxTransaction = await this.getIcxTransaction(wallet, toAddress, amount);

    let signedTransaction: any;

    if (!isNil(options.rawTx) && !isNil(options.signature)) {
      signedTransaction = buildSignedTransaction(options.rawTx, options.signature);
    } else {
      if (options.getRawTx === true) {
        return getRawTransaction(IconConverter.toRawTransaction(sendIcxTransaction as any));
      }

      signedTransaction = await this.signTransaction(sendIcxTransaction);
    }

    try {
      const txHash = (await this.icon.sendTransaction(signedTransaction).execute()) as string;

      const transaction: Transaction = {
        type: TransactionType.SendNativeToken,
        hash: txHash,
        from: wallet.address,
        to: toAddress,
        amount,
        date: new Date(),
        isPending: true,
        chainID: wallet.type,
        tokenSymbol: this.tokenSymbol,
      };

      return transaction;
    } catch (error) {
      throw new Error(error as string);
    }
  }

  public async sendToken(
    wallet: ChainWallet,
    token: Token,
    toAddress: string,
    amount: BigNumber,
    options: TransactionOptions = {}
  ): Promise<Transaction | RawTxResponse> {
    let sendTransaction: any = {
      jsonrpc: '2.0',
      method: 'icx_sendTransaction',
      id: 12876341,
    };

    if (!isNil(options.rawTx) && !isNil(options.signature)) {
      sendTransaction.params = { ...options.rawTx, signature: options.signature };
    } else {
      const transferTransaction = await this.getTokenTransaction(wallet, token, toAddress, amount);

      sendTransaction.params = IconConverter.toRawTransaction(transferTransaction);

      const estimatedStep = await this.getStepEstimate(sendTransaction);
      sendTransaction.params.stepLimit = IconConverter.toHexNumber(
        estimatedStep.plus(TX_STEP_BUFFER)
      );

      if (options.getRawTx === true) {
        return getRawTransaction(sendTransaction.params);
      }
    }

    try {
      const response = await this.rpcTransaction(wallet, sendTransaction);
      if (!isNil(response.error)) throw new Error(response.error);
      const txHash = response.result;

      const transaction: Transaction = {
        type: TransactionType.SendToken,
        hash: txHash,
        tokenSymbol: token.symbol,
        token,
        amount,
        date: new Date(),
        isPending: true,
        from: wallet.address,
        to: toAddress,
        chainID: wallet.type,
      };
      return transaction;
    } catch (error) {
      throw new Error(error as string);
    }
  }

  public async rpcTransaction(
    wallet: ChainWallet,
    transaction: any,
    options: TransactionOptions = {}
  ) {
    if (isNil(transaction.params.stepLimit)) {
      const estimatedStep = await this.getStepEstimate(transaction);
      transaction.params.stepLimit = IconConverter.toHexNumber(estimatedStep.plus(TX_STEP_BUFFER));
    }

    if (options.getRawTx) {
      return getRawTransaction(transaction.params);
    }

    let transactionToSend = transaction;
    if (!isNil(options.signature)) {
      // signature provided
      transactionToSend.params.signature = options.signature;
    } else if (
      transaction.method === 'icx_sendTransaction' &&
      isNil(transaction.params.signature)
    ) {
      // needs signing
      const transactionHash = IconUtil.makeTxHash(transaction.params);
      transactionToSend.params.signature = await this.sign(transactionHash);
    }

    // TODO: can we use this.icon.call() for 'icx_call' and this.icon.sendTransaction() for 'icx_sendTransaction'?

    const response = await fetch(this.network.providerApi, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(transactionToSend),
    });

    return await response.json();
  }

  public async getTransactions(address: string): Promise<Transaction[]> {
    const transactionsResults = await Promise.all([
      this.getIcxTransactions(address),
      this.getTokenTransactions(address),
      this.getIScoreClaimTransactions(address),
    ]);
    const allTransactionsSorted = flatten(transactionsResults).sort(sortByDate);
    return take(allTransactionsSorted, NUMBER_OF_TRANSACTIONS);
  }

  private async getIcxTransactions(address: string): Promise<Array<Transaction>> {
    if (isNil(this.network.blockExplorerApi)) return [];

    const url = `${this.network.blockExplorerApi}/address/txList?address=${address}&count=50`;
    const response = await fetch(url);
    const jsonResponse: HttpListResponse<IcxTransactionResponse> = await response.json();
    return (jsonResponse.data ?? [])
      .filter((transaction) => transaction.dataType === 'icx')
      .map((transaction) => {
        const from = transaction.fromAddr;
        const to = transaction.toAddr;
        return {
          hash: transaction.txHash,
          type: TransactionType.TokenTransfer,
          from,
          to,
          date: !isNil(transaction.createDate)
            ? parseISO(transaction.createDate)
            : new Date(transaction.timestamp! + ' UTC'),
          amount: IconConverter.toBigNumber(transaction.amount),
          fee: new BigNumber(transaction.fee),
          title: this.network.token?.name ?? this.chain.name,
          tokenSymbol: this.network.token?.symbol ?? this.chain.token.symbol,
          isDeposit: to === address,
          isWithdrawal: from === address,
        };
      });
  }

  private async getTokenTransactions(address: string): Promise<Array<Transaction>> {
    if (isNil(this.network.blockExplorerApi)) return [];

    const url = `${this.network.blockExplorerApi}/address/tokenTxList?address=${address}&count=50`;
    const response = await fetch(url);
    const jsonResponse: HttpListResponse<TokenTransactionResponse> = await response.json();

    const txnArr: Array<Promise<Transaction>> = [];
    (jsonResponse.data ?? []).forEach(async (transaction: any) => {
      const from = transaction.fromAddr;
      const to = transaction.toAddr;
      const tokenContract = transaction.contractAddr || transaction.scoreAddr;

      // just to remove token send trasactions for balaned network, at least for now
      if (to !== BALANCED_CONFIG.IconMainnet.HANA_WALLET_ROUTER) {
        txnArr.push(
          (async () =>
            ({
              hash: transaction.txHash,
              type: TransactionType.TokenTransfer,
              from,
              to,
              title: transaction.contractName ?? transaction.scoreName!,
              date: !isNil(transaction.createDate)
                ? parseISO(transaction.createDate)
                : new Date(transaction.timestamp! + ' UTC'),
              amount: IconConverter.toBigNumber(transaction.quantity),
              tokenContract,
              tokenSymbol: transaction.contractSymbol ?? transaction.scoreSymbol!,
              token: !isNil(tokenContract) ? await this.getTokenDetails(tokenContract) : undefined,
              isDeposit: to === address,
              isWithdrawal: from === address,
            } as Transaction))()
        );
      }
    });
    return await Promise.all(txnArr);
  }

  private async getIScoreClaimTransactions(address: string): Promise<Array<Transaction>> {
    if (isEmpty(this.network.blockExplorerApi)) return [];

    const url = `${this.network.blockExplorerApi}/address/claimIScoreList?address=${address}&count=${NUMBER_OF_TRANSACTIONS}`;
    const response = await fetch(url);
    const jsonResponse: HttpListResponse<IScoreClaimTransactionResponse> = await response.json();
    return (jsonResponse.data || []).map((transaction) => {
      const [date, time] = transaction.createDate.split(' ');
      return {
        hash: transaction.txHash,
        type: TransactionType.IScoreClaim,
        date: parseISO(`${date}T${time}.000Z`),
        amount: IconConverter.toBigNumber(transaction.icx),
        tokenSymbol: this.tokenSymbol,
      };
    });
  }

  private async getDefaultStepCost() {
    const governanceAddress =
      this.chain.id === ChainID.ICON ? ICX_GOVERNANCE_ADDRESS : ICX_SCORE_INSTALL_ADDRESS;
    const builder = new IconBuilder.CallBuilder();
    const getStepCostsCall = builder.to(governanceAddress).method('getStepCosts').build();
    const { default: defaultStepCost } = await this.icon.call(getStepCostsCall).execute();
    return IconConverter.toBigNumber(defaultStepCost);
  }

  public async sign(data: any): Promise<string | undefined> {
    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    if (activeWallet) {
      const privateKey = await getPrivateKey(activeWallet, this.chain.coinType);

      if (privateKey) {
        const iconWallet = IconWallet.loadPrivateKey(privateKey);
        return iconWallet.sign(data);
      }
    }

    return undefined;
  }

  private async signTransaction(transaction: any): Promise<any> {
    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    if (activeWallet) {
      const privateKey = await getPrivateKey(activeWallet, this.chain.coinType);

      if (privateKey) {
        const iconWallet = IconWallet.loadPrivateKey(privateKey);
        return new SignedTransaction(transaction, iconWallet);
      }
    }

    return undefined;
  }

  public isValidAddress(address: string): boolean {
    return IconValidator.isAddress(address);
  }

  public async estimateTransaction(
    wallet: ChainWallet,
    params: EstimateTransactionParams
  ): Promise<TransactionEstimate> {
    const { type, toAddress, amount, token } = params;

    let rawTransaction;
    let transaction;

    if (type === TransactionType.SendNativeToken) {
      const sendIcxTransaction = await this.getIcxTransaction(wallet, toAddress, amount);

      rawTransaction = IconConverter.toRawTransaction(sendIcxTransaction);

      transaction = rawTransaction;
    }

    if (type === TransactionType.SendToken && token) {
      const sendTokenTransaction = await this.getTokenTransaction(wallet, token, toAddress, amount);

      rawTransaction = IconConverter.toRawTransaction(sendTokenTransaction);
      transaction = rawTransaction;
    }

    if (isNil(transaction.jsonrpc)) {
      transaction = {
        jsonrpc: '2.0',
        method: 'icx_sendTransaction',
        params: rawTransaction,
        id: 12876341,
      };
    }

    const [stepEstimate, stepPrice] = await Promise.all([
      this.getStepEstimate(transaction),
      this.getStepPrice(),
    ]);

    return {
      amount: stepEstimate,
      price: stepPrice,
      tokenPrice: convertLoopToToken(stepPrice),
    };
  }

  private async getStepPrice() {
    const governanceAddress =
      this.chain.id === ChainID.ICON ? ICX_GOVERNANCE_ADDRESS : ICX_SCORE_INSTALL_ADDRESS;
    const builder = new IconBuilder.CallBuilder();
    const getStepCostsCall = builder.to(governanceAddress).method('getStepPrice').build();
    const stepPrice = (await this.icon.call(getStepCostsCall).execute()) as string;
    return IconConverter.toBigNumber(stepPrice);
  }

  private async getStepEstimate(transaction: any) {
    const transactionToSend = {
      ...transaction,
      method: 'debug_estimateStep',
      params: { ...transaction.params, stepLimit: undefined },
    };

    const debugApi = this.network.providerApi + 'd';
    const response = await fetch(debugApi, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(transactionToSend),
    });

    const data = await response.json();
    if (!isNil(data.error)) throw new Error(data.error.message);
    return IconConverter.toBigNumber(data.result);
  }

  public async getAssets(address: string): Promise<IconAssets> {
    const [
      availableBalance,
      { staked, unstaking },
      { iScore, estimatedIcx: iScoreEstimatedIcx },
      delegations,
    ] = await Promise.all([
      this.getAvailableBalance(address),
      this.getStake(address),
      this.getIScore(address),
      this.getDelegations(address),
    ]);

    const balance = availableBalance.plus(staked).plus(unstaking ?? 0);

    return {
      balance,
      availableBalance,
      staked,
      unstaking,
      iScore,
      iScoreEstimatedIcx,
      delegations,
    };
  }

  public async estimateRawTransaction(rawTransaction: any) {
    let transaction = rawTransaction;
    if (isNil(transaction.jsonrpc)) {
      transaction = {
        jsonrpc: '2.0',
        method: 'icx_sendTransaction',
        params: rawTransaction,
        id: 12876341,
      };
    }

    const [stepEstimate, stepPrice] = await Promise.all([
      this.getStepEstimate(transaction),
      this.getStepPrice(),
    ]);
    return {
      amount: stepEstimate,
      price: stepPrice,
      tokenPrice: convertLoopToToken(stepPrice),
    };
  }

  private async verifyCanAffordTransaction(icxWallet: ChainWallet, transaction: any) {
    const [balance, { amount, tokenPrice }] = await Promise.all([
      this.getAvailableBalance(icxWallet.address),
      this.estimateRawTransaction(transaction),
    ]);
    if (balance.lt(tokenPrice.times(amount).times(10))) {
      throw new Error('Insufficient ICX for transaction');
    }
    return true;
  }

  public async waitForTransaction(
    txHash: string,
    pollingTimeout = 600,
    maxAttempts = 10
  ): Promise<TransactionResult> {
    let count = 0;
    while (true) {
      try {
        const transaction = (await this.icon
          .getTransactionResult(txHash)
          .execute()) as TransactionResponse;
        if (!transaction.status) throw new Error('TRANSACTION_FAILED');

        return transaction;
      } catch (error: any) {
        count++;
        if (error.message === 'TRANSACTION_FAILED') {
          throw new Error(`Transaction ${txHash} failed.`);
        } else if (count === maxAttempts) {
          throw new Error(`Gave up waiting for transaction ${txHash}, last error: ${error}`);
        }

        await wait(pollingTimeout);
      }
    }
  }

  public async getEstimatedFee(transaction: any) {
    const stepPrice = await this.getStepPrice();
    const stepEstimate = await this.getStepEstimate(transaction);
    return stepEstimate.times(stepPrice);
  }

  public async sendCollectable(
    wallet: ChainWallet,
    params: SendCollectableParams,
    options: TransactionOptions = {}
  ) {
    let sendTransaction: any = {
      jsonrpc: '2.0',
      method: 'icx_sendTransaction',
      id: 12876341,
    };
    if (!isNil(options.rawTx) && !isNil(options.signature)) {
      sendTransaction.params = { ...options.rawTx, signature: options.signature };
    } else {
      let transactionParams: any = {
        _from: wallet.address,
        _to: params.toAddress,
      };
      if (NFT_STANDARDS.includes(params.collection.standard)) {
        transactionParams._tokenId = String(params.collectable.tokenId);
      } else if (NFT_MULTITOKEN_STANDARDS.includes(params.collection.standard)) {
        transactionParams._id = String(params.collectable.tokenId);
        transactionParams._value = '0x1';
      }

      const builder = new IconBuilder.CallTransactionBuilder();
      const transferTransaction = builder
        .method('transferFrom')
        .params(transactionParams)
        .from(wallet.address)
        .to(params.collection.contract)
        .nid(this.network.networkId)
        .version(ICX_API_VERSION)
        .timestamp(Date.now() * 1000)
        .build();

      sendTransaction.params = IconConverter.toRawTransaction(transferTransaction);

      const estimatedStep = await this.getStepEstimate(sendTransaction);
      sendTransaction.params.stepLimit = IconConverter.toHexNumber(
        estimatedStep.plus(TX_STEP_BUFFER)
      );

      if (options.getRawTx) {
        return getRawTransaction(sendTransaction.params);
      }
    }

    try {
      const response = await this.rpcTransaction(wallet, sendTransaction);
      if (!isNil(response.error)) throw new Error(response.error);
      const txHash = response.result;

      const transaction: Transaction = {
        type: TransactionType.CollectableTransfer,
        hash: txHash,
        from: wallet.address,
        to: params.toAddress,
        amount: ONE,
        date: new Date(),
        isPending: true,
        chainID: wallet.type,
        imageUrl: params.collectable.imageUrl,
        title: params.collectable.name,
      };
      return transaction;
    } catch (error) {
      throw new Error(error as string);
    }
  }

  // TODO: Split ICON Service out
  getSigner(): Promise<ethers.Wallet> {
    throw new Error('Method not implemented.');
  }

  public readContract(contractAddress: string, method: string, params: any) {
    const { CallBuilder } = IconBuilder;
    const callBuilder = new CallBuilder();

    const contractCall = callBuilder.to(contractAddress).method(method).params(params).build();
    return this.icon.call(contractCall).execute();
  }
}

function buildSignedTransaction(rawTx: any, signature: string): any {
  return {
    getRawTransaction: () => rawTx,
    getProperties: () => ({ ...rawTx, signature }),
    getSignature: () => signature,
  };
}

interface GetStakeResponse {
  stake: string;
  unstakes?: Array<{ unstake: string }>;
}

function getRawTransaction(rawTx: any) {
  return {
    rawTx,
    serializedTx: IconUtil.generateHashKey(rawTx),
  };
}

interface GetIScoreResponse {
  iscore: string;
  estimatedICX: string;
  blockHeight: string;
}

interface GetStakeResponse {
  stake: string;
  unstakes?: Array<{ unstake: string }>;
}

interface GetDelegationsResponse {
  delegations: Array<{ address: string; value: string }>;
  totalDelegated: string;
  votingPower: string;
}

interface TransactionResponse {
  status: 0 | 1;
  to: string;
  txHash: string;
  txIndex: number;
  blockHash: string;
  blockHeight: number;
  cumulativeStepUsed: BigNumber;
  stepUsed: BigNumber;
  stepPrice: BigNumber;
  eventLogs: Array<any>;
}

interface IcxTransactionResponse {
  txHash: string;
  createDate?: string; // Returned by ICON
  timestamp?: string; // Returned by HAVAH
  fromAddr: string;
  toAddr: string;
  dataType: string;
  amount: string;
  fee: string;
}

interface TokenTransactionResponse {
  txHash: string;
  createDate?: string; // Returned by ICON
  timestamp?: string; // Returned by HAVAH
  fromAddr: string;
  toAddr: string;
  contractAddr?: string; // Returned by ICON
  contractName?: string; // Returned by ICON
  contractSymbol?: string; // Returned by ICON
  scoreAddr?: string; // Returned by HAVAH
  scoreName?: string; // Returned by HAVAH
  scoreSymbol?: string; // Returned by HAVAH
  quantity: string;
}

interface IScoreClaimTransactionResponse {
  txHash: string;
  createDate: string;
  icx: string;
}

interface HttpListResponse<T> {
  data: Array<T>;
  listSize: number;
  totalSize: number;
  result: string; // HTTP status code
  description: string; // HTTP status description
}

export interface SetDelegationsParams {
  delegations: Array<Delegation>;
}

export interface RawTxResponse {
  rawTx: any;
  serializedTx: string;
}

export interface SetStakeParams {
  amount: BigNumber;
}
