import { CoinAssets } from '@/models/Asset';
import { FetchedAssetBalance } from '@/models/Token';
import { Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet, Token, Wallet, WalletType } from '@/models/Vault';
import {
  EstimateTransactionParams,
  RawTxResponse,
  SendAssetOptions,
  SendNativeTokenOptions,
  SubstrateChainService,
  TransactionEstimate,
  TransactionOptions,
} from '@/models/ChainService';
import { useSettings } from '@/stores/Settings';
import { getMnemonic, getPrivateKey, useVault } from '@/stores/Vault';
import { BigNumber, toNumber } from '@/utils/bignumber';
import { ChainDetails, chains } from '@/utils/chains';
import { SubstrateKeyDerivationMethod, ZERO } from '@/utils/constants';
import { NetworkDetails } from '@/utils/networks';
import { getKeyringPairForWallet } from '@/utils/polkadot';
import { wait } from '@/utils/wait';
import type { ApiPromise } from '@polkadot/api';
import '@polkadot/api-augment';
import type { Keyring } from '@polkadot/keyring';
import { SignerPayloadJSON } from '@polkadot/types/types';
import { hexToString, hexToU8a, isHex, u8aToHex, u8aWrapBytes } from '@polkadot/util';
import { cryptoWaitReady } from '@polkadot/util-crypto';
import { HexString } from '@polkadot/util/types';
import { isNil } from 'lodash-es';

let _Keyring: typeof Keyring | undefined = undefined;

// REMINDER: lazy imports are required to get it working properly on Android
cryptoWaitReady().then(() => {
  import('@polkadot/keyring').then((keyring) => {
    _Keyring = keyring.Keyring;
  });
});

export class PolkadotService implements SubstrateChainService {
  private chain: ChainDetails;
  private _api: ApiPromise | undefined;

  private async initApi(): Promise<ApiPromise> {
    return new Promise(async (resolve, reject) => {
      cryptoWaitReady().then(() => {
        import('@polkadot/api').then((api) => {
          const { WsProvider, ApiPromise } = api;

          const provider = new WsProvider(this.network.providerApi);
          this._api = new ApiPromise({ provider });

          return resolve(this._api);
        });
      });
    });
  }

  private get api(): Promise<ApiPromise> {
    return new Promise(async (resolve, reject) => {
      // Init API if it's not already available
      if (!this._api) {
        await this.initApi();
      }

      await this._api!.isReadyOrError;
      if (await this._api!.isReady) {
        return resolve(this._api!);
      } else {
        return reject(new Error('Failed intializing Polkadot API.'));
      }
    });
  }

  constructor(private network: NetworkDetails) {
    this.chain = chains.find((chain) => chain.id === network.chainType)!;

    this.initApi();
  }

  public async getBalance(address: string): Promise<BigNumber> {
    const api = await this.api;
    const { data: balance } = await api.query.system.account(address);

    return new BigNumber(balance.free.toString()).div(
      new BigNumber(10).pow(this.network.token?.decimals ?? this.chain.token.decimals)
    );
  }

  public async sendNativeToken(
    wallet: ChainWallet,
    toAddress: string,
    amount: BigNumber,
    options?: SendNativeTokenOptions
  ): Promise<RawTxResponse | Transaction | string> {
    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    const api = await this.api;

    const amountToSend = amount.multipliedBy(
      new BigNumber(10).pow(this.network.token?.decimals ?? this.chain.token.decimals)
    );

    // Convert BigNumber to String
    const amountString = toNumber(amountToSend).toLocaleString('fullwide', { useGrouping: false });

    // Create a extrinsic
    const transfer =
      options && options.dotTransferKeepAlive === false
        ? api.tx.balances.transfer(toAddress, amountString)
        : api.tx.balances.transferKeepAlive(toAddress, amountString);

    if (!options?.getRawTx && activeWallet!.type !== WalletType.Ledger) {
      // Sign and send the transaction
      const pair = await this.keyringPair(activeWallet!);

      const hash = await transfer.signAndSend(pair);
      const isDeposit = toAddress === wallet.address;

      return {
        type: TransactionType.SendNativeToken,
        hash: hash.toString(),
        from: wallet.address,
        to: toAddress,
        amount,
        date: new Date(),
        isPending: true,
        chainID: wallet.type,
      };
    } else {
      // For Ledger hw wallet
      const senderAddress = wallet.address;

      const { nonce } = await api.query.system.account(senderAddress);
      const registry = await api.registry;

      const signer = api.createType('SignerPayload', {
        method: transfer,
        nonce,
        genesisHash: api.genesisHash,
        blockHash: api.genesisHash,
        runtimeVersion: api.runtimeVersion,
        version: api.extrinsicVersion,
      });

      const extrinsicPayload = api.createType('ExtrinsicPayload', signer.toPayload(), {
        version: api.extrinsicVersion,
      });

      const extrinsicPayloadU8a = extrinsicPayload.toU8a({ method: true });

      // `SignedPayloads` bigger than 256 bits get hashed with blake2_256
      // ref: https://substrate.dev/rustdocs/v3.0.0/src/sp_runtime/generic/unchecked_extrinsic.rs.html#201-209
      const signingPayloadU8a =
        extrinsicPayloadU8a.length > 256 ? registry.hash(extrinsicPayloadU8a) : extrinsicPayloadU8a;

      const signingPayload = u8aToHex(signingPayloadU8a);

      if (options?.getRawTx === true) {
        return {
          rawTx: transfer,
          serializedTx: signingPayload.slice(2), // NOTE: Need to remove the '0x' in front for it to work
        };
      } else if (options?.signature) {
        transfer.addSignature(
          senderAddress,
          hexToU8a('0x' + options?.signature),
          signer.toPayload()
        );

        const hash = await transfer.send();
        return hash.toString();
      }
    }

    return '';
  }

  private async keyringPair(wallet: Wallet) {
    if (!_Keyring) {
      throw new Error('No Keyring available');
    }

    const { substrateKeyDerivationMethod } = useSettings.getState();
    const useSr25519 =
      substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.MnemonicSr25519;
    const signatureType = useSr25519 ? 'sr25519' : 'ed25519';

    const keyring = new _Keyring({ type: signatureType });

    if (wallet.type === WalletType.PK) {
      const privateKey = await getPrivateKey(wallet, this.chain.coinType);
      const pair = keyring.createFromUri('0x' + privateKey, undefined, signatureType);

      return pair;
    }

    if (wallet.type === WalletType.HD) {
      if (substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.MnemonicSr25519) {
        // Use Mnemonic
        const mnemonic = await getMnemonic();
        const pair = getKeyringPairForWallet(wallet, mnemonic!);

        return pair;
      }

      if (substrateKeyDerivationMethod === SubstrateKeyDerivationMethod.Bip44Ed25519) {
        // Use private key
        const privateKey = await getPrivateKey(wallet, this.chain.coinType);
        const pair = keyring.createFromUri('0x' + privateKey, undefined, 'ed25519');

        return pair;
      }
    }

    /*
    if (wallet.type === WalletType.DotKeystore) {
      const keystore = await this.vaultManager.getDotKeystore(wallet, this.network.chainType);
      const pair = keyring.createFromJson(keystore);
      pair.unlock();

      return pair;
    }
*/
    throw new Error(`Cannot get keyring pair for invalid wallet type: ${wallet.type}`);
  }

  public async estimateTransaction(
    wallet: ChainWallet,
    params: EstimateTransactionParams
  ): Promise<TransactionEstimate> {
    const api = await this.api;

    const { toAddress, amount, token } = params;

    const amountToSend = amount.multipliedBy(
      new BigNumber(10).pow(this.network.token?.decimals ?? this.chain.token.decimals)
    );
    // Create a extrinsic

    // Convert BigNumber to String
    const amountString = toNumber(amountToSend).toLocaleString('fullwide', { useGrouping: false });

    const transfer =
      params.type === TransactionType.SendToken && !isNil(token?.assetId)
        ? api.tx.assets.transferKeepAlive(token!.assetId, toAddress, amountString)
        : api.tx.balances.transferKeepAlive(toAddress, amountString);

    // Get payment info
    const info = await transfer.paymentInfo(wallet.address);
    const price = new BigNumber(info.partialFee.toString());

    return {
      amount: new BigNumber(1),
      price,
      tokenPrice: new BigNumber(0),
    } as TransactionEstimate;
  }

  public isValidAddress(address: string): boolean {
    try {
      if (!_Keyring) {
        throw new Error('No Keyring available');
      }

      const keyring: Keyring = new _Keyring();

      const { encodeAddress, decodeAddress } = keyring;

      encodeAddress(isHex(address) ? hexToU8a(address) : decodeAddress(address));

      return true;
    } catch (error) {
      return false;
    }
  }

  public async rpcTransaction(
    wallet: ChainWallet,
    transaction: any,
    options?: TransactionOptions
  ): Promise<any> {
    return {};
  }

  public async getTransactions(address: string): Promise<Transaction[]> {
    const url = `${this.network.blockExplorerApi}/scan/transfers`;
    const data = {
      row: 100,
      page: 0,
      address,
    };
    const response = await fetch(url, {
      method: 'POST',
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json',
      },
    });
    const jsonResponse: TransfersResponse = await response.json();
    if (jsonResponse.code !== 0) {
      console.warn('Failed getting DOT transactions.', jsonResponse.message);
      return [];
    }

    return (jsonResponse.data.transfers ?? [])
      .filter((transfer) => transfer.success)
      .map((transfer) => {
        const { hash } = transfer;

        return {
          hash,
          type: TransactionType.SendNativeToken,
          date: new Date(transfer.block_timestamp * 1000),
          amount: new BigNumber(transfer.amount),
          tokenSymbol: this.network.token?.symbol ?? this.chain.token.symbol,
          from: transfer.from_account_display.address,
          to: transfer.to_account_display.address,
        } as Transaction;
      });
  }

  getNetworkDetails(): NetworkDetails {
    return this.network;
  }

  public async getAssets(address: string): Promise<CoinAssets> {
    const [balance] = await Promise.all([this.getBalance(address)]);

    return {
      balance,
    };
  }

  public async sign(data: string): Promise<HexString> {
    const { getActiveWallet } = useVault.getState();
    const wallet = getActiveWallet();

    if (!wallet) {
      throw new Error('No wallet available');
    }

    const pair = await this.keyringPair(wallet);
    const signature = u8aToHex(pair.sign(u8aWrapBytes(data)));

    return signature;
  }

  public async signPayload(payload: SignerPayloadJSON, getSerializedTx: boolean = false) {
    const { getActiveWallet } = useVault.getState();
    const wallet = getActiveWallet();

    if (!wallet) {
      throw new Error('No wallet available');
    }

    const api = await this.api;
    const { registry } = api;
    const extrinsic = registry.createType('ExtrinsicPayload', payload, {
      version: payload.version,
    });

    if (getSerializedTx === true) {
      const extrinsicPayloadU8a = extrinsic.toU8a({ method: true });

      // `SignedPayloads` bigger than 256 bits get hashed with blake2_256
      // ref: https://substrate.dev/rustdocs/v3.0.0/src/sp_runtime/generic/unchecked_extrinsic.rs.html#201-209
      const signingPayloadU8a =
        extrinsicPayloadU8a.length > 256 ? registry.hash(extrinsicPayloadU8a) : extrinsicPayloadU8a;

      const signingPayload = u8aToHex(signingPayloadU8a);

      return signingPayload.slice(2);
    }

    const pair = await this.keyringPair(wallet);

    const { signature } = extrinsic.sign(pair);

    return signature;
  }

  public async waitForTransaction(txHash: string, maxAttempts?: number): Promise<void> {
    return new Promise<void>(async (resolve, reject) => {
      const api = await this.api;

      // Setup subscription to new blocks, initially returns current latest block
      const unsubscribe = await api.rpc.chain.subscribeNewHeads(async (header) => {
        const headerBlock = await api.rpc.chain.getBlock(header.hash);
        const minedInBlock = headerBlock.block.extrinsics.some(
          (extrinsic) => extrinsic.hash.toHex() === txHash
        );
        if (minedInBlock) {
          unsubscribe();
          resolve();
        }
      });

      // Setup a 2 minute timeout to reject the promise
      wait(2 * 60 * 1000).then(() => {
        unsubscribe();
        reject(new Error(`Gave up waiting for transaction ${txHash}`));
      });
    });
  }

  public async getExistentialDepositAmount() {
    const api = await this.api;

    // NOTE: This value is not yet divided by decimals
    const ed = api.consts.balances.existentialDeposit.toString();

    // Divide by decimals
    const result = new BigNumber(ed).div(
      new BigNumber(10).pow(this.network.token?.decimals ?? this.chain.token.decimals)
    );

    return result;
  }

  public async getGenesisHash() {
    const api = await this.api;

    return api.genesisHash.toString();
  }

  public async getAssetBalance(address: string, asset: Token): Promise<BigNumber> {
    if (!asset.assetId) {
      return ZERO;
    }

    const api = await this.api;
    const query = await api.query.assets.account(asset.assetId, address);
    const rawBalance = query.value.balance.toString();

    return new BigNumber(rawBalance).div(new BigNumber(10).pow(asset.decimals));
  }

  public async getAssetBalances(
    address: string,
    assets: Array<Token>
  ): Promise<{ [assetId: string]: FetchedAssetBalance }> {
    const assetBalances = await Promise.all(
      assets.map((asset) => this.getAssetBalance(address, asset).catch(() => ZERO))
    );
    return assetBalances.reduce((assetBalances, balance, index) => {
      const asset = assets[index];

      if (asset.assetId) {
        assetBalances[asset.assetId] = { assetId: asset.assetId, balance };
      }

      return assetBalances;
    }, {} as { [token: string]: FetchedAssetBalance });

    // Examples
    // const metadata = await api.query.assets.metadata(1);
    // const asset = await api.query.assets.asset(1);
  }

  public async getAssetDetails(assetId: string): Promise<Token> {
    const api = await this.api;
    const metadata = await api.query.assets.metadata(assetId);

    const { name: _name, decimals, symbol: _symbol } = metadata;

    const name = hexToString(_name.toString());
    const symbol = hexToString(_symbol.toString());

    return {
      assetId,
      name,
      symbol,
      decimals: decimals.toNumber(),
    } as Token;
  }

  public async sendAsset(
    wallet: ChainWallet,
    asset: Token,
    toAddress: string,
    amount: BigNumber,
    options: SendAssetOptions = {}
  ): Promise<Transaction> {
    if (!asset.assetId) {
      throw new Error("Can't send asset without assetId");
    }

    const { getActiveWallet } = useVault.getState();
    const activeWallet = getActiveWallet();

    const api = await this.api;

    const amountToSend = amount.multipliedBy(
      new BigNumber(10).pow(this.network.token?.decimals ?? this.chain.token.decimals)
    );

    // Convert BigNumber to String
    const amountString = toNumber(amountToSend).toLocaleString('fullwide', { useGrouping: false });

    // Create a extrinsic
    const transfer =
      options && options.dotTransferKeepAlive === false
        ? api.tx.assets.transfer(asset.assetId, toAddress, amountString)
        : api.tx.assets.transferKeepAlive(asset.assetId, toAddress, amountString);

    // Sign and send the transaction
    const pair = await this.keyringPair(activeWallet!);

    const hash = await transfer.signAndSend(pair);

    return {
      type: TransactionType.SendToken,
      hash: hash.toString(),
      from: wallet.address,
      to: toAddress,
      amount,
      date: new Date(),
      isPending: true,
      chainID: wallet.type,
    };
  }
}

interface TransfersResponse {
  code: number;
  message: string;
  data: TransfersResponseData;
}

interface TransfersResponseData {
  count: number;
  transfers: Array<Transfer>;
}

interface Transfer {
  from: string;
  to: string;
  success: boolean;
  hash: string;
  block_timestamp: number;
  amount: string;
  fee: string;
  nonce: number;
  from_account_display: TransferAccountDisplay;
  to_account_display: TransferAccountDisplay;
}

interface TransferAccountDisplay {
  address: string;
}
