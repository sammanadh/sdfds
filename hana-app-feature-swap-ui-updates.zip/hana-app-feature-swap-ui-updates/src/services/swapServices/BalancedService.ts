import type {
  ChainService,
  RawTxResponse,
  RpcTransactionResponse,
  TransactionOptions,
} from '@/models/ChainService';
import { ICONChainService } from '../chainServices/IconService';
import {
  CreateSwapParams,
  CreatedSwap,
  CreatedSwapBalanced,
  GetEstimateResponse,
  GetStatusResponse,
  SwapService,
  SwapServiceProvider,
  SwapStatus,
  SwappableToken,
} from '@/models/SwapService';
import { Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet, Wallet } from '@/models/Vault';
import { ChainID } from '@/utils/chains';
import {
  BALANCED_CONFIG,
  TokensListResponse,
  PoolDetailsResponse,
  ICX_CONTRACT,
  SICX_ICX_POOL_ID,
  BALANCED_GENERAL_SWAP_FEE,
  BALANCED_ICX_SWAP_FEE,
  BALANCED_SWAP_SLIPPAGE,
  CALL_AGGREGATE_CHUNK_SIZE,
  MultiPoolDetailsResponse,
} from '@/utils/balancedSwap';
import BigNumber from 'bignumber.js';
import { isArray, isNil, intersection, uniqWith, isEqual } from 'lodash-es';
import Web3 from 'web3';
import { mainnets } from '@/utils/networks';
import TransactionResult from 'icon-sdk-js/build/data/Formatter/TransactionResult';
import { ONE, TEN, ZERO } from '@/utils/constants';

export class BalancedService implements SwapService {
  provider = SwapServiceProvider.BalancedNetwork;
  chainService: ICONChainService | undefined;
  config = BALANCED_CONFIG.IconMainnet;
  swapServiceFeePercent: BigNumber | undefined;
  supportedTokens: Array<TokensListResponse> = [];
  memoizedPools: Array<PoolDetailsResponse & { timestamp: number }> = [];

  currentSwapEstimates = {
    bestAmount: [new BigNumber(0), new BigNumber(0)],
    bestPath: [''],
  };

  constructor(chainService: ICONChainService) {
    this.chainService = chainService;
    this.setSwapServiceFee();
  }

  async setSwapServiceFee() {
    const fee = await this.chainService?.readContract(
      this.config.HANA_WALLET_ROUTER,
      this.config.GET_SWAP_SERVICE_FEE,
      {}
    );
    this.swapServiceFeePercent = new BigNumber(fee);
  }

  async getTokens(): Promise<Array<SwappableToken>> {
    const res = await fetch(this.config.API_BASE + this.config.GET_TOKENS_PATH);
    const data = (await res.json()) as Array<TokensListResponse>;

    // filter only balanced token & format ICX token info
    this.supportedTokens = data
      // .filter((d) => d.type === 'balanced')
      .map((d) => {
        if (d.symbol === 'ICX')
          return {
            ...d,
            address: ICX_CONTRACT,
          };
        return d;
      });

    return this.supportedTokens.map((token) => ({
      provider: SwapServiceProvider.BalancedNetwork,
      providers: [this.provider],
      providerId: token.symbol,
      chainId: ChainID.ICON,
      isNative: token.address === ICX_CONTRACT,
      contract: token.address,
    }));
  }

  getPossibleSwaps(from: SwappableToken): SwappableToken[] {
    if (!from.providers.includes(this.provider)) {
      return [];
    }

    const fromContract = from.isNative ? ICX_CONTRACT : from.contract;

    return this.supportedTokens
      .filter((t) => t.address !== fromContract)
      .map((token) => ({
        providers: [this.provider],
        providerId: token.symbol,
        chainId: ChainID.ICON,
        isNative: token.address === ICX_CONTRACT,
        contract: token.address,
      }));
  }

  async getMinAmount(from: SwappableToken, to: SwappableToken): Promise<BigNumber> {
    // minimum amount that can be swapped
    return new Promise((resolve) => {
      resolve(new BigNumber('0.1'));
    });
  }

  private getPoolPrice(poolDetails: PoolDetailsResponse, from: string, to: string) {
    let readablePrice = new BigNumber(0);
    if (from === ICX_CONTRACT || to === ICX_CONTRACT) {
      readablePrice = new BigNumber(poolDetails.price).dividedBy(
        TEN.pow(poolDetails.base_decimals)
      );
    } else {
      const baseTokenInPool = new BigNumber(poolDetails.base).div(
        TEN.pow(poolDetails.base_decimals)
      );
      const quoteTokenInPool = new BigNumber(poolDetails.quote).div(
        TEN.pow(poolDetails.quote_decimals)
      );
      readablePrice = quoteTokenInPool.div(baseTokenInPool);
    }
    if (poolDetails.base_token === to) {
      return new BigNumber(1).dividedBy(readablePrice);
    }
    return readablePrice;
  }

  private async loadAllPools(routes: Array<string[]>) {
    const poolsCallData: Array<any> = [];
    for (const route of routes) {
      for (let i = 0; i < route.length - 1; i++) {
        const sortedTokenAddress = [route[i], route[i + 1]].sort((a, b) => a.localeCompare(b));
        const isIcxPool = route[i] === ICX_CONTRACT || route[i + 1] === ICX_CONTRACT;
        poolsCallData.push({
          target: this.config.BALANCED_DEX_ADDRESS,
          method: isIcxPool ? this.config.GET_POOL_STATS_BY_ID : this.config.GET_POOL_STATS_BY_PAIR,
          params: isIcxPool ? [Web3.utils.toHex(SICX_ICX_POOL_ID)] : sortedTokenAddress,
        });
      }
    }

    const uniquePoolsCallData = uniqWith(poolsCallData, isEqual);

    // clear memoized pools
    this.memoizedPools = [];

    let index = 0;
    while (index < uniquePoolsCallData.length) {
      const result: MultiPoolDetailsResponse = await this.chainService?.readContract(
        this.config.BALANCED_MULTICALL_ADDRESS,
        this.config.TRY_AGGREGATE,
        {
          requireSuccess: '0x0',
          calls: uniquePoolsCallData.slice(index, index + CALL_AGGREGATE_CHUNK_SIZE),
        }
      );
      index += CALL_AGGREGATE_CHUNK_SIZE;
      const formattedPools = result.returnData.map((data) => {
        const returnData = {
          ...data.returnData,
          timestamp: Date.now(),
        };
        // re-fix response for sICX/ICX pool
        if (isNil(data.returnData.quote_token) && data.returnData.name === 'sICX/ICX') {
          returnData.quote_token = ICX_CONTRACT;
        }
        return returnData;
      });
      this.memoizedPools.push(...formattedPools);
    }
  }

  private async getPoolDetails(
    token1Address: string,
    token2Address: string
  ): Promise<PoolDetailsResponse> {
    const poolIndexFromCache = this.memoizedPools.findIndex(
      (pool) =>
        (pool.base_token === token1Address && pool.quote_token === token2Address) ||
        (pool.quote_token === token1Address && pool.base_token === token2Address)
    );

    if (poolIndexFromCache !== -1) {
      return this.memoizedPools[poolIndexFromCache];
    }

    if (token1Address === ICX_CONTRACT || token2Address === ICX_CONTRACT) {
      return this.chainService?.readContract(
        this.config.BALANCED_DEX_ADDRESS,
        this.config.GET_POOL_STATS_BY_ID,
        {
          _id: Web3.utils.toHex(SICX_ICX_POOL_ID),
        }
      );
    }

    return this.chainService?.readContract(
      this.config.BALANCED_DEX_ADDRESS,
      this.config.GET_POOL_STATS_BY_PAIR,
      {
        _base: token1Address,
        _quote: token2Address,
      }
    );
  }

  private getBaseAndQuote(
    poolStats: PoolDetailsResponse,
    fromContract: string,
    toContract: string
  ) {
    const assumedBase = { liquidity: poolStats.base, decimals: poolStats.base_decimals };
    const assumedQuote = { liquidity: poolStats.quote, decimals: poolStats.quote_decimals };

    if (poolStats.base_token === fromContract && poolStats.quote_token === toContract)
      return [assumedBase, assumedQuote];
    else if (poolStats.base_token === toContract && poolStats.quote_token === fromContract)
      return [assumedQuote, assumedBase];
    else throw new Error('Invalid LP');
  }

  async getEstimate(
    from: SwappableToken,
    to: SwappableToken,
    amount: BigNumber
  ): Promise<GetEstimateResponse> {
    if (isNil(this.swapServiceFeePercent))
      throw new Error('Could not communicate with the Hana Router contract');

    const amountAfterHanaFee = amount.times(ONE.minus(this.swapServiceFeePercent.div(10_000)));

    const { bestAmount, bestPath } = await this.getBestRoute(
      this.supportedTokens.find((t) => t.address === from.contract)!,

      this.supportedTokens.find((t) => t.address === to.contract)!,
      amountAfterHanaFee
    );

    this.currentSwapEstimates = { bestAmount, bestPath };

    const [estimatedAmt, idealEstimateAmt] = bestAmount;

    const priceImpactPercent = idealEstimateAmt.eq(ZERO)
      ? ZERO
      : idealEstimateAmt.minus(estimatedAmt).div(idealEstimateAmt);

    return {
      amount: bestAmount[0],
      speed: { min: Number(0), max: Number(1) },
      priceImpactPercent,
    };
  }

  private computeAllRoutes(
    fromToken: TokensListResponse,
    toAddress: string,
    currentHop: number,
    traversedPools: Array<number>,
    traversedTokens: Array<string>,
    routes: Array<string[]>
  ) {
    const nextTokensInPath = this.supportedTokens.filter((token) => {
      const commonPool = intersection(fromToken.pools, token.pools)[0];
      // should have atleast one pool untraversed
      return (
        !isNil(commonPool) &&
        token.address !== fromToken.address &&
        !traversedPools.includes(commonPool) &&
        !traversedTokens.includes(token.address)
      );
    });

    nextTokensInPath.forEach((token) => {
      if (currentHop > 1 && token.address !== toAddress) {
        const currentPool = intersection(fromToken.pools, token.pools);

        this.computeAllRoutes(
          token,
          toAddress,
          currentHop - 1,
          [...traversedPools, currentPool[0]],
          [...traversedTokens, token.address],
          routes
        );
      } else {
        if (token.address === toAddress) {
          routes.push([...traversedTokens, toAddress]);
        }
      }
    });
  }

  private async getBestRoute(
    fromToken: TokensListResponse,
    toToken: TokensListResponse,
    amount: BigNumber,
    maxHops: number = 3
  ) {
    const routes: Array<string[]> = [];
    // populate routes with new all possible routes
    this.computeAllRoutes(fromToken, toToken.address, maxHops, [], [fromToken.address], routes);

    // fetch and save pool info beforehand
    await this.loadAllPools(routes);

    let bestPathSoFar: Array<string> = [];
    let bestPriceSoFar = new BigNumber(0);
    let idealPriceSoFar = new BigNumber(0);

    for (let route of routes) {
      let swapInputAmt = new BigNumber(amount);
      let bestInputAmt = new BigNumber(amount);

      for (let j = 0; j < route.length - 1; j++) {
        const poolStats = await this.getPoolDetails(route[j], route[j + 1]);

        let estimatedAmt = new BigNumber(0);
        let fromAmtAfterFee = swapInputAmt;

        if (route[j] === ICX_CONTRACT || route[j + 1] === ICX_CONTRACT) {
          // icx only exists for sicx/icx pool
          if (route[j] === ICX_CONTRACT) {
            fromAmtAfterFee = swapInputAmt;

            const priceMultiplier = new BigNumber(1)
              .times(TEN.pow(poolStats.quote_decimals))
              .div(poolStats.price);

            estimatedAmt = priceMultiplier.times(swapInputAmt);
          } else {
            fromAmtAfterFee = swapInputAmt.minus(swapInputAmt.times(BALANCED_ICX_SWAP_FEE));

            const priceMultiplier = new BigNumber(poolStats.price).div(
              TEN.pow(poolStats.quote_decimals)
            );
            estimatedAmt = priceMultiplier.times(fromAmtAfterFee);
          }
        } else {
          fromAmtAfterFee = swapInputAmt.minus(swapInputAmt.times(BALANCED_GENERAL_SWAP_FEE));

          const [base, quote] = this.getBaseAndQuote(poolStats, route[j], route[j + 1]);
          const k = new BigNumber(base.liquidity).times(quote.liquidity);
          const fromInLP = new BigNumber(base.liquidity).plus(
            fromAmtAfterFee.times(TEN.pow(base.decimals))
          );
          const toInLP = k.div(fromInLP);
          estimatedAmt = new BigNumber(quote.liquidity)
            .minus(toInLP)
            .div(Math.pow(10, parseInt(quote.decimals, 16)));
        }

        const bestSwapPrice = this.getPoolPrice(poolStats, route[j], route[j + 1]);
        const bestSwapAmt = bestSwapPrice.times(fromAmtAfterFee);

        // prepare for next iteration
        bestInputAmt = bestSwapAmt;
        swapInputAmt = estimatedAmt;
      }
      // update best route details
      if (swapInputAmt.gt(bestPriceSoFar)) {
        bestPriceSoFar = swapInputAmt;
        idealPriceSoFar = bestInputAmt;
        bestPathSoFar = route;
      }
    }
    return { bestAmount: [bestPriceSoFar, idealPriceSoFar], bestPath: bestPathSoFar };
  }

  async createSwap(
    wallet: ChainWallet,
    chainService: ChainService,
    params: CreateSwapParams,
    fromAddress: string,
    toAddress: string
  ): Promise<CreatedSwapBalanced> {
    if (!params.fromSwappable.contract || !params.toSwappable.contract) {
      throw new Error('Must specify from and to token');
    }

    if (this.currentSwapEstimates.bestPath.length < 2) {
      throw new Error('LP does not exist for this swap');
    }

    const route = this.currentSwapEstimates.bestPath.slice(1);

    // todo: pass slippage as params
    const minReceive = params.estimate.amount
      .multipliedBy(Math.pow(10, params.toToken.decimals))
      .multipliedBy(1 - BALANCED_SWAP_SLIPPAGE)
      .decimalPlaces(0, 1);

    const swapAmtInWei = params.amount
      .multipliedBy(Math.pow(10, params.fromToken.decimals))
      .toFixed(0);

    let txParams;
    if (params.fromSwappable.isNative) {
      txParams = {
        to: this.config.HANA_WALLET_ROUTER,
        from: fromAddress,
        nid: Web3.utils.toHex(this.config.NETWORK_ID),
        timestamp: Web3.utils.toHex(Date.now() * 1000),
        version: '0x3',
        dataType: 'call',
        value: Web3.utils.toHex(swapAmtInWei),
        data: {
          method: 'route',
          params: {
            minReceive: minReceive.toFixed(0),
            path: route,
          },
        },
      };
    } else {
      txParams = {
        to: params.fromToken.contract,
        from: fromAddress,
        nid: Web3.utils.toHex(this.config.NETWORK_ID),
        timestamp: Web3.utils.toHex(Date.now() * 1000),
        version: '0x3',
        dataType: 'call',
        value: '0x0',
        data: {
          method: 'transfer',
          params: {
            _to: this.config.HANA_WALLET_ROUTER,
            _value: Web3.utils.toHex(swapAmtInWei),
            _data: Web3.utils.toHex(
              JSON.stringify({
                method: '_swap',
                params: {
                  toToken: route[route.length - 1],
                  minimumReceive: minReceive.toFixed(0),
                  // ICX contract is represented as null in route array
                  path: route.map((tokenAddress) =>
                    tokenAddress === ICX_CONTRACT ? null : tokenAddress
                  ),
                },
              })
            ),
          },
        },
      };
    }

    return {
      txObj: {
        jsonrpc: '2.0',
        method: 'icx_sendTransaction',
        params: txParams,
        id: 414231,
      },
      txOptions: {},
    };
  }

  async completeSwap(
    wallet: ChainWallet,
    chainService: ChainService,
    params: CreateSwapParams,
    fromAddress: string,
    toAddress: string,
    swap: CreatedSwapBalanced,
    options: TransactionOptions = {}
  ): Promise<Transaction | RawTxResponse> {
    // send transaction
    const response = await chainService.rpcTransaction(wallet, swap.txObj, swap.txOptions);

    if (options.getRawTx) {
      return response as RawTxResponse;
    }

    if (!isNil(response.error)) throw new Error(response.error);
    const txHash = response.result;

    // Change to swap transaction
    const transaction = {} as Transaction;
    transaction.type = TransactionType.TokenSwap;
    transaction.provider = SwapServiceProvider.BalancedNetwork;
    transaction.hash = txHash;
    transaction.nonce = undefined;
    transaction.title = `${params.fromToken.symbol} → ${params.toToken.symbol}`;
    transaction.to = swap.txObj?.params?.to;
    transaction.rawTx = undefined;
    transaction.chainID = wallet.type;
    transaction.amount = params.amount;

    transaction.fromChainId = params.fromToken.chainId;
    transaction.fromTokenContract = params.fromToken.contract;
    transaction.fromTokenAssetId = params.fromToken.assetId;
    transaction.fromTokenSymbol = params.fromToken.symbol;
    transaction.fromToken = params.fromToken;
    transaction.fromAmount = params.amount;

    transaction.toChainId = params.toToken.chainId;
    transaction.toTokenContract = params.toToken.contract;
    transaction.toTokenAssetId = params.toToken.assetId;
    transaction.toTokenSymbol = params.toToken.symbol;
    transaction.toTokenDecimal = params.toToken.decimals;
    transaction.toToken = params.toToken;
    transaction.toAmount = params.estimate.amount;

    transaction.speedEstimate = params.estimate.speed;

    transaction.transactionUrl = `${
      mainnets[ChainID.ICON]?.blockExplorerUrl
    }/transaction/${txHash}`;

    transaction.statusLabel = 'Finished'; // since this is an instance transacition
    transaction.from = swap.txObj?.params?.from;
    transaction.tokenSymbol = params.fromToken.symbol;
    transaction.fee = new BigNumber(
      params.fromSwappable.isNative || params.toSwappable.isNative
        ? BALANCED_ICX_SWAP_FEE
        : BALANCED_GENERAL_SWAP_FEE
    );
    // decrease timestamp so that the swap appears after token transfer tx
    transaction.date = new Date(Date.now() - 2000);

    return transaction;
  }

  async getSwapStatus(
    swap: Transaction,
    chainService: ICONChainService
  ): Promise<GetStatusResponse> {
    let txStatus = SwapStatus.Pending;
    let receiveAmount = new BigNumber(0);
    let fee;

    try {
      const txResult = await chainService.waitForTransaction(swap.hash);
      txStatus = SwapStatus.Success;
      receiveAmount = this.getReceivedAmount(txResult, swap.from!).div(
        swap.toTokenDecimal ? TEN.pow(swap.toTokenDecimal) : 1
      );
      fee = txResult.cumulativeStepUsed.times(txResult.stepPrice).div(TEN.pow(18));
    } catch (error: any) {
      if (error?.message?.toLowerCase().includes('failed')) {
        txStatus = SwapStatus.Failed;
      }
    }

    return {
      status: txStatus,
      fee,
      receiveAmount,
      label: 'finished',
    };
  }

  private getReceivedAmount(txResult: TransactionResult, sender: string): BigNumber {
    if (!isArray(txResult.eventLogs)) throw new Error("Couldn't parse event logs");
    // get receipt of this transaction
    const eventOfInterest = txResult.eventLogs.find(
      (ev) => isArray(ev?.indexed) && ev.indexed[2] === sender
    );

    return new BigNumber(eventOfInterest.indexed[3]);
  }
}
