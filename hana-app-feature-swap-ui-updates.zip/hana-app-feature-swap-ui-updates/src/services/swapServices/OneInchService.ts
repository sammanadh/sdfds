import type {
  ChainService,
  RpcTransactionResponse,
  EvmChainService,
  TransactionOptions,
} from '@/models/ChainService';
import { TransactionConfig } from 'web3-core';
import {
  CreateSwapParams,
  CreatedSwapOneInch,
  GetEstimateResponse,
  GetStatusResponse,
  SwapService,
  SwapServiceProvider,
  SwapStatus,
  SwappableToken,
  ONE_INCH_API_BASE_URL,
  ONE_INCH_API_VERSION,
  ONE_INCH_TX_TYPE,
  EstimateResponse,
  OneInchTokenResponse,
  ONE_INCH_SUPPORTED_CHAINS,
} from '@/models/SwapService';
import { Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet } from '@/models/Vault';
import { EthereumNetworkDetails, evmMainnets } from '@/utils/networks';
import BigNumber from 'bignumber.js';
import { isEmpty } from 'lodash-es';
import { TEN } from '@/utils/constants';
import { wait } from '@/utils/wait';
import { ONE_INCH_API_KEY } from 'dotenv';

export class OneInchService implements SwapService {
  provider = SwapServiceProvider.OneInch;
  private supportedTokens: Array<SwappableToken & { decimals: number }> = [];
  private fetchedChainIds: Set<number> = new Set();

  private apiRequestWithAuth(url: string) {
    return fetch(url, { headers: { Authorization: `Bearer ${ONE_INCH_API_KEY}` } }).then((res) => {
      if (!res.ok) {
        return res.text().then((text) => {
          throw new Error(text);
        });
      }
      return res;
    });
  }

  async getTokens(
    networkDetailsArray: EthereumNetworkDetails[]
  ): Promise<typeof this.supportedTokens> {
    for (const networkDetails of networkDetailsArray) {
      if (
        this.fetchedChainIds.has(networkDetails.chainId) ||
        !ONE_INCH_SUPPORTED_CHAINS.includes(networkDetails.chainType)
      ) {
        continue;
      }

      const tokenFetchUrl =
        ONE_INCH_API_BASE_URL + `/token/${ONE_INCH_API_VERSION.TOKEN}/${networkDetails.chainId}`;
      try {
        const result = await this.apiRequestWithAuth(tokenFetchUrl);
        const resultJson: OneInchTokenResponse = await result.json();

        const newTokensList = Object.values(resultJson).map((tokenDetails) => {
          return {
            providers: [this.provider],
            providerId: tokenDetails.symbol,
            chainId: networkDetails.chainType,
            isNative: tokenDetails.tags.includes('native'),
            contract: tokenDetails.address.toLowerCase(),
            decimals: tokenDetails.decimals,
          };
        });

        this.fetchedChainIds.add(networkDetails.chainId);
        if (
          !this.supportedTokens.some(
            (x) =>
              x.providerId === newTokensList[0].providerId && x.chainId === newTokensList[0].chainId
          )
        ) {
          this.supportedTokens = [...this.supportedTokens, ...newTokensList];
        }
      } catch (e: any) {
        console.warn(e);
      }
    }

    return [...this.supportedTokens];
  }

  getPossibleSwaps(from: SwappableToken): SwappableToken[] {
    if (!from.providers.includes(SwapServiceProvider.OneInch)) return [];
    return this.supportedTokens.filter(
      (token) => token.contract !== from.contract && token.chainId === from.chainId
    );
  }

  async getMinAmount(from: SwappableToken, to: SwappableToken): Promise<BigNumber> {
    // imitate api call time
    await wait(300);
    return new BigNumber(0.001);
  }

  async getEstimate(
    from: SwappableToken,
    to: SwappableToken,
    amount: BigNumber,
    toAddress: string,
    chainWallet: ChainWallet
  ): Promise<GetEstimateResponse> {
    if (from.chainId !== to.chainId) {
      console.warn('OneInch can only swap tokens from same chain');
      throw new Error('Cannot swap tokens from different chains');
    }

    const fromToken = this.supportedTokens.find(
      (t) => t.contract?.toLowerCase() === from.contract?.toLowerCase()
    );
    const toToken = this.supportedTokens.find(
      (t) => t.contract?.toLowerCase() === to.contract?.toLowerCase()
    );

    const networkDetails = evmMainnets.find(
      (network) => network.chainType === from.chainId
    ) as EthereumNetworkDetails;

    const urlQueryStrings = new URLSearchParams({
      src: from.contract!,
      dst: to.contract!,
      amount: amount.times(TEN.pow(fromToken!.decimals)).toFixed(0),
    });

    const url =
      ONE_INCH_API_BASE_URL +
      `/swap/${ONE_INCH_API_VERSION.SWAP}/${networkDetails?.chainId}/quote` +
      `?${urlQueryStrings}`;

    // avoid rate limiting
    await wait(1000);
    const response = await this.apiRequestWithAuth(url);
    const data = await response.json();

    if (!isEmpty(data.error)) {
      throw new Error(data.message ?? data.error);
    }

    const value = data as EstimateResponse;

    return {
      amount: new BigNumber(value.toAmount).div(TEN.pow(toToken!.decimals)),
      // todo
      speed: { min: 0, max: 1 },
    };
  }

  private async checkAllowance(
    tokenAddress: string,
    walletAddress: string,
    chainId: number
  ): Promise<BigNumber> {
    const urlQueryStrings = new URLSearchParams({
      tokenAddress,
      walletAddress,
    });
    return this.apiRequestWithAuth(
      ONE_INCH_API_BASE_URL +
        `/swap/${ONE_INCH_API_VERSION.SWAP}/${chainId}/approve/allowance` +
        `?${urlQueryStrings.toString()}`
    )
      .then((res) => res.json())
      .then((res) => new BigNumber(res.allowance));
  }

  private async buildApprovalTxn(
    tokenAddress: string,
    approvalAmt: BigNumber,
    walletAddress: string,
    chainId: number
  ): Promise<TransactionConfig> {
    const urlQueryStrings = new URLSearchParams({
      tokenAddress,
      amount: approvalAmt.toFixed(0),
    });
    const url =
      ONE_INCH_API_BASE_URL +
      `/swap/${ONE_INCH_API_VERSION.SWAP}/${chainId}/approve/transaction` +
      `?${urlQueryStrings.toString()}`;

    return this.apiRequestWithAuth(url)
      .then((res) => res.json())
      .then((res) => ({ ...res, from: walletAddress }));
  }

  async createSwap(
    wallet: ChainWallet,
    chainService: ChainService,
    params: CreateSwapParams,
    fromAddress: string,
    toAddress: string,
    slippage: BigNumber
  ): Promise<CreatedSwapOneInch> {
    const networkDetails = evmMainnets.find(
      (network) => network.chainType === params.fromSwappable.chainId
    ) as EthereumNetworkDetails;

    // check allowance
    await wait(1000); // avoid rate limiting
    const allowance = await this.checkAllowance(
      this.supportedTokens.find(
        (t) => t.providerId === params.fromToken.symbol && t.chainId === params.fromToken.chainId
      )!.contract!,
      fromAddress,
      networkDetails.chainId
    );

    let createSwapTxn: TransactionConfig | undefined;
    let txnType = ONE_INCH_TX_TYPE.SWAP;

    await wait(1000); // to avoid rate limiting
    if (!allowance.gte(params.amount.times(TEN.pow(params.fromToken.decimals)))) {
      // if no allowance, create transaction for allowance
      createSwapTxn = await this.buildApprovalTxn(
        params.fromSwappable.contract!,
        params.amount.times(TEN.pow(params.fromToken.decimals)),
        fromAddress,
        networkDetails.chainId
      );

      txnType = ONE_INCH_TX_TYPE.APPROVAL;
    } else {
      createSwapTxn = await this.buildSwapTxn(
        params.fromSwappable.contract!,
        params.toSwappable.contract!,
        params.amount.times(TEN.pow(params.fromToken.decimals)),
        fromAddress,
        slippage,
        networkDetails.chainId
      );
    }

    return { txn: createSwapTxn, type: txnType };
  }

  private async buildSwapTxn(
    fromContract: string,
    toContract: string,
    amount: BigNumber,
    walletAddress: string,
    slippage: BigNumber,
    chainId: number
  ): Promise<TransactionConfig> {
    const urlQueryStrings = new URLSearchParams({
      src: fromContract,
      dst: toContract,
      amount: amount.toString(),
      from: walletAddress,
      slippage: new BigNumber(slippage).times(100).toString(),
    });
    const url =
      ONE_INCH_API_BASE_URL +
      `/swap/${ONE_INCH_API_VERSION.SWAP}/${chainId}/swap` +
      `?${urlQueryStrings.toString()}`;

    return this.apiRequestWithAuth(url)
      .then(async (res) => {
        return res.json();
      })
      .then((data) => data.tx);
  }

  async completeSwap(
    wallet: ChainWallet,
    chainService: ChainService,
    params: CreateSwapParams,
    fromAddress: string,
    toAddress: string,
    swap: CreatedSwapOneInch,
    options: TransactionOptions = {},
    slippage: BigNumber
  ) {
    let txnResponse: RpcTransactionResponse;
    let txnObject = swap.txn;

    const networkDetails = evmMainnets.find(
      (network) => network.chainType === params.fromSwappable.chainId
    ) as EthereumNetworkDetails;

    // sign and send approval/swap txn
    try {
      const approveTxnForChainService = {
        method: 'eth_sendTransaction',
        params: [{ ...swap.txn }],
      };

      txnResponse = (await chainService.rpcTransaction(
        wallet,
        approveTxnForChainService
      )) as RpcTransactionResponse;

      await chainService.waitForTransaction(txnResponse.rpcResponse, 1200);

      if (swap.type === ONE_INCH_TX_TYPE.APPROVAL) {
        await wait(1000); // avoid 1inch API rate limiting
        // build tx for swap
        txnObject = await this.buildSwapTxn(
          params.fromSwappable.contract!,
          params.toSwappable.contract!,
          params.amount.times(TEN.pow(params.fromToken.decimals)),
          fromAddress,
          slippage,
          networkDetails.chainId
        );

        const swapTxnForChainService = {
          method: 'eth_sendTransaction',
          params: [{ ...txnObject }],
        };

        txnResponse = (await chainService.rpcTransaction(
          wallet,
          swapTxnForChainService
        )) as RpcTransactionResponse;
      }

      // Change to swap transaction
      let transaction = {} as Transaction;
      transaction.from = fromAddress;
      transaction.type = TransactionType.TokenSwap;
      transaction.provider = SwapServiceProvider.OneInch;
      transaction.hash = txnResponse.rpcResponse;
      transaction.nonce = undefined;
      transaction.title = `${params.fromToken.symbol} → ${params.toToken.symbol}`;
      transaction.amount = params.amount;
      transaction.tokenSymbol = params.fromToken.symbol;
      transaction.tokenContract = params.fromToken.contract;
      transaction.to = txnObject.to!;
      // transaction.isWithdrawal = true;
      transaction.tokenSymbol = params.fromToken.symbol;
      transaction.rawTx = undefined;
      transaction.toChainId = params.toToken.chainId;
      transaction.toTokenContract = params.toToken.contract;
      transaction.toTokenAssetId = params.toToken.assetId;
      transaction.toTokenSymbol = params.toToken.symbol;
      transaction.toAmount = params.estimate.amount;
      transaction.speedEstimate = params.estimate.speed;
      transaction.date = new Date(Date.now() - 4000);
      transaction.transactionUrl = `${
        evmMainnets.find((net) => net.chainType === params.fromToken.chainId)?.blockExplorerUrl
      }/tx/${txnResponse.rpcResponse}`;
      transaction.statusLabel = 'Waiting';

      return transaction;
    } catch (e: any) {
      console.warn(e);
      throw new Error('Error swapping via 1inch');
    }
  }

  async getSwapStatus(
    swap: Transaction,
    chainService: EvmChainService
  ): Promise<GetStatusResponse> {
    let txStatus = SwapStatus.Pending;
    let receiveAmount = new BigNumber(0);
    let fee;
    try {
      await chainService.waitForTransaction(swap.hash, 1200);
      txStatus = SwapStatus.Success;
    } catch (e: any) {
      console.warn(e);
      txStatus = SwapStatus.Failed;
    }
    // todo: parse tx and return receiveAmt & fee accordingly
    return {
      status: txStatus,
      receiveAmount: swap.toAmount ?? receiveAmount,
    };
  }
}
