import {
  CreatedSwapChangeNow,
  CreateSwapParams,
  GetEstimateResponse,
  SwappableToken,
  SwapService,
  SwapServiceProvider,
} from '@/models/SwapService';
import { ChainID, isIconChain, isSubstrateChain } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import BigNumber from 'bignumber.js';
import { isEmpty } from 'lodash-es';
import { CHANGENOW_API_KEY } from 'dotenv';
import { Transaction, TransactionType } from '@/models/Transaction';
import { ChainWallet, Wallet } from '@/models/Vault';
import { ChainService } from '@/models/ChainService';
import { isEvmChainID } from '@/utils/networks';
import { EthereumService } from '../chainServices/EthereumService';
import IconService from 'icon-sdk-js/build/IconService';
import { ICONService } from '../chainServices/IconService';
import { PolkadotService } from '../chainServices/PolkadotService';
import { NearService } from '../chainServices/NearService';
import { GetStatusResponse, SwapStatus } from '@/models/SwapService';
import { capitalize } from 'lodash';

const API_BASE = 'https://api.changenow.io';
const API_KEY = CHANGENOW_API_KEY;

export class ChangeNowService implements SwapService {
  provider = SwapServiceProvider.ChangeNow;

  async getTokens(): Promise<Array<SwappableToken>> {
    return supportedTokens;
  }

  async getMinAmount(from: SwappableToken, to: SwappableToken): Promise<BigNumber> {
    const pair = `${from.providerId}_${to.providerId}`;
    const url = `${API_BASE}/v1/min-amount/${pair}?api_key=${API_KEY}`;
    const response = await fetch(url);
    const data = await response.json();
    if (!isEmpty(data.error)) {
      throw new Error(data.message ?? data.error);
    }

    return new BigNumber((data as MinAmountResponse).minAmount);
  }

  async getEstimate(
    from: SwappableToken,
    to: SwappableToken,
    amount: BigNumber
  ): Promise<GetEstimateResponse> {
    const pair = `${from.providerId}_${to.providerId}`;
    const url = `${API_BASE}/v1/exchange-amount/${amount.toFixed()}/${pair}?api_key=${API_KEY}`;

    const response = await fetch(url);
    const data = await response.json();
    if (!isEmpty(data.error)) {
      throw new Error(data.message ?? data.error);
    }

    const value = data as EstimateResponse;
    const [minSpeed, maxSpeed] = value.transactionSpeedForecast.split('-');
    return {
      amount: new BigNumber(value.estimatedAmount),
      speed: { min: Number(minSpeed), max: Number(maxSpeed) },
      message: value.warningMessage ?? undefined,
    };
  }

  getPossibleSwaps(from: SwappableToken): SwappableToken[] {
    return supportedTokens.filter((swappable) => {
      // Must use same swap provider
      if (!from.providers.includes(SwapServiceProvider.ChangeNow)) return false;
      // Exclude the chosen from swappable
      return !(
        swappable.chainId === from.chainId &&
        ((swappable.isNative && from.isNative) ||
          (!swappable.isNative &&
            !from.isNative &&
            swappable.contract?.toLowerCase() === from.contract?.toLowerCase()))
      );
    });
  }

  async createSwap(
    chainWallet: ChainWallet,
    chainService: ChainService,
    params: CreateSwapParams,
    fromAddress: string,
    toAddress: string
  ): Promise<CreatedSwapChangeNow> {
    const swapUrl = `${API_BASE}/v1/transactions/${API_KEY}`;

    const body = {
      from: params.fromSwappable.providerId,
      to: params.toSwappable.providerId,
      amount: params.amount.toFixed(),
      address: toAddress,
      refundAddress: fromAddress,
    };

    // Create the swap on the ChangeNOW API
    const swapResponse = await fetch(swapUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    const swapData = await swapResponse.json();

    if (!isEmpty(swapData.error)) {
      throw new Error(swapData.message ?? swapData.error);
    }

    const swap = swapData as CreateSwapResponse;

    // Confirm the swap status on the ChangeNOW API
    const statusUrl = `${API_BASE}/v1/transactions/${swap.id}/${API_KEY}`;
    const statusResponse = await fetch(statusUrl);
    const statusData = await statusResponse.json();
    if (!isEmpty(statusData.error)) {
      throw new Error(statusData.message ?? statusData.error);
    }

    const status = statusData as SwapStatusResponse;

    if (status.status !== 'waiting' || status.payinAddress !== swap.payinAddress) {
      throw new Error(`Failed confirming swap status.`);
    }

    return swap;
  }

  async completeSwap(
    chainWallet: ChainWallet,
    chainService: ChainService,
    params: CreateSwapParams,
    fromAddress: string,
    toAddress: string,
    swap: CreatedSwapChangeNow
  ) {
    // Transfer to the provided pay-in address
    const { fromSwappable, fromToken, amount } = params;

    let transaction;

    if (fromSwappable.isNative) {
      transaction = await chainService.sendNativeToken(chainWallet, swap.payinAddress, amount);
    } else if (fromSwappable.chainId === ChainID.Ethereum || isEvmChainID(fromSwappable.chainId)) {
      transaction = await (chainService as EthereumService).sendToken(
        chainWallet,
        fromToken,
        swap.payinAddress,
        amount
      );
    } else if (isIconChain(fromSwappable.chainId)) {
      transaction = await (chainService as ICONService).sendToken(
        chainWallet,
        fromToken,
        swap.payinAddress,
        amount
      );
    } else if (isSubstrateChain(fromSwappable.chainId)) {
      transaction = await (chainService as PolkadotService).sendAsset(
        chainWallet,
        fromToken,
        swap.payinAddress,
        amount
      );
    } else if (fromSwappable.chainId === ChainID.NEAR) {
      transaction = await (chainService as NearService).sendToken(
        chainWallet,
        fromToken,
        swap.payinAddress,
        amount
      );
    }

    if (!transaction) {
      throw new Error(`Failed to create swap transaction.`);
    }

    if ((transaction as Transaction).type) {
      // Change to swap transaction
      let swapTransaction = transaction as Transaction;

      swapTransaction.type = TransactionType.TokenSwap;
      swapTransaction.provider = SwapServiceProvider.ChangeNow;
      swapTransaction.hash = swap.id;
      swapTransaction.nonce = undefined;
      swapTransaction.title = `${params.fromToken.symbol} → ${params.toToken.symbol}`;
      swapTransaction.to = toAddress;
      // swapTransaction.isDeposit = true;
      swapTransaction.rawTx = undefined;

      swapTransaction.fromChainId = params.fromToken.chainId;
      swapTransaction.fromTokenContract = params.fromToken.contract;
      swapTransaction.fromTokenAssetId = params.fromToken.assetId;
      swapTransaction.fromTokenSymbol = params.fromToken.symbol;
      swapTransaction.fromAmount = params.amount;

      swapTransaction.toChainId = params.toToken.chainId;
      swapTransaction.toTokenContract = params.toToken.contract;
      swapTransaction.toTokenAssetId = params.toToken.assetId;
      swapTransaction.toTokenSymbol = params.toToken.symbol;
      swapTransaction.toAmount = params.estimate.amount;
      swapTransaction.speedEstimate = params.estimate.speed;

      swapTransaction.transactionUrl = `https://changenow.io/exchange/txs/${swap.id}`;
      swapTransaction.statusLabel = 'Waiting';

      return swapTransaction;
    } else {
      throw new Error(`Failed to create swap transaction.`);
    }
  }

  async getSwapStatus(swap: Transaction): Promise<GetStatusResponse> {
    const url = `${API_BASE}/v1/transactions/${swap.hash}/${API_KEY}`;
    const response = await fetch(url);
    const data = await response.json();
    if (!isEmpty(data.error)) {
      throw new Error(data.message ?? data.error);
    }

    const value = data as SwapStatusResponse;
    return {
      status:
        value.status === 'finished'
          ? SwapStatus.Success
          : value.status === 'failed'
          ? SwapStatus.Failed
          : SwapStatus.Pending,
      label: capitalize(value.status),
      receiveAmount: new BigNumber(value.amountReceive || value.expectedReceiveAmount),
    };
  }
}

const supportedTokens: Array<SwappableToken> = [
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'icx',
    chainId: ChainID.ICON,
    isNative: true,
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'eth',
    chainId: ChainID.Ethereum,
    isNative: true,
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'usdterc20',
    chainId: ChainID.Ethereum,
    isNative: false,
    contract: '0xdAC17F958D2ee523a2206206994597C13D831ec7', // USDT
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'usdc',
    chainId: ChainID.Ethereum,
    isNative: false,
    contract: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', // USDC
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'busd',
    chainId: ChainID.Ethereum,
    isNative: false,
    contract: '0x4Fabb145d64652a948d72533023f6E7A623C7C53', // BUSD
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'bnbbsc',
    chainId: ChainID.Binance,
    isNative: true,
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'usdtbsc',
    chainId: ChainID.Binance,
    isNative: false,
    contract: '0x55d398326f99059fF775485246999027B3197955', // USDT
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'usdcbsc',
    chainId: ChainID.Binance,
    isNative: false,
    contract: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', // USDC
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'busdbsc',
    chainId: ChainID.Binance,
    isNative: false,
    contract: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56', // BUSD
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'glmr',
    chainId: ChainID.Moonbeam,
    isNative: true,
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'movr',
    chainId: ChainID.Moonriver,
    isNative: true,
  },
  {
    providers: [SwapServiceProvider.ChangeNow],
    providerId: 'shib',
    chainId: ChainID.Ethereum,
    isNative: false,
    contract: '0x95aD61b0a150d79219dCF64E1E6Cc01f0B64C4cE',
  },
];

interface MinAmountResponse {
  minAmount: number;
}

interface EstimateResponse {
  estimatedAmount: number;
  transactionSpeedForecast: string;
  warningMessage: string | null;
}

interface CreateSwapResponse {
  id: string;
  payinAddress: string;
  payoutAddress: string;
  fromCurrency: string;
  toCurrency: string;
  amount: number;
  refundAddress: string;
}

type SwapStatusStatus =
  | 'new'
  | 'waiting'
  | 'confirming'
  | 'exchanging'
  | 'sending'
  | 'finished'
  | 'failed'
  | 'refunded'
  | 'verifying';

interface SwapStatusResponse {
  id: string;
  status: SwapStatusStatus;
  payinAddress: string;
  payoutAddress: string;
  fromCurrency: string;
  toCurrency: string;
  expectedSendAmount: number;
  expectedReceiveAmount: number;
  amountSend: number;
  amountReceive: number;
  isPartner: boolean;
  createdAt: string;
  updatedAt: string;
}

interface ErrorResponse {
  error: string;
  message?: string;
}
