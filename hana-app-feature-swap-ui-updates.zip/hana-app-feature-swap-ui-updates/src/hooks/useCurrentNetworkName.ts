import type { CustomNetwork } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { networkDetailsForTestnet, TestnetConfig } from '@/utils/networks';
import { isNil } from 'lodash-es';

export const MAINNET = 'Mainnet';

export function useCurrentNetworkName() {
  const { otherNetwork } = useChainServices();
  if (!isNil(otherNetwork)) {
    if ((otherNetwork as TestnetConfig)?.chainType) {
      const testnet = otherNetwork as TestnetConfig;
      const networkDetails = networkDetailsForTestnet(testnet);
      return networkDetails?.shortName ?? MAINNET;
    }

    if ((otherNetwork as CustomNetwork)?.id) {
      const customNetwork = otherNetwork as CustomNetwork;
      return customNetwork.name ?? MAINNET;
    }
  }

  return MAINNET;
}
