import JailMonkey from 'jail-monkey';
import { useEffect, useMemo, useState } from 'react';
import DeviceInfo from 'react-native-device-info';

export function useEnvironment() {
  const isJailBroken = useMemo(() => JailMonkey.isJailBroken(), []);

  const [isReady, setIsReady] = useState(false);
  const [isEmulator, setIsEmulator] = useState(false);
  useEffect(() => {
    DeviceInfo.isEmulator().then((isEmulator) => {
      setIsEmulator(isEmulator);
      setIsReady(true);
    });
  }, []);

  const environment = useMemo(
    () => ({ isJailBroken, isEmulator, isReady }),
    [isJailBroken, isEmulator, isReady]
  );
  return environment;
}
