import { SwapServiceProvider } from '@/models/SwapService';
import { Token } from '@/models/Vault';
import { useChainServices } from '@/stores/ChainServices';
import { useSwapServices } from '@/stores/SwapServices';
import { useVault } from '@/stores/Vault';
import { BigNumber } from '@/utils/bignumber';
import { ChainID, chains } from '@/utils/chains';
import { ZERO } from '@/utils/constants';
import {
  getValueForNativeTokensInChainWallet,
  getValueForTokensInChainWallet,
} from '@/utils/price';
import { isCustomNetwork } from '@/utils/types';
import { isTestnetConfig } from '@/utils/types';
import { chainWalletForChain, tokensForChainWallet } from '@/utils/wallet';
import { isEmpty, isNil } from 'lodash-es';
import { useMemo } from 'react';

export interface TokenWithBalance {
  chainId: ChainID;
  native: boolean;
  contract?: string;
  assetId?: string;
  name: string;
  symbol: string;
  decimals: number;
  logoUrl?: string;
  balance: BigNumber;
  usdBalance?: BigNumber;
}

interface Options {
  filterByValue?: boolean | 'contractTokens';
  // filterBySwappableProvider?: SwapServiceProvider;
  filterBySwappable?: boolean;
  filterByChainIds?: Array<ChainID>;
  filterByActiveChains?: boolean;
}

export function useTokens(options: Options = {}) {
  const { getActiveChainWallets, getActiveWallet } = useVault();
  const { connectedChains, otherNetwork } = useChainServices.getState();
  const allChainTokenContracts = getActiveChainWallets().flatMap((chainWallet) => {
    const chainTokens = tokensForChainWallet(chainWallet);
    return chainTokens.map((token) => token.contract!);
  });

  const swappableTokens = useSwapServices.getState().getAllSwappableTokens();

  const tokens = useMemo(() => {
    let tokens: Array<TokenWithBalance> = [];
    let activeChainWallets = getActiveChainWallets();

    if (options.filterByChainIds) {
      activeChainWallets = activeChainWallets.filter((chainWallet) =>
        options.filterByChainIds?.includes(chainWallet.type)
      );
    }

    let chainsToUse = chains;

    if (options.filterByActiveChains) {
      if (otherNetwork) {
        if (isTestnetConfig(otherNetwork)) {
          chainsToUse = chains.filter((chain) => chain.id === otherNetwork.chainType);
        }

        if (isCustomNetwork(otherNetwork)) {
          chainsToUse = chains.filter((chain) => chain.id === otherNetwork.chain);
        }
      } else {
        chainsToUse = connectedChains;
      }
    }

    for (let i = 0, n = chainsToUse.length; i < n; i++) {
      const chainWallet = chainWalletForChain(chainsToUse[i].id);
      const chain = chainsToUse[i];
      if (isNil(chain)) continue;

      // Native tokens
      const balance = new BigNumber(chainWallet?.balance ?? 0);

      const filterBySwappable =
        !options.filterBySwappable ||
        swappableTokens.some((swappable) => swappable.chainId === chain.id && swappable.isNative);
      const filterByValue = !options.filterByValue || balance.gt(0);

      if (filterBySwappable && filterByValue) {
        tokens.push({
          chainId: chain.id,
          native: true,
          name: chain.token.name ?? chain.name,
          symbol: chain.token.symbol,
          decimals: chain.token.decimals,
          balance,
          usdBalance: chainWallet ? getValueForNativeTokensInChainWallet(chainWallet) : ZERO,
        });
      }

      // Contract tokens
      if (chainWallet) {
        const chainTokens = tokensForChainWallet(chainWallet);
        for (let j = 0, m = chainTokens.length; j < m; j++) {
          const token = chainTokens[j];
          const balance = new BigNumber(
            token.balances.find((balance) => balance.address === chainWallet.address)?.balance ?? 0
          );
          const filterBySwappable =
            !options.filterBySwappable ||
            swappableTokens.some(
              (swappable) =>
                swappable.chainId === chain.id &&
                !swappable.isNative &&
                (swappable.contract?.toLowerCase() === token.contract?.toLowerCase() ||
                  swappable.contract === String(token.assetId))
            );
          const filterByValue = !options.filterByValue || balance.gt(0);

          if (filterBySwappable && filterByValue) {
            tokens.push({
              chainId: chain.id,
              native: false,
              contract: token.contract,
              assetId: token.assetId,
              name: token.name,
              symbol: token.symbol,
              decimals: token.decimals,
              logoUrl: token.logoUrl,
              balance,
              usdBalance: getValueForTokensInChainWallet(chainWallet, token),
            });
          }
        }
      }
    }

    // if (!isNil(options.filterBySwappableProvider)) {
    //   const swappableTokens = useSwapServices
    //     .getState()
    //     .swappableTokensForProvider(options.filterBySwappableProvider);

    //   tokens = tokens.filter((token) => {
    //     if (token.native) {
    //       return swappableTokens.some(
    //         (swappable) => swappable.chainId === token.chainId && swappable.isNative
    //       );
    //     }

    //     return swappableTokens.some(
    //       (swappable) =>
    //         swappable.chainId === token.chainId &&
    //         !swappable.isNative &&
    //         swappable.contract === token.contract
    //     );
    //   });
    // }

    return tokens;
  }, [getActiveWallet()?.id, connectedChains, otherNetwork, allChainTokenContracts]);

  const sortedTokens = useMemo(() => tokens?.sort(sortTokensByValue) || [], [tokens]);

  return sortedTokens;
}

function sortTokensByValue(a: TokenWithBalance, b: TokenWithBalance) {
  const aUsdBalance = a.usdBalance ?? ZERO;
  const bUsdBalance = b.usdBalance ?? ZERO;
  if (aUsdBalance.gt(bUsdBalance)) return -1;
  if (aUsdBalance.lt(bUsdBalance)) return 1;

  if (a.balance.gt(b.balance)) return -1;
  if (a.balance.lt(b.balance)) return 1;

  return 0;
}
