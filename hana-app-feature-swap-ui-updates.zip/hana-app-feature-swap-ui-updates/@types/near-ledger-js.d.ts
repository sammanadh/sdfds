declare module 'near-ledger-js' {
  import type Transport from '@ledgerhq/hw-transport';

  export function createClient(transport: Transport): Client;

  export function getSupportedTransport(): Promise<Transport>;

  export interface Client {
    getPublicKey(path: string): Promise<Buffer>;

    getVersion(): Promise<string>;

    sign(data: any, path: string): Promise<Buffer>;
  }
}
