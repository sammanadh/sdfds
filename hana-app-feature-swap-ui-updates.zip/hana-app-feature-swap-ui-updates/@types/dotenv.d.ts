declare module 'dotenv' {
  export const INFURA_PROJECT_ID: string;
  export const ETHERSCAN_API_KEY: string;
  export const MOONSCAN_MOONRIVER_API_KEY: string;
  export const MOONSCAN_MOONBEAM_API_KEY: string;
  export const ONFINALITY_API_KEY: string;
  export const BSCSCAN_API_KEY: string;
  export const AGGREGATION_GRAPHQL_API: string;
  export const CHANGENOW_API_KEY: string;
  export const OPTIMISM_API_KEY: string;
  export const AVALANCHE_API_KEY: string;
  export const POLYGON_API_KEY: string;
  export const ONE_INCH_API_KEY: string;
}
