declare module 'rn-content-loader' {
  import type { FunctionComponent, ReactNode } from 'react';
  const RNContentLoader: FunctionComponent<{
    width?: number | string;
    height?: number | string;
    primaryColor?: string;
    secondaryColor?: string;
    children: ReactNode;
  }>;
  export default RNContentLoader;
}
