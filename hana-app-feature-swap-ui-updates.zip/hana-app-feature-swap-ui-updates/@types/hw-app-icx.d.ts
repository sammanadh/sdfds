declare module '@ledgerhq/hw-app-icx' {
  import type Transport from '@ledgerhq/hw-transport';

  export default class AppIcx {
    transport: Transport;

    /**
     * ICON API
     *
     * @example
     * import Icx from "@ledgerhq/hw-app-icx";
     * const icx = new Icx(transport)
     */
    constructor(transport: Transport);

    /**
     * Returns the public key and ICON address for a given BIP 32 path.
     *
     * @param path a path in BIP 32 format
     * @param display enable or not the display
     * @param chaincode enable or not the chaincode request
     * @return an object with a publickey(hexa string), address(string) and (optionally) chainCode(hexa string)
     *
     * @example
     * icx.getAddress("44'/4801368'/0'", true, true).then(o => o.address)
     */
    getAddress(
      path: string,
      display?: boolean,
      chaincode?: boolean
    ): Promise<{ address: Uint8Array; publicKey: string; chainCode: string }>;

    /**
     * Signs a transaction and returns signed message given the raw transaction and the BIP 32 path of the account to sign
     *
     * @param path a path in BIP 32 format
     * @param rawTxAscii raw transaction data to sign in ASCII string format
     * @return an object with a base64 encoded signature and hash in hexa string
     *
     * @example
     * icx.signTransaction(
     *   "44'/4801368'/0'",
     *   "icx_sendTransaction.fee.0x2386f26fc10000.from.hxc9ecad30b05a0650a337452fce031e0c60eacc3a.nonce.0x3.to.hx4c5101add2caa6a920420cf951f7dd7c7df6ca24.value.0xde0b6b3a7640000"
     * ).then(result => ...)
     */
    signTransaction(
      path: string,
      rawTxAscii: string
    ): Promise<{ signedRawTxBase64: string; hashHex: string }>;

    /**
     * Returns the application configurations such as versions.
     *
     * @return major/minor/patch versions of Icon application
     */
    getAppConfiguration(): Promise<{
      majorVersion: number;
      minorVersion: number;
      patchVersion: number;
    }>;
  }
}
