module.exports = {
  printWidth: 100,
  quoteProps: 'consistent',
  singleQuote: true,
  trailingComma: 'es5',
};
