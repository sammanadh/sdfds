// Import react-native-gesture-handler before anything else -- https://docs.swmansion.com/react-native-gesture-handler/docs/installation
import 'react-native-gesture-handler';
import '@/global';
import './shim';
import App from '@/App';
import { registerRootComponent } from 'expo';
import { LogBox, Platform, UIManager } from 'react-native';

// Disable console statements in production
if (!__DEV__) {
  console.log = function () {};
  console.debug = function () {};
  console.info = function () {};
  console.warn = function () {};
  console.error = function () {};
}

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

LogBox.ignoreLogs([
  `Seems like you're using an old API with gesture components`,
  'RCTBridge required dispatch_sync to load RCTDevLoadingView',
  'Invalid `viewBox` prop:0 0 100% 84',
  'Invalid `viewBox` prop:0 0 100% 90',
  '"false" is not a valid color or "0.48349999999999993" is not a valid offset',
  'Possible Unhandled Promise Rejection',
]);

// registerRootComponent calls AppRegistry.registerComponent('main', () => App);
// It also ensures that whether you load the app in Expo Go or in a native build,
// the environment is set up appropriately
registerRootComponent(App);
